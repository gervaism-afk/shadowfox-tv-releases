package nl.vanvrouwerff.iptv.ui.settings

import android.content.res.Configuration
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.input.key.onPreviewKeyEvent
import android.view.KeyEvent
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.ui.input.Button
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.CinemaChip
import nl.vanvrouwerff.iptv.ui.theme.FocusStyle
import nl.vanvrouwerff.iptv.ui.theme.tvFocus

/** Flat settings controls share one understated focus marker and a bottom divider. */
@Composable
internal fun Modifier.settingsRowDecoration(focused: Boolean, divider: Boolean = true): Modifier {
    val line = Cinema.Line
    val accent = Cinema.Accent
    return drawBehind {
        if (divider) drawLine(line, Offset(20.dp.toPx(), size.height), Offset(size.width, size.height), 1.dp.toPx())
        if (focused) {
            val height = minOf(38.dp.toPx(), size.height - 16.dp.toPx())
            drawRoundRect(accent, Offset(0f, (size.height - height) / 2), Size(3.dp.toPx(), height), CornerRadius(2.dp.toPx()))
        }
    }
}

@Composable
internal fun SettingsOptionSurface(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    divider: Boolean = true, content: @Composable BoxScope.(Boolean) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, enabled = enabled,
        modifier = modifier.onFocusChanged { focused = it.isFocused }.settingsRowDecoration(focused, divider),
        shape = ClickableSurfaceDefaults.shape(RectangleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = Color.Transparent,
            focusedContainerColor = Color.Transparent, pressedContainerColor = Color.Transparent,
            contentColor = Cinema.Text, focusedContentColor = Cinema.Accent)) { content(focused) }
}

@Composable
internal fun SettingsMenuItem(label: String, active: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    SettingsOptionSurface(onClick, modifier.heightIn(min = 48.dp).semantics { selected = active }, divider = false) { focused ->
        Text(label, Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            color = if (active || focused) Cinema.Accent else Cinema.Muted, fontSize = 15.sp,
            fontWeight = if (active || focused) FontWeight.SemiBold else FontWeight.Normal)
    }
}

/** TV uses a fixed section rail beside a bounded, independently scrolling content pane. */
@Composable
internal fun SettingsPage(onBack: () -> Unit, pageKey: Any = Unit, navigation: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    val television = settingsOnTv()
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val scope = rememberCoroutineScope()
    val remote = remember { SettingsRemoteFocus(scope) }.takeIf { television }
    remote?.page = pageKey
    (pageKey as? SettingsCategory)?.let { remote?.selected = it }
    val savedPages = rememberSaveableStateHolder()
    BackHandler { if (remote != null) remote.back(onBack) else onBack() }
    LaunchedEffect(Unit) {
        if (remote != null) { withFrameNanos { }; remote.menu() }
    }
    CompositionLocalProvider(LocalSettingsRemoteFocus provides remote) {
        Column(Modifier.fillMaxSize().background(Cinema.Background).safeDrawingPadding().imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.widthIn(max = 1100.dp).fillMaxWidth().padding(horizontal = if (phone) 16.dp else 32.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Settings", color = Cinema.Text, fontSize = 28.sp,
                        fontWeight = FontWeight.SemiBold, letterSpacing = (-0.7).sp)
                    Text("MOVIES & SERIES", color = Cinema.Accent, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                if (!television) SettingsMenuItem("Back", onClick = onBack)
            }
            val pane: @Composable (Modifier) -> Unit = { modifier ->
                savedPages.SaveableStateProvider(pageKey.toString()) {
                    SettingsViewport(modifier, television, content)
                }
            }
            if (television) {
                Row(Modifier.weight(1f).widthIn(max = 1100.dp).fillMaxWidth()
                    .padding(start = 32.dp, end = 24.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(Modifier.width(if (LocalConfiguration.current.screenWidthDp < 900) 156.dp else 184.dp).fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        navigation()
                        Spacer(Modifier.weight(1f))
                        Text("Right: options\nLeft: sections", color = Cinema.Muted, fontSize = 11.sp, lineHeight = 17.sp)
                        SettingsMenuItem("Back", modifier = Modifier.fillMaxWidth().focusRequester(remote!!.back)
                            .onFocusChanged { if (it.isFocused) remote.region = SettingsRemoteFocus.Region.Back }
                            .onPreviewKeyEvent { event ->
                                if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false else when (event.nativeKeyEvent.keyCode) {
                                    KeyEvent.KEYCODE_DPAD_UP -> { remote.menu(SettingsCategory.entries.last()); true }
                                    KeyEvent.KEYCODE_DPAD_LEFT -> { remote.menu(); true }
                                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                                    else -> false
                                }
                            }, onClick = onBack)
                    }
                    pane(Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Box(Modifier.widthIn(max = 1100.dp).fillMaxWidth().padding(horizontal = if (phone) 16.dp else 48.dp, vertical = 8.dp)) { navigation() }
                pane(Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable
private fun SettingsViewport(modifier: Modifier, television: Boolean, content: @Composable ColumnScope.() -> Unit) {
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val scroll = rememberScrollState()
    Box(modifier.testTag("settings-viewport")) {
        Column(Modifier.align(Alignment.TopCenter).widthIn(max = 1100.dp).fillMaxWidth()
            .verticalScroll(scroll).padding(horizontal = if (television) 8.dp else if (phone) 16.dp else 48.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp), content = content)
        val track = Cinema.Line
        val thumb = Cinema.Accent.copy(alpha = 0.7f)
        Canvas(Modifier.align(Alignment.CenterEnd).padding(end = if (television || phone) 0.dp else 18.dp, top = 8.dp, bottom = 8.dp)
            .fillMaxHeight().width(3.dp)) {
            if (scroll.maxValue > 0) {
                val height = (size.height * size.height / (size.height + scroll.maxValue)).coerceAtLeast(24.dp.toPx()).coerceAtMost(size.height)
                val top = (size.height - height) * scroll.value / scroll.maxValue
                drawRoundRect(track, cornerRadius = CornerRadius(size.width))
                drawRoundRect(thumb, Offset(0f, top), Size(size.width, height), CornerRadius(size.width))
            }
        }
    }
}

/** TV browsing never focuses an editor or opens the IME. OK deliberately opens an editor. */
@Composable
internal fun SettingsAccountField(label: String, value: String, onValueChange: (String) -> Unit,
    password: Boolean = false, modifier: Modifier = Modifier, navigationOrder: Int = 0) {
    val television = LocalConfiguration.current.uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION
    if (!television) {
        OutlinedTextField(value, onValueChange, modifier = modifier.fillMaxWidth(),
            label = { androidx.compose.material3.Text(label) }, singleLine = true,
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Text))
        return
    }
    var editing by remember { mutableStateOf(false) }
    var restoreFocus by remember { mutableStateOf(false) }
    val requester = remember { FocusRequester() }
    LaunchedEffect(editing) {
        if (!editing && restoreFocus) {
            withFrameNanos { }
            requester.requestFocus()
            restoreFocus = false
        }
    }
    SettingsOptionSurface(onClick = { editing = true; restoreFocus = true },
        modifier = modifier.fillMaxWidth().heightIn(min = 88.dp).focusRequester(requester).settingsControl("account:$label", navigationOrder)
    ) { focused ->
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(label, color = if (focused) Cinema.Accent else Cinema.Text, fontSize = 14.sp, lineHeight = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (value.isBlank()) "Not set" else if (password) "•".repeat(value.length.coerceAtMost(12)) else value,
                    color = Cinema.Muted, fontSize = 14.sp, lineHeight = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Edit  ›", Modifier.padding(start = 20.dp), color = if (focused) Cinema.Accent else Cinema.Muted, fontSize = 12.sp)
        }
    }
    if (editing) AccountFieldEditor(label, value, password,
        onConfirm = { onValueChange(it); editing = false }, onDismiss = { editing = false })
}

@Composable
internal fun AccountFieldEditor(label: String, value: String, password: Boolean,
    onConfirm: (String) -> Unit, onDismiss: () -> Unit, keyboardInsets: WindowInsets? = null) {
    // Keep selection alongside the text: the String overload initially places the
    // caret at zero when the TV keyboard opens. Subsequent IME selection updates
    // must remain intact so moving within a long filter does not reset the caret.
    var draft by remember { mutableStateOf(TextFieldValue(value, selection = TextRange(value.length))) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        val keyboard = LocalSoftwareKeyboardController.current
        val editorInsets = keyboardInsets ?: WindowInsets.ime
        val requester = remember { FocusRequester() }
        val view = LocalView.current
        DisposableEffect(view) {
            val window = (view.parent as? DialogWindowProvider)?.window
            val previousMode = window?.attributes?.softInputMode
            // Google TV's IME can overlay a centered wrap-content dialog without resizing it.
            window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            onDispose { if (previousMode != null) window?.setSoftInputMode(previousMode) }
        }
        fun cancel() { keyboard?.hide(); onDismiss() }
        fun confirm() { keyboard?.hide(); onConfirm(draft.text) }
        BackHandler(onBack = ::cancel)
        LaunchedEffect(Unit) { withFrameNanos { }; requester.requestFocus(); keyboard?.show() }
        Box(Modifier.fillMaxSize().windowInsetsPadding(editorInsets).padding(24.dp), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 600.dp).fillMaxWidth().verticalScroll(rememberScrollState())
            .background(Cinema.Surface).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(draft, { draft = it }, modifier = Modifier.fillMaxWidth().focusRequester(requester), singleLine = true,
                visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Text, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { confirm() }))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SettingsMenuItem("Done", onClick = ::confirm)
                SettingsMenuItem("Cancel", onClick = ::cancel)
            }
        }
        }
    }
}

/** Give the final explanatory block a D-pad stop, so the last paragraphs can be read. */
@Composable
internal fun SettingsInformation(navigationKey: String = "information", navigationOrder: Int = 0, content: @Composable ColumnScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().settingsControl(navigationKey, navigationOrder)
        .onFocusChanged { focused = it.isFocused }
        .settingsRowDecoration(focused)
        .focusable().padding(18.dp).testTag("settings-information"),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}
