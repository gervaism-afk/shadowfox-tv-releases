# Movies & Series performance update v0.2.3

Package ca.shadowfoxtv.movieseries. Version code 5. Android 10/API 29 minimum remains unchanged. This release is separate from Platinum Player.

## Changes
- Database schema 18 adds compound indexes on (type, sortIndex) and (type, groupTitle, sortIndex). The 17-to-18 migration creates indexes only; all existing tables, rows, profiles, saved lists and watch progress remain in place.
- Ordinary browsing uses direct indexed queries without inactive search/saved/kids predicates. Search, saved lists and kids profiles retain the protected general query path.
- Page changes replace only the bounded 60-row query. Counts remain subscribed at the filter level. Category grouping is shared by content type. Pagination no longer has the 180 ms search/filter debounce.
- Import converts Channels to database entities in batches of 256 instead of allocating a second complete catalogue-sized entity list. Timestamp preservation and atomic replacement are retained. Category aggregation retains only distinct category keys.
- The Tanix defaults, bounded poster/player caches, updater, package, signing key and final TV icon/banner assets are preserved.

## Validation and limits
The exported Room v17 schema was seeded with 254,000 synthetic movies and series. The actual migration SQL preserves every seeded table. 120 query scenarios cover movie/series, categories, deep pages, literal wildcard searches, profile-scoped saved lists and kids filters. Ordinary page queries no longer create temporary sort trees. See verification/performance-v0.2.3.json. These host SQLite timings are not Tanix timings.

Flow unit tests verify that pagination does not restart count/category work, profile changes replace saved queries, kids categories remain filtered, count changes clamp pages, and failures produce an error state. Final build checks are recorded in verification/release-v0.2.3.json after completion.

No physical Android devices are connected to this workspace. The earlier software-emulator attempt lacked KVM and did not boot within 150 seconds; no Android emulator performance measurement is claimed. Provider transfer speed, poster-server speed and hardware can still affect loading/browsing.

## Installation
Installed v0.2.1/v0.2.2 can download this update through Settings > App updates. v0.2.0 needs one manual updater bootstrap. Install over the existing app without uninstalling. Initial startup may take longer while the two indexes are created for an existing large catalogue. Subsequent browsing uses them automatically.
