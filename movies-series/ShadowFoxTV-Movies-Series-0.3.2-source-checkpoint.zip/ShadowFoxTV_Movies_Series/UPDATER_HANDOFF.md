# ShadowFoxTV Movies & Series v0.2.2

Standalone Android TV Movies & Series app; not Platinum Player.
Package: ca.shadowfoxtv.movieseries. Version code: 4. Minimum Android: 10 (API 29).

v0.2.2 integrates the final Movies & Series Android TV icon pack and the updater, retaining v0.2.0 Tanix stability improvements: bounded/paged library, streaming catalogue import, bounded Room writes, reduced image/player buffers, conservative playback settings, deferred D-pad navigation, and private Java crash capture. Device/provider testing is still required; these changes do not establish that every reported Tanix crash has been fixed.

Installed v0.2.0 needs one manual bootstrap installation over the existing app because it has no updater. Do not uninstall: an update preserves credentials, database and progress. Subsequent updates are checked at launch and under Settings > App updates. Android may request permission to install unknown apps and always confirms installation.

Updater feed: https://raw.githubusercontent.com/gervaism-afk/shadowfox-tv-releases/main/movies-series/update.json
Only this app's package is accepted. Downloads are bounded to 100 MB and verified by exact size, SHA-256, package, higher version code and the installed signing certificate before invoking Android's installer.
The Movies & Series channel is a separate repository folder; no Platinum Player release/latest tag is changed.

Final icon pack input SHA-256: f903c744f68a2937a87d6e045771636d67c11e18eef1d1aec834a3ce5b5788e6.
Only android_tv/res was integrated; strings were merged. Old shadowfox_logo/app_banner files were removed. Launcher uses @mipmap/ic_launcher and @mipmap/ic_launcher_round; banner uses @drawable/tv_banner; internal branding uses @drawable/shadowfox_cutout. Preview/reference art is excluded.

## Building
Use JDK 17, Gradle 8.7, Android SDK 34 and build-tools 34.0.0. Set sdk.dir in local.properties (not included). Run ./gradlew assembleRelease testDebugUnitTest lintDebug lintRelease.
The private project includes signing/preview-debug.keystore to preserve updates. Keep it private.
The public source archive excludes every keystore and local.properties. Without the original key, Gradle uses the normal local debug key; that build cannot update the installed official app. Configure RELEASE_STORE_FILE, RELEASE_STORE_PASSWORD, RELEASE_KEY_ALIAS and RELEASE_KEY_PASSWORD in private local.properties for signing with the original key, or use the privately held preview key.
Official signing SHA-256: c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90.
Source is based on SERFF/iptv-app, Apache 2.0; existing attribution/license files are retained.

Verification for this final build is in verification/release-v0.2.2.json. Older verification files are historical.
