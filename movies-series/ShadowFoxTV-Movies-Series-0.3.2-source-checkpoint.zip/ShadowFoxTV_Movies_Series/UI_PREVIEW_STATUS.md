# ShadowFoxTV Movies & Series 0.3.1 UI preview

Mobile touch fix based on v0.3.0. Touch-capable wrappers now serve Connect, account settings, library cards, details, playback controls, profiles and updater buttons while retaining TV key handlers. Welcome content adapts to narrow windows and the Home navigation can scroll on narrow screens. The Apple TV-inspired Home, previous scoped search histories, playback recovery, branding and Tanix limits remain.

See the published verification-v0.3.1.json for checks and physical-device limits. Private signing keys, local machine settings and build outputs are excluded from the source archive.

The existing launch-time update check now opens a touch/remote-friendly update notice for a newer version. The notice reuses the existing verified download and Android installer flow; Later suppresses that version for the current activity session. The dedicated Movies & Series live feed is promoted with this release.
