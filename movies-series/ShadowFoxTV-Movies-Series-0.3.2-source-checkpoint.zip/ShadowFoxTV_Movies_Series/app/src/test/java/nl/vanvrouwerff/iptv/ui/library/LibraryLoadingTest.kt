package nl.vanvrouwerff.iptv.ui.library

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.*
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LibraryLoadingTest {
    private fun row(id: String) = Channel(id, id, null, null, null, null, ContentType.MOVIE)

    @Test fun categoryStreamSurvivesFailureAndIgnoresPageChanges() = runTest {
        val selection = MutableStateFlow(LibrarySelection())
        val calls = mutableListOf<ContentType>()
        val result = mutableListOf<Pair<ContentType, List<String?>>>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryCategoryFlow(selection) { type ->
                calls.add(type)
                if (type == ContentType.MOVIE) flow { throw IllegalStateException("query failed") }
                else flowOf(listOf("Series"))
            }.collect { result.add(it) }
        }
        runCurrent()
        assertEquals(emptyList<String?>(), result.last().second)
        selection.value = selection.value.copy(page = 2)
        runCurrent()
        assertEquals(1, calls.size)
        selection.value = selection.value.copy(type = ContentType.SERIES, page = 0)
        runCurrent()
        assertEquals(listOf(ContentType.MOVIE, ContentType.SERIES), calls)
        assertEquals(listOf("Series"), result.last().second)
    }

    @Test fun pagingDoesNotRestartCountsOrCategories() = runTest {
        val selection = MutableStateFlow(LibrarySelection())
        val counts = mutableListOf<LibrarySelection>()
        val pages = mutableListOf<LibrarySelection>()
        var categoryCalls = 0
        val states = mutableListOf<LibraryState>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(selection, flowOf("default"), flowOf(false),
                { s, _, _ -> pages.add(s); flowOf(listOf(row("page-${s.page}"))) },
                { s, _, _ -> counts.add(s); flowOf(1000) },
                { categoryCalls++; flowOf(listOf("Films")) }, {}, 0).collect { states.add(it) }
        }
        runCurrent()
        selection.value = selection.value.copy(page = 3)
        runCurrent()
        assertEquals(1, counts.size)
        assertEquals(1, categoryCalls)
        assertEquals(listOf(0, 3), pages.map { it.page })
        assertEquals("page-3", states.last().items.single().id)
        selection.value = selection.value.copy(category = "Films", page = 0)
        runCurrent()
        assertEquals(2, counts.size)
        assertEquals("Films", states.last().selection.category)
    }

    @Test fun searchSavedAndKidsNeverUseUnfilteredFastPath() {
        assertTrue(usesPlainLibraryQuery(LibrarySelection(), false))
        assertTrue(usesPlainLibraryQuery(LibrarySelection(query = "  ", category = "Films"), false))
        assertFalse(usesPlainLibraryQuery(LibrarySelection(query = "100%"), false))
        assertFalse(usesPlainLibraryQuery(LibrarySelection(saved = true), false))
        assertFalse(usesPlainLibraryQuery(LibrarySelection(), true))
    }

    @Test fun profileChangeRestartsSavedQueriesAndKidsFiltersCategories() = runTest {
        val selection = MutableStateFlow(LibrarySelection(saved = true))
        val profile = MutableStateFlow("one")
        val kids = MutableStateFlow(false)
        val requestedProfiles = mutableListOf<String>()
        var state: LibraryState? = null
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(selection, profile, kids,
                { _, p, _ -> requestedProfiles.add(p); flowOf(listOf(row(p))) },
                { _, _, _ -> flowOf(60) },
                { flowOf(listOf("Family", "XXX Adult", null)) }, {}, 0).collect { state = it }
        }
        runCurrent()
        profile.value = "two"
        runCurrent()
        assertEquals(listOf("one", "two"), requestedProfiles)
        assertEquals("two", state!!.items.single().id)
        kids.value = true
        runCurrent()
        assertEquals(listOf("Family"), state!!.categories)
    }

    @Test fun countShrinkClampsPageAndQueryFailureShowsError() = runTest {
        val selection = MutableStateFlow(LibrarySelection(page = 3))
        val counts = MutableStateFlow(1000)
        var clamped = -1
        var state: LibraryState? = null
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(selection, flowOf("default"), flowOf(false),
                { _, _, _ -> flowOf(emptyList()) }, { _, _, _ -> counts },
                { flowOf(emptyList()) }, { clamped = it }, 0).collect { state = it }
        }
        runCurrent()
        counts.value = 60
        runCurrent()
        assertEquals(0, clamped)
        assertFalse(state!!.loading)
        var error: LibraryState? = null
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(MutableStateFlow(LibrarySelection()), flowOf("default"), flowOf(false),
                { _, _, _ -> flow { throw IllegalStateException("fixture failure") } },
                { _, _, _ -> flowOf(60) }, { flowOf(emptyList()) }, {}, 0).collect { error = it }
        }
        runCurrent()
        assertNotNull(error!!.error)
        assertFalse(error!!.loading)
    }
}
