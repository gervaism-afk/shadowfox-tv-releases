package nl.vanvrouwerff.iptv.data.settings

import android.app.Application
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class SearchHistoryTest {
    private val settings = SettingsStore(RuntimeEnvironment.getApplication())
    private val profile = UUID.randomUUID().toString()

    @Test fun moviesSeriesProfilesAndLegacyHistoryStaySeparateWhenCleared() = runBlocking {
        settings.pushRecentSearch(profile, "Batman", ContentType.MOVIE)
        settings.pushRecentSearch(profile, "Chicago", ContentType.SERIES)
        settings.pushRecentSearch(profile, "Legacy")
        settings.pushRecentSearch("other-$profile", "Castle", ContentType.MOVIE)
        assertEquals(listOf("Batman"), settings.recentSearches(profile, ContentType.MOVIE).first())
        assertEquals(listOf("Chicago"), settings.recentSearches(profile, ContentType.SERIES).first())
        settings.clearRecentSearches(profile, ContentType.MOVIE)
        assertTrue(settings.recentSearches(profile, ContentType.MOVIE).first().isEmpty())
        assertEquals(listOf("Chicago"), settings.recentSearches(profile, ContentType.SERIES).first())
        assertEquals(listOf("Legacy"), settings.recentSearches(profile).first())
        assertEquals(listOf("Castle"), settings.recentSearches("other-$profile", ContentType.MOVIE).first())
    }

    @Test fun newestFirstDeduplicatedBoundedAndReadableByAnotherStore() = runBlocking {
        for (i in 1..8) settings.pushRecentSearch(profile, "Movie $i", ContentType.MOVIE)
        settings.pushRecentSearch(profile, "  movie 5  ", ContentType.MOVIE)
        settings.pushRecentSearch(profile, "   ", ContentType.MOVIE)
        val reopened = SettingsStore(RuntimeEnvironment.getApplication())
        assertEquals(listOf("movie 5", "Movie 8", "Movie 7", "Movie 6", "Movie 4", "Movie 3"),
            reopened.recentSearches(profile, ContentType.MOVIE).first())
    }

    @Test fun deletingProfileRemovesSectionHistories() = runBlocking {
        settings.pushRecentSearch(profile, "Batman", ContentType.MOVIE)
        settings.pushRecentSearch(profile, "Chicago", ContentType.SERIES)
        settings.wipeProfilePrefs(profile)
        assertTrue(settings.recentSearches(profile, ContentType.MOVIE).first().isEmpty())
        assertTrue(settings.recentSearches(profile, ContentType.SERIES).first().isEmpty())
    }
}
