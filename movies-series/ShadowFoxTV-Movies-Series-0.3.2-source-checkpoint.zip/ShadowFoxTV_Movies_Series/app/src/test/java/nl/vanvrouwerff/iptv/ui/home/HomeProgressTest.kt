package nl.vanvrouwerff.iptv.ui.home

import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test

class HomeProgressTest {
    private fun entry(id: String, type: ContentType, time: Long) = HomeItem(Channel(id, id, null, null, null, null, type), updatedAt = time)
    @Test fun progressSortsAcrossTypesAndKeepsOnlyLatestEpisodePerSeries() {
        val result = mergeHomeProgress(listOf(entry("movie", ContentType.MOVIE, 20)),
            listOf(entry("series", ContentType.SERIES, 10), entry("series", ContentType.SERIES, 30)))
        assertEquals(listOf("series", "movie"), result.map { it.channel.id })
        assertEquals(30L, result.first().updatedAt)
    }
    @Test fun rowsStayBoundedAndNeverIncludeLiveChannels() {
        val entries = (0..30).map { entry("m$it", ContentType.MOVIE, it.toLong()) } + entry("live", ContentType.TV, 100)
        val result = mergeHomeProgress(entries, emptyList())
        assertEquals(PERSONAL_ROW_LIMIT, result.size)
        assertEquals("m30", result.first().channel.id)
        assertFalse(result.any { it.channel.type == ContentType.TV })
    }
}
