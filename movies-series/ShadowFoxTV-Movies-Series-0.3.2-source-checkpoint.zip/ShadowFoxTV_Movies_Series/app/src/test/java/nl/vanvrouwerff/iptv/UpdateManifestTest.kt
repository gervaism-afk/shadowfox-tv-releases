package nl.vanvrouwerff.iptv

import nl.vanvrouwerff.iptv.updates.*
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test

class UpdateManifestTest {
    private val release = UpdateManifest(UPDATE_PACKAGE, 3, "0.2.1-updater-preview",
        "https://raw.githubusercontent.com/gervaism-afk/shadowfox-tv-releases/main/movies-series/app.apk",
        "a".repeat(64), 1024)
    private fun rejected(m: UpdateManifest) {
        try { validateManifest(m); fail("Manifest must be rejected") } catch (_: IllegalArgumentException) { }
    }
    @Test fun valid() { validateManifest(release) }
    @Test fun newer() { assertTrue(isNewer(release, 2)) }
    @Test fun equalAndOlder() { assertFalse(isNewer(release, 3)); assertFalse(isNewer(release, 4)) }
    @Test fun wrongPackage() { rejected(release.copy(packageName = "other.app")) }
    @Test fun insecureUrl() { rejected(release.copy(apkUrl = release.apkUrl.replace("https:", "http:"))) }
    @Test fun otherHost() { rejected(release.copy(apkUrl = release.apkUrl.replace("raw.githubusercontent.com", "example.com"))) }
    @Test fun otherRepository() { rejected(release.copy(apkUrl = release.apkUrl.replace("shadowfox-tv-releases", "other"))) }
    @Test fun userInfo() { rejected(release.copy(apkUrl = release.apkUrl.replace("https://", "https://name@"))) }
    @Test fun badHash() { rejected(release.copy(sha256 = "invalid")) }
    @Test fun badSize() { rejected(release.copy(sizeBytes = 0)); rejected(release.copy(sizeBytes = MAX_UPDATE_BYTES + 1)) }
    @Test fun exactDownload() { verifyDownloadFacts(release, 1024, "A".repeat(64)) }
    @Test fun corruptOrIncomplete() {
        try { verifyDownloadFacts(release, 1023, release.sha256); fail() } catch (_: IllegalArgumentException) {}
        try { verifyDownloadFacts(release, 1024, "b".repeat(64)); fail() } catch (_: IllegalArgumentException) {}
    }
    @Test fun certificates() {
        assertTrue(certificateSetsMatch(setOf("a"), setOf("a")))
        assertFalse(certificateSetsMatch(emptySet(), emptySet()))
        assertFalse(certificateSetsMatch(setOf("a"), setOf("b")))
        assertFalse(certificateSetsMatch(setOf("a"), setOf("a", "b")))
    }
    @Test fun ignoresFutureFields() {
        val m = Json { ignoreUnknownKeys = true }.decodeFromString<UpdateManifest>(
            """{"packageName":"$UPDATE_PACKAGE","versionCode":3,"versionName":"next","apkUrl":"${release.apkUrl}","sha256":"${release.sha256}","sizeBytes":1024,"future":true}""")
        validateManifest(m)
    }
}
