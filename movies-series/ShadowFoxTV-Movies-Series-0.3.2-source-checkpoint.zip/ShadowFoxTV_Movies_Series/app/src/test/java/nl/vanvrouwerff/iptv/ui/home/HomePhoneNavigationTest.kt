package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.MaterialTheme
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import androidx.compose.ui.unit.dp
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w360dp-h800dp-port-xhdpi")
class HomePhoneNavigationTest {
    @get:Rule val compose = createComposeRule()

    @Test fun featuredPhoneActionsAreVisibleAndComfortableToTap() {
        val channel = Channel("phone", "A very long featured movie title for a narrow phone", null, "Drama", null, null, ContentType.MOVIE)
        var played = 0
        var details = 0
        compose.setContent { MaterialTheme {
            HomeScreen(HomeState(movies = listOf(HomeItem(channel)), loading = false),
                onSection = {}, onSettings = {}, onDetail = { _, _ -> details++ }, onPlay = { played++ })
        } }
        val title = compose.onAllNodesWithText(channel.name).fetchSemanticsNodes().first()
        compose.runOnIdle { assertTrue("Featured title must use the phone width", title.boundsInRoot.width > 400f) }
        compose.onNodeWithText("▶  Play").onParent().assertHeightIsAtLeast(48.dp)
        compose.onNodeWithText("Details").onParent().assertHeightIsAtLeast(48.dp)
        compose.onNodeWithText("▶  Play").assertIsDisplayed().performTouchInput { click() }
        compose.onNodeWithText("Details").assertIsDisplayed().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, played); assertEquals(1, details) }
    }

    @Test fun phoneCanReachAndTapSettings() {
        var settings = 0
        compose.setContent { MaterialTheme {
            HomeScreen(HomeState(loading = false), onSection = {}, onSettings = { settings++ },
                onDetail = { _, _ -> }, onPlay = {})
        } }
        compose.onNodeWithText("Settings").performScrollTo().assertIsDisplayed().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, settings) }
    }
}
