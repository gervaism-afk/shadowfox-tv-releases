package nl.vanvrouwerff.iptv.data.xtream

import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import org.junit.Assert.*
import org.junit.Test

class XtreamEpisodeInfoTest {
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }
    private fun episode(info: String) = json.decodeFromString(XtreamEpisode.serializer(), """{"id":"42","episode_num":"1","container_extension":"mp4","info":$info}""")

    @Test fun providerEmptyMetadataDoesNotRemovePlayableEpisodes() {
        for (info in listOf("\"\"", "\"unavailable\"", "[]", "false", "0", "null")) {
            val item = episode(info)
            assertEquals(JsonPrimitive("42"), item.id)
            assertEquals("mp4", item.containerExtension)
            assertNull(item.info)
        }
    }

    @Test fun aSeasonWithEmptyAndValidMetadataKeepsBothEpisodes() {
        val items = json.decodeFromString(ListSerializer(XtreamEpisode.serializer()), """[
            {"id":101,"title":"Episode one","info":""},
            {"id":102,"title":"Episode two","info":{"duration_secs":"123","plot":"Story"}}
        ]""")
        assertEquals(2, items.size)
        assertNull(items[0].info)
        assertEquals(123L, items[1].info?.durationSecs)
        assertEquals("Story", items[1].info?.plot)
    }

    @Test fun malformedOptionalFieldsDoNotHideTheEpisode() {
        val item = episode("""{"duration_secs":"unknown","movie_image":[],"plot":false,"duration":"00:42:00"}""")
        assertNotNull(item.info)
        assertNull(item.info?.durationSecs)
        assertNull(item.info?.movieImage)
        assertNull(item.info?.plot)
        assertEquals("00:42:00", item.info?.duration)
    }

    @Test fun cachedEpisodeMetadataRoundTripsAfterNormalization() {
        val item = episode("\"\"")
        val cached = json.encodeToString(XtreamEpisode.serializer(), item)
        assertEquals(item, json.decodeFromString(XtreamEpisode.serializer(), cached))
    }
}
