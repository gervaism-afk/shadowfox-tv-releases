package nl.vanvrouwerff.iptv.ui.input

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
@OptIn(ExperimentalTestApi::class)
class TouchControlsTest {
    @get:Rule val compose = createComposeRule()

    @Test fun touchHonorsDisabledStateAndLatestCallback() {
        var enabled by mutableStateOf(true)
        var latest by mutableStateOf(false)
        var first = 0
        var second = 0
        compose.setContent { MaterialTheme {
            Button(enabled = enabled, onClick = if (latest) ({ second++ }) else ({ first++ })) { Text("Save") }
        } }
        compose.onNodeWithText("Save").performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, first); enabled = false }
        compose.onNodeWithText("Save").assertIsNotEnabled().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, first); enabled = true; latest = true }
        compose.onNodeWithText("Save").performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, first); assertEquals(1, second) }
    }

    @Test fun posterLongPressDoesNotAlsoClickAndRemoteStillClicks() {
        var clicks = 0
        var longPresses = 0
        compose.setContent { MaterialTheme {
            Surface(onClick = { clicks++ }, onLongClick = { longPresses++ }) { Text("Poster") }
        } }
        val poster = compose.onNodeWithText("Poster")
        poster.performTouchInput { longClick() }
        compose.runOnIdle { assertEquals(0, clicks); assertEquals(1, longPresses) }
        poster.performSemanticsAction(SemanticsActions.RequestFocus)
        poster.performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertEquals(1, clicks); assertEquals(1, longPresses) }
    }
}
