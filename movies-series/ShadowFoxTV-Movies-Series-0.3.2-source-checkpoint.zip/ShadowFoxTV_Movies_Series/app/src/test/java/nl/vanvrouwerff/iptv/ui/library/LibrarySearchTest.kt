package nl.vanvrouwerff.iptv.ui.library

import org.junit.Assert.assertEquals
import org.junit.Test
class LibrarySearchTest {
    @Test fun searchTreatsSqlWildcardsAsLiteralText() {
        assertEquals("%100\\%\\_complete%", librarySearchPattern(" 100%_complete "))
        assertEquals("%a\\\\b%", librarySearchPattern("a\\b"))
        assertEquals("%%", librarySearchPattern(""))
    }
}
