package nl.vanvrouwerff.iptv.data.xtream

import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test

class StreamingCatalogueTest {
    private val json = Json { ignoreUnknownKeys = true }
    @Test fun largeCataloguePreservesEveryTitleAndMixedIdentifiers() {
        val count = 25_000
        val input = buildString {
            append('[')
            repeat(count) { i ->
                if (i > 0) append(',')
                append("""{"stream_id":$i,"name":"Movie $i","ignored":{"large":"metadata"}}""")
            }
            append(']')
        }.byteInputStream()
        var progress = 0
        val titles = input.use {
            readCatalogue(json, it, XtreamVodStream.serializer(), map = { dto -> dto.name }, onEntry = { progress = it })
        }
        assertEquals(count, titles.size)
        assertEquals(count, progress)
        assertEquals("Movie 24999", titles.last())
    }
    @Test fun emptyCatalogueIsValid() {
        val entries = "[]".byteInputStream().use { readCatalogue(json, it, XtreamSeries.serializer(), map = { dto -> dto.name }) }
        assertTrue(entries.isEmpty())
    }
    @Test(expected = kotlinx.serialization.SerializationException::class)
    fun malformedCatalogueCannotBecomeSilentSuccess() {
        "[{\"stream_id\":1,\"name\":\"Valid\"},broken]".byteInputStream().use {
            readCatalogue(json, it, XtreamVodStream.serializer(), map = { dto -> dto.name })
        }
    }
}
