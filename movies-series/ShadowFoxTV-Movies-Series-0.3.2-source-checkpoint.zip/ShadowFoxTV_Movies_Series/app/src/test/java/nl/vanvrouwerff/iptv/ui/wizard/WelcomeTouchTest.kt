package nl.vanvrouwerff.iptv.ui.wizard

import android.app.Application
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.MaterialTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w360dp-h800dp-port-xhdpi")
@OptIn(ExperimentalTestApi::class)
class WelcomeTouchTest {
    @get:Rule val compose = createComposeRule()

    @Test fun connectRespondsToRealTouchOnPhone() {
        var opened = 0
        compose.setContent { MaterialTheme { WelcomeScreen { opened++ } } }
        val button = compose.onNodeWithText("Connect your account")
        button.performScrollTo().assertIsDisplayed()
        button.performTouchInput { click() }
        compose.runOnIdle { assertEquals("A finger tap must open account setup exactly once", 1, opened) }
        val buttonBounds = button.fetchSemanticsNode().boundsInRoot
        val rootBounds = compose.onRoot().fetchSemanticsNode().boundsInRoot
        assertTrue("Connect must fit within the phone screen", buttonBounds.left >= rootBounds.left && buttonBounds.right <= rootBounds.right)
    }

    @Test
    @Config(qualifiers = "w800dp-h360dp-land-xhdpi")
    fun connectRespondsToRealTouchInLandscape() {
        connectRespondsToRealTouchOnPhone()
    }

    @Test fun connectStillRespondsToRemote() {
        var opened = 0
        compose.setContent { MaterialTheme { WelcomeScreen { opened++ } } }
        val button = compose.onNodeWithText("Connect your account")
        button.performScrollTo().performSemanticsAction(SemanticsActions.RequestFocus)
        button.performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertEquals(1, opened) }
    }
}
