package nl.vanvrouwerff.iptv.player

import androidx.media3.common.ParserException
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test

class StreamFormatRecoveryTest {
    private fun mislabeled() = RuntimeException("Source error",
        ParserException.createForMalformedManifest("Input does not start with the #EXTM3U header.", null))

    @Test fun seriesAndMoviesRecoverFromMislabeledPlaylist() {
        for (type in listOf(ContentType.SERIES, ContentType.MOVIE)) {
            assertTrue(StreamFormatRecovery().tryProgressive(type, mislabeled()))
        }
    }

    @Test fun liveAndUnknownContentKeepTheirOriginalError() {
        for (type in listOf(ContentType.TV, null)) {
            assertFalse(StreamFormatRecovery().tryProgressive(type, mislabeled()))
        }
    }

    @Test fun recoveryRunsOncePerItemAndResetsForNextEpisode() {
        val recovery = StreamFormatRecovery()
        assertTrue(recovery.tryProgressive(ContentType.SERIES, mislabeled()))
        assertFalse(recovery.tryProgressive(ContentType.SERIES, mislabeled()))
        recovery.reset()
        assertTrue(recovery.tryProgressive(ContentType.SERIES, mislabeled()))
    }

    @Test fun networkAndOtherPlaylistErrorsDoNotTriggerContainerFallback() {
        val recovery = StreamFormatRecovery()
        assertFalse(recovery.tryProgressive(ContentType.MOVIE, java.io.IOException("Connection failed")))
        assertFalse(recovery.tryProgressive(ContentType.MOVIE,
            ParserException.createForMalformedManifest("Invalid segment duration", null)))
        assertTrue(recovery.tryProgressive(ContentType.MOVIE, mislabeled()))
    }
}
