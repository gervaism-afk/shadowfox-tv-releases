package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.db.ChannelEntity
import nl.vanvrouwerff.iptv.data.db.IptvDatabase
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class HomeQueriesTest {
    @Test fun homeQueriesRespectTypeLimitsKidsAndProfile() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), IptvDatabase::class.java).allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels((0..30).map { ChannelEntity("movie$it", "Film $it", null, "Films", null, null, it + 1, "MOVIE") } + listOf(
                ChannelEntity("adult", "Adult", null, "XXX Adult", null, null, 0, "MOVIE"),
                ChannelEntity("series", "Series", null, "Shows", null, null, 0, "SERIES"),
                ChannelEntity("live", "Live", null, "Live", null, null, 0, "TV")))
            assertEquals(HOME_ROW_LIMIT, dao.observeHomeTitles("MOVIE", false, HOME_ROW_LIMIT).first().size)
            assertFalse(dao.observeHomeTitles("MOVIE", true, HOME_ROW_LIMIT).first().any { it.id == "adult" })
            assertEquals(listOf("series"), dao.observeHomeTitles("SERIES", true, HOME_ROW_LIMIT).first().map { it.id })
            dao.addFavorite("one", "movie0", 1)
            dao.addFavorite("one", "adult", 2)
            dao.addFavorite("one", "live", 3)
            dao.addFavorite("two", "series", 4)
            assertEquals(listOf("movie0"), dao.observeHomeSaved("one", true, PERSONAL_ROW_LIMIT).first().map { it.id })
            assertEquals(listOf("series"), dao.observeHomeSaved("two", false, PERSONAL_ROW_LIMIT).first().map { it.id })
        } finally { db.close() }
    }
}
