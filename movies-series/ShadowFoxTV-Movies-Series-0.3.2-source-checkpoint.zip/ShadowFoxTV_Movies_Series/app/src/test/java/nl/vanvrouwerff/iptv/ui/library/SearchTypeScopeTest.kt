package nl.vanvrouwerff.iptv.ui.library

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.db.ChannelEntity
import nl.vanvrouwerff.iptv.data.db.IptvDatabase
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class SearchTypeScopeTest {
    @Test fun identicalTitlesHaveTypeScopedResultsCountsAndCategories() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), IptvDatabase::class.java)
            .allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels(listOf(
                ChannelEntity("movie", "Castle", null, "Films", null, null, 0, "MOVIE"),
                ChannelEntity("movie2", "Castle Rock", null, "Films", null, null, 1, "MOVIE"),
                ChannelEntity("series", "Castle", null, "Shows", null, null, 2, "SERIES"),
                ChannelEntity("live", "Castle", null, "Live", null, null, 3, "TV"),
            ))
            for ((type, expected) in listOf("MOVIE" to listOf("movie", "movie2"), "SERIES" to listOf("series"))) {
                assertEquals(expected, dao.observeLibraryPage(type, null, librarySearchPattern("castle"), false, "default", false, 60, 0).first().map { it.id })
                assertEquals(expected.size, dao.observeLibraryCount(type, null, librarySearchPattern("castle"), false, "default", false).first())
                assertEquals(listOf(if (type == "MOVIE") "Films" else "Shows"), dao.observeGroupTitlesByType(type).first())
            }
            assertTrue(dao.observeLibraryPage("MOVIE", "Shows", librarySearchPattern("castle"), false, "default", false, 60, 0).first().isEmpty())
            assertEquals(0, dao.observeLibraryCount("SERIES", "Films", librarySearchPattern("castle"), false, "default", false).first())
        } finally { db.close() }
    }
}
