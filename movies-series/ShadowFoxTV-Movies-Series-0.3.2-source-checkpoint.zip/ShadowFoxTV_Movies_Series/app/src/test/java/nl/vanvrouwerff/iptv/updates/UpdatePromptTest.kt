package nl.vanvrouwerff.iptv.updates

import android.app.Application
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
@OptIn(ExperimentalTestApi::class)
class UpdatePromptTest {
    @get:Rule val compose = createComposeRule()

    @Test fun onlyOffersNewerUndismissedVersions() {
        assertFalse(shouldOfferUpdate(null, 13, 0))
        assertFalse(shouldOfferUpdate(12, 13, 0))
        assertFalse(shouldOfferUpdate(13, 13, 0))
        assertTrue(shouldOfferUpdate(14, 13, 0))
        assertFalse(shouldOfferUpdate(14, 13, 14))
        assertTrue(shouldOfferUpdate(15, 13, 14))
    }

    @Test fun startupNoticeIsVisibleAndDismissesByTouchAndRemote() {
        var dismissals = 0
        compose.setContent { MaterialTheme {
            AvailableUpdateDialog("0.3.2", onDismiss = { dismissals++ }) { Text("Download & install") }
        } }
        compose.onNodeWithText("Version 0.3.2").assertIsDisplayed()
        compose.onNodeWithText("Download & install").assertIsDisplayed()
        val later = compose.onNodeWithText("Later")
        later.performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, dismissals) }
        later.performSemanticsAction(SemanticsActions.RequestFocus)
        later.performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertEquals(2, dismissals) }
    }
}
