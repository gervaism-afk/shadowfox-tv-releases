package nl.vanvrouwerff.iptv.data.repo

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.db.ProgrammeEntity
import nl.vanvrouwerff.iptv.data.remote.HttpClient
import nl.vanvrouwerff.iptv.data.xtream.*

class XtreamPlaylistRepository(
    private val host: String,
    private val username: String,
    private val password: String,
    private val categoryFilter: CategoryFilter = CategoryFilter(emptyList()),
) : PlaylistRepository {
    private val api = HttpClient.retrofitFor(host).create(XtreamApi::class.java)

    override suspend fun fetch(
        etag: String?, lastModified: String?, onProgress: (ImportProgress) -> Unit,
    ): PlaylistSnapshot = withContext(Dispatchers.IO) {
        onProgress(ImportProgress(ImportProgress.Stage.Downloading, 0))
        val channels = ArrayList<Channel>()
        val movieCategories = api.getVodCategories(username, password)
            .associate { it.categoryId.scalar() to it.categoryName }
        val movies = api.getVodStreamsStream(username, password).use { body ->
            body.byteStream().use { input ->
                readCatalogue(HttpClient.json, input, XtreamVodStream.serializer(), map = { item ->
                    val id = item.streamId.scalar()
                    Channel(
                        id = "xt-vod:$id", name = item.name,
                        logoUrl = item.streamIcon?.takeIf(String::isNotBlank),
                        groupTitle = item.categoryId?.scalar()?.let(movieCategories::get),
                        streamUrl = XtreamUrls.stream(host, "movie", username, password,
                            "$id.${item.containerExtension?.takeIf(String::isNotBlank) ?: "mp4"}"),
                        epgChannelId = null, type = ContentType.MOVIE,
                    )
                }, onEntry = { count ->
                    ensureActive()
                    if (count % 500 == 0) onProgress(ImportProgress(ImportProgress.Stage.Movies, count))
                })
            }
        }
        filterInPlace(movies)
        onProgress(ImportProgress(ImportProgress.Stage.Movies, movies.size))
        channels.addAll(movies)
        movies.clear()
        val seriesCategories = api.getSeriesCategories(username, password)
            .associate { it.categoryId.scalar() to it.categoryName }
        val shows = api.getSeriesStream(username, password).use { body ->
            body.byteStream().use { input ->
                readCatalogue(HttpClient.json, input, XtreamSeries.serializer(), map = { item ->
                    Channel(
                        id = "xt-series:${item.seriesId.scalar()}", name = item.name,
                        logoUrl = item.cover?.takeIf(String::isNotBlank),
                        groupTitle = item.categoryId?.scalar()?.let(seriesCategories::get),
                        streamUrl = null, epgChannelId = null, type = ContentType.SERIES,
                    )
                }, onEntry = { count ->
                    ensureActive()
                    if (count % 500 == 0) onProgress(ImportProgress(ImportProgress.Stage.Series, count))
                })
            }
        }
        filterInPlace(shows)
        onProgress(ImportProgress(ImportProgress.Stage.Series, shows.size))
        channels.addAll(shows)
        // A failed request is allowed to propagate. Do not erase a cached library with an
        // empty "successful" snapshot, or swallow cancellation and fatal VM failures.
        PlaylistSnapshot(channels)
    }

    private fun filterInPlace(items: ArrayList<Channel>) {
        if (!categoryFilter.isEnabled) return
        if (items.any { categoryFilter.accepts(it.groupTitle) }) {
            items.removeAll { !categoryFilter.accepts(it.groupTitle) }
        } else if (items.isNotEmpty()) {
            Log.w("XtreamRepo", "Category filter matched no titles; keeping available library")
        }
    }

    override suspend fun fetchProgrammes(epgKeys: Set<String>): List<ProgrammeEntity> = emptyList()
    private fun JsonElement.scalar(): String = (this as? JsonPrimitive)?.contentOrNull ?: toString().trim('"')
}
