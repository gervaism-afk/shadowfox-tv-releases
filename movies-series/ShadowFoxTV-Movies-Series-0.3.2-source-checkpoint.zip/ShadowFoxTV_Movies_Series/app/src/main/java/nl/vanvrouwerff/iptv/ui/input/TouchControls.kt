package nl.vanvrouwerff.iptv.ui.input

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.*
import androidx.tv.material3.Button as TvButton
import androidx.tv.material3.Surface as TvSurface

/** Pointer gestures complement the TV component's existing semantics and key handling. */
@Composable
private fun Modifier.touchActions(enabled: Boolean, onClick: () -> Unit, onLongClick: (() -> Unit)?): Modifier {
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)
    return if (!enabled) this else pointerInput(onLongClick != null) {
        detectTapGestures(onTap = { click() }, onLongPress = if (onLongClick == null) null else { _ -> longClick?.invoke() })
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun Button(onClick: () -> Unit, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true, scale: ButtonScale = ButtonDefaults.scale(), glow: ButtonGlow = ButtonDefaults.glow(),
    shape: ButtonShape = ButtonDefaults.shape(), colors: ButtonColors = ButtonDefaults.colors(), tonalElevation: Dp = 0.dp,
    border: ButtonBorder = ButtonDefaults.border(), contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() }, content: @Composable RowScope.() -> Unit,
) = TvButton(onClick, modifier.touchActions(enabled, onClick, onLongClick), onLongClick, enabled,
    scale, glow, shape, colors, tonalElevation, border, contentPadding, interactionSource, content)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun Surface(onClick: () -> Unit, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true, tonalElevation: Dp = 0.dp, shape: ClickableSurfaceShape = ClickableSurfaceDefaults.shape(),
    colors: ClickableSurfaceColors = ClickableSurfaceDefaults.colors(), scale: ClickableSurfaceScale = ClickableSurfaceDefaults.scale(),
    border: ClickableSurfaceBorder = ClickableSurfaceDefaults.border(), glow: ClickableSurfaceGlow = ClickableSurfaceDefaults.glow(),
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() }, content: @Composable BoxScope.() -> Unit,
) = TvSurface(onClick, modifier.touchActions(enabled, onClick, onLongClick), onLongClick, enabled,
    tonalElevation, shape, colors, scale, border, glow, interactionSource, content)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun Surface(modifier: Modifier = Modifier, tonalElevation: Dp = 0.dp, shape: Shape = RectangleShape,
    colors: NonInteractiveSurfaceColors = NonInteractiveSurfaceDefaults.colors(), border: Border = Border.None,
    glow: Glow = Glow.None, content: @Composable BoxScope.() -> Unit,
) = TvSurface(modifier, tonalElevation, shape, colors, border, glow, content)
