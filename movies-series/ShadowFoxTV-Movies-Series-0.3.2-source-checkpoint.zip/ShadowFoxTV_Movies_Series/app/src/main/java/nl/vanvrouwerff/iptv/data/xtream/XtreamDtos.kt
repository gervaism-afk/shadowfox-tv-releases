package nl.vanvrouwerff.iptv.data.xtream

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerializationException
import kotlinx.serialization.builtins.nullable
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

@Serializable
data class XtreamCategory(
    @SerialName("category_id") val categoryId: JsonElement,
    @SerialName("category_name") val categoryName: String,
)

@Serializable
data class XtreamLiveStream(
    @SerialName("stream_id") val streamId: JsonElement,
    val name: String,
    @SerialName("stream_icon") val streamIcon: String? = null,
    @SerialName("epg_channel_id") val epgChannelId: String? = null,
    @SerialName("category_id") val categoryId: JsonElement? = null,
    @SerialName("tv_archive") val tvArchive: JsonElement? = null,
    @SerialName("tv_archive_duration") val tvArchiveDuration: JsonElement? = null,
)

@Serializable
data class XtreamVodStream(
    @SerialName("stream_id") val streamId: JsonElement,
    val name: String,
    @SerialName("stream_icon") val streamIcon: String? = null,
    @SerialName("category_id") val categoryId: JsonElement? = null,
    @SerialName("container_extension") val containerExtension: String? = null,
)

@Serializable
data class XtreamSeries(
    @SerialName("series_id") val seriesId: JsonElement,
    val name: String,
    val cover: String? = null,
    @SerialName("category_id") val categoryId: JsonElement? = null,
)

@Serializable
data class XtreamSeriesInfoResponse(
    val info: XtreamSeriesInfoMeta? = null,
    val seasons: List<XtreamSeason> = emptyList(),
    // Providers return this either as `{"1": [...], "2": [...]}` (JsonObject) or as
    // `[]` when empty. Keep as JsonElement and decode per-season in the repo layer.
    val episodes: JsonElement? = null,
)

@Serializable
data class XtreamSeriesInfoMeta(
    val name: String? = null,
    val cover: String? = null,
    val plot: String? = null,
    val cast: String? = null,
    val director: String? = null,
    val genre: String? = null,
    @SerialName("releaseDate") val releaseDate: String? = null,
    val rating: String? = null,
)

@Serializable
data class XtreamSeason(
    @SerialName("season_number") val seasonNumber: JsonElement? = null,
    val name: String? = null,
    val cover: String? = null,
    @SerialName("episode_count") val episodeCount: JsonElement? = null,
    @SerialName("air_date") val airDate: String? = null,
)

@Serializable
data class XtreamEpisode(
    val id: JsonElement,
    @SerialName("episode_num") val episodeNum: JsonElement? = null,
    val title: String? = null,
    @SerialName("container_extension") val containerExtension: String? = null,
    @Serializable(with = OptionalXtreamEpisodeInfoSerializer::class)
    val info: XtreamEpisodeInfo? = null,
)

/** Missing optional metadata must not reject an otherwise playable episode. */
object OptionalXtreamEpisodeInfoSerializer : KSerializer<XtreamEpisodeInfo?> {
    private val delegate = XtreamEpisodeInfo.serializer().nullable
    override val descriptor: SerialDescriptor = delegate.descriptor
    override fun deserialize(decoder: Decoder): XtreamEpisodeInfo? {
        val input = decoder as? JsonDecoder ?: throw SerializationException("Episode metadata requires JSON")
        val element = input.decodeJsonElement()
        if (element !is JsonObject) return null
        val normalized = JsonObject(element.mapValues { (name, value) ->
            when (name) {
                "duration_secs" -> (value as? JsonPrimitive)?.contentOrNull?.toLongOrNull()
                    ?.let { JsonPrimitive(it.coerceAtLeast(0)) } ?: JsonNull
                "duration", "plot", "movie_image", "air_date", "releasedate" ->
                    value.takeIf { it is JsonPrimitive && it.isString } ?: JsonNull
                else -> value
            }
        })
        return input.json.decodeFromJsonElement(delegate, normalized)
    }
    override fun serialize(encoder: Encoder, value: XtreamEpisodeInfo?) =
        encoder.encodeSerializableValue(delegate, value)
}

@Serializable
data class XtreamEpisodeInfo(
    @SerialName("duration_secs") val durationSecs: Long? = null,
    val duration: String? = null,
    val plot: String? = null,
    @SerialName("movie_image") val movieImage: String? = null,
    @SerialName("air_date") val airDate: String? = null,
    // Alternate spelling used by some Xtream providers.
    @SerialName("releasedate") val releaseDate: String? = null,
)

@Serializable
data class XtreamVodInfoResponse(
    val info: XtreamVodInfoMeta? = null,
    @SerialName("movie_data") val movieData: XtreamVodMovieData? = null,
)

@Serializable
data class XtreamVodInfoMeta(
    val name: String? = null,
    val plot: String? = null,
    val cast: String? = null,
    val director: String? = null,
    val genre: String? = null,
    @SerialName("releasedate") val releaseDate: String? = null,
    val rating: String? = null,
    @SerialName("movie_image") val movieImage: String? = null,
    @SerialName("cover_big") val coverBig: String? = null,
    @SerialName("backdrop_path") val backdropPath: JsonElement? = null,
    @SerialName("duration_secs") val durationSecs: Long? = null,
    val duration: String? = null,
    @SerialName("youtube_trailer") val youtubeTrailer: String? = null,
    val country: String? = null,
)

@Serializable
data class XtreamVodMovieData(
    @SerialName("stream_id") val streamId: JsonElement? = null,
    val name: String? = null,
    @SerialName("container_extension") val containerExtension: String? = null,
)
