package nl.vanvrouwerff.iptv.updates

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import nl.vanvrouwerff.iptv.BuildConfig
import nl.vanvrouwerff.iptv.data.remote.HttpClient
import okhttp3.Request

data class UpdateState(val checking: Boolean = false, val checked: Boolean = false,
    val release: UpdateManifest? = null, val downloading: Boolean = false, val percent: Int = 0,
    val readyFile: File? = null, val error: String? = null)
class UpdateController(context: Context) {
    private val context = context.applicationContext
    private val mutable = MutableStateFlow(UpdateState())
    val state = mutable.asStateFlow()
    private val mutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true }
    private val client by lazy { HttpClient.okHttp.newBuilder().cache(null).followSslRedirects(false)
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build() }
    private fun request(url: String) = Request.Builder().url(url).header("Cache-Control", "no-cache").build()
    suspend fun check() = withContext(Dispatchers.IO) {
        if (!mutex.tryLock()) return@withContext
        try {
            mutable.update { it.copy(checking = true, error = null, readyFile = null) }
            File(context.filesDir, "updates").listFiles()?.forEach { file ->
                val code = file.name.removePrefix("verified-").removeSuffix(".apk").toIntOrNull()
                if (code != null && code <= BuildConfig.VERSION_CODE) file.delete()
            }
            val release = client.newCall(request(UPDATE_FEED)).execute().use { response ->
                require(response.isSuccessful) { "Update server unavailable." }
                val body = requireNotNull(response.body)
                val out = ByteArrayOutputStream(4096)
                body.byteStream().use { input ->
                    val buffer = ByteArray(4096)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buffer); if (n < 0) break
                        require(out.size() + n <= 32768) { "Update feed too large." }
                        out.write(buffer, 0, n)
                    }
                }
                json.decodeFromString<UpdateManifest>(out.toString("UTF-8")).also(::validateManifest)
            }
            mutable.update { it.copy(checked = true, release = release.takeIf { r ->
                isNewer(r, BuildConfig.VERSION_CODE.toLong()) }) }
        } catch (e: CancellationException) { throw e
        } catch (_: Exception) {
            mutable.update { it.copy(error = "Could not check for updates. Check your connection and try again.") }
        } finally { mutable.update { it.copy(checking = false) }; mutex.unlock() }
    }
    suspend fun download(): File? = withContext(Dispatchers.IO) {
        if (!mutex.tryLock()) return@withContext null
        var temporary: File? = null
        try {
            val release = state.value.release ?: return@withContext null
            validateManifest(release)
            require(isNewer(release, BuildConfig.VERSION_CODE.toLong()))
            val dir = File(context.filesDir, "updates").apply { mkdirs() }
            val target = File(dir, "verified-${release.versionCode}.apk")
            val partial = File(dir, "downloading-${release.versionCode}.apk"); temporary = partial
            mutable.update { it.copy(downloading = true, percent = 0, readyFile = null, error = null) }
            if (target.exists()) {
                try { verifyFile(target, release); mutable.update { it.copy(readyFile = target, percent = 100) }; return@withContext target
                } catch (e: CancellationException) { throw e
                } catch (_: Exception) { target.delete() }
            }
            val digest = MessageDigest.getInstance("SHA-256")
            var count = 0L
            client.newCall(request(release.apkUrl)).execute().use { response ->
                require(response.isSuccessful) { "Update download unavailable." }
                val body = requireNotNull(response.body)
                require(body.contentLength() <= MAX_UPDATE_BYTES)
                body.byteStream().use { input -> partial.outputStream().buffered().use { output ->
                    val buffer = ByteArray(65536)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buffer); if (n < 0) break
                        count += n
                        require(count <= release.sizeBytes && count <= MAX_UPDATE_BYTES) { "Update download too large." }
                        output.write(buffer, 0, n); digest.update(buffer, 0, n)
                        val percent = (count * 100 / release.sizeBytes).toInt()
                        if (percent != state.value.percent) mutable.update { it.copy(percent = percent) }
                    }
                } }
            }
            verifyDownloadFacts(release, count, digest.digest().hex())
            verifyPackage(partial, release)
            require(partial.renameTo(target)) { "Could not save verified update." }
            mutable.update { it.copy(readyFile = target, percent = 100) }
            target
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) {
            mutable.update { it.copy(error = if (e is IllegalArgumentException) e.message else
                "Could not download or verify the update. Check your connection and available storage.") }
            null
        } finally { temporary?.delete(); mutable.update { it.copy(downloading = false) }; mutex.unlock() }
    }
    private suspend fun verifyFile(file: File, release: UpdateManifest) {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(65536)
            while (true) { currentCoroutineContext().ensureActive(); val n = input.read(buffer)
                if (n < 0) break; digest.update(buffer, 0, n) }
        }
        verifyDownloadFacts(release, file.length(), digest.digest().hex()); verifyPackage(file, release)
    }
    @Suppress("DEPRECATION")
    private fun verifyPackage(file: File, release: UpdateManifest) {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val incoming = requireNotNull(pm.getPackageArchiveInfo(file.absolutePath, flags)) {
            "Android could not read the update APK."
        }
        require(incoming.packageName == context.packageName && incoming.packageName == release.packageName) { "Wrong update package." }
        val code = if (Build.VERSION.SDK_INT >= 28) incoming.longVersionCode else incoming.versionCode.toLong()
        require(code == release.versionCode.toLong() && code > BuildConfig.VERSION_CODE) { "Wrong update version." }
        val installed = pm.getPackageInfo(context.packageName, flags)
        val installedSignatures = if (Build.VERSION.SDK_INT >= 28) installed.signingInfo?.apkContentsSigners else installed.signatures
        val incomingSignatures = if (Build.VERSION.SDK_INT >= 28) incoming.signingInfo?.apkContentsSigners else incoming.signatures
        require(certificateSetsMatch(certificates(installedSignatures),
            certificates(incomingSignatures))) { "Update signing certificate mismatch." }
    }
    private fun certificates(signatures: Array<out Signature>?) = signatures.orEmpty().map {
        MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).hex()
    }.toSet()
    fun reportInstallError() { mutable.update { it.copy(error = "Could not open Android's installer. Please try again.") } }
}
private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }
