package nl.vanvrouwerff.iptv

import android.content.Context
import nl.vanvrouwerff.iptv.data.remote.HttpClient
import java.io.File

/** Retain a small, private and credential-redacted report before the normal crash handler. */
object CrashCapture {
    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, failure ->
            try {
                val runtime = Runtime.getRuntime()
                val report = buildString {
                    appendLine("${BuildConfig.VERSION_NAME} · ${failure.javaClass.simpleName}")
                    appendLine("Heap: ${(runtime.totalMemory() - runtime.freeMemory()) / 1048576} / ${runtime.maxMemory() / 1048576} MB")
                    appendLine(HttpClient.redact(failure.stackTraceToString()).take(12_000))
                }
                File(context.filesDir, "last-crash.txt").writeText(report)
            } catch (_: Throwable) { }
            previous?.uncaughtException(thread, failure)
        }
    }
    fun report(context: Context): String? = try {
        File(context.filesDir, "last-crash.txt").takeIf(File::exists)?.bufferedReader()?.use { reader ->
            val chars = CharArray(12000)
            val count = reader.read(chars)
            if (count > 0) String(chars, 0, count) else null
        }
    } catch (_: Exception) { null }
    fun summary(context: Context): String? = try {
        File(context.filesDir, "last-crash.txt").takeIf(File::exists)?.bufferedReader()?.use { it.readLine() }
    } catch (_: Exception) { null }
}
