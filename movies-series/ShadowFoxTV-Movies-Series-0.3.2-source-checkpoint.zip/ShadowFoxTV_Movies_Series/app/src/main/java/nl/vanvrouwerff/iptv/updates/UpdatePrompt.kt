package nl.vanvrouwerff.iptv.updates

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.BuildConfig
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.ui.input.Button
import nl.vanvrouwerff.iptv.ui.input.Surface

internal fun shouldOfferUpdate(available: Int?, installed: Int, dismissed: Int): Boolean =
    available != null && available > installed && available > dismissed

/** The application checks on startup; expose its verified release even before account setup. */
@Composable
fun UpdatePrompt() {
    val state by IptvApp.get().updates.state.collectAsState()
    var dismissed by rememberSaveable { mutableStateOf(0) }
    val release = state.release ?: return
    if (!shouldOfferUpdate(release.versionCode, BuildConfig.VERSION_CODE, dismissed)) return
    AvailableUpdateDialog(release.versionName, onDismiss = { dismissed = release.versionCode }) {
        UpdatePanel()
    }
}

@Composable
internal fun AvailableUpdateDialog(version: String, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.widthIn(max = 520.dp).fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("ShadowFoxTV update available")
                Text("Version $version")
                content()
                Button(onClick = onDismiss) { Text("Later") }
            }
        }
    }
}
