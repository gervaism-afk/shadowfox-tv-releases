package nl.vanvrouwerff.iptv.ui.library

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType

internal fun usesPlainLibraryQuery(selection: LibrarySelection, kids: Boolean): Boolean =
    !kids && !selection.saved && selection.query.isBlank()

@OptIn(ExperimentalCoroutinesApi::class)
internal fun libraryCategoryFlow(
    selection: Flow<LibrarySelection>,
    categoryQuery: (ContentType) -> Flow<List<String?>>,
): Flow<Pair<ContentType, List<String?>>> = selection.map { it.type }.distinctUntilChanged()
    .flatMapLatest { type ->
        categoryQuery(type).map { type to it }.catch { error ->
            if (error is Exception) emit(type to emptyList()) else throw error
        }
    }

/** Counts are filter-level work. A page change replaces only the bounded page query. */
@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
internal fun libraryStateFlow(
    selection: StateFlow<LibrarySelection>, profiles: Flow<String>, kidsModes: Flow<Boolean>,
    pageQuery: (LibrarySelection, String, Boolean) -> Flow<List<Channel>>,
    countQuery: (LibrarySelection, String, Boolean) -> Flow<Int>,
    categoryQuery: (ContentType) -> Flow<List<String?>>,
    onPageClamped: (Int) -> Unit,
    debounceMs: Long = 180,
): Flow<LibraryState> = combine(
    selection.map { it.copy(page = 0) }.distinctUntilChanged().debounce(debounceMs), profiles, kidsModes,
) { filter, profile, kids -> Triple(filter, profile, kids) }.flatMapLatest { (filter, profile, kids) ->
    val pages = selection.map { it.page }.distinctUntilChanged().flatMapLatest { page ->
        pageQuery(filter.copy(page = page), profile, kids).map { page to it }
    }
    combine(pages, countQuery(filter, profile, kids), categoryQuery(filter.type)) { (page, rows), count, cats ->
        val lastPage = (count - 1).coerceAtLeast(0) / LIBRARY_PAGE_SIZE
        if (page > lastPage && selection.value.copy(page = 0) == filter) onPageClamped(lastPage)
        LibraryState(filter.copy(page = page), rows,
            cats.filterNotNull().filterNot { kids && AdultContent.isAdultCategory(it) }, count, false)
    }.catch { emit(LibraryState(selection = filter, loading = false,
        error = "Could not read library. Try refreshing.")) }
}
