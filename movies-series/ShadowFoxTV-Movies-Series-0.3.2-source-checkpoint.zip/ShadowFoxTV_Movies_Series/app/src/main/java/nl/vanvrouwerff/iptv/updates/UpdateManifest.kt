package nl.vanvrouwerff.iptv.updates

import java.net.URI
import kotlinx.serialization.Serializable

const val UPDATE_FEED = "https://raw.githubusercontent.com/gervaism-afk/shadowfox-tv-releases/main/movies-series/update.json"
const val UPDATE_PACKAGE = "ca.shadowfoxtv.movieseries"
const val MAX_UPDATE_BYTES = 100L * 1024 * 1024
@Serializable
data class UpdateManifest(val packageName: String, val versionCode: Int, val versionName: String,
    val apkUrl: String, val sha256: String, val sizeBytes: Long, val notes: String = "")
fun validateManifest(m: UpdateManifest) {
    require(m.packageName == UPDATE_PACKAGE) { "Wrong update package." }
    require(m.versionCode > 0 && m.versionName.isNotBlank()) { "Invalid update version." }
    require(m.sha256.matches(Regex("[0-9a-fA-F]{64}"))) { "Invalid update checksum." }
    require(m.sizeBytes in 1..MAX_UPDATE_BYTES) { "Invalid update size." }
    val uri = URI(m.apkUrl)
    require(uri.scheme == "https" && uri.host == "raw.githubusercontent.com" &&
        uri.userInfo == null && uri.port in listOf(-1, 443) && uri.fragment == null &&
        uri.path.startsWith("/gervaism-afk/shadowfox-tv-releases/") && uri.path.endsWith(".apk")) {
        "Untrusted update URL."
    }
}
fun isNewer(m: UpdateManifest, installed: Long) = m.versionCode.toLong() > installed
fun verifyDownloadFacts(m: UpdateManifest, bytes: Long, hash: String) {
    require(bytes == m.sizeBytes) { "Incomplete update download." }
    require(hash.equals(m.sha256, ignoreCase = true)) { "Update checksum mismatch." }
}
fun certificateSetsMatch(installed: Set<String>, incoming: Set<String>) =
    installed.isNotEmpty() && installed == incoming
