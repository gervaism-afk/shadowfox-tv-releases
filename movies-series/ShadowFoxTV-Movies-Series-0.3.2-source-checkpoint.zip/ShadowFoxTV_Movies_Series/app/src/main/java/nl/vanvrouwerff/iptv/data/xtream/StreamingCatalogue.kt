package nl.vanvrouwerff.iptv.data.xtream

import kotlinx.serialization.DeserializationStrategy
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.DecodeSequenceMode
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeToSequence
import java.io.InputStream

/** Decode one entry at a time; never hold a DTO list alongside the mapped catalogue. */
@OptIn(ExperimentalSerializationApi::class)
internal fun <T, R> readCatalogue(
    json: Json,
    input: InputStream,
    serializer: DeserializationStrategy<T>,
    map: (T) -> R,
    onEntry: (Int) -> Unit = {},
): ArrayList<R> {
    val result = ArrayList<R>()
    for (entry in json.decodeToSequence(input, serializer, DecodeSequenceMode.ARRAY_WRAPPED)) {
        result.add(map(entry))
        onEntry(result.size)
    }
    return result
}
