from pathlib import Path
import subprocess, json, hashlib, zipfile, collections
import xml.etree.ElementTree as ET
from PIL import Image
from io import BytesIO

root=Path(__file__).resolve().parent
p=root/'fire-project/ShadowFoxTV_Movies_Series'
apk=p/'app/build/outputs/apk/release/app-release.apk'
bt=root/'fire-toolchain/android-sdk/build-tools/34.0.0'
def run(*args): return subprocess.check_output(list(map(str,args)),text=True)
badging=run(bt/'aapt','dump','badging',apk)
assert "name='ca.shadowfoxtv.movieseries' versionCode='7' versionName='0.2.5'" in badging
assert "sdkVersion:'25'" in badging
assert 'launchable-activity:' in badging and 'leanback-launchable-activity:' in badging
assert "'armeabi-v7a'" in badging
manifest=run(bt/'aapt','dump','xmltree',apk,'AndroidManifest.xml')
assert 'android.intent.category.LAUNCHER' in manifest and 'android.intent.category.LEANBACK_LAUNCHER' in manifest
sig=run(bt/'apksigner','verify','--min-sdk-version','25','--max-sdk-version','25','--verbose','--print-certs',apk)
signer='c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90'
assert signer in sig
def pngs(path):
    out=collections.Counter()
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for n in z.namelist():
            if n.endswith('.png'):
                im=Image.open(BytesIO(z.read(n))).convert('RGBA')
                raw=bytearray(im.tobytes())
                for i in range(0,len(raw),4):
                    if raw[i+3]==0: raw[i:i+3]=b'\0\0\0'
                out[(im.size,hashlib.sha256(raw).hexdigest())]+=1
    return out
assert hashlib.sha256((root/'fire-reference-v024.apk').read_bytes()).hexdigest()=='760da6fed62a51f1f0ed210059dbd57543919c275b1a721c534bb9b6df3a97f5'
assert pngs(apk)==pngs(root/'fire-reference-v024.apk'), 'Embedded PNG artwork changed'
with zipfile.ZipFile(apk) as z:
    dex=b''.join(z.read(n) for n in z.namelist() if n.endswith('.dex'))
    for name in [b'index_channels_type_sortIndex',b'index_channels_type_groupTitle_sortIndex',b'Lj$/time/']: assert name in dex
tests=[ET.parse(f).getroot() for f in (p/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml')]
assert tests
counts={a:sum(int(t.attrib.get(a,0)) for t in tests) for a in ['tests','failures','errors','skipped']}
assert counts['failures']==counts['errors']==0
lint={}
for v in ['debug','release']:
    issues=ET.parse(p/f'app/build/reports/lint-results-{v}.xml').getroot().findall('issue')
    lint[v]=dict(collections.Counter(x.attrib['severity'] for x in issues))
    assert not any(x.attrib['severity'] in ['Error','Fatal'] for x in issues)
    assert not any(x.attrib['id']=='NewApi' for x in issues)
out=root/'release-0.2.5'; out.mkdir(exist_ok=True)
target=out/'ShadowFoxTV-Movies-Series-0.2.5.apk';target.write_bytes(apk.read_bytes())
report={'packageName':'ca.shadowfoxtv.movieseries','versionCode':7,'versionName':'0.2.5','minSdk':25,
 'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'sizeBytes':target.stat().st_size,
 'signerSha256':signer,'api25SignatureVerification':'PASS','armeabiV7a':True,
 'mobileLauncher':True,'tvLauncher':True,'embeddedPngsMatchV024':True,
 'performanceIndexesPresent':True,'desugaredDateTimeClassesPresent':True,
 'unitTests':counts,'lint':lint,'physicalFirestickTested':False}
(out/'verification-v0.2.5.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'signature-v0.2.5.txt').write_text(sig)
print(json.dumps(report,indent=2))
