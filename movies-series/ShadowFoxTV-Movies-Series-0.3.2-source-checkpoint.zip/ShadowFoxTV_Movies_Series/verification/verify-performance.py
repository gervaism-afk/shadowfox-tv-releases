from pathlib import Path
import json,sqlite3,re,time,statistics,hashlib
b=Path('/workspace/scratch/64ea90a8f114');p=b/'performance-project/ShadowFoxTV_Movies_Series';src=p/'app/src/main/java/nl/vanvrouwerff/iptv';v=p/'verification';v.mkdir(exist_ok=True)
schema=json.loads((p/'app/schemas/nl.vanvrouwerff.iptv.data.db.IptvDatabase/17.json').read_text())['database'];db=sqlite3.connect(b/'performance-expanded.sqlite');db.execute('PRAGMA journal_mode=WAL')
for e in schema['entities']:
 db.execute(e['createSql'].replace('${TABLE_NAME}',e['tableName']))
 for idx in e['indices']:db.execute(idx['createSql'].replace('${TABLE_NAME}',e['tableName']))
db.executemany('INSERT INTO channels VALUES (?,?,?,?,?,?,?,?,?,?)',((f'id-{i}', ('100%_literal\\ title' if i%997==0 else f'Title {i:06d}'), None, (None if i%101==0 else 'XXX Adult' if i%97==0 else f'Category {i%200:03d}'), 'https://example.invalid/video.mp4',None,i,'SERIES' if i%10==0 else 'MOVIE',1700000000000,0) for i in range(254000)))
db.executemany('INSERT INTO profiles(id,name,colorArgb,sortIndex,createdAt,isKids) VALUES(?,?,?,?,?,?)',[('default','Default',0,0,1,0),('kids','Kids',0,1,1,1)])
db.executemany('INSERT INTO favorites(profileId,channelId,addedAt,position) VALUES(?,?,?,?)',[('default',f'id-{i}',1,i) for i in range(0,254000,997)]+[('kids',f'id-{i}',1,i) for i in range(1,254000,1013)])
db.execute("INSERT INTO watch_progress VALUES ('default','id-1',12345,90000,1)");db.execute("INSERT INTO watchlist VALUES ('default','id-2',1)");db.commit()
def digest_tables():
 return {e['tableName']:hashlib.sha256(repr(db.execute('SELECT * FROM '+e['tableName']+' ORDER BY rowid').fetchall()).encode()).hexdigest() for e in schema['entities']}
before=digest_tables()
source=(src/'data/db/ChannelDao.kt').read_text();generic=re.findall(r'@Query\("""(.*?)"""\)',source,re.S)[:2]
page,count=generic;params={'type':'MOVIE','category':None,'pattern':'%%','saved':0,'profileId':'default','kids':0,'limit':60,'offset':0}
def bench(sql,args,n=9):
 times=[]
 for _ in range(n):
  t=time.perf_counter();rows=db.execute(sql,args).fetchall();times.append((time.perf_counter()-t)*1000)
 return {'medianMs':round(statistics.median(times),3),'maxMs':round(max(times),3),'rows':len(rows),'plan':[x[3] for x in db.execute('EXPLAIN QUERY PLAN '+sql,args)]}
base={'firstPage':bench(page,params),'deepPage':bench(page,dict(params,offset=60000)),'count':bench(count,params)}
ddl=(src/'data/db/IptvDatabase.kt').read_text().split('private val MIGRATION_17_18',1)[1].split('/** v15',1)[0];statements=re.findall(r'db.execSQL\("([^"\n]+)"\)',ddl);assert len(statements)==2
for sql in statements:db.execute(sql)
db.commit();assert digest_tables()==before
fast=re.findall(r'@Query\("([^"\n]+)"\)\s*fun observe(?:Plain|Category)Library(?:Page|Count)',source);assert len(fast)==4;plain,category,plain_count,category_count=fast
scenarios=0
for typ in ['MOVIE','SERIES']:
 for cat in [None,'Category 001','XXX Adult','Not present']:
  for offset in [0,60,60000]:
   args=dict(params,type=typ,category=cat,offset=offset);sql=plain if cat is None else category;cnt=plain_count if cat is None else category_count
   assert db.execute(page,args).fetchall()==db.execute(sql,args).fetchall()
   assert db.execute(count,args).fetchall()==db.execute(cnt,args).fetchall();scenarios+=1
# The protected/general path stays exact for search, literal wildcards, saved profiles and kids.
for typ in ['MOVIE','SERIES']:
 for pattern in ['%Title 000%','%100\\%\\_literal\\\\%','%%']:
  for saved in [0,1]:
   for kids in [0,1]:
    for profile in ['default','kids']:
     for protected_category in [None, 'Category 001']:
      args=dict(params,type=typ,pattern=pattern,saved=saved,kids=kids,profileId=profile,category=protected_category)
      rows=db.execute(page,args).fetchall();cnt=db.execute(count,args).fetchone()[0]
      assert len(rows)<=60 and cnt>=len(rows)
      for row in rows:
       if saved:assert db.execute('SELECT COUNT(*) FROM favorites WHERE profileId=? AND channelId=?',(profile,row[0])).fetchone()[0]==1
       if kids:assert not any(t in (row[3] or '').lower() for t in ['adult','xxx','18+','porn'])
      scenarios+=1
new={'firstPage':bench(plain,params),'deepPage':bench(plain,dict(params,offset=60000)),'categoryPage':bench(category,dict(params,category='Category 001')),'count':bench(plain_count,params)}
for name in ['firstPage','deepPage','categoryPage']:assert not any('TEMP B-TREE' in plan for plan in new[name]['plan'])
report={'version':'0.2.3','datasetRows':254000,'noLiveChannels':True,'environment':'Host SQLite '+sqlite3.sqlite_version+'; not Tanix timings','migrationStatements':statements,'migrationAllTablesPreserved':True,'queryScenariosPassed':scenarios,'baseline':base,'releaseQueries':new,'physicalDeviceConnected':False}
(v/'performance-v0.2.3.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
