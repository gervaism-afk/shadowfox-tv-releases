from pathlib import Path
import subprocess, os, json, hashlib, zipfile, collections
import xml.etree.ElementTree as ET
from PIL import Image
from io import BytesIO

root=Path('/workspace/scratch/64ea90a8f114')
p=root/'performance-project/ShadowFoxTV_Movies_Series'
apk=p/'app/build/outputs/apk/release/app-release.apk'
bt=root/'toolchain/android-sdk/build-tools/34.0.0'
env=os.environ.copy(); env['JAVA_HOME']=str(root/'toolchain/jdk-17.0.20.1+1')
def run(*args): return subprocess.check_output(list(map(str,args)),env=env,text=True)
badging=run(bt/'aapt','dump','badging',apk)
assert "name='ca.shadowfoxtv.movieseries' versionCode='6' versionName='0.2.4'" in badging
assert 'launchable-activity:' in badging and 'leanback-launchable-activity:' in badging
manifest=run(bt/'aapt','dump','xmltree',apk,'AndroidManifest.xml')
assert 'android.intent.category.LAUNCHER' in manifest and 'android.intent.category.LEANBACK_LAUNCHER' in manifest
sig=run(bt/'apksigner','verify','--print-certs',apk)
signer='c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90'
assert signer in sig
def pngs(path):
    out=collections.Counter()
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for n in z.namelist():
            if n.endswith('.png'):
                im=Image.open(BytesIO(z.read(n))).convert('RGBA')
                raw=bytearray(im.tobytes())
                for i in range(0,len(raw),4):
                    if raw[i+3]==0: raw[i:i+3]=b'\0\0\0'
                out[(im.size,hashlib.sha256(raw).hexdigest())]+=1
    return out
assert pngs(apk)==pngs(root/'recovered-v023.apk'), 'Embedded PNG artwork changed'
with zipfile.ZipFile(apk) as z:
    dex=b''.join(z.read(n) for n in z.namelist() if n.endswith('.dex'))
    for name in [b'index_channels_type_sortIndex',b'index_channels_type_groupTitle_sortIndex']: assert name in dex
tests=[ET.parse(f).getroot() for f in (p/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml')]
assert tests
counts={a:sum(int(t.attrib.get(a,0)) for t in tests) for a in ['tests','failures','errors','skipped']}
assert counts['failures']==counts['errors']==0
lint={}
for v in ['debug','release']:
    issues=ET.parse(p/f'app/build/reports/lint-results-{v}.xml').getroot().findall('issue')
    lint[v]=dict(collections.Counter(x.attrib['severity'] for x in issues))
    assert not any(x.attrib['severity'] in ['Error','Fatal'] for x in issues)
out=root/'release-0.2.4'; out.mkdir(exist_ok=True)
target=out/'ShadowFoxTV-Movies-Series-0.2.4.apk';target.write_bytes(apk.read_bytes())
report={'packageName':'ca.shadowfoxtv.movieseries','versionCode':6,'versionName':'0.2.4',
 'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'sizeBytes':target.stat().st_size,
 'signerSha256':signer,'mobileLauncher':True,'tvLauncher':True,'embeddedPngsMatchV023':True,
 'performanceIndexesPresent':True,'unitTests':counts,'lint':lint,'physicalDeviceTested':False}
(out/'verification-v0.2.4.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
