# ShadowFoxTV Movies & Series — Tanix preview v0.2.0

Android TV 10+; package ca.shadowfoxtv.movieseries; versionCode 2. Separate from Platinum Player and Ultra Cleaner. SERFF baseline commit 47052277b56fcf57791749f7b61bbdd0e82a0e09; Apache 2.0 licence retained.

User reported random crashes, crashes during library loading, slow performance and an unattractive UI on a Tanix box. No Tanix crash log or screenshot was supplied, so the original crash cause is not confirmed.

Changes:
- Replaced the active home screen with a clean dark poster library, Movies/Series tabs, category sidebar, search, My List and explicit paging. Room returns at most 60 titles per page rather than holding tens of thousands of titles in eager UI flows. Query work runs off the main thread; cached titles remain browseable during refresh.
- Stream-decode catalogue entries directly into domain records, without retaining complete movie/series DTO lists. Report progress during imports. Parsing/request failures do not replace the library with a silently empty success; cancellation and fatal VM errors are not swallowed.
- Database insertion adjusts timestamps in batches of 256 instead of copying the entire catalogue again. Transactional replacement and added-at values remain intact.
- Poster requests use explicit 240x360 sizing and no crossfade. Image memory cache reduced from 64 MB to 16 MB.
- Playback buffer limited to 12 MB with 5-15 second time targets. Trailer autoplay, tunneled AV sync and automatic frame-rate switching default off; a one-time migration applies the conservative defaults to existing installations. User may re-enable playback options in Settings.
- Playback activity launch deferred until after remote key dispatch; poster focus restored when returning from details.
- Private, credential-redacted Java crash capture. After a captured crash, home offers Crash details. Native crashes and OS process kills may not produce a Java report.
- Optimised release-mode APK removes unused code/resources and debug HTTP logging. Same preview signing key and database schema allow an in-place update from v0.1.0 without clearing login or watch progress. Production signing remains pending.

Validation: assembleDebug, testDebugUnitTest, lintDebug, assembleRelease and lintRelease succeeded. 81 unit tests passed with no failures or skips. Added 25,000-item catalogue parsing, empty/malformed catalogue and literal wildcard search tests. Actual Room SQL exercised through SQLite for page/count/filter correctness. Debug and release lint have zero errors. APK v2 signature, version, package, Android TV launcher and ARM 32/64-bit native support verified. No physical Tanix test or provider playback test was possible here.

APK bytes: 9381434
APK SHA-256: 0f2f4fb577b48df032ae6aebf3179ad2ee83e50e865da4e2acaa608ecd2b482d
Signing certificate SHA-256: c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90

Build with a full JDK 17, SDK platform/build-tools 34, and sdk.dir in local.properties. Run ./gradlew testDebugUnitTest lintDebug assembleRelease lintRelease. Output: app/build/outputs/apk/release/app-release.apk. The included signing key is for previews only, with standard Android debug credentials. The R8 mapping needed to interpret optimised crash reports is preserved in verification/mapping-v0.2.0.txt.

Next verification: install over the old APK on the Tanix; check large library loading, category/search paging, remote navigation/back, movie and episode playback, My List, and resume progress. Crash resolution is not confirmed until that device test.
