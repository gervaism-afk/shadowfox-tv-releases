package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.tv.material3.MaterialTheme
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "land-w960dp-h540dp-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class HomeScreenTest {
    @get:Rule val compose = androidx.compose.ui.test.junit4.createComposeRule()
    private fun sample(id: String, title: String, color: Int, type: ContentType): HomeItem {
        val bitmap = Bitmap.createBitmap(720, 1080, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, 720f, 1080f, intArrayOf(0xFF111625.toInt(), color, 0xFF06060E.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, 720f, 1080f, paint)
        paint.shader = null; paint.color = 0x6FFFFFFF; canvas.drawCircle(430f, 360f, 230f, paint)
        paint.color = 0xFF101728.toInt(); canvas.drawCircle(370f, 320f, 210f, paint)
        paint.color = 0xFFFFFFFF.toInt(); paint.textSize = 52f; canvas.drawText(title.uppercase(), 48f, 890f, paint)
        paint.textSize = 20f; canvas.drawText("SAMPLE ARTWORK · LAYOUT PREVIEW", 48f, 945f, paint)
        val file = File.createTempFile("poster-$id", ".png"); file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
        return HomeItem(Channel(id, title, file.toURI().toString(), "Drama", null, null, type))
    }
    @Test fun navigationSupportsTouchAndDpadAndRendersPreview() {
        val movies = listOf(sample("one", "Midnight Atlas", 0xFF245885.toInt(), ContentType.MOVIE),
            sample("two", "Northward", 0xFF70515F.toInt(), ContentType.MOVIE), sample("three", "Still Water", 0xFF315C58.toInt(), ContentType.MOVIE))
        val series = listOf(sample("four", "After Hours", 0xFF725D38.toInt(), ContentType.SERIES))
        var chosen: HomeSection? = null
        compose.setContent { MaterialTheme { HomeScreen(HomeState("sample", movies, series, movies.take(2), listOf(movies.first().copy(progress = 0.36f, caption = "Continue movie")), false),
            onSection = { chosen = it }, onSettings = {}, onDetail = { _, _ -> }, onPlay = {}) } }
        compose.onNodeWithText("Movies").performTouchInput { click() }
        compose.runOnIdle { assertEquals(HomeSection.MOVIES, chosen) }
        compose.onNodeWithText("Series").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Series").performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertEquals(HomeSection.SERIES, chosen) }
        Thread.sleep(1_000)
        compose.waitForIdle()
        val output = File(System.getProperty("shadowfox.preview.path", "build/ui-preview.png"))
        output.parentFile.mkdirs()
        output.outputStream().use { compose.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
