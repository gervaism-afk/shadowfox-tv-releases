UI preview 0.3.0/code12 based on verified v0.2.9. BUILD AND TESTS PENDING. Stable updater feed remains v0.2.9.
