package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.MaterialTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w360dp-h800dp-port-xhdpi")
class HomePhoneNavigationTest {
    @get:Rule val compose = createComposeRule()

    @Test fun phoneCanReachAndTapSettings() {
        var settings = 0
        compose.setContent { MaterialTheme {
            HomeScreen(HomeState(loading = false), onSection = {}, onSettings = { settings++ },
                onDetail = { _, _ -> }, onPlay = {})
        } }
        compose.onNodeWithText("Settings").performScrollTo().assertIsDisplayed().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, settings) }
    }
}
