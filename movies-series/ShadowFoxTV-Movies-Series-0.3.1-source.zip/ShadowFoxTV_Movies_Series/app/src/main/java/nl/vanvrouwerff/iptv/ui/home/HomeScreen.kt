package nl.vanvrouwerff.iptv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.foundation.lazy.list.items
import androidx.tv.foundation.lazy.list.rememberTvLazyListState
import androidx.tv.material3.*
import coil.compose.AsyncImage
import coil.request.ImageRequest
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.ui.library.LibraryScreen
import nl.vanvrouwerff.iptv.ui.library.LibraryViewModel

private val Night = Color(0xFF08080B)
private val Tile = Color(0xFF18181E)
private val Secondary = Color(0xFFABABB7)

@Composable
internal fun ShadowFoxBrowseScreen(onOpenSettings: () -> Unit, onOpenDetail: (Channel) -> Unit, onPlay: (Channel) -> Unit,
    vm: LibraryViewModel = viewModel(), home: HomeViewModel = viewModel()) {
    if (vm.browseSection == HomeSection.HOME) {
        val state by home.state.collectAsState()
        HomeScreen(state, onSection = { section ->
            vm.rememberSearch()
            when (section) {
                HomeSection.MOVIES -> { vm.selectType(ContentType.MOVIE); vm.searchOpen = false }
                HomeSection.SERIES -> { vm.selectType(ContentType.SERIES); vm.searchOpen = false }
                HomeSection.SEARCH -> vm.searchOpen = true
                HomeSection.HOME -> Unit
            }
            vm.browseSection = section
        }, onSettings = onOpenSettings,
            onDetail = { channel, rail -> home.beforeDetail(if (rail == "featured") null else "$rail:${channel.id}"); onOpenDetail(channel) }, onPlay = onPlay,
            restoreId = remember { home.takeReturnFocus() })
    } else {
        BackHandler { vm.rememberSearch(); vm.browseSection = HomeSection.HOME }
        LibraryScreen(onOpenSettings, onOpenDetail, onOpenHome = { vm.rememberSearch(); vm.browseSection = HomeSection.HOME }, vm = vm)
    }
}

@Composable
internal fun HomeScreen(state: HomeState, onSection: (HomeSection) -> Unit, onSettings: () -> Unit,
    onDetail: (Channel, String) -> Unit, onPlay: (Channel) -> Unit, restoreId: String? = null) {
    val featured = state.movies.firstOrNull()?.channel ?: state.series.firstOrNull()?.channel
    var pendingFocus by remember(restoreId, state.profile) { mutableStateOf(restoreId) }
    val sections = listOf("Continue Watching" to state.continuing, "My List" to state.saved,
        "Movies for your evening" to state.movies, "Series to settle into" to state.series).filter { it.second.isNotEmpty() }
    val scroll = rememberTvLazyListState()
    val compact = LocalConfiguration.current.screenWidthDp < 600
    val navigationScroll = rememberScrollState()
    LaunchedEffect(pendingFocus, sections) {
        val row = sections.indexOfFirst { (rail, entries) -> entries.any { "$rail:${it.channel.id}" == pendingFocus } }
        if (pendingFocus != null && row >= 0) scroll.scrollToItem(row + 1)
    }
    Column(Modifier.fillMaxSize().background(Night)) {
        Row(Modifier.fillMaxWidth().then(if (compact) Modifier.horizontalScroll(navigationScroll) else Modifier)
            .padding(horizontal = 30.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Image(painterResource(R.drawable.shadowfox_cutout), "ShadowFoxTV", Modifier.size(38.dp))
            Column { Text("ShadowFoxTV", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("MOVIES & SERIES", color = Secondary, fontSize = 8.sp, letterSpacing = 2.sp) }
            Spacer(Modifier.weight(1f))
            HomeTab("Home", true) { onSection(HomeSection.HOME) }
            HomeTab("Movies", false) { onSection(HomeSection.MOVIES) }
            HomeTab("Series", false) { onSection(HomeSection.SERIES) }
            HomeTab("Search", false) { onSection(HomeSection.SEARCH) }
            Spacer(Modifier.weight(1f))
            HomeTab("Settings", false, onSettings)
        }
        TvLazyColumn(state = scroll, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(26.dp),
            contentPadding = PaddingValues(bottom = 36.dp)) {
            item(key = "featured") {
                FeaturedTitle(featured, state.loading, { onDetail(it, "featured") }, onPlay) { onSection(HomeSection.MOVIES) }
                state.error?.let { Text(it, Modifier.padding(horizontal = 34.dp, vertical = 12.dp), color = Secondary, fontSize = 13.sp) }
            }
            items(sections, key = { it.first }) { (title, entries) ->
                HomeRail(title, entries, title == "Continue Watching", pendingFocus?.takeIf { it.startsWith("$title:") }?.removePrefix("$title:"),
                    onRestored = { pendingFocus = null }, onDetail = { onDetail(it, title) })
            }
            if (!state.loading && sections.isEmpty() && state.error == null) item {
                Text("Open Movies or Series to refresh your library or check your account in Settings.",
                    Modifier.padding(horizontal = 34.dp), color = Secondary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun FeaturedTitle(channel: Channel?, loading: Boolean, onDetail: (Channel) -> Unit, onPlay: (Channel) -> Unit, onBrowse: () -> Unit) {
    val context = LocalContext.current
    Box(Modifier.padding(horizontal = 28.dp).fillMaxWidth().height(278.dp).clip(RoundedCornerShape(18.dp)).background(Tile)) {
        if (channel?.logoUrl != null) AsyncImage(
            model = remember(channel.logoUrl) { ImageRequest.Builder(context).data(channel.logoUrl).size(960, 560).crossfade(false).build() },
            contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxHeight().fillMaxWidth(0.65f).align(Alignment.CenterEnd))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF101016), Color(0xEE101016), Color(0x18101016)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xA8101016)))))
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.59f).padding(30.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text("YOUR FRONT ROW", color = Color(0xFFCACAD2), fontSize = 10.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Medium)
            Text(channel?.name ?: if (loading) "Welcome back." else "Your next watch awaits.", color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = 32.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 36.sp)
            Text(channel?.let { (if (it.type == ContentType.MOVIE) "Movie" else "Series") + (it.groupTitle?.let { group -> "  ·  $group" } ?: "") }
                ?: "All your movies and series. One place to enjoy them.", color = Secondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction(onClick = { if (channel == null) onBrowse() else if (channel.type == ContentType.MOVIE) onPlay(channel) else onDetail(channel) }, bright = true) {
                    Text(if (channel == null) "Explore movies" else if (channel.type == ContentType.MOVIE) "▶  Play" else "View episodes",
                        Modifier.padding(horizontal = 19.dp, vertical = 11.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF101014))
                }
                if (channel != null) HomeAction(onClick = { onDetail(channel) }) {
                    Text("Details", Modifier.padding(horizontal = 18.dp, vertical = 11.dp), fontSize = 13.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun HomeRail(title: String, entries: List<HomeItem>, wide: Boolean, restoreId: String?, onRestored: () -> Unit, onDetail: (Channel) -> Unit) {
    val row = rememberTvLazyListState()
    LaunchedEffect(restoreId, entries) {
        val index = entries.indexOfFirst { it.channel.id == restoreId }
        if (index >= 0) row.scrollToItem(index)
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, Modifier.padding(horizontal = 34.dp), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        TvLazyRow(state = row, contentPadding = PaddingValues(horizontal = 28.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(15.dp)) {
            items(entries, key = { it.channel.id }) { entry ->
                HomePoster(entry, wide, restoreId == entry.channel.id, onRestored) { onDetail(entry.channel) }
            }
        }
    }
}

@Composable
private fun HomePoster(entry: HomeItem, wide: Boolean, restore: Boolean, onRestored: () -> Unit, onClick: () -> Unit) {
    val context = LocalContext.current
    val requester = remember(entry.channel.id) { FocusRequester() }
    LaunchedEffect(restore) { if (restore) { withFrameNanos { }; try { requester.requestFocus(); onRestored() } catch (_: IllegalStateException) { } } }
    Column(Modifier.width(if (wide) 220.dp else 132.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        HomeAction(onClick, Modifier.fillMaxWidth().focusRequester(requester)) {
            Box(Modifier.fillMaxWidth().aspectRatio(if (wide) 16f / 9 else 2f / 3).background(Tile), contentAlignment = Alignment.Center) {
                if (entry.channel.logoUrl != null) AsyncImage(
                    model = remember(entry.channel.logoUrl, wide) { ImageRequest.Builder(context).data(entry.channel.logoUrl)
                        .size(if (wide) 440 else 264, if (wide) 248 else 396).crossfade(false).build() },
                    contentDescription = entry.channel.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                else Text(if (entry.channel.type == ContentType.MOVIE) "MOVIE" else "SERIES", color = Secondary, fontSize = 11.sp, letterSpacing = 2.sp)
                if (entry.progress > 0f) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0xFF484852))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(entry.progress.coerceIn(0f, 1f)).background(Color.White))
                }
            }
        }
        Text(entry.channel.name, color = Color(0xFFE5E5EA), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (wide) Text(entry.caption ?: "Continue watching", color = Secondary, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HomeTab(label: String, selected: Boolean, onClick: () -> Unit) {
    HomeAction(onClick, bright = selected) {
        Text(label, Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = if (selected) Night else Color(0xFFD0D0D8),
            fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HomeAction(onClick: () -> Unit, modifier: Modifier = Modifier, bright: Boolean = false, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val click by rememberUpdatedState(onClick)
    val shape = RoundedCornerShape(10.dp)
    Surface(onClick = onClick, modifier = modifier.onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(2.dp, Color.White, shape) else Modifier)
        .pointerInput(Unit) { detectTapGestures(onTap = { click() }) },
        shape = ClickableSurfaceDefaults.shape(shape), scale = ClickableSurfaceDefaults.scale(focusedScale = 1.025f),
        colors = ClickableSurfaceDefaults.colors(containerColor = if (bright) Color.White else Color(0xFF27272F),
            contentColor = if (bright) Night else Color.White, focusedContainerColor = if (bright) Color.White else Color(0xFF444450), focusedContentColor = Color.White), content = content)
}
