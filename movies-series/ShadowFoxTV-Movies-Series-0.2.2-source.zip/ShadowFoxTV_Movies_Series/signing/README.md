The official preview keystore is private and is excluded from public source downloads.
Use your original compatible key to produce installable updates. A newly generated key cannot replace the installed official app.
