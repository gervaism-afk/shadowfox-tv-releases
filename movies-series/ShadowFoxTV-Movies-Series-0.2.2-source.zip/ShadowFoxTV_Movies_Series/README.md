# ShadowFoxTV Movies & Series

Standalone Android TV movies and series player for user-supplied Xtream Codes accounts. No content or account credentials are bundled. Package: `ca.shadowfoxtv.movieseries`. Android TV 10+.

v0.2.2 (version code 4) adds the final Movies & Series Android TV artwork and a verified in-app updater while retaining the v0.2.0 Tanix stability improvements. See [UPDATER_HANDOFF.md](UPDATER_HANDOFF.md) for build, signing and updater details, and [verification/release-v0.2.2.json](verification/release-v0.2.2.json) for final build verification. Original upstream documentation and Apache 2.0 licence are retained in README_SERFF.md and LICENSE.

Use JDK 17, Gradle 8.7 and Android SDK 34. Set `sdk.dir` in private `local.properties`, then run:

```sh
./gradlew assembleRelease testDebugUnitTest lintDebug lintRelease
```

Install the signed APK over the existing app without uninstalling. v0.2.0 needs this one manual bootstrap because it has no updater. Later versions are checked at launch and in Settings > App updates.

Public source downloads exclude the official signing key and local.properties. A build with a new key cannot replace the installed official app; use the compatible privately held key for releases. Physical Tanix playback and installation testing remain to be completed.
