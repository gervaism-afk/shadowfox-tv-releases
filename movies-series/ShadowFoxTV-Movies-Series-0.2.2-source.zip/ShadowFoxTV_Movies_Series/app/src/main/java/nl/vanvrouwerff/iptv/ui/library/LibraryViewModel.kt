package nl.vanvrouwerff.iptv.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.db.toDomain

internal const val LIBRARY_PAGE_SIZE = 60
internal data class LibrarySelection(
    val type: ContentType = ContentType.MOVIE,
    val category: String? = null,
    val query: String = "",
    val saved: Boolean = false,
    val page: Int = 0,
)
internal data class LibraryState(
    val selection: LibrarySelection = LibrarySelection(),
    val items: List<Channel> = emptyList(),
    val categories: List<String> = emptyList(),
    val count: Int = 0,
    val loading: Boolean = true,
    val error: String? = null,
)
internal fun librarySearchPattern(query: String): String =
    "%${query.trim().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")}%"

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class LibraryViewModel : ViewModel() {
    private val app = IptvApp.get()
    private val dao = app.database.channelDao()
    private val selection = MutableStateFlow(LibrarySelection())
    val refreshing = app.refreshUseCase.refreshing
    val progress = app.refreshUseCase.progress
    val refreshError = app.refreshUseCase.lastError

    internal val state: StateFlow<LibraryState> = combine(
        selection.debounce(180), app.activeProfileId, app.kidsMode,
    ) { s, profile, kids -> Triple(s, profile, kids) }.flatMapLatest { (s, profile, kids) ->
        val pattern = librarySearchPattern(s.query)
        combine(
            dao.observeLibraryPage(s.type.name, s.category, pattern, s.saved, profile,
                kids, LIBRARY_PAGE_SIZE, s.page * LIBRARY_PAGE_SIZE),
            dao.observeLibraryCount(s.type.name, s.category, pattern, s.saved, profile, kids),
            dao.observeGroupTitlesByType(s.type.name),
        ) { rows, count, cats ->
            val lastPage = ((count - 1).coerceAtLeast(0) / LIBRARY_PAGE_SIZE)
            if (s.page > lastPage) selection.update { it.copy(page = lastPage) }
            LibraryState(s, rows.map { it.toDomain() },
                cats.filterNotNull().filterNot { kids && AdultContent.isAdultCategory(it) }, count, false)
        }.catch { emit(LibraryState(selection = s, loading = false, error = "Could not read library. Try refreshing.")) }
    }.flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(0), LibraryState())

    init {
        viewModelScope.launch {
            val last = app.settings.lastRefreshSuccessAt.first()
            if (last == 0L || System.currentTimeMillis() - last > 6 * 3_600_000L) refresh()
        }
    }
    internal var focusedId: String? = null
    internal var focusedIndex: Int = 0
    fun rememberFocus(id: String, index: Int) { focusedId = id; focusedIndex = index }

    fun selectType(type: ContentType) { focusedId = null; focusedIndex = 0; selection.value = LibrarySelection(type = type) }
    fun selectCategory(value: String?) { selection.update { it.copy(category = value, page = 0) } }
    fun search(value: String) { selection.update { it.copy(query = value, page = 0) } }
    fun saved() { selection.update { it.copy(saved = !it.saved, page = 0) } }
    fun page(delta: Int) { selection.update { it.copy(page = (it.page + delta).coerceAtLeast(0)) } }
    fun refresh() {
        if (!refreshing.value) app.appScope.launch { app.refreshUseCase(force = true) }
    }
}
