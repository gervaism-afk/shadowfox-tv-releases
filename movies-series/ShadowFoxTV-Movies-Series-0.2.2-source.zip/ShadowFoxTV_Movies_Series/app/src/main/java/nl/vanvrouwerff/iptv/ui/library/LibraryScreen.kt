package nl.vanvrouwerff.iptv.ui.library

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.grid.TvGridCells
import androidx.tv.foundation.lazy.grid.TvLazyVerticalGrid
import androidx.tv.foundation.lazy.grid.itemsIndexed
import androidx.tv.foundation.lazy.grid.rememberTvLazyGridState
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.items
import androidx.tv.material3.*
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import nl.vanvrouwerff.iptv.CrashCapture
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType

private val Ink = Color(0xFF080E19)
private val Panel = Color(0xFF101C2C)
private val Ice = Color(0xFF76CCFF)

/** Bounded, poster-first TV library. No rotating hero, WebView or whole-catalogue StateFlow. */
@Composable
fun LibraryScreen(
    onOpenSettings: () -> Unit,
    onOpenDetail: (Channel) -> Unit,
    vm: LibraryViewModel = viewModel(),
) {
    val updates by nl.vanvrouwerff.iptv.IptvApp.get().updates.state.collectAsState()
    val state by vm.state.collectAsState()
    val refreshing by vm.refreshing.collectAsState()
    val progress by vm.progress.collectAsState()
    val refreshError by vm.refreshError.collectAsState()
    var searchVisible by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val crash = remember { CrashCapture.summary(context) }
    val grid = rememberTvLazyGridState()
    val scope = rememberCoroutineScope()
    var crashVisible by remember { mutableStateOf(false) }
    val restoreId = remember { vm.focusedId }
    LaunchedEffect(state.selection, state.items.isEmpty()) {
        val index = state.items.indexOfFirst { it.id == restoreId }
        grid.scrollToItem(if (index >= 0) index else 0)
    }

    Column(Modifier.fillMaxSize().background(Ink).padding(horizontal = 28.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Image(painterResource(R.drawable.shadowfox_cutout), "ShadowFoxTV", Modifier.size(48.dp))
            Column(Modifier.width(174.dp)) {
                Text("ShadowFoxTV", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("MOVIES & SERIES", fontSize = 11.sp, color = Ice, letterSpacing = 1.3.sp)
            }
            LibraryChip("Movies", state.selection.type == ContentType.MOVIE) { vm.selectType(ContentType.MOVIE) }
            LibraryChip("Series", state.selection.type == ContentType.SERIES) { vm.selectType(ContentType.SERIES) }
            LibraryChip("My List", state.selection.saved, onClick = vm::saved)
            Spacer(Modifier.weight(1f))
            LibraryChip("Search", searchVisible) { searchVisible = !searchVisible; if (!searchVisible) vm.search("") }
            LibraryChip("Settings", false, onClick = onOpenSettings)
        }
        if (updates.release != null) LibraryChip("Update available — open Settings", false, onClick = onOpenSettings)
        Spacer(Modifier.height(18.dp))
        if (searchVisible) {
            OutlinedTextField(state.selection.query, vm::search,
                label = { androidx.compose.material3.Text("Search your library") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Column(Modifier.width(156.dp)) {
                Text("CATEGORIES", fontSize = 10.sp, letterSpacing = 1.5.sp, color = Ice)
                Spacer(Modifier.height(12.dp))
                TvLazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { LibraryChip("All titles", state.selection.category == null, Modifier.fillMaxWidth()) { vm.selectCategory(null) } }
                    items(state.categories.distinct(), key = { it }) { cat ->
                        LibraryChip(cat, state.selection.category == cat, Modifier.fillMaxWidth()) { vm.selectCategory(cat) }
                    }
                }
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(state.selection.category ?: if (state.selection.saved) "My List" else if (state.selection.type == ContentType.MOVIE) "Discover movies" else "Discover series",
                            color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (refreshing) "Loading ${progress?.stage?.name?.lowercase() ?: "library"} · ${progress?.count ?: 0} titles"
                            else "${state.count} titles in your library", color = Color(0xFF94A7BD), fontSize = 12.sp)
                    }
                    LibraryChip(if (refreshing) "Loading…" else "Refresh", false, onClick = vm::refresh)
                }
                Spacer(Modifier.height(12.dp))
                if (state.error != null || refreshError != null) {
                    Text(state.error ?: "Library refresh failed. Check your account or connection in Settings.", color = Color(0xFFFFB195), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                }
                if (state.loading || state.items.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(when { state.loading || refreshing -> "Preparing your library…"
                            state.selection.saved -> "Save a movie or series from its detail page."
                            else -> "No titles here. Try another category or refresh." }, color = Color(0xFF94A7BD), fontSize = 15.sp)
                    }
                } else {
                    TvLazyVerticalGrid(columns = TvGridCells.Fixed(5), state = grid,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        itemsIndexed(state.items, key = { _, it -> it.id }) { index, item ->
                            LibraryPoster(item, restoreFocus = item.id == restoreId,
                                onFocus = { vm.rememberFocus(item.id, index) }) {
                                scope.launch { yield(); onOpenDetail(item) }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (state.selection.page > 0) LibraryChip("Previous", false) { vm.page(-1) }
                    Text("Page ${state.selection.page + 1} of ${maxOf(1, (state.count + LIBRARY_PAGE_SIZE - 1) / LIBRARY_PAGE_SIZE)}", color = Color(0xFF94A7BD), fontSize = 12.sp)
                    if ((state.selection.page + 1) * LIBRARY_PAGE_SIZE < state.count) LibraryChip("Next", false) { vm.page(1) }
                    Spacer(Modifier.weight(1f))
                    Text("OK · Details", fontSize = 10.sp, color = Color(0xFF657D98))
                }
            }
        }
        if (crash != null) Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Previous crash: $crash", fontSize = 10.sp, color = Color(0xFF94A7BD))
            Spacer(Modifier.width(12.dp))
            LibraryChip("Crash details", false) { crashVisible = true }
        }
        if (crashVisible) androidx.compose.ui.window.Dialog(onDismissRequest = { crashVisible = false }) {
            Column(Modifier.background(Panel, RoundedCornerShape(12.dp)).padding(20.dp)) {
                Text("Crash report", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(remember { CrashCapture.report(context).orEmpty().take(2500) }, fontSize = 11.sp,
                    lineHeight = 15.sp, maxLines = 16, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                LibraryChip("Close", false) { crashVisible = false }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun LibraryChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Surface(onClick = onClick, modifier = modifier.onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(1.5.dp, Color.White, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = if (selected) Color(0xFF173C5B) else Panel,
            contentColor = if (selected) Ice else Color(0xFFC5D0DF), focusedContainerColor = Color(0xFF30465E), focusedContentColor = Color.White)) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun LibraryPoster(item: Channel, restoreFocus: Boolean, onFocus: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    val context = LocalContext.current
    val requester = remember(item.id) { FocusRequester() }
    LaunchedEffect(item.id, restoreFocus) {
        if (restoreFocus) {
            withFrameNanos { }
            try { requester.requestFocus() } catch (_: IllegalStateException) { }
        }
    }
    Surface(onClick = onClick, modifier = Modifier.fillMaxWidth().focusRequester(requester).onFocusChanged {
        focused = it.isFocused
        if (it.isFocused) onFocus()
    }
        .then(if (focused) Modifier.border(2.dp, Color.White, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape), scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = Panel, contentColor = Color.White,
            focusedContainerColor = Color(0xFF243C55), focusedContentColor = Color.White)) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(Panel), contentAlignment = Alignment.Center) {
                if (item.logoUrl != null) AsyncImage(
                    model = remember(item.logoUrl) { ImageRequest.Builder(context).data(item.logoUrl).size(240, 360).crossfade(false).build() },
                    contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                else Text(if (item.type == ContentType.MOVIE) "MOVIE" else "SERIES", color = Ice, fontSize = 11.sp)
            }
            Text(item.name, Modifier.padding(8.dp).height(32.dp), fontSize = 11.sp,
                lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
