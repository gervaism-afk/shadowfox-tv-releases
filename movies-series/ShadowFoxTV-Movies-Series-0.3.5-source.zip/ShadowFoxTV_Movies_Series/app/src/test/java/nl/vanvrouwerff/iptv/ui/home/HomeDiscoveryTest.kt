package nl.vanvrouwerff.iptv.ui.home

import org.junit.Assert.*
import org.junit.Test

class HomeDiscoveryTest {
    @Test fun everyAnchorIsVisitedBeforeRepeatingEvenForSmallCatalogues() {
        for (count in 2..64) {
            val offsets = (0L until count.toLong()).map { homeWindow(count, it, -173).offset }
            assertEquals("Catalogue size $count must not get stuck on one spotlight", count, offsets.toSet().size)
        }
    }

    @Test fun circularWindowsAreBoundedAndNeverDuplicateRows() {
        for (count in listOf(0, 1, 12, 24, 25, 31, 100, 50_000)) {
            for (generation in listOf(1L, 2L, 32L, Long.MAX_VALUE)) {
                val window = homeWindow(count, generation)
                assertEquals(minOf(count, HOME_ROW_LIMIT), window.tailCount + window.headCount)
                val indices = (window.offset until window.offset + window.tailCount).toList() + (0 until window.headCount)
                assertTrue(indices.all { it in 0 until count })
                assertEquals(indices.size, indices.toSet().size)
            }
        }
    }

    @Test fun largeCataloguesShowDifferentWindowsInsteadOfOnlyReorderingTheFirstPage() {
        val first = homeWindow(50_000, 1)
        val second = homeWindow(50_000, 2)
        assertTrue(first.offset >= HOME_ROW_LIMIT)
        assertTrue(second.offset - first.offset >= HOME_ROW_LIMIT)
    }

    @Test fun picksStayStableWithinAVisitAndKeepTheSpotlightAtTheFront() {
        val items = (0..20).toList()
        val picks = arrangeHomePicks(items, 12)
        assertEquals(0, picks.first())
        assertEquals(items.toSet(), picks.toSet())
        assertEquals(picks, arrangeHomePicks(items, 12))
        assertNotEquals(picks, arrangeHomePicks(items, 13))
    }
}
