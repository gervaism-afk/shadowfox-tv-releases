package nl.vanvrouwerff.iptv.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.ui.input.Surface

internal object Cinema {
    val Background = Color(0xFF090B10)
    val Surface = Color(0xFF171B23)
    val Raised = Color(0xFF232832)
    val Muted = Color(0xFFA9B0BE)
    val Accent = Color(0xFFE4BD8A)
    val Line = Color(0xFF303640)
    val Atmosphere = Brush.linearGradient(listOf(Color(0xFF24222A), Color(0xFF131A24), Background))
}

/** One navigation language for Home and the paged library, with a separate phone header. */
@Composable
internal fun CinemaNavigation(selected: String, onNavigate: (String) -> Unit) {
    val phone = LocalConfiguration.current.screenWidthDp < 600
    Column(Modifier.fillMaxWidth().padding(horizontal = if (phone) 20.dp else 32.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.shadowfox_cutout), "ShadowFoxTV", Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("ShadowFoxTV", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp)
                Text("MOVIES & SERIES", color = Cinema.Accent, fontSize = 8.sp, letterSpacing = 1.7.sp)
            }
            Spacer(Modifier.weight(1f))
            if (!phone) NavigationTabs(selected, onNavigate)
            Spacer(Modifier.width(if (phone) 8.dp else 20.dp))
            CinemaChip("Settings", selected == "Settings", onClick = { onNavigate("Settings") })
        }
        if (phone) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NavigationTabs(selected, onNavigate)
            }
        }
    }
}

@Composable
private fun NavigationTabs(selected: String, onNavigate: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("Home", "Movies", "Series", "My List", "Search").forEach { label ->
            CinemaChip(label, selected == label, onClick = { onNavigate(label) })
        }
    }
}

@Composable
internal fun CinemaChip(label: String, active: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val shape = RoundedCornerShape(50)
    Surface(onClick = onClick,
        modifier = modifier.heightIn(min = if (phone) 48.dp else 40.dp)
            .semantics { selected = active }.onFocusChanged { focused = it.isFocused }
            .then(if (focused) Modifier.border(1.5.dp, Color.White, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.025f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (active) Color(0xFFF1F0EB) else Color.Transparent,
            contentColor = if (active) Cinema.Background else Cinema.Muted,
            focusedContainerColor = if (active) Color.White else Cinema.Raised,
            focusedContentColor = if (active) Cinema.Background else Color.White)) {
        Box(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text(label, color = if (active) Cinema.Background else if (focused) Color.White else Cinema.Muted,
                fontSize = 12.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
