package nl.vanvrouwerff.iptv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.foundation.lazy.list.items
import androidx.tv.foundation.lazy.list.rememberTvLazyListState
import androidx.tv.material3.*
import coil.compose.AsyncImage
import coil.request.ImageRequest
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.ui.library.LibraryScreen
import nl.vanvrouwerff.iptv.ui.library.LibraryViewModel
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.CinemaNavigation

private val Night = Cinema.Background
private val Tile = Cinema.Surface
private val Secondary = Cinema.Muted

@Composable
internal fun ShadowFoxBrowseScreen(onOpenSettings: () -> Unit, onOpenDetail: (Channel) -> Unit, onPlay: (Channel) -> Unit,
    vm: LibraryViewModel = viewModel(), home: HomeViewModel = viewModel()) {
    if (vm.browseSection == HomeSection.HOME) {
        val state by home.state.collectAsState()
        HomeScreen(state, onSection = { section ->
            vm.rememberSearch()
            when (section) {
                HomeSection.MOVIES -> { vm.selectType(ContentType.MOVIE); vm.searchOpen = false }
                HomeSection.SERIES -> { vm.selectType(ContentType.SERIES); vm.searchOpen = false }
                HomeSection.SAVED -> { vm.showSaved(); vm.searchOpen = false }
                HomeSection.SEARCH -> vm.searchOpen = true
                HomeSection.HOME -> Unit
            }
            vm.browseSection = section
        }, onSettings = onOpenSettings,
            onDetail = { channel, rail -> home.beforeDetail(if (rail == "featured") null else "$rail:${channel.id}"); onOpenDetail(channel) }, onPlay = onPlay,
            restoreId = remember { home.takeReturnFocus() }, onRefreshPicks = home::refreshPicks)
    } else {
        BackHandler { vm.rememberSearch(); vm.browseSection = HomeSection.HOME }
        LibraryScreen(onOpenSettings, onOpenDetail, onOpenHome = { vm.rememberSearch(); vm.browseSection = HomeSection.HOME }, vm = vm)
    }
}

@Composable
internal fun HomeScreen(state: HomeState, onSection: (HomeSection) -> Unit, onSettings: () -> Unit,
    onDetail: (Channel, String) -> Unit, onPlay: (Channel) -> Unit, restoreId: String? = null,
    onRefreshPicks: () -> Unit = {}) {
    val featured = state.movies.firstOrNull()?.channel ?: state.series.firstOrNull()?.channel
    var pendingFocus by remember(restoreId, state.profile) { mutableStateOf(restoreId) }
    val sections = listOf("Continue Watching" to state.continuing, "My List" to state.saved,
        "Movies for your evening" to state.movies, "Series to settle into" to state.series).filter { it.second.isNotEmpty() }
    val scroll = rememberTvLazyListState()
    LaunchedEffect(pendingFocus, sections) {
        val row = sections.indexOfFirst { (rail, entries) -> entries.any { "$rail:${it.channel.id}" == pendingFocus } }
        if (pendingFocus != null && row >= 0) scroll.scrollToItem(row + 1)
    }
    Column(Modifier.fillMaxSize().background(Night)) {
        CinemaNavigation("Home") { label ->
            when (label) {
                "Settings" -> onSettings()
                "Movies" -> onSection(HomeSection.MOVIES)
                "Series" -> onSection(HomeSection.SERIES)
                "My List" -> onSection(HomeSection.SAVED)
                "Search" -> onSection(HomeSection.SEARCH)
                else -> onSection(HomeSection.HOME)
            }
        }
        TvLazyColumn(state = scroll, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(24.dp),
            contentPadding = PaddingValues(bottom = 40.dp)) {
            item(key = "featured") {
                FeaturedTitle(featured, state.loading, { onDetail(it, "featured") }, onPlay,
                    onBrowse = { onSection(HomeSection.MOVIES) }, onRefreshPicks = onRefreshPicks)
                state.error?.let { Text(it, Modifier.padding(horizontal = 34.dp, vertical = 12.dp), color = Secondary, fontSize = 13.sp) }
            }
            items(sections, key = { it.first }) { (title, entries) ->
                HomeRail(title, entries, title == "Continue Watching", pendingFocus?.takeIf { it.startsWith("$title:") }?.removePrefix("$title:"),
                    onRestored = { pendingFocus = null }, onDetail = { onDetail(it, title) })
            }
            if (!state.loading && sections.isEmpty() && state.error == null) item {
                Text("Open Movies or Series to refresh your library or check your account in Settings.",
                    Modifier.padding(horizontal = 34.dp), color = Secondary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun FeaturedTitle(channel: Channel?, loading: Boolean, onDetail: (Channel) -> Unit, onPlay: (Channel) -> Unit,
    onBrowse: () -> Unit, onRefreshPicks: () -> Unit) {
    val context = LocalContext.current
    val compact = LocalConfiguration.current.screenWidthDp < 600
    val shape = RoundedCornerShape(22.dp)
    Box(Modifier.padding(horizontal = if (compact) 16.dp else 28.dp).fillMaxWidth().height(if (compact) 364.dp else 316.dp)
        .clip(shape).background(Cinema.Atmosphere).border(1.dp, Color.White.copy(alpha = 0.07f), shape)) {
        if (channel?.logoUrl != null) AsyncImage(
            model = remember(channel.logoUrl) { ImageRequest.Builder(context).data(channel.logoUrl).size(960, 540).crossfade(false).build() },
            contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxHeight().fillMaxWidth(if (compact) 1f else 0.72f).align(Alignment.CenterEnd))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF10141B), Color(0xED10141B), Color(0x9910141B), Color(0x3310141B)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x2410141B), Color(0x5410141B), Color(0xFA10141B)))))
        if (!compact) {
            if (channel?.logoUrl != null) AsyncImage(
                model = remember(channel.logoUrl) { ImageRequest.Builder(context).data(channel.logoUrl).size(344, 516).crossfade(false).build() },
                contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 44.dp).size(160.dp, 240.dp)
                    .shadow(22.dp, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.17f), RoundedCornerShape(12.dp)))
            else Image(painterResource(R.drawable.shadowfox_cutout), null,
                Modifier.align(Alignment.CenterEnd).padding(end = 50.dp).size(150.dp))
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(if (compact) 1f else 0.63f).padding(if (compact) 22.dp else 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Box(Modifier.width(20.dp).height(2.dp).background(Cinema.Accent))
                Text(if (channel == null) "YOUR PRIVATE CINEMA" else "IN THE SPOTLIGHT", color = Cinema.Accent,
                    fontSize = 9.sp, letterSpacing = 2.5.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(channel?.name ?: if (loading) "Something great awaits." else "Your front row.\nEvery night.", color = Color.White,
                modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold, fontSize = if (compact) 30.sp else 37.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, letterSpacing = (-0.8).sp, lineHeight = if (compact) 34.sp else 41.sp)
            Text(channel?.let { (if (it.type == ContentType.MOVIE) "MOVIE" else "SERIES") + (it.groupTitle?.let { group -> "   ·   $group" } ?: "") }
                ?: "Your collection. Beautifully brought together.", color = Color(0xFFCDD2DC), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (channel == null) "Discover a new favourite, or pick up right where you left off." else "Settle in. Your next great watch is right here.",
                color = Secondary, fontSize = 12.sp, lineHeight = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            FlowRow(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction(modifier = Modifier.heightIn(min = 48.dp), onClick = { if (channel == null) onBrowse() else if (channel.type == ContentType.MOVIE) onPlay(channel) else onDetail(channel) }, bright = true) {
                    Text(if (channel == null) "Explore movies" else if (channel.type == ContentType.MOVIE) "▶  Play" else "View episodes",
                        Modifier.padding(horizontal = 19.dp, vertical = 11.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF101014))
                }
                if (channel != null) HomeAction(modifier = Modifier.heightIn(min = 48.dp), onClick = { onDetail(channel) }) {
                    Text("Details", Modifier.padding(horizontal = 18.dp, vertical = 11.dp), fontSize = 13.sp, color = Color.White)
                }
                if (channel != null) HomeAction(modifier = Modifier.heightIn(min = 48.dp), onClick = onRefreshPicks) {
                    Text("↻  New picks", Modifier.padding(horizontal = 16.dp, vertical = 11.dp), fontSize = 13.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun HomeRail(title: String, entries: List<HomeItem>, wide: Boolean, restoreId: String?, onRestored: () -> Unit, onDetail: (Channel) -> Unit) {
    val row = rememberTvLazyListState()
    LaunchedEffect(restoreId, entries) {
        val index = entries.indexOfFirst { it.channel.id == restoreId }
        if (index >= 0) row.scrollToItem(index)
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 30.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color(0xFFF4F4F7), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp)
                Text(when (title) { "Continue Watching" -> "A good story is worth coming back to."
                    "My List" -> "The ones you saved for a great night in."
                    "Movies for your evening" -> "Make tonight a movie night."
                    else -> "Your next favourite, one episode away." },
                    Modifier.padding(top = 3.dp), color = Secondary, fontSize = 10.sp)
            }
        }
        TvLazyRow(state = row, contentPadding = PaddingValues(horizontal = 28.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(entries, key = { it.channel.id }) { entry ->
                HomePoster(entry, wide, restoreId == entry.channel.id, onRestored) { onDetail(entry.channel) }
            }
        }
    }
}

@Composable
private fun HomePoster(entry: HomeItem, wide: Boolean, restore: Boolean, onRestored: () -> Unit, onClick: () -> Unit) {
    val context = LocalContext.current
    val requester = remember(entry.channel.id) { FocusRequester() }
    LaunchedEffect(restore) { if (restore) { withFrameNanos { }; try { requester.requestFocus(); onRestored() } catch (_: IllegalStateException) { } } }
    Column(Modifier.width(if (wide) 236.dp else 140.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HomeAction(onClick, Modifier.fillMaxWidth().focusRequester(requester)) {
            Box(Modifier.fillMaxWidth().aspectRatio(if (wide) 16f / 10 else 2f / 3).background(Cinema.Atmosphere), contentAlignment = Alignment.Center) {
                Icon(if (entry.channel.type == ContentType.MOVIE) Icons.Outlined.Movie else Icons.Outlined.Tv,
                    null, Modifier.size(34.dp), tint = Cinema.Accent.copy(alpha = 0.65f))
                if (entry.channel.logoUrl != null) AsyncImage(
                    model = remember(entry.channel.logoUrl, wide) { ImageRequest.Builder(context).data(entry.channel.logoUrl)
                        .size(if (wide) 440 else 264, if (wide) 248 else 396).crossfade(false).build() },
                    contentDescription = entry.channel.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                if (wide) {
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD9090B10)))))
                    Text("${(entry.progress.coerceIn(0f, 1f) * 100).toInt()}% watched",
                        Modifier.align(Alignment.BottomStart).padding(12.dp), color = Color.White, fontSize = 10.sp)
                }
                if (entry.progress > 0f) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Cinema.Line)) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(entry.progress.coerceIn(0f, 1f)).background(Cinema.Accent))
                }
            }
        }
        Text(entry.channel.name, color = Color(0xFFE5E8EF), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (wide) Text(entry.caption ?: "Continue watching", color = Secondary, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HomeAction(onClick: () -> Unit, modifier: Modifier = Modifier, bright: Boolean = false, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Surface(onClick = onClick, modifier = modifier.onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(2.dp, Color.White, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape), scale = ClickableSurfaceDefaults.scale(focusedScale = 1.025f),
        colors = ClickableSurfaceDefaults.colors(containerColor = if (bright) Color(0xFFF1F0EB) else Cinema.Raised,
            contentColor = if (bright) Night else Color.White, focusedContainerColor = if (bright) Color.White else Color(0xFF383F4C), focusedContentColor = Color.White), content = content)
}
