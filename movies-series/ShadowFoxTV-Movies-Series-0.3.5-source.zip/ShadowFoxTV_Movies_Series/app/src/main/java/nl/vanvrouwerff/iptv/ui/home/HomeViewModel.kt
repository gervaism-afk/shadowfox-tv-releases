package nl.vanvrouwerff.iptv.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.db.toDomain
import android.content.Context

internal const val HOME_ROW_LIMIT = 24
internal const val PERSONAL_ROW_LIMIT = 12
internal enum class HomeSection { HOME, MOVIES, SERIES, SAVED, SEARCH }
internal data class HomeItem(val channel: Channel, val progress: Float = 0f, val caption: String? = null, val updatedAt: Long = 0)
internal data class HomeState(val profile: String = "", val movies: List<HomeItem> = emptyList(), val series: List<HomeItem> = emptyList(),
    val saved: List<HomeItem> = emptyList(), val continuing: List<HomeItem> = emptyList(), val loading: Boolean = true, val error: String? = null)

internal fun mergeHomeProgress(movies: List<HomeItem>, episodes: List<HomeItem>): List<HomeItem> =
    (movies + episodes).filter { it.channel.type != ContentType.TV }.sortedByDescending { it.updatedAt }
        .distinctBy { it.channel.id }.take(PERSONAL_ROW_LIMIT)

@OptIn(ExperimentalCoroutinesApi::class)
internal class HomeViewModel : ViewModel() {
    private val app = IptvApp.get()
    private val dao = app.database.channelDao()
    // Separate UI-only preferences; saved provider credentials and account settings are untouched.
    private val discoveryPreferences = app.getSharedPreferences("home_discovery", Context.MODE_PRIVATE)
    private fun nextGeneration(): Long {
        val next = (discoveryPreferences.getLong("generation", 0L) + 1L) and Long.MAX_VALUE
        discoveryPreferences.edit().putLong("generation", next).apply()
        return next
    }
    private val generation = MutableStateFlow(nextGeneration())
    fun refreshPicks() { generation.value = nextGeneration() }

    private fun cataloguePicks(type: String, kids: Boolean, profile: String, seed: Long): Flow<List<HomeItem>> =
        dao.observeHomeTitleCount(type, kids).distinctUntilChanged().flatMapLatest { count ->
            val salt = type.hashCode() xor profile.hashCode()
            val window = homeWindow(count, seed, salt)
            if (window.tailCount == 0) flowOf(emptyList()) else {
                val tail = dao.observeHomeTitles(type, kids, window.tailCount, window.offset)
                val rows = if (window.headCount == 0) tail else combine(tail,
                    dao.observeHomeTitles(type, kids, window.headCount, 0)) { end, start -> end + start }
                rows.map { entries -> arrangeHomePicks(entries, seed, salt).map { HomeItem(it.toDomain()) } }
            }
        }
    private var returnFocusId: String? = null
    fun beforeDetail(id: String?) { returnFocusId = id }
    fun takeReturnFocus(): String? = returnFocusId.also { returnFocusId = null }
    val state = combine(app.activeProfileId, app.database.profileDao().observeProfiles()) { id, profiles ->
        id to (profiles.firstOrNull { it.id == id }?.isKids ?: true)
    }.distinctUntilChanged().flatMapLatest { (profile, kids) ->
        val catalogue = generation.flatMapLatest { seed ->
            combine(cataloguePicks("MOVIE", kids, profile, seed), cataloguePicks("SERIES", kids, profile, seed)) { movies, series -> movies to series }
        }
        val saved = dao.observeHomeSaved(profile, kids, PERSONAL_ROW_LIMIT).map { rows -> rows.map { HomeItem(it.toDomain()) } }
        val movieProgress = dao.observeContinueWatching(profile, "MOVIE", 30_000, PERSONAL_ROW_LIMIT).map { rows ->
            rows.filterNot { kids && AdultContent.isAdultCategory(it.channel.groupTitle.orEmpty()) }.map {
                HomeItem(it.channel.toDomain(), (it.positionMs.toFloat() / it.durationMs.coerceAtLeast(1)).coerceIn(0f, 1f), "Continue movie", it.progressUpdatedAt)
            }
        }
        val episodeProgress = dao.observeContinueWatchingEpisodes(profile, 30_000, PERSONAL_ROW_LIMIT).mapLatest { rows ->
            rows.mapNotNull {
                val channel = dao.getChannelById(it.episode.seriesChannelId) ?: return@mapNotNull null
                if (channel.type != "SERIES" || (kids && AdultContent.isAdultCategory(channel.groupTitle.orEmpty()))) return@mapNotNull null
                HomeItem(channel.toDomain(), (it.positionMs.toFloat() / it.durationMs.coerceAtLeast(1)).coerceIn(0f, 1f),
                    "Season ${it.episode.seasonNumber} · Episode ${it.episode.episodeNumber}", it.progressUpdatedAt)
            }
        }
        val continuing = combine(movieProgress, episodeProgress, ::mergeHomeProgress)
        combine(catalogue, saved, continuing) { (movies, series), savedItems, continueItems ->
            HomeState(profile, movies, series, savedItems, continueItems, false)
        }
            .onStart { emit(HomeState(profile = profile)) }
            .catch { emit(HomeState(profile = profile, loading = false, error = "Could not read your library. Open Movies or Series to refresh.")) }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())
}
