package nl.vanvrouwerff.iptv.ui.home

import kotlin.random.Random

internal data class HomeWindow(val offset: Int, val tailCount: Int, val headCount: Int)

/** A bounded circular catalogue window. A coprime stride visits every anchor before repeating. */
internal fun homeWindow(count: Int, generation: Long, salt: Int = 0): HomeWindow {
    if (count <= 0) return HomeWindow(0, 0, 0)
    fun gcd(a: Int, b: Int): Int {
        var x = a; var y = b
        while (y != 0) { val remainder = x % y; x = y; y = remainder }
        return x
    }
    var stride = HOME_ROW_LIMIT + 7
    while (gcd(stride, count) != 1) stride++
    val offset = ((Math.floorMod(generation, count.toLong()) * stride +
        Math.floorMod(salt.toLong(), count.toLong())) % count).toInt()
    val size = minOf(HOME_ROW_LIMIT, count)
    val tail = minOf(size, count - offset)
    return HomeWindow(offset, tail, size - tail)
}

/** Keep the non-repeating window anchor as the spotlight; vary the remaining bounded shelf. */
internal fun <T> arrangeHomePicks(items: List<T>, generation: Long, salt: Int = 0): List<T> =
    if (items.size < 2) items else listOf(items.first()) + items.drop(1).shuffled(Random(generation xor salt.toLong()))
