# ShadowFoxTV Movies & Series 0.3.5 / code 17

Includes the cinematic visual refinement described in POLISH_RELEASE_0.3.4.md,
plus fresh Home discovery instead of the same fixed first catalogue page.

Each new Home view-model session and explicit launcher reopen advances a private
UI-only generation counter. A coprime catalogue stride advances the featured
title through the eligible collection before its anchor repeats. Movie and
series shelves read at most 24 entries each, wrapping at the end of the catalogue
and varying the remaining shelf order with a stable session seed. There is no
whole-catalogue object load or ORDER BY RANDOM sort.

The New picks action changes the spotlight and discovery shelves immediately.
Returning from details/playback or rotating a phone retains the current picks
and return-focus state. My List and Continue Watching keep their existing order.
Profile/kids filters apply to both the count and sampled rows. A library with
only one eligible title necessarily keeps that title.

The added SQL is read-only; database schema, provider credentials, player and
updater implementations are unchanged. The generation counter is in a separate
home_discovery UI preferences file, not in account settings.

Install over the existing app. Package ca.shadowfoxtv.movieseries and the original
signing certificate are retained. Source archives exclude keys and local machine
properties. The private original key is required for compatible signed rebuilds.

Validation is recorded in the delivery verification JSON. Synthetic catalogue
and artwork used for layout checks are outside production/source artifacts.
