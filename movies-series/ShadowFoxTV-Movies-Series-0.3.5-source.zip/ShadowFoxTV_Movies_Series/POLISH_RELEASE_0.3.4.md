# ShadowFoxTV Movies & Series 0.3.4 / code 16

Visual refinement of the Apple TV inspired Movies & Series app. This is separate
from ShadowFoxTV Launcher Pro and Platinum Player.

- Dark cinema palette with restrained champagne accents, softer surfaces and
  consistent typography across browsing, details, setup and settings.
- Atmospheric featured artwork with a correctly proportioned poster on TV,
  larger title typography and clear Play / Details actions.
- Shared navigation across Home and the library; phones have a separate brand
  and Settings row so controls no longer sit beyond a long branding strip.
- Direct My List navigation, enriched rail headings, readable poster fallbacks,
  and actual watched-percentage indicators on Continue Watching cards.
- Detail artwork is decoded at a bounded size. Settings/updater copy now inherits
  readable light text even when it is outside a Material Surface.

No database/schema, account-storage, player, orientation-policy, or updater
implementation changes. The existing package and original signing certificate
are retained. Install over the existing app to keep accounts and progress.
Provider artwork is used as supplied; there is no new artwork/metadata service,
autoplay carousel, catalogue scan or fabricated rating/recommendation data.
Synthetic catalogue/artwork used for QA is outside the app and source archive.

Build: Android Studio JBR 21.0.10; Java/Kotlin target 17; Gradle 8.7; SDK 34.
Run `gradlew.bat :app:testDebugUnitTest :app:lintRelease :app:assembleRelease`.
136 unit/Compose tests passed, including phone touch, TV D-pad, portrait policy,
search input, saved items, progress and updater checks. Release lint passed.

Signing certificate SHA-256:
`c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90`

Restore the original private signing key at signing/preview-debug.keystore or use
the existing RELEASE_* properties in private local.properties. Keys, local
properties, Gradle caches and build output are excluded from public source.

See the delivery verification report for final APK checksums, emulator/device
checks and publication details. Historical release reports describe earlier builds.
