# ShadowFoxTV Movies & Series 0.3.3 (code 15)

Built from the published 0.3.2 source checkpoint. Package remains
`ca.shadowfoxtv.movieseries` and the released APK uses the original signing key.
Install over the existing app to keep saved accounts, library and progress.

Phone/tablet browsing follows the user's rotation preference. Android TV browsing
stays in landscape, and playback retains its existing landscape orientation.
Orientation/size configuration updates retain navigation and form input while
Compose updates its responsive layout.

Narrow libraries have a scrolling navigation bar, horizontal category rail and
readable poster columns. Settings have narrower margins and wrapping account
actions. Movie/series details use the phone width and scroll their actions.
The existing Apple TV style home, touch/remote controls, updater implementation,
database schemas and account-storage code are retained.

An existing missing Media3 unstable-API opt-in was added to StreamFormatRecovery
so release lint can pass. The phone layout test uses Robolectric native text
rendering and density-independent width assertions.

## Rebuild

Validated with Android Studio's bundled JDK 21.0.10, Gradle 8.7, Android SDK 34
and build-tools 34.0.0, compiling for Java/Kotlin 17. Set sdk.dir in private
local.properties, restore the original signing key privately, then run:

```
gradlew.bat :app:testDebugUnitTest :app:lintRelease :app:assembleRelease --offline --no-daemon --console=plain --max-workers=2
```

The public source archive excludes signing keys, local.properties and build
caches. Configure the original key through the existing RELEASE_STORE_FILE,
RELEASE_STORE_PASSWORD, RELEASE_KEY_ALIAS and RELEASE_KEY_PASSWORD properties
or the private signing/preview-debug.keystore path. A different key cannot
update an existing official installation.

Certificate SHA-256:
`c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90`

All 135 unit/Compose regression tests and release lint passed. The original
preview/debug certificate remains the signing identity for compatible sideloaded
updates. No replacement signing identity was created.

Phone emulator: installed over 0.3.2, retained the synthetic account/catalogue,
opened portrait home/library/details, and rotated the library to landscape and
back with the same process and current screen. TV emulator: landscape welcome
and remote D-pad navigation into Settings. No real provider playback was tested.
The physical streamer continued to report unauthorized over ADB after reconnect.
