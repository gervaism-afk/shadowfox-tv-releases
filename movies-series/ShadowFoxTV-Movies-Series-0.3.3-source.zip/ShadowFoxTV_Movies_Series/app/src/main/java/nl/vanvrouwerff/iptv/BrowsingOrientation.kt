package nl.vanvrouwerff.iptv

import android.content.pm.ActivityInfo
import android.content.res.Configuration

internal fun browsingOrientation(configuration: Configuration): Int =
    if (configuration.uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION) {
        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    } else {
        ActivityInfo.SCREEN_ORIENTATION_FULL_USER
    }
