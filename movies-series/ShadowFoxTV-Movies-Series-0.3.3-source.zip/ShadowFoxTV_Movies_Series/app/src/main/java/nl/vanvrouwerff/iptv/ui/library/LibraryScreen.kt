package nl.vanvrouwerff.iptv.ui.library

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.grid.TvGridCells
import androidx.tv.foundation.lazy.grid.TvLazyVerticalGrid
import androidx.tv.foundation.lazy.grid.itemsIndexed
import androidx.tv.foundation.lazy.grid.rememberTvLazyGridState
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.foundation.lazy.list.items
import androidx.tv.material3.*
import nl.vanvrouwerff.iptv.ui.input.Surface
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import nl.vanvrouwerff.iptv.CrashCapture
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import kotlin.math.ceil

private val Ink = Color(0xFF08080B)
private val Panel = Color(0xFF18181E)
private val Ice = Color(0xFFD8D8E4)

/** Bounded, poster-first TV library. No rotating hero, WebView or whole-catalogue StateFlow. */
@Composable
fun LibraryScreen(
    onOpenSettings: () -> Unit,
    onOpenDetail: (Channel) -> Unit,
    onOpenHome: (() -> Unit)? = null,
    vm: LibraryViewModel = viewModel(),
) {
    val updates by nl.vanvrouwerff.iptv.IptvApp.get().updates.state.collectAsState()
    val state by vm.state.collectAsState()
    val requested by vm.requestedSelection.collectAsState()
    val savedSearches by vm.recentSearches.collectAsState()
    val recentSearches = if (savedSearches.first == requested.type) savedSearches.second else emptyList()
    val refreshing by vm.refreshing.collectAsState()
    val progress by vm.progress.collectAsState()
    val refreshError by vm.refreshError.collectAsState()
    var searchVisible by remember { mutableStateOf(vm.searchOpen) }
    val searchInput = remember { LibrarySearchInput(vm.currentQuery) }
    var editing by remember { mutableStateOf(false) }
    val keyboardVisible = rememberLibraryKeyboardVisible()
    val compact = searchVisible && keyboardVisible
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val context = LocalContext.current
    val crash = remember { CrashCapture.summary(context) }
    val grid = rememberTvLazyGridState()
    val scope = rememberCoroutineScope()
    var crashVisible by remember { mutableStateOf(false) }
    var restoreId by remember { mutableStateOf(vm.takeDetailReturnFocus()) }
    var keyboardWasVisible by remember { mutableStateOf(false) }
    LaunchedEffect(keyboardVisible) {
        if (keyboardWasVisible && !keyboardVisible) {
            vm.rememberSearch()
            // Back closes the IME without dispatching its Search action. Release the
            // editor so the TV remote can reach history, sections and results again.
            focusManager.clearFocus()
        }
        keyboardWasVisible = keyboardVisible
    }
    LaunchedEffect(state.selection) {
        if (!editing && restoreId == null && state.selection == requested) grid.scrollToItem(0)
    }
    LaunchedEffect(restoreId, state.items, editing) {
        if (restoreId != null && !editing && state.selection == requested) {
            val index = state.items.indexOfFirst { it.id == restoreId }
            if (index >= 0) grid.scrollToItem(index)
        }
    }

    Column(Modifier.fillMaxSize().background(Ink).padding(horizontal = if (phone) 16.dp else 28.dp, vertical = if (compact) 6.dp else 18.dp)) {
        if (!compact) Row(Modifier.fillMaxWidth().then(if (phone) Modifier.horizontalScroll(rememberScrollState()) else Modifier),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Image(painterResource(R.drawable.shadowfox_cutout), "ShadowFoxTV", Modifier.size(if (compact) 36.dp else 48.dp))
            Column(Modifier.width(174.dp)) {
                Text("ShadowFoxTV", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("MOVIES & SERIES", fontSize = 11.sp, color = Ice, letterSpacing = 1.3.sp)
            }
            if (onOpenHome != null) LibraryChip("Home", false, onClick = onOpenHome)
            LibraryChip("Movies", requested.type == ContentType.MOVIE) { searchInput.clear(); restoreId = null; vm.selectType(ContentType.MOVIE) }
            LibraryChip("Series", requested.type == ContentType.SERIES) { searchInput.clear(); restoreId = null; vm.selectType(ContentType.SERIES) }
            LibraryChip("My List", state.selection.saved, onClick = vm::saved)
            if (!phone) Spacer(Modifier.weight(1f))
            LibraryChip("Search", searchVisible) {
                searchVisible = !searchVisible; vm.searchOpen = searchVisible; restoreId = null
                if (!searchVisible) { vm.rememberSearch(); searchInput.clear(); vm.search(""); keyboard?.hide(); focusManager.clearFocus() }
            }
            LibraryChip("Settings", false) { vm.rememberSearch(); onOpenSettings() }
        }
        if (!compact && updates.release != null) LibraryChip("Update available — open Settings", false, onClick = onOpenSettings)
        Spacer(Modifier.height(if (compact) 0.dp else 18.dp))
        if (searchVisible) {
            LibrarySearchField(searchInput, requested.type, vm::search,
                modifier = Modifier.fillMaxWidth().padding(bottom = if (compact) 4.dp else 8.dp),
                onEditingChanged = { editing = it }, onDone = { vm.rememberSearch(); keyboard?.hide(); focusManager.clearFocus() })
            if (!compact) LibrarySearchHistory(requested.type, recentSearches,
                onRecall = { query ->
                    searchInput.recall(query, vm::search)
                    vm.rememberSearch()
                    keyboard?.hide(); focusManager.clearFocus()
                }, onClear = vm::clearSearchHistory)
        }
        if (phone && !compact) {
            TvLazyRow(Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { LibraryChip("All titles", state.selection.category == null) { vm.selectCategory(null) } }
                items(state.categories.distinct(), key = { it }) { category ->
                    LibraryChip(category, state.selection.category == category, Modifier.widthIn(max = 200.dp)) { vm.selectCategory(category) }
                }
            }
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            if (!compact && !phone) Column(Modifier.width(156.dp)) {
                Text("CATEGORIES", fontSize = 10.sp, letterSpacing = 1.5.sp, color = Ice)
                Spacer(Modifier.height(12.dp))
                TvLazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { LibraryChip("All titles", state.selection.category == null, Modifier.fillMaxWidth()) { vm.selectCategory(null) } }
                    items(state.categories.distinct(), key = { it }) { cat ->
                        LibraryChip(cat, state.selection.category == cat, Modifier.fillMaxWidth()) { vm.selectCategory(cat) }
                    }
                }
            }
            Column(Modifier.weight(1f)) {
                if (compact) {
                    Text("${state.count} ${if (requested.type == ContentType.MOVIE) "movies" else "series"}", color = Ice, fontSize = 12.sp)
                } else Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(state.selection.category ?: if (state.selection.saved) "My List" else if (state.selection.type == ContentType.MOVIE) "Discover movies" else "Discover series",
                            color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (refreshing) "Loading ${progress?.stage?.name?.lowercase() ?: "library"} · ${progress?.count ?: 0} titles"
                            else "${state.count} titles in your library", color = Color(0xFF94A7BD), fontSize = 12.sp)
                    }
                    LibraryChip(if (refreshing) "Loading…" else "Refresh", false, onClick = vm::refresh)
                }
                Spacer(Modifier.height(if (compact) 4.dp else 12.dp))
                if (state.error != null || refreshError != null) {
                    Text(state.error ?: "Library refresh failed. Check your account or connection in Settings.", color = Color(0xFFFFB195), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                }
                if (state.loading || state.items.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(when { state.loading || refreshing -> "Preparing your library…"
                            state.selection.saved -> "Save a movie or series from its detail page."
                            else -> "No titles here. Try another category or refresh." }, color = Color(0xFF94A7BD), fontSize = 15.sp)
                    }
                } else {
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    // Fit complete posters above the keyboard instead of clipping a large first row.
                    val columns = if (phone) phonePosterColumns(maxWidth.value) else if (compact) maxOf(8, ceil(maxWidth.value /
                        (((maxHeight.value - 44f).coerceIn(84f, 144f)) * 2f / 3f + 8f)).toInt()) else 5
                    TvLazyVerticalGrid(columns = TvGridCells.Fixed(columns), state = grid,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(4.dp),
                        verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 12.dp)) {
                        itemsIndexed(state.items, key = { _, it -> it.id }) { index, item ->
                            LibraryPoster(item, restoreFocus = canRestoreLibraryFocus(restoreId, item.id, editing, state.selection == requested),
                                compact = compact,
                                onRestored = { restoreId = null }, onFocus = { vm.rememberFocus(item.id, index) }) {
                                vm.rememberSearch()
                                vm.beforeOpeningDetail(item.id, index)
                                keyboard?.hide(); focusManager.clearFocus()
                                scope.launch { yield(); onOpenDetail(item) }
                            }
                        }
                    }
                    }
                }
                if (!compact) Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (state.selection.page > 0) LibraryChip("Previous", false) { vm.page(-1) }
                    Text("Page ${state.selection.page + 1} of ${maxOf(1, (state.count + LIBRARY_PAGE_SIZE - 1) / LIBRARY_PAGE_SIZE)}", color = Color(0xFF94A7BD), fontSize = 12.sp)
                    if ((state.selection.page + 1) * LIBRARY_PAGE_SIZE < state.count) LibraryChip("Next", false) { vm.page(1) }
                    Spacer(Modifier.weight(1f))
                    if (!phone) Text("OK · Details", fontSize = 10.sp, color = Color(0xFF657D98))
                }
            }
        }
        if (crash != null) Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Previous crash: $crash", fontSize = 10.sp, color = Color(0xFF94A7BD))
            Spacer(Modifier.width(12.dp))
            LibraryChip("Crash details", false) { crashVisible = true }
        }
        if (crashVisible) androidx.compose.ui.window.Dialog(onDismissRequest = { crashVisible = false }) {
            Column(Modifier.background(Panel, RoundedCornerShape(12.dp)).padding(20.dp)) {
                Text("Crash report", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(remember { CrashCapture.report(context).orEmpty().take(2500) }, fontSize = 11.sp,
                    lineHeight = 15.sp, maxLines = 16, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                LibraryChip("Close", false) { crashVisible = false }
            }
        }
    }
}

@Composable
private fun rememberLibraryKeyboardVisible(): Boolean {
    val view = LocalView.current
    val orientation = LocalConfiguration.current.orientation
    var visible by remember(view) { mutableStateOf(false) }
    DisposableEffect(view, orientation) {
        var largestHeight = 0
        val frame = android.graphics.Rect()
        // H96 firmware can report IME-visible insets after the keyboard has closed.
        // With adjustResize, the actual unobscured window reliably tracks its presence.
        val listener = android.view.ViewTreeObserver.OnGlobalLayoutListener {
            view.getWindowVisibleDisplayFrame(frame)
            largestHeight = maxOf(largestHeight, frame.height())
            visible = largestHeight > 0 && largestHeight - frame.height() > largestHeight / 6
        }
        view.viewTreeObserver.addOnGlobalLayoutListener(listener)
        listener.onGlobalLayout()
        onDispose { view.viewTreeObserver.removeOnGlobalLayoutListener(listener) }
    }
    return visible
}

@Composable
internal fun LibrarySearchHistory(type: ContentType, recents: List<String>, onRecall: (String) -> Unit, onClear: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (type == ContentType.MOVIE) "Recent movies" else "Recent series", color = Ice, fontSize = 11.sp)
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (recents.isEmpty()) Text("No recent searches", color = Color(0xFF94A7BD), fontSize = 11.sp)
            recents.forEach { query -> LibraryChip(query, false, Modifier.widthIn(max = 180.dp)) { onRecall(query) } }
        }
        LibraryChip("Clear history", false, onClick = onClear)
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun LibraryChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    val phone = LocalConfiguration.current.screenWidthDp < 600
    Surface(onClick = onClick, modifier = modifier.then(if (phone) Modifier.heightIn(min = 48.dp) else Modifier).onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(1.5.dp, Color.White, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = if (selected) Color(0xFF173C5B) else Panel,
            contentColor = if (selected) Ice else Color(0xFFC5D0DF), focusedContainerColor = Color(0xFF30465E), focusedContentColor = Color.White)) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

internal fun phonePosterColumns(widthDp: Float): Int = maxOf(1, (widthDp / 140f).toInt())

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
internal fun LibraryPoster(item: Channel, restoreFocus: Boolean, compact: Boolean = false, onRestored: () -> Unit = {}, onFocus: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    val context = LocalContext.current
    val requester = remember(item.id) { FocusRequester() }
    LaunchedEffect(item.id, restoreFocus) {
        if (restoreFocus) {
            withFrameNanos { }
            try { requester.requestFocus(); onRestored() } catch (_: IllegalStateException) { }
        }
    }
    Surface(onClick = onClick, modifier = Modifier.fillMaxWidth().focusRequester(requester).onFocusChanged {
        focused = it.isFocused
        if (it.isFocused) onFocus()
    }
        .then(if (focused) Modifier.border(2.dp, Color.White, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape), scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = Panel, contentColor = Color.White,
            focusedContainerColor = Color(0xFF243C55), focusedContentColor = Color.White)) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(Panel), contentAlignment = Alignment.Center) {
                if (item.logoUrl != null) AsyncImage(
                    model = remember(item.logoUrl) { ImageRequest.Builder(context).data(item.logoUrl).size(240, 360).crossfade(false).build() },
                    contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                else Text(if (item.type == ContentType.MOVIE) "MOVIE" else "SERIES", color = Ice, fontSize = 11.sp)
            }
            Text(item.name, Modifier.padding(if (compact) 4.dp else 8.dp).height(if (compact) 28.dp else 32.dp), fontSize = if (compact) 10.sp else 11.sp,
                lineHeight = if (compact) 13.sp else 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
