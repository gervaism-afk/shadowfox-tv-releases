package nl.vanvrouwerff.iptv.player

import androidx.media3.common.ParserException
import androidx.media3.common.util.UnstableApi
import androidx.annotation.OptIn
import nl.vanvrouwerff.iptv.data.ContentType

/** Some Xtream catalogues advertise .m3u8 while serving a progressive video file. */
internal class StreamFormatRecovery {
    private var attempted = false

    fun reset() { attempted = false }

    @OptIn(UnstableApi::class)
    fun tryProgressive(type: ContentType?, error: Throwable): Boolean {
        if (attempted || type !in listOf(ContentType.MOVIE, ContentType.SERIES)) return false
        var cause: Throwable? = error
        while (cause != null) {
            if (cause is ParserException &&
                cause.message?.contains("Input does not start with the #EXTM3U header") == true
            ) {
                attempted = true
                return true
            }
            cause = cause.cause
        }
        return false
    }
}
