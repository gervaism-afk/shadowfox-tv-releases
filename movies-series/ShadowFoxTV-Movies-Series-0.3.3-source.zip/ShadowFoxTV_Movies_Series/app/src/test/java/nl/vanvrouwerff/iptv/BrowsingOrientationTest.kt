package nl.vanvrouwerff.iptv

import android.app.Application
import android.content.ComponentName
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class BrowsingOrientationTest {
    @Test fun phonesAndTabletsFollowUserRotationInBothOrientations() {
        for (orientation in listOf(Configuration.ORIENTATION_PORTRAIT, Configuration.ORIENTATION_LANDSCAPE)) {
            val configuration = Configuration().apply {
                uiMode = Configuration.UI_MODE_TYPE_NORMAL or Configuration.UI_MODE_NIGHT_YES
                this.orientation = orientation
            }
            assertEquals(ActivityInfo.SCREEN_ORIENTATION_FULL_USER, browsingOrientation(configuration))
        }
    }

    @Test fun televisionRemainsLandscapeInDayAndNightMode() {
        for (nightMode in listOf(Configuration.UI_MODE_NIGHT_NO, Configuration.UI_MODE_NIGHT_YES)) {
            val configuration = Configuration().apply {
                uiMode = Configuration.UI_MODE_TYPE_TELEVISION or nightMode
            }
            assertEquals(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, browsingOrientation(configuration))
        }
    }

    @Test fun manifestAllowsPortraitAndRetainsNavigationDuringRotation() {
        val app = RuntimeEnvironment.getApplication()
        val activity = app.packageManager.getActivityInfo(ComponentName(app, MainActivity::class.java), 0)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, activity.screenOrientation)
        val changes = ActivityInfo.CONFIG_ORIENTATION or ActivityInfo.CONFIG_SCREEN_SIZE or ActivityInfo.CONFIG_SMALLEST_SCREEN_SIZE
        assertEquals(changes, activity.configChanges and changes)
        val player = app.packageManager.getActivityInfo(ComponentName(app, "nl.vanvrouwerff.iptv.player.PlayerActivity"), 0)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, player.screenOrientation)
    }
}
