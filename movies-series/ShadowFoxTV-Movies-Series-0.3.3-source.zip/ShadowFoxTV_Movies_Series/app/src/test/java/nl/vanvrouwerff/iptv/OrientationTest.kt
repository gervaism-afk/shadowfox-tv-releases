package nl.vanvrouwerff.iptv

import android.app.Application
import android.content.ComponentName
import android.content.pm.ActivityInfo
import androidx.test.core.app.ApplicationProvider
import nl.vanvrouwerff.iptv.player.PlayerActivity
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class OrientationTest {
    private val context get() = ApplicationProvider.getApplicationContext<Application>()

    @Test fun browsingFollowsDeviceOrientation() {
        val activity = context.packageManager.getActivityInfo(ComponentName(context, MainActivity::class.java), 0)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, activity.screenOrientation)
    }

    @Test fun playbackKeepsLandscapeOrientation() {
        val activity = context.packageManager.getActivityInfo(ComponentName(context, PlayerActivity::class.java), 0)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, activity.screenOrientation)
    }
}
