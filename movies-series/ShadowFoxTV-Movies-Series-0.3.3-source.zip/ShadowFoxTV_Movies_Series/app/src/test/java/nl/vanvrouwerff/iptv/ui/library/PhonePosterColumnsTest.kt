package nl.vanvrouwerff.iptv.ui.library

import org.junit.Assert.assertEquals
import org.junit.Test

class PhonePosterColumnsTest {
    @Test fun portraitPhonesHaveReadablePosters() {
        assertEquals(2, phonePosterColumns(288f))
        assertEquals(2, phonePosterColumns(328f))
        assertEquals(3, phonePosterColumns(448f))
    }

    @Test fun veryNarrowWindowsKeepAtLeastOneColumn() {
        assertEquals(1, phonePosterColumns(100f))
    }
}
