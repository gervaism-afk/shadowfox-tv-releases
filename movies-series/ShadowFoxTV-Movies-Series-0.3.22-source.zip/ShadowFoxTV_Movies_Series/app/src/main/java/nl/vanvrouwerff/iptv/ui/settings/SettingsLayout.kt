package nl.vanvrouwerff.iptv.ui.settings

import android.content.res.Configuration
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.input.key.onPreviewKeyEvent
import android.view.KeyEvent
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.ui.input.Button
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.CinemaChip
import nl.vanvrouwerff.iptv.ui.theme.FocusStyle
import nl.vanvrouwerff.iptv.ui.theme.tvFocus

/** TV uses a fixed section rail beside a bounded, independently scrolling content pane. */
@Composable
internal fun SettingsPage(onBack: () -> Unit, pageKey: Any = Unit, navigation: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    val television = settingsOnTv()
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val scope = rememberCoroutineScope()
    val remote = remember { SettingsRemoteFocus(scope) }.takeIf { television }
    remote?.page = pageKey
    (pageKey as? SettingsCategory)?.let { remote?.selected = it }
    val savedPages = rememberSaveableStateHolder()
    BackHandler { if (remote != null) remote.back(onBack) else onBack() }
    LaunchedEffect(Unit) {
        if (remote != null) { withFrameNanos { }; remote.menu() }
    }
    CompositionLocalProvider(LocalSettingsRemoteFocus provides remote) {
        Column(Modifier.fillMaxSize().background(Cinema.Background).safeDrawingPadding().imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.widthIn(max = 1100.dp).fillMaxWidth().padding(horizontal = if (phone) 16.dp else 32.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Settings", color = Cinema.Text, fontSize = if (phone) 28.sp else 32.sp,
                        fontWeight = FontWeight.SemiBold, letterSpacing = (-0.7).sp)
                    Text("MOVIES & SERIES", color = Cinema.Accent, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                if (!television) CinemaChip("Back", onClick = onBack)
            }
            val pane: @Composable (Modifier) -> Unit = { modifier ->
                savedPages.SaveableStateProvider(pageKey.toString()) {
                    SettingsViewport(modifier, television, content)
                }
            }
            if (television) {
                Row(Modifier.weight(1f).widthIn(max = 1100.dp).fillMaxWidth()
                    .padding(start = 32.dp, end = 24.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(Modifier.width(if (LocalConfiguration.current.screenWidthDp < 900) 156.dp else 184.dp).fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        navigation()
                        Spacer(Modifier.weight(1f))
                        Text("Right: options\nLeft: sections", color = Cinema.Muted, fontSize = 11.sp, lineHeight = 17.sp)
                        CinemaChip("Back", modifier = Modifier.fillMaxWidth().focusRequester(remote!!.back)
                            .onFocusChanged { if (it.isFocused) remote.region = SettingsRemoteFocus.Region.Back }
                            .onPreviewKeyEvent { event ->
                                if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false else when (event.nativeKeyEvent.keyCode) {
                                    KeyEvent.KEYCODE_DPAD_UP -> { remote.menu(SettingsCategory.entries.last()); true }
                                    KeyEvent.KEYCODE_DPAD_LEFT -> { remote.menu(); true }
                                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                                    else -> false
                                }
                            }, onClick = onBack)
                    }
                    pane(Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Box(Modifier.widthIn(max = 1100.dp).fillMaxWidth().padding(horizontal = if (phone) 16.dp else 48.dp, vertical = 8.dp)) { navigation() }
                pane(Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable
private fun SettingsViewport(modifier: Modifier, television: Boolean, content: @Composable ColumnScope.() -> Unit) {
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val scroll = rememberScrollState()
    Box(modifier.testTag("settings-viewport")) {
        Column(Modifier.align(Alignment.TopCenter).widthIn(max = 1100.dp).fillMaxWidth()
            .verticalScroll(scroll).padding(horizontal = if (television) 8.dp else if (phone) 16.dp else 48.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp), content = content)
        val track = Cinema.Line
        val thumb = Cinema.Accent.copy(alpha = 0.7f)
        Canvas(Modifier.align(Alignment.CenterEnd).padding(end = if (television || phone) 0.dp else 18.dp, top = 8.dp, bottom = 8.dp)
            .fillMaxHeight().width(3.dp)) {
            if (scroll.maxValue > 0) {
                val height = (size.height * size.height / (size.height + scroll.maxValue)).coerceAtLeast(24.dp.toPx()).coerceAtMost(size.height)
                val top = (size.height - height) * scroll.value / scroll.maxValue
                drawRoundRect(track, cornerRadius = CornerRadius(size.width))
                drawRoundRect(thumb, Offset(0f, top), Size(size.width, height), CornerRadius(size.width))
            }
        }
    }
}

/** TV browsing never focuses an editor or opens the IME. OK deliberately opens an editor. */
@Composable
internal fun SettingsAccountField(label: String, value: String, onValueChange: (String) -> Unit,
    password: Boolean = false, modifier: Modifier = Modifier, navigationOrder: Int = 0) {
    val television = LocalConfiguration.current.uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION
    if (!television) {
        OutlinedTextField(value, onValueChange, modifier = modifier.fillMaxWidth(),
            label = { androidx.compose.material3.Text(label) }, singleLine = true,
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Text))
        return
    }
    var editing by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(false) }
    var restoreFocus by remember { mutableStateOf(false) }
    val requester = remember { FocusRequester() }
    val shape = RoundedCornerShape(12.dp)
    LaunchedEffect(editing) {
        if (!editing && restoreFocus) {
            withFrameNanos { }
            requester.requestFocus()
            restoreFocus = false
        }
    }
    Surface(onClick = { editing = true; restoreFocus = true },
        modifier = modifier.fillMaxWidth().heightIn(min = 88.dp).focusRequester(requester).settingsControl("account:$label", navigationOrder)
            .onFocusChanged { focused = it.isFocused }.tvFocus(focused, shape, 1f),
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = Cinema.Surface, contentColor = Color.White,
            focusedContainerColor = FocusStyle.Fill, focusedContentColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(label, color = Cinema.Accent, fontSize = 12.sp, lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (value.isBlank()) "Not set" else if (password) "•".repeat(value.length.coerceAtMost(12)) else value,
                    color = if (value.isBlank()) Cinema.Muted else Color.White, fontSize = 17.sp, lineHeight = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Press OK to edit", color = Cinema.Muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
            Text("Edit", Modifier.padding(start = 20.dp), color = Cinema.Accent, fontSize = 12.sp)
        }
    }
    if (editing) AccountFieldEditor(label, value, password,
        onConfirm = { onValueChange(it); editing = false }, onDismiss = { editing = false })
}

@Composable
internal fun AccountFieldEditor(label: String, value: String, password: Boolean,
    onConfirm: (String) -> Unit, onDismiss: () -> Unit, keyboardInsets: WindowInsets? = null) {
    var draft by remember { mutableStateOf(value) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        val keyboard = LocalSoftwareKeyboardController.current
        val editorInsets = keyboardInsets ?: WindowInsets.ime
        val requester = remember { FocusRequester() }
        val view = LocalView.current
        DisposableEffect(view) {
            val window = (view.parent as? DialogWindowProvider)?.window
            val previousMode = window?.attributes?.softInputMode
            // Google TV's IME can overlay a centered wrap-content dialog without resizing it.
            window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            onDispose { if (previousMode != null) window?.setSoftInputMode(previousMode) }
        }
        fun cancel() { keyboard?.hide(); onDismiss() }
        fun confirm() { keyboard?.hide(); onConfirm(draft) }
        BackHandler(onBack = ::cancel)
        LaunchedEffect(Unit) { withFrameNanos { }; requester.requestFocus(); keyboard?.show() }
        Box(Modifier.fillMaxSize().windowInsetsPadding(editorInsets).padding(24.dp), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 600.dp).fillMaxWidth().verticalScroll(rememberScrollState()).clip(RoundedCornerShape(20.dp))
            .background(Cinema.Surface).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(draft, { draft = it }, modifier = Modifier.fillMaxWidth().focusRequester(requester), singleLine = true,
                visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Text, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { confirm() }))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = ::confirm) { Text("Done") }
                Button(onClick = ::cancel) { Text("Cancel") }
            }
        }
        }
    }
}

/** Give the final explanatory block a D-pad stop, so the last paragraphs can be read. */
@Composable
internal fun SettingsInformation(navigationKey: String = "information", navigationOrder: Int = 0, content: @Composable ColumnScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxWidth().settingsControl(navigationKey, navigationOrder).clip(shape).background(Cinema.Surface)
        .onFocusChanged { focused = it.isFocused }
        .border(if (focused) 2.dp else 0.dp, if (focused) Cinema.FocusRing else Color.Transparent, shape)
        .focusable().padding(18.dp).testTag("settings-information"),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}
