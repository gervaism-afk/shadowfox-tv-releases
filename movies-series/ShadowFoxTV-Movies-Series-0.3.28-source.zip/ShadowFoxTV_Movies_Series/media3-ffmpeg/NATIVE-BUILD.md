# Audio decoder provenance

The Java audio renderer and decoder sources are the official AndroidX Media3
1.4.1 FFmpeg extension, matching this application's Media3 dependencies.
Video continues to use MediaCodec; no FFmpeg video renderer is included.

The four ABI libraries were copied without modification from the existing
ShadowFox Platinum decoder build (FFmpeg 6.1.6, Android NDK 27.1.12297006,
minimum native API 24, 16 KB ELF load alignment). They contain only the `ac3`,
`eac3`, and `dca` audio decoders, with network support disabled. AAC therefore
continues to use the Android audio decoder even when the extension is preferred.
The JNI source is Media3 1.8.0. Its audio JNI signatures match 1.4.1; the only
functional difference is a TrueHD reset lifetime fix (TrueHD is not enabled).
Both JNI source versions are included for review.

The original FFmpeg source archive is in `native-source/ffmpeg-6.1.6.tar.xz`.
Its SHA-256 is `d4fcb164028dd3beee5d92c0ac72e46aac6973c75ea12dc14de07bf8f407370a`.
The original configure arguments and upstream URLs are included alongside it.
Adjust the local toolchain and prefix paths when rebuilding. The upstream
`src/main/jni/build_ffmpeg.sh` describes the standard four-ABI build process;
enable `ac3 eac3 dca` and use the included JNI source. FFmpeg is dynamically
linked as separate `libavcodec`, `libavutil`, and `libswresample` libraries.

FFmpeg is used under LGPL 2.1 or later. Its license is included in the app's
`assets/licenses/FFmpeg-LGPL-2.1.txt` and in the FFmpeg source archive. AndroidX
extension sources retain their Apache 2.0 headers and module LICENSE.

Upstream sources:
- https://github.com/androidx/media/tree/1.4.1/libraries/decoder_ffmpeg
- https://github.com/androidx/media/tree/1.8.0/libraries/decoder_ffmpeg
- https://ffmpeg.org/releases/ffmpeg-6.1.6.tar.xz
