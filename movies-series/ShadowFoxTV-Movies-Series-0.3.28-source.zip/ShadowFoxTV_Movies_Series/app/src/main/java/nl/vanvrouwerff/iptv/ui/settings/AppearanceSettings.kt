package nl.vanvrouwerff.iptv.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.tv.material3.Icon
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.appearanceColors

@Composable
internal fun AppearanceSettings(selected: AppearanceTheme, onSelect: (AppearanceTheme) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Choose a theme. Your selection is saved automatically.",
            fontSize = 12.sp, lineHeight = 18.sp, color = IptvPalette.TextSecondary)
        AppearanceTheme.entries.forEach { theme ->
            AppearanceChoice(theme, selected == theme) { onSelect(theme) }
        }
    }
}

@Composable
private fun AppearanceChoice(theme: AppearanceTheme, selected: Boolean, onClick: () -> Unit) {
    val preview = appearanceColors(theme)
    SettingsOptionSurface(onClick = onClick,
        modifier = Modifier.fillMaxWidth().settingsControl("theme:${theme.id}", theme.ordinal * 10).semantics { this.selected = selected }
    ) { focused ->
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.width(48.dp).height(38.dp)) {
                Box(Modifier.weight(1f).fillMaxHeight().background(preview.background))
                Box(Modifier.weight(1f).fillMaxHeight().background(preview.surface2))
                Box(Modifier.weight(1f).fillMaxHeight().background(preview.accent))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(theme.title, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold,
                    color = if (focused) IptvPalette.Accent else IptvPalette.TextPrimary)
                Text(if (theme == AppearanceTheme.CINEMA) "Warm gold accents and a classic cinema feel." else "Midnight tones with a crisp cyan accent.",
                    fontSize = 12.sp, lineHeight = 18.sp, color = IptvPalette.TextSecondary)
            }
            if (selected) Icon(Icons.Outlined.CheckCircle, "Selected", Modifier.size(22.dp), tint = IptvPalette.Accent)
        }
    }
}
