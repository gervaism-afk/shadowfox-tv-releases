package nl.vanvrouwerff.iptv.data

/** Provider category visibility. Kids profiles always keep Adult content hidden. */
object AdultContent {

    fun shouldHide(kidsMode: Boolean, showAdultCategories: Boolean): Boolean = kidsMode || !showAdultCategories

    private val keywords = listOf("adult", "xxx", "18+", "porn")

    fun isAdultCategory(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        val lower = name.lowercase()
        return keywords.any { it in lower }
    }

    fun <T> filterChannels(items: List<T>, hide: Boolean, group: (T) -> String?): List<T> =
        if (!hide) items else items.filterNot { isAdultCategory(group(it)) }
}
