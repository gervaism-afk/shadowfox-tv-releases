package nl.vanvrouwerff.iptv.ui.library

import androidx.paging.PagingConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.ContentType

internal fun usesPlainLibraryQuery(selection: LibrarySelection, hideAdult: Boolean): Boolean =
    selection.genre == null && !hideAdult && !selection.saved && selection.query.isBlank()

internal fun libraryPagingConfig() = PagingConfig(
    pageSize = LIBRARY_PAGE_SIZE, initialLoadSize = LIBRARY_PAGE_SIZE,
    prefetchDistance = 20, maxSize = 180, enablePlaceholders = true,
)

@OptIn(ExperimentalCoroutinesApi::class)
internal fun libraryCategoryFlow(
    selection: Flow<LibrarySelection>,
    categoryQuery: (ContentType) -> Flow<List<String?>>,
): Flow<Pair<ContentType, List<String?>>> = selection.map { it.type }.distinctUntilChanged()
    .flatMapLatest { type ->
        categoryQuery(type).map { type to it }.catch { error ->
            if (error is CancellationException) throw error
            emit(type to emptyList())
        }
    }

@OptIn(FlowPreview::class)
internal fun libraryFilterFlow(selection: Flow<LibrarySelection>, profiles: Flow<String>,
    hideAdultModes: Flow<Boolean>, debounceMs: Long = 180,
): Flow<Triple<LibrarySelection, String, Boolean>> = combine(
    selection.distinctUntilChanged().debounce(debounceMs), profiles, hideAdultModes,
) { filter, profile, hideAdult -> Triple(filter.forAdultVisibility(hideAdult), profile, hideAdult) }

/** Scrolling uses a separate bounded Pager, so it never restarts metadata queries. */
@OptIn(ExperimentalCoroutinesApi::class)
internal fun libraryStateFlow(
    selection: StateFlow<LibrarySelection>, profiles: Flow<String>, hideAdultModes: Flow<Boolean>,
    countQuery: (LibrarySelection, String, Boolean) -> Flow<Int>,
    categoryQuery: (ContentType) -> Flow<List<String?>>,
    debounceMs: Long = 180,
): Flow<LibraryState> = libraryFilterFlow(selection, profiles, hideAdultModes, debounceMs)
    .flatMapLatest { (filter, profile, hideAdult) ->
        combine(countQuery(filter, profile, hideAdult), categoryQuery(filter.type)) { count, cats ->
            LibraryState(selection = filter, hideAdult = hideAdult,
                categories = cats.filterNotNull().filterNot { hideAdult && AdultContent.isAdultCategory(it) },
                count = count, loading = false)
        }.catch { error ->
            if (error is CancellationException) throw error
            emit(LibraryState(selection = filter, hideAdult = hideAdult, loading = false,
                error = "Could not read library. Try refreshing."))
        }
    }
