package nl.vanvrouwerff.iptv.ui.settings

import androidx.compose.runtime.Composable

@Composable
internal fun AdultCategorySetting(show: Boolean, onToggle: () -> Unit) {
    SwitchRow("Show Adult categories",
        "Show Adult categories and their titles in your library and Home. Changes save automatically.",
        checked = show, onToggle = onToggle, navigationOrder = 5)
}
