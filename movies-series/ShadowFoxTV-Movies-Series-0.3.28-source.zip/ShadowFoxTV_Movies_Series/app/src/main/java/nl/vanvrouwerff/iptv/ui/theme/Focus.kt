package nl.vanvrouwerff.iptv.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * One focus recipe for rows, tabs and chips: a lighter fill (via [FocusStyle.Fill] as the
 * Surface's focusedContainerColor), a 2dp light outline and a subtle scale. A selected item
 * keeps its accent fill; focus adds the outline and scale on top, so "selected" and
 * "selected + focused" always look different.
 */
object FocusStyle {
    val Fill: Color @Composable get() = if (Cinema.Exclusive) Cinema.Raised else Color(0xFF3B3F4C)
    val Border: Color @Composable get() = IptvPalette.FocusRing
    const val RowScale = 1.02f
    const val ChipScale = 1.025f
}

fun Modifier.tvFocus(focused: Boolean, shape: Shape, focusedScale: Float = FocusStyle.RowScale): Modifier =
    composed {
        val scale = animateFloatAsState(
            targetValue = if (focused && !Cinema.Exclusive) focusedScale else 1f,
            animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
            label = "tv-focus-scale",
        )
        this
            .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .then(if (focused) Modifier.border(2.dp, FocusStyle.Border, shape) else Modifier)
    }
