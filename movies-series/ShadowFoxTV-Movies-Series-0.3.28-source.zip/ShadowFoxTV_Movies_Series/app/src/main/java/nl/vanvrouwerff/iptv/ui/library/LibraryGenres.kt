package nl.vanvrouwerff.iptv.ui.library

import java.text.Normalizer
import java.util.Locale
import nl.vanvrouwerff.iptv.data.AdultContent

internal data class LibraryGenre(val label: String, val categories: List<String>)

/** Classify provider category labels only; never guess a title's genre. */
internal fun libraryGenres(categories: List<String>, includeEmptyAdult: Boolean = false): List<LibraryGenre> {
    val terms = linkedMapOf(
        "Action" to listOf("action", "accion"),
        "Adventure" to listOf("adventure", "aventure", "aventura"),
        "Animation" to listOf("animation", "animated", "anime", "animacion"),
        "Comedy" to listOf("comedy", "comedy", "comedie", "comedia"),
        "Crime" to listOf("crime", "criminal", "policier"),
        "Documentary" to listOf("documentary", "documentaries", "documentaire", "documentaires", "documental"),
        "Drama" to listOf("drama", "drame"),
        "Family" to listOf("family", "kids", "children", "familial", "famille", "enfants"),
        "Fantasy" to listOf("fantasy", "fantastique", "fantasia"),
        "Horror" to listOf("horror", "horreur", "terror"),
        "Mystery" to listOf("mystery", "mystere", "misterio"),
        "Romance" to listOf("romance", "romantic", "romantique"),
        "Sci-Fi" to listOf("sci fi", "scifi", "science fiction"),
        "Thriller" to listOf("thriller", "suspense"),
        "Western" to listOf("western", "westerns"),
    )
    fun normalized(value: String) = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9]+"), " ").trim()
    val unique = categories.distinct()
    val ordinary = unique.filterNot(AdultContent::isAdultCategory)
    return terms.mapNotNull { (label, aliases) ->
        val matches = ordinary.filter { category ->
            val words = " ${normalized(category)} "
            aliases.any { " $it " in words }
        }
        matches.takeIf { it.isNotEmpty() }?.let { LibraryGenre(label, it) }
    } + unique.filter(AdultContent::isAdultCategory).takeIf { it.isNotEmpty() }
        .let { if (it == null && !includeEmptyAdult) emptyList() else listOf(LibraryGenre("Adult", it.orEmpty())) }
}
