package nl.vanvrouwerff.iptv.ui.library

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.testTag
import androidx.paging.compose.LazyPagingItems
import androidx.paging.compose.itemKey
import androidx.tv.foundation.lazy.grid.*
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.Cinema

/** Virtual placeholders keep remote focus stable while bounded Room pages load. */
@Composable
internal fun LibraryTitleGrid(
    titles: LazyPagingItems<Channel>, grid: TvLazyGridState, columns: Int,
    focusedIndex: Int, entryToken: Int, restoreId: String?, compact: Boolean,
    onExitUp: () -> Unit, onExitLeft: () -> Unit,
    onFocus: (Channel?, Int) -> Unit, onRestored: () -> Unit, onOpen: (Channel, Int) -> Unit,
) {
    var focusTarget by remember { mutableStateOf(restoreId) }
    var pendingIndex by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(restoreId, titles.itemCount) {
        if (restoreId == null) focusTarget = null
        if (restoreId != null && titles.itemCount > 0) {
            val snapshot = titles.itemSnapshotList
            val known = snapshot.items.indexOfFirst { it.id == restoreId }
            pendingIndex = if (known >= 0) snapshot.placeholdersBefore + known
                else focusedIndex.coerceIn(0, titles.itemCount - 1)
            grid.scrollToItem(requireNotNull(pendingIndex))
        }
    }
    LaunchedEffect(entryToken) {
        if (entryToken > 0 && titles.itemCount > 0) {
            pendingIndex = focusedIndex.coerceIn(0, titles.itemCount - 1)
            grid.scrollToItem(requireNotNull(pendingIndex))
        }
    }
    LaunchedEffect(pendingIndex, titles.itemSnapshotList) {
        pendingIndex?.takeIf { it < titles.itemCount }?.let { index ->
            titles.peek(index)?.let { focusTarget = it.id; pendingIndex = null }
        }
    }
    TvLazyVerticalGrid(
        columns = TvGridCells.Fixed(columns), state = grid,
        modifier = Modifier.fillMaxSize().testTag("library-title-grid").focusGroup().onPreviewKeyEvent { event ->
            if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false else when {
                event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_UP && focusedIndex < columns -> {
                    onExitUp(); true
                }
                event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && focusedIndex % columns == 0 -> {
                    onExitLeft(); true
                }
                event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT &&
                    (focusedIndex % columns == columns - 1 || focusedIndex == titles.itemCount - 1) -> true
                else -> false
            }
        },
        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 14.dp),
        horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 12.dp),
    ) {
        items(count = titles.itemCount, key = titles.itemKey { it.id },
            contentType = { index -> if (titles.peek(index) == null) "placeholder" else "poster" }) { index ->
            val item = titles[index]
            if (item != null) {
                LibraryPoster(item, restoreFocus = focusTarget == item.id, compact = compact,
                    onRestored = { focusTarget = null; if (restoreId != null) onRestored() },
                    onFocus = { onFocus(item, index) }, onClick = { onOpen(item, index) })
            } else {
                Surface(onClick = {}, modifier = Modifier.fillMaxWidth().onFocusChanged {
                    if (it.isFocused) { pendingIndex = index; onFocus(null, index) }
                }) {
                    Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)
                        .background(Cinema.Surface, RoundedCornerShape(12.dp)))
                }
            }
        }
    }
}
