package nl.vanvrouwerff.iptv.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme

@Immutable
internal data class AppearanceColors(
    val background: Color, val backgroundLift: Color, val surface: Color, val surface2: Color,
    val high: Color, val accent: Color, val accentSoft: Color, val accentDeep: Color,
    val text: Color, val textSub: Color, val textDim: Color, val line: Color,
    val border: Color, val focusRing: Color, val exclusive: Boolean,
)

private val CinemaColors = AppearanceColors(
    Color(0xFF090B10), Color(0xFF11151D), Color(0xFF171B23), Color(0xFF232832),
    Color(0xFF232832), Color(0xFFE4BD8A), Color(0xFFF5DAB7), Color(0xFF4A3527),
    Color(0xFFF4F4F6), Color(0xFFB4B7C0), Color(0xFF9AA0AC), Color(0xFF303640),
    Color(0x22FFFFFF), Color(0xFFF4F4F6), false,
)

// Matches the approved Platinum ShadowFox Exclusive palette. Opaque, static surfaces.
private val ExclusiveColors = AppearanceColors(
    Color(0xFF070D15), Color(0xFF122131), Color(0xFF122131), Color(0xFF1B3044),
    Color(0xFF223D54), Color(0xFF58D2FF), Color(0xFFAFCAE0), Color(0xFF1B3044),
    Color(0xFFF5F9FF), Color(0xFFC0CEDD), Color(0xFFA9BED2), Color(0x6634506A),
    Color(0x9934506A), Color(0xFF58D2FF), true,
)

internal fun appearanceColors(theme: AppearanceTheme): AppearanceColors =
    if (theme == AppearanceTheme.SHADOWFOX_EXCLUSIVE) ExclusiveColors else CinemaColors

internal val LocalAppearanceColors = staticCompositionLocalOf { CinemaColors }
