package nl.vanvrouwerff.iptv.ui.library

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import nl.vanvrouwerff.iptv.ui.home.HomeSection

import androidx.paging.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.db.toDomain

internal const val LIBRARY_PAGE_SIZE = 60
internal data class LibrarySelection(
    val type: ContentType = ContentType.MOVIE,
    val category: String? = null,
    val genre: String? = null,
    val genreCategories: List<String> = emptyList(),
    val query: String = "",
    val saved: Boolean = false,
)
internal data class LibraryState(
    val selection: LibrarySelection = LibrarySelection(),
    val hideAdult: Boolean = true,
    val categories: List<String> = emptyList(),
    val count: Int = 0,
    val loading: Boolean = true,
    val error: String? = null,
)
/** Leaving a now-hidden category preserves the current query, media type and saved filter. */
internal fun LibrarySelection.forAdultVisibility(hide: Boolean): LibrarySelection =
    if (hide && (genre == "Adult" || AdultContent.isAdultCategory(category)))
        copy(category = null, genre = null, genreCategories = emptyList()) else this

internal fun librarySearchPattern(query: String): String =
    "%${query.trim().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")}%"

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class LibraryViewModel : ViewModel() {
    internal var browseSection by mutableStateOf(HomeSection.HOME)
    private val app = IptvApp.get()
    private val dao = app.database.channelDao()
    private val selection = MutableStateFlow(LibrarySelection())
    private val adultHidden = combine(app.kidsMode, app.settings.showAdultCategories, AdultContent::shouldHide)
        .distinctUntilChanged()
    private var adultHiddenNow = false
    internal val requestedSelection: StateFlow<LibrarySelection> = selection.asStateFlow()
    internal val currentQuery: String get() = selection.value.query
    internal var searchOpen: Boolean = false
    private var detailReturnFocusId: String? = null
    private var settingsReturnFocus = false
    internal var gridFirstVisibleIndex = 0
    internal var gridFirstVisibleOffset = 0
    internal var lastDisplayedSelection: LibrarySelection? = null
    internal fun beforeOpeningSettings() { settingsReturnFocus = true }
    internal fun takeSettingsReturnFocus(): Boolean = settingsReturnFocus.also { settingsReturnFocus = false }
    internal fun beforeOpeningDetail(id: String, index: Int) {
        rememberFocus(id, index)
        detailReturnFocusId = id
    }
    internal fun takeDetailReturnFocus(): String? = detailReturnFocusId.also { detailReturnFocusId = null }
    val refreshing = app.refreshUseCase.refreshing
    val progress = app.refreshUseCase.progress
    val refreshError = app.refreshUseCase.lastError
    internal val recentSearches = combine(app.activeProfileId, selection.map { it.type }.distinctUntilChanged()) { profile, type ->
        profile to type
    }.flatMapLatest { (profile, type) -> app.settings.recentSearches(profile, type).map { type to it } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ContentType.MOVIE to emptyList<String>())

    fun rememberSearch() {
        val current = selection.value
        val profile = app.activeProfileId.value
        if (current.query.isBlank()) return
        viewModelScope.launch { app.settings.pushRecentSearch(profile, current.query, current.type) }
    }

    fun clearSearchHistory() {
        val type = selection.value.type
        val profile = app.activeProfileId.value
        viewModelScope.launch { app.settings.clearRecentSearches(profile, type) }
    }

    private val categories = libraryCategoryFlow(selection) { type -> dao.observeGroupTitlesByType(type.name) }
        .flowOn(Dispatchers.IO)
        .shareIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), replay = 1)

    internal val state: StateFlow<LibraryState> = libraryStateFlow(
        selection = selection, profiles = app.activeProfileId, hideAdultModes = adultHidden,
        countQuery = { s, profile, hideAdult ->
            when {
                s.genre != null -> dao.observeGenreLibraryCount(s.type.name, s.genreCategories,
                    librarySearchPattern(s.query), s.saved, profile, hideAdult)
                usesPlainLibraryQuery(s, hideAdult) && s.category == null -> dao.observePlainLibraryCount(s.type.name)
                usesPlainLibraryQuery(s, hideAdult) -> dao.observeCategoryLibraryCount(s.type.name, requireNotNull(s.category))
                else -> dao.observeLibraryCount(s.type.name, s.category, librarySearchPattern(s.query), s.saved, profile, hideAdult)
            }
        },
        categoryQuery = { type -> categories.filter { it.first == type }.map { it.second } },
    ).flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryState())

    internal val titles = libraryFilterFlow(selection, app.activeProfileId, adultHidden)
        .flatMapLatest { (s, profile, hideAdult) ->
            Pager(libraryPagingConfig()) {
                when {
                    s.genre != null -> dao.pagingGenreLibrary(s.type.name, s.genreCategories,
                        librarySearchPattern(s.query), s.saved, profile, hideAdult)
                    usesPlainLibraryQuery(s, hideAdult) && s.category == null -> dao.pagingPlainLibrary(s.type.name)
                    usesPlainLibraryQuery(s, hideAdult) -> dao.pagingCategoryLibrary(s.type.name, requireNotNull(s.category))
                    else -> dao.pagingFilteredLibrary(s.type.name, s.category,
                        librarySearchPattern(s.query), s.saved, profile, hideAdult)
                }
            }.flow.map { page -> page.map { it.toDomain() } }
        }.cachedIn(viewModelScope)

    init {
        viewModelScope.launch {
            adultHidden.collect { hide ->
                adultHiddenNow = hide
                if (hide) select(selection.value.forAdultVisibility(true))
            }
        }
        viewModelScope.launch {
            val last = app.settings.lastRefreshSuccessAt.first()
            if (last == 0L || System.currentTimeMillis() - last > 6 * 3_600_000L) refresh()
        }
    }
    internal var focusedId: String? = null
    internal var focusedIndex by androidx.compose.runtime.mutableIntStateOf(0)
    fun rememberFocus(id: String, index: Int) { focusedId = id; focusedIndex = index }

    private fun select(requested: LibrarySelection) {
        val value = requested.forAdultVisibility(adultHiddenNow)
        if (value != selection.value) {
            focusedId = null
            focusedIndex = 0
            gridFirstVisibleIndex = 0
            gridFirstVisibleOffset = 0
            detailReturnFocusId = null
            selection.value = value
        }
    }
    fun selectType(type: ContentType) { rememberSearch(); select(LibrarySelection(type = type)) }
    fun selectCategory(value: String?) { select(selection.value.copy(category = value, genre = null, genreCategories = emptyList())) }
    internal fun selectGenre(genre: LibraryGenre) {
        select(selection.value.copy(category = null, genre = genre.label,
            genreCategories = genre.categories))
    }
    fun search(value: String) { select(selection.value.copy(query = value)) }
    fun saved() { select(selection.value.copy(saved = !selection.value.saved)) }
    fun showSaved() { rememberSearch(); select(LibrarySelection(type = selection.value.type, saved = true)) }
    fun refresh() {
        if (!refreshing.value) app.appScope.launch { app.refreshUseCase(force = true) }
    }
}
