package nl.vanvrouwerff.iptv.updates

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.BuildConfig
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.ui.input.Button
import nl.vanvrouwerff.iptv.ui.input.Surface

internal fun shouldOfferUpdate(available: Int?, installed: Int, dismissed: Int): Boolean =
    available != null && available > installed && available > dismissed

/** The application checks on startup; expose its verified release even before account setup. */
@Composable
fun UpdatePrompt() {
    val state by IptvApp.get().updates.state.collectAsState()
    var dismissed by rememberSaveable { mutableStateOf(0) }
    val release = state.release ?: return
    if (!shouldOfferUpdate(release.versionCode, BuildConfig.VERSION_CODE, dismissed)) return
    AvailableUpdateDialog(release.versionName, onDismiss = { dismissed = release.versionCode }) {
        UpdatePanel()
    }
}

@Composable
internal fun AvailableUpdateDialog(version: String, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.9f).dp
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val shape = RoundedCornerShape(20.dp)
        Column(Modifier.padding(20.dp).widthIn(max = 560.dp).fillMaxWidth().heightIn(max = maxHeight)
            .background(Cinema.Surface, shape).border(1.dp, Cinema.Line, shape).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Update available", color = Cinema.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text("Version $version", color = Cinema.Muted, fontSize = 13.sp)
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                content()
            }
            UpdateActionButton("Later", true, onDismiss)
        }
    }
}
