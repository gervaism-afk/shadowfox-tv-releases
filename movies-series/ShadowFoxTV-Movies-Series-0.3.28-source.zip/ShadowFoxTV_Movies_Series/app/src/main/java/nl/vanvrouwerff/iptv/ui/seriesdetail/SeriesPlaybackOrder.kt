package nl.vanvrouwerff.iptv.ui.seriesdetail

import nl.vanvrouwerff.iptv.data.db.WatchProgressEntity

private val SeasonOrder = compareBy<SeriesSeason> {
    when { it.number > 0 -> 0; it.number == 0 -> 1; else -> 2 }
}.thenBy { it.number }

internal fun seriesSeasonsInPlaybackOrder(seasons: List<SeriesSeason>): List<SeriesSeason> =
    seasons.sortedWith(SeasonOrder).map { season ->
        season.copy(episodes = season.episodes.sortedBy { it.episodeNumber })
    }

internal fun defaultSeriesSeason(seasons: List<SeriesSeason>): SeriesSeason? =
    seasons.filter { it.episodes.isNotEmpty() }.minWithOrNull(SeasonOrder)
        ?: seasons.minWithOrNull(SeasonOrder)

internal fun seriesSeasonLabel(number: Int, providerLabel: String?): String {
    val label = providerLabel?.trim()?.takeIf { it.isNotEmpty() }
    if (number == 0 && (label == null || label == "0" || Regex("(?i)(season|seizoen|s)\\s*0").matches(label))) return "Specials"
    return label ?: "Season $number"
}

/** Prepare ordering once per loaded series, rather than sorting again on each Room update. */
internal class SeriesPlaybackPlan(seasons: List<SeriesSeason>) {
    private data class Entry(val episode: Episode, val season: SeriesSeason)
    private val all = seriesSeasonsInPlaybackOrder(seasons).flatMap { season ->
        season.episodes.map { Entry(it, season) }
    }.distinctBy { it.episode.id }
    private val byId = all.associateBy { it.episode.id }
    private val main = all.filter { it.season.number > 0 }
    private val extras = all.filter { it.season.number <= 0 }

    fun nextUp(progress: List<WatchProgressEntity>): NextUp? {
        if (all.isEmpty()) return null
        val saved = progress.filter { it.channelId in byId }.groupBy { it.channelId }
            .mapValues { (_, rows) -> rows.maxBy { it.updatedAt } }
        val latest = saved.values.filter { it.positionMs > 0L }.maxByOrNull { it.updatedAt }
        val default = main.firstOrNull() ?: all.first()
        if (latest == null) return choice(default, null)
        val current = byId.getValue(latest.channelId)
        if (!finished(latest)) return choice(current, latest)
        if (current.season.number > 0) return advance(main, current, saved)

        // An explicitly watched special can continue within Specials. It never becomes
        // the default queue for a new series or after the final main-season episode.
        val extraIndex = extras.indexOf(current)
        val followingExtra = extras.asSequence().drop(extraIndex + 1)
            .firstOrNull { !finished(saved[it.episode.id]) }
        if (followingExtra != null) return choice(followingExtra, saved[followingExtra.episode.id])
        if (main.isEmpty()) return advance(extras, current, saved)
        val latestMain = saved.values.filter { it.positionMs > 0L && byId.getValue(it.channelId).season.number > 0 }
            .maxByOrNull { it.updatedAt }
        if (latestMain == null) return choice(main.first(), null)
        val mainEntry = byId.getValue(latestMain.channelId)
        return if (finished(latestMain)) advance(main, mainEntry, saved) else choice(mainEntry, latestMain)
    }

    private fun advance(queue: List<Entry>, current: Entry, saved: Map<String, WatchProgressEntity>): NextUp {
        val index = queue.indexOf(current)
        val next = queue.asSequence().drop(index + 1).firstOrNull { !finished(saved[it.episode.id]) }
            ?: queue.firstOrNull { !finished(saved[it.episode.id]) }
            ?: return choice(queue.first(), null) // Explicit replay starts with the main season.
        return choice(next, saved[next.episode.id])
    }
    private fun choice(entry: Entry, saved: WatchProgressEntity?): NextUp {
        val resume = saved != null && saved.positionMs > 0L && !finished(saved)
        return NextUp(entry.episode, entry.season, if (resume) saved!!.positionMs else 0L, resume)
    }
    private fun finished(saved: WatchProgressEntity?): Boolean = saved != null && saved.durationMs > 0L &&
        saved.positionMs.toFloat() / saved.durationMs >= 0.95f
}

internal fun computeNextUp(seasons: List<SeriesSeason>, progress: List<WatchProgressEntity>): NextUp? =
    SeriesPlaybackPlan(seasons).nextUp(progress)
