package nl.vanvrouwerff.iptv.data.settings

enum class AppearanceTheme(val id: String, val title: String, val description: String) {
    CINEMA("cinema", "Cinema", "Original charcoal and warm gold"),
    SHADOWFOX_EXCLUSIVE("shadowfox_exclusive", "ShadowFox Exclusive", "Charcoal, precision cyan and Inter typography");

    companion object {
        fun fromId(id: String?): AppearanceTheme = entries.firstOrNull { it.id == id } ?: CINEMA
    }
}
