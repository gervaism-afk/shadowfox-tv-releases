package nl.vanvrouwerff.iptv.ui.settings

import android.content.res.Configuration
import android.view.KeyEvent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalConfiguration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
internal fun settingsOnTv(): Boolean =
    LocalConfiguration.current.uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION

/** A section menu and one ordered list of controls, independent of screen coordinates. */
internal class SettingsRemoteFocus(private val scope: CoroutineScope) {
    enum class Region { Menu, Content, Back }
    private data class Control(val key: String, val order: Int, val focus: FocusRequester)
    val sections = SettingsCategory.entries.associateWith { FocusRequester() }
    val back = FocusRequester()
    var selected = SettingsCategory.Account
    var page: Any = Unit
    var region = Region.Menu
    private val controls = mutableMapOf<Any, LinkedHashMap<String, Control>>()
    private val lastControl = mutableMapOf<Any, String>()
    private var entering: Job? = null

    private fun ordered(page: Any = this.page) = controls[page]?.values.orEmpty().sortedBy { it.order }
    private fun request(focus: FocusRequester) = runCatching { focus.requestFocus(); true }.getOrDefault(false)
    fun menu(category: SettingsCategory = selected) { request(sections.getValue(category)) }
    fun focused(key: String, page: Any) { region = Region.Content; lastControl[page] = key }
    fun register(page: Any, key: String, order: Int, focus: FocusRequester) {
        controls.getOrPut(page) { linkedMapOf() }[key] = Control(key, order, focus)
    }
    fun unregister(page: Any, key: String) {
        val removed = controls[page]?.remove(key) ?: return
        if (page == this.page && region == Region.Content && lastControl[page] == key) {
            scope.launch {
                withFrameNanos { }; withFrameNanos { }
                if (page == this@SettingsRemoteFocus.page && region == Region.Content && lastControl[page] == key) {
                    val remaining = ordered(page)
                    val next = remaining.firstOrNull { it.key == key }
                        ?: remaining.firstOrNull { it.order >= removed.order } ?: remaining.lastOrNull()
                    if (next == null) menu() else request(next.focus)
                }
            }
        }
    }
    fun enter() {
        entering?.cancel()
        entering = scope.launch {
            // Section selection composes its controls before a requester is used.
            withFrameNanos { }; withFrameNanos { }
            val items = ordered()
            val target = items.firstOrNull { it.key == lastControl[page] } ?: items.firstOrNull()
            if (target == null) menu() else request(target.focus)
        }
    }
    fun move(key: String, delta: Int) {
        val items = ordered()
        val index = items.indexOfFirst { it.key == key }
        if (index < 0) return
        val next = index + delta
        when {
            next < 0 -> menu()
            next < items.size -> request(items[next].focus)
            // Stop at the last control instead of jumping to an unrelated header button.
        }
    }
    fun back(onExit: () -> Unit) { if (region == Region.Content) menu() else onExit() }
}

internal val LocalSettingsRemoteFocus = staticCompositionLocalOf<SettingsRemoteFocus?> { null }

/** Register only enabled controls. Focus scrolls the whole row into the content viewport. */
@OptIn(ExperimentalFoundationApi::class)
internal fun Modifier.settingsControl(key: String, order: Int = 0, enabled: Boolean = true): Modifier = composed {
    val navigation = LocalSettingsRemoteFocus.current ?: return@composed this
    val page = navigation.page
    val requester = remember(key) { FocusRequester() }
    val visibility = remember(key) { BringIntoViewRequester() }
    val scope = rememberCoroutineScope()
    var scrolling by remember { mutableStateOf<Job?>(null) }
    DisposableEffect(navigation, page, key, enabled) {
        if (enabled) navigation.register(page, key, order, requester)
        onDispose { if (enabled) navigation.unregister(page, key) }
    }
    this.focusRequester(requester).bringIntoViewRequester(visibility)
        .onFocusChanged { state ->
            scrolling?.cancel()
            if (state.isFocused) {
                navigation.focused(key, page)
                scrolling = scope.launch { withFrameNanos { }; visibility.bringIntoView() }
            }
        }.onPreviewKeyEvent { event ->
            if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false
            else when (event.nativeKeyEvent.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> { navigation.move(key, -1); true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { navigation.move(key, 1); true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { navigation.menu(); true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> true
                else -> false
            }
        }
}
