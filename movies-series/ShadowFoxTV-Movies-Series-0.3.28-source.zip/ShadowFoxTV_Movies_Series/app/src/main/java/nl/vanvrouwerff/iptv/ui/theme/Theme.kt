package nl.vanvrouwerff.iptv.ui.theme

import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.sp
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Typography
import androidx.tv.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme as M3MaterialTheme
import androidx.compose.material3.Typography as M3Typography
import androidx.compose.material3.darkColorScheme as m3DarkColorScheme
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme

object IptvPalette {
    val OnAccent: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.background
    val BackgroundDeep: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.background
    val BackgroundLift: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.backgroundLift
    val SurfaceLift: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.surface
    val SurfaceElevated: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.surface2
    val Accent: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.accent
    val AccentSoft: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.accentSoft
    val AccentDeep: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.accentDeep
    val TextPrimary: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.text
    val TextSecondary: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.textSub
    val TextTertiary: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.textDim
    val Border: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.border
    val FocusRing: Color
        @Composable @ReadOnlyComposable get() = LocalAppearanceColors.current.focusRing
}

private fun tvScheme(p: AppearanceColors) = darkColorScheme(
    primary = p.accent, onPrimary = p.background,
    primaryContainer = p.accentDeep, onPrimaryContainer = p.accentSoft,
    secondary = p.accentSoft, onSecondary = p.background,
    surface = p.surface, onSurface = p.text, surfaceVariant = p.surface2,
    onSurfaceVariant = p.textSub, background = p.background, onBackground = p.text,
    border = p.border, borderVariant = if (p.exclusive) p.line else Color(0x11FFFFFF),
)

private fun materialScheme(p: AppearanceColors) = m3DarkColorScheme(
    primary = p.accent, onPrimary = p.background,
    surface = p.surface, onSurface = if (p.exclusive) p.text else Color.White,
    surfaceVariant = p.surface2, onSurfaceVariant = p.textSub,
    background = p.background, onBackground = if (p.exclusive) p.text else Color.White,
)

private val TvTypography = Typography(
    bodySmall = TextStyle(fontSize = 15.sp, lineHeight = 20.sp),
    bodyMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontSize = 19.sp, lineHeight = 26.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
)


// Real bundled faces, including aliases for heavier requested weights. No synthetic bold.
internal val ExclusiveFontFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_semibold, FontWeight.Bold),
    Font(R.font.inter_semibold, FontWeight.ExtraBold),
    Font(R.font.inter_semibold, FontWeight.Black),
)
private fun TextStyle.inter() = copy(fontFamily = ExclusiveFontFamily, fontSynthesis = FontSynthesis.None)
private val ExclusiveTvTypography = Typography(
    displayLarge = TvTypography.displayLarge.inter(),
    displayMedium = TvTypography.displayMedium.inter(),
    displaySmall = TvTypography.displaySmall.inter(),
    headlineLarge = TvTypography.headlineLarge.inter(),
    headlineMedium = TvTypography.headlineMedium.inter(),
    headlineSmall = TvTypography.headlineSmall.inter(),
    titleLarge = TvTypography.titleLarge.inter(),
    titleMedium = TvTypography.titleMedium.inter(),
    titleSmall = TvTypography.titleSmall.inter(),
    bodyLarge = TvTypography.bodyLarge.inter(),
    bodyMedium = TvTypography.bodyMedium.inter(),
    bodySmall = TvTypography.bodySmall.inter(),
    labelLarge = TvTypography.labelLarge.inter(),
    labelMedium = TvTypography.labelMedium.inter(),
    labelSmall = TvTypography.labelSmall.inter()
)
private val DefaultM3Typography = M3Typography()
private val ExclusiveM3Typography = M3Typography(
    displayLarge = DefaultM3Typography.displayLarge.inter(),
    displayMedium = DefaultM3Typography.displayMedium.inter(),
    displaySmall = DefaultM3Typography.displaySmall.inter(),
    headlineLarge = DefaultM3Typography.headlineLarge.inter(),
    headlineMedium = DefaultM3Typography.headlineMedium.inter(),
    headlineSmall = DefaultM3Typography.headlineSmall.inter(),
    titleLarge = DefaultM3Typography.titleLarge.inter(),
    titleMedium = DefaultM3Typography.titleMedium.inter(),
    titleSmall = DefaultM3Typography.titleSmall.inter(),
    bodyLarge = DefaultM3Typography.bodyLarge.inter(),
    bodyMedium = DefaultM3Typography.bodyMedium.inter(),
    bodySmall = DefaultM3Typography.bodySmall.inter(),
    labelLarge = DefaultM3Typography.labelLarge.inter(),
    labelMedium = DefaultM3Typography.labelMedium.inter(),
    labelSmall = DefaultM3Typography.labelSmall.inter()
)

@Composable
fun StoredIptvTheme(content: @Composable () -> Unit) {
    val appearance by IptvApp.get().settings.appearanceTheme.collectAsState(initial = AppearanceTheme.CINEMA)
    IptvTheme(appearance, content)
}

@Composable
fun IptvTheme(appearance: AppearanceTheme = AppearanceTheme.CINEMA, content: @Composable () -> Unit) {
    val palette = appearanceColors(appearance)
    val scheme = remember(appearance) { tvScheme(palette) }
    val material = remember(appearance) { materialScheme(palette) }
    CompositionLocalProvider(LocalAppearanceColors provides palette) {
        MaterialTheme(colorScheme = scheme, typography = ExclusiveTvTypography) {
            M3MaterialTheme(colorScheme = material, typography = ExclusiveM3Typography) {
                val tvText = androidx.tv.material3.LocalTextStyle.current
                val m3Text = androidx.compose.material3.LocalTextStyle.current
                CompositionLocalProvider(
                    androidx.tv.material3.LocalContentColor provides palette.text,
                    androidx.compose.material3.LocalContentColor provides palette.text,
                    androidx.tv.material3.LocalTextStyle provides tvText.inter(),
                    androidx.compose.material3.LocalTextStyle provides m3Text.inter(),
                    content = content,
                )
            }
        }
    }
}
