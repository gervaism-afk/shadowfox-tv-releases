package nl.vanvrouwerff.iptv.ui.settings

import android.view.KeyEvent
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.heightIn
import nl.vanvrouwerff.iptv.BuildConfig
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.toggleableState
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.outlined.SystemUpdate
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.tv.material3.Icon
import androidx.lifecycle.viewmodel.compose.viewModel
import nl.vanvrouwerff.iptv.ui.input.Button
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import nl.vanvrouwerff.iptv.ui.input.Surface
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.ui.parental.PinPad
import nl.vanvrouwerff.iptv.data.settings.SourceTestResult
import nl.vanvrouwerff.iptv.ui.theme.FocusStyle
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.tvFocus
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import androidx.compose.foundation.border

internal enum class SettingsCategory(val label: String) {
    Account("Account"), Appearance("Appearance"), Playback("Playback"), Library("Library"),
    Updates("Updates"),
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    onSaved: () -> Unit,
    onBack: () -> Unit,
    onOpenProfiles: () -> Unit,
    vm: SettingsViewModel = viewModel(),
) {
    val state by vm.state.collectAsState()
    LaunchedEffect(vm) { vm.receivePhoneSubmissions() }
    var category by rememberSaveable { mutableStateOf(SettingsCategory.Account) }

    // BACK goes back without saving — matches the "Terug"-labelled button below, so the
    // remote BACK key is no longer a no-op on this screen.

    Box(modifier = Modifier.fillMaxSize().background(IptvPalette.BackgroundDeep)) {
        SettingsPage(onBack = onBack, pageKey = category, navigation = {
            SettingsCategories(category, onSelect = { category = it })
        }) {
            if (category == SettingsCategory.Updates) {
                SettingsSection("Update center") {
                    nl.vanvrouwerff.iptv.updates.UpdatePanel(flat = true) { label, enabled, action ->
                        val check = label == "Check for updates"
                        SettingsActionButton(label, action, enabled, if (check) "update-check" else "update-install", if (check) 10 else 20, prominent = !check)
                    }
                }
            }

            if (category == SettingsCategory.Account) SettingsSection(title = "Your account") {
                SourceSection(state = state, vm = vm, onSaved = onSaved, onBack = onBack)
            }

            if (category == SettingsCategory.Appearance) SettingsSection("Appearance") {
                AppearanceSettings(state.appearanceTheme, vm::setAppearanceTheme)
            }

            if (category == SettingsCategory.Playback) SettingsSection(title = "Playback & languages") {
                SwitchRow(
                    title = stringResource(R.string.settings_trailers_title),
                    navigationOrder = 10,
                    body = stringResource(R.string.settings_trailers_body),
                    checked = state.trailersAutoplay,
                    onToggle = { vm.setTrailersAutoplay(!state.trailersAutoplay) },
                )
                SwitchRow(
                    title = stringResource(R.string.settings_av_sync_title),
                    navigationOrder = 20,
                    body = stringResource(R.string.settings_av_sync_body),
                    checked = state.hardwareAvSync,
                    onToggle = { vm.setHardwareAvSync(!state.hardwareAvSync) },
                )
                SwitchRow(
                    title = stringResource(R.string.settings_afr_title),
                    navigationOrder = 30,
                    body = stringResource(R.string.settings_afr_body),
                    checked = state.frameRateMatching,
                    onToggle = { vm.setFrameRateMatching(!state.frameRateMatching) },
                )
                ChoiceRow(
                    title = stringResource(R.string.settings_aspect_title),
                    navigationOrder = 40,
                    value = aspectLabel(state.playerAspect),
                    onClick = vm::cycleAspect,
                )
                ChoiceRow(
                    title = stringResource(R.string.settings_audio_lang_title),
                    navigationOrder = 50,
                    value = languageLabel(state.audioLanguage),
                    onClick = vm::cycleAudioLanguage,
                )
                ChoiceRow(
                    title = stringResource(R.string.settings_subtitle_lang_title),
                    navigationOrder = 60,
                    value = languageLabel(state.subtitleLanguage),
                    onClick = vm::cycleSubtitleLanguage,
                )
            }

            if (category == SettingsCategory.Library) SettingsSection(title = "Library preferences") {
                AdultCategorySetting(state.showAdultCategories) { vm.setShowAdultCategories(!state.showAdultCategories) }
                SettingsActions {
                    SettingsActionButton(
                        if (state.refreshing) stringResource(R.string.status_refreshing) else stringResource(R.string.settings_refresh_now),
                        onClick = { vm.refreshNow() }, enabled = !state.refreshing, navigationKey = "library-refresh", navigationOrder = 10)
                    if (state.refreshing) {
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                        )
                    }
                    if (state.refreshError != null && !state.refreshing) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Outlined.ErrorOutline, null, Modifier.size(20.dp), tint = Cinema.Accent)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Refresh didn't finish", color = Cinema.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text("Check your connection and account details, then try Refresh now again.",
                                    color = Cinema.Muted, fontSize = 12.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                }
                Text(
                    stringResource(R.string.settings_refresh_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = IptvPalette.TextSecondary,
                )
                SwitchRow(
                    title = stringResource(R.string.settings_auto_refresh_title),
                    navigationOrder = 20,
                    body = stringResource(R.string.settings_auto_refresh_body),
                    checked = state.autoRefreshEnabled,
                    onToggle = { vm.setAutoRefreshEnabled(!state.autoRefreshEnabled) },
                )
                if (state.autoRefreshEnabled) {
                    SettingsActions {
                        SettingsActionButton(stringResource(R.string.settings_auto_refresh_hour_prev), { vm.bumpAutoRefreshHour(-1) },
                            navigationKey = "library-earlier", navigationOrder = 30)
                        Text(
                            stringResource(R.string.settings_auto_refresh_hour, state.autoRefreshHour),
                            style = MaterialTheme.typography.titleMedium,
                            color = IptvPalette.TextPrimary,
                        )
                        SettingsActionButton(stringResource(R.string.settings_auto_refresh_hour_next), { vm.bumpAutoRefreshHour(1) },
                            navigationKey = "library-later", navigationOrder = 40)
                    }
                }
            }



        }

    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SettingsCategories(selected: SettingsCategory, onSelect: (SettingsCategory) -> Unit) {
    val remote = LocalSettingsRemoteFocus.current
    val items: @Composable () -> Unit = {
        SettingsCategory.entries.forEachIndexed { index, category ->
            var modifier: Modifier = Modifier
            if (remote != null) modifier = modifier.fillMaxWidth().focusRequester(remote.sections.getValue(category))
                .onFocusChanged {
                    if (it.isFocused) {
                        remote.region = SettingsRemoteFocus.Region.Menu
                        remote.selected = category
                        onSelect(category)
                    }
                }.onPreviewKeyEvent { event ->
                    if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false else when (event.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_DPAD_UP -> { if (index > 0) remote.menu(SettingsCategory.entries[index - 1]); true }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (index < SettingsCategory.entries.lastIndex) remote.menu(SettingsCategory.entries[index + 1])
                            else remote.back.requestFocus()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { remote.enter(); true }
                        KeyEvent.KEYCODE_DPAD_LEFT -> true
                        else -> false
                    }
                }
            SettingsMenuItem(category.label, active = selected == category, modifier = modifier,
                icon = if (!settingsOnTv()) null else when (category) {
                    SettingsCategory.Account -> Icons.Outlined.AccountCircle
                    SettingsCategory.Appearance -> Icons.Outlined.Palette
                    SettingsCategory.Playback -> Icons.Outlined.PlayCircleOutline
                    SettingsCategory.Library -> Icons.Outlined.VideoLibrary
                    SettingsCategory.Updates -> Icons.Outlined.SystemUpdate
                },
                onClick = { onSelect(category); remote?.enter() })
        }
    }
    if (remote != null) Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) { items() }
    else FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) { items() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingsActions(content: @Composable () -> Unit) {
    if (settingsOnTv()) Column(Modifier.fillMaxWidth()) { content() }
    else FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
internal fun SettingsActionButton(label: String, onClick: () -> Unit, enabled: Boolean = true,
    navigationKey: String = label, navigationOrder: Int = 0, prominent: Boolean = false) {
    if (!settingsOnTv()) {
        Button(onClick = onClick, enabled = enabled) { Text(label) }
        return
    }
    SettingsOptionSurface(onClick = onClick, enabled = enabled,
        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).settingsControl(navigationKey, navigationOrder, enabled)) { focused ->
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f),
                color = if (!enabled) IptvPalette.TextTertiary else if (focused || prominent) Cinema.Accent else Cinema.Text,
                style = MaterialTheme.typography.labelLarge)
            Text("›", color = if (focused) Cinema.Accent else Cinema.Muted)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SourceSection(
    state: SettingsUiState,
    vm: SettingsViewModel,
    onSaved: () -> Unit,
    onBack: () -> Unit,
) {
    Text(
        text = "Edit your connection details, then choose Save. Playback preferences save automatically.",
        fontSize = 12.sp, lineHeight = 18.sp,
        color = IptvPalette.TextSecondary,
    )
    if (state.filledFromPhone) {
        Text(
            stringResource(R.string.phone_setup_received),
            style = MaterialTheme.typography.bodyMedium,
            color = IptvPalette.AccentSoft,
        )
    }
    when (state.type) {
        SourceType.M3u -> SettingsAccountField(stringResource(R.string.settings_m3u_url), state.m3uUrl, vm::setM3uUrl, navigationOrder = 10)
        SourceType.Xtream -> Column {
            SettingsAccountField(stringResource(R.string.settings_xtream_host), state.host, vm::setHost, navigationOrder = 10)
            SettingsAccountField(stringResource(R.string.settings_xtream_user), state.username, vm::setUsername, navigationOrder = 20)
            SettingsAccountField(stringResource(R.string.settings_xtream_pass), state.password, vm::setPassword, password = true, navigationOrder = 30)
            SettingsAccountField(stringResource(R.string.settings_category_filter), state.categoryFilter, vm::setCategoryFilter, navigationOrder = 40)
            Text(stringResource(R.string.settings_category_filter_hint), fontSize = 12.sp, lineHeight = 18.sp,
                color = IptvPalette.TextSecondary, modifier = Modifier.fillMaxWidth())
        }
    }

    state.validationError?.let {
        Text(text = it, style = MaterialTheme.typography.bodyMedium, color = IptvPalette.Accent)
    }

    SettingsActions {
        SettingsActionButton(stringResource(R.string.settings_save), { vm.save(onSaved) }, !state.saving && !state.testing, "account-save", 50)
        SettingsActionButton(stringResource(if (state.testing) R.string.settings_testing else R.string.settings_test),
            vm::testConnection, !state.testing && !state.saving, "account-test", 60)
        SettingsActionButton(stringResource(R.string.detail_back), onBack, navigationKey = "account-back", navigationOrder = 70)
        if (state.testing) {
            androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
        }
    }
    state.testResult?.let { TestResultLine(it) }

    Spacer(Modifier.height(4.dp))
    SettingsInformation("account-phone-setup", 80) { PhoneSetupPanel() }
}

@Composable
private fun TestResultLine(result: SourceTestResult) {
    val (text, color) = when (result) {
        is SourceTestResult.Ok -> stringResource(
            R.string.settings_test_ok,
            formatCount(result.live),
            formatCount(result.movies),
            formatCount(result.series),
        ) to IptvPalette.TextPrimary
        is SourceTestResult.Failed -> {
            val reason = when (result.reason) {
                SourceTestResult.Reason.BadLogin -> stringResource(R.string.settings_test_bad_login)
                SourceTestResult.Reason.HostUnreachable -> stringResource(R.string.settings_test_unreachable)
                SourceTestResult.Reason.Timeout -> stringResource(R.string.settings_test_timeout)
                SourceTestResult.Reason.NotAPlaylist -> stringResource(R.string.settings_test_not_playlist)
                SourceTestResult.Reason.HttpError,
                SourceTestResult.Reason.Other,
                -> stringResource(R.string.settings_test_other, result.detail ?: "")
            }
            reason to IptvPalette.Accent
        }
    }
    Text(text = text, style = MaterialTheme.typography.bodyMedium, color = color)
}

private fun formatCount(n: Int): String =
    java.text.NumberFormat.getIntegerInstance(java.util.Locale("nl", "NL")).format(n)

@Composable
internal fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = title,
            fontSize = 25.sp, lineHeight = 31.sp, fontWeight = FontWeight.SemiBold,
            color = IptvPalette.TextPrimary,
        )
        val description = when (title) {
            "Your account" -> "Keep your cinema connected."
            "Appearance" -> "Make it feel like your cinema."
            "Playback & languages" -> "Picture, sound and language, just how you like them."
            "Library preferences" -> "Choose what you see and keep it up to date."
            "Update center" -> "The latest improvements, in one place."
            else -> null
        }
        if (description != null) Text(description, fontSize = 12.sp, lineHeight = 18.sp, color = Cinema.Muted)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Cinema.Line),
        )
        content()
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
internal fun SwitchRow(title: String, body: String?, checked: Boolean, onToggle: () -> Unit, navigationOrder: Int = 0) {
    SettingsOptionSurface(
        onClick = onToggle,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .semantics { role = Role.Switch; toggleableState = if (checked) ToggleableState.On else ToggleableState.Off }
            .settingsControl("row:$title", navigationOrder),
    ) { focused ->
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium, color = if (focused) Cinema.Accent else Cinema.Text)
                body?.let {
                    Text(it, fontSize = 12.sp, lineHeight = 18.sp, color = IptvPalette.TextSecondary)
                }
            }
            Spacer(Modifier.width(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (settingsOnTv()) Text(if (checked) "On" else "Off", fontSize = 12.sp,
                    color = if (checked) Cinema.Accent else Cinema.Muted)
                SwitchVisual(checked)
            }
        }
    }
}

/** Track + thumb drawn in app colours; the whole row is the focus/click target. */
@Composable
private fun SwitchVisual(checked: Boolean) {
    Box(
        modifier = Modifier
            .size(width = 48.dp, height = 26.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(if (checked) IptvPalette.Accent else IptvPalette.SurfaceElevated)
            .padding(3.dp),
        contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Color.White),
        )
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
internal fun ChoiceRow(title: String, value: String, onClick: () -> Unit, navigationOrder: Int = 0) {
    SettingsOptionSurface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .settingsControl("row:$title", navigationOrder),
    ) { focused ->
        val compact = LocalConfiguration.current.screenWidthDp < 600
        if (compact) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium, color = if (focused) Cinema.Accent else Cinema.Text)
                Text("$value  ›", color = IptvPalette.AccentSoft, fontSize = 13.sp, lineHeight = 19.sp)
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f), color = if (focused) Cinema.Accent else Cinema.Text)
                Text("$value  ›", fontSize = 13.sp, lineHeight = 19.sp,
                    color = IptvPalette.AccentSoft, modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.End)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun SegmentPill(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(999.dp)
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(shape),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (selected) IptvPalette.Accent else IptvPalette.SurfaceLift,
            contentColor = if (selected) IptvPalette.OnAccent else IptvPalette.TextSecondary,
            focusedContainerColor = if (selected) IptvPalette.Accent else FocusStyle.Fill,
            focusedContentColor = if (selected) IptvPalette.OnAccent else IptvPalette.TextPrimary,
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        modifier = Modifier
            .onFocusChanged { focused = it.isFocused }
            .tvFocus(focused, shape, FocusStyle.ChipScale),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp),
        )
    }
}

@Composable
private fun aspectLabel(value: String): String = stringResource(
    when (value) {
        "FILL" -> R.string.player_aspect_fill
        "ZOOM" -> R.string.player_aspect_zoom
        else -> R.string.player_aspect_fit
    },
)

@Composable
private fun languageLabel(code: String): String = when (code) {
    "" -> stringResource(R.string.settings_lang_none)
    "off" -> stringResource(R.string.settings_lang_off)
    else -> java.util.Locale(code).getDisplayLanguage(java.util.Locale("nl", "NL"))
        .replaceFirstChar { it.uppercase() }
}
