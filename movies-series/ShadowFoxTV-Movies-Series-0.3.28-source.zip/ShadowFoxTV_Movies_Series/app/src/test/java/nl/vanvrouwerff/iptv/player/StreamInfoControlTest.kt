package nl.vanvrouwerff.iptv.player

import android.app.Application
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class StreamInfoControlTest {
    @get:Rule val compose = createComposeRule()

    private fun controls(onInfo: () -> Unit) {
        compose.setContent { IptvTheme {
            PlayerControlsOverlay(
                ui = ControlsUi("Test movie", null, false, false, false, false, 0),
                playerProvider = { null }, onPlayPause = {}, onSeekBy = {},
                onOpenTracks = {}, onOpenStreamInfo = onInfo, onFromStart = {},
                onNextEpisode = {}, onPreviousChannel = {}, onStartOver = {}, onInteraction = {},
            )
        } }
    }

    @Test fun remoteOpensStreamInfoWithoutUsingAColorKey() {
        var opened = false
        controls { opened = true }
        compose.onNodeWithText("Stream info").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Stream info").performKeyInput { pressKey(Key.DirectionCenter) }
        assertTrue(opened)
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun narrowPhoneShowsAndTouchesStreamInfoWithoutClippingActions() {
        var opened = false
        controls { opened = true }
        val root = compose.onRoot().fetchSemanticsNode().boundsInRoot
        listOf("Stream info", "Play from beginning").forEach { text ->
            val node = compose.onNodeWithText(text)
            node.assertIsDisplayed()
            val bounds = node.fetchSemanticsNode().boundsInRoot
            assertTrue(bounds.left >= root.left && bounds.right <= root.right)
        }
        compose.onNodeWithText("Stream info").performClick()
        assertTrue(opened)
    }
}
