package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28], application=Application::class, qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SettingsRemotePathsTest {
    @get:Rule val compose=createComposeRule()
    private fun fixture() {
        var category by mutableStateOf(SettingsCategory.Account)
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            SettingsPage(onBack={},pageKey=category,navigation={SettingsCategories(category){category=it}}) {
                if(category==SettingsCategory.Account) SettingsAccountField("Server","fixture",{})
                else {
                    SwitchRow("First option","Fixture",false,{})
                    SwitchRow("Second option","Fixture",false,{})
                }
            }
        } }
    }
    @Test fun initialFocusIsTheSelectedSectionWithoutOpeningTheKeyboard() {
        fixture()
        compose.onNodeWithText("Account").assertIsFocused()
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
    }
    @Test fun rightEntersControlsAndLeftReturnsToTheSameSection() {
        fixture()
        val playback=compose.onNodeWithText("Playback")
        playback.performSemanticsAction(SemanticsActions.RequestFocus)
        playback.performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onNodeWithText("First option").assertIsFocused()
        compose.onNodeWithText("First option").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Second option").assertIsFocused()
        compose.onNodeWithText("Second option").performKeyInput { pressKey(Key.DirectionLeft) }
        playback.assertIsFocused()
        playback.performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithText("Second option").assertIsFocused()
    }
}
