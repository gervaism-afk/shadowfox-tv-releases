package nl.vanvrouwerff.iptv.player

import android.app.Application
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.CinemaActionButton
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class TimelineInteractionTest {
    @get:Rule val compose = createComposeRule()
    private val timeline get() = compose.onNodeWithContentDescription("Playback position")

    private fun fixture(position: Long = 120_000L, seek: (Long) -> Unit, pause: () -> Unit = {}, interaction: () -> Unit = {}) {
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            Column(Modifier.fillMaxWidth()) {
                Timebar(position, 600_000L, 300_000L, Modifier, pause, seek, interaction)
                CinemaActionButton(onClick = {}) { Text("Audio / Subtitles") }
            }
        } }
    }

    @Test fun remoteArrowsSeekAndOkPausesWithoutLeavingTimeline() {
        val deltas = mutableListOf<Long>(); var pauses = 0
        fixture(seek = { deltas += it }, pause = { pauses++ })
        timeline.performSemanticsAction(SemanticsActions.RequestFocus)
        timeline.performKeyInput { pressKey(Key.DirectionLeft); pressKey(Key.DirectionRight); pressKey(Key.DirectionCenter) }
        assertEquals(listOf(-10_000L, 10_000L), deltas)
        assertEquals(1, pauses)
        timeline.assertIsFocused()
        timeline.performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Audio / Subtitles").assertIsFocused()
        compose.onNodeWithText("Audio / Subtitles").performKeyInput { pressKey(Key.DirectionUp) }
        timeline.assertIsFocused()
    }

    @Test fun accessibilityCanReadAndAdjustPositionWithinBounds() {
        val deltas = mutableListOf<Long>()
        fixture(seek = { deltas += it })
        timeline.assertHeightIsAtLeast(48.dp)
        timeline.assert(SemanticsMatcher.expectValue(androidx.compose.ui.semantics.SemanticsProperties.StateDescription, "2:00 of 10:00"))
        timeline.performSemanticsAction(SemanticsActions.SetProgress) { it(2f) }
        timeline.performSemanticsAction(SemanticsActions.SetProgress) { it(-1f) }
        assertEquals(listOf(480_000L, -120_000L), deltas)
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun touchSwipeSeeksOnceAndDoesNotTogglePlayback() {
        val deltas = mutableListOf<Long>(); var pauses = 0; var interactions = 0
        fixture(seek = { deltas += it }, pause = { pauses++ }, interaction = { interactions++ })
        timeline.performTouchInput { swipe(Offset(width * 0.2f, centerY), Offset(width * 0.6f, centerY), 800L) }
        assertEquals(1, deltas.size)
        assertTrue(deltas.single() in 180_000L..250_000L)
        assertEquals(0, pauses)
        assertTrue(interactions >= 2)
        timeline.performTouchInput { click() }
        assertEquals(1, pauses)
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun swipeClampsAtBeginningAndKeepsExpandedTouchTarget() {
        val deltas = mutableListOf<Long>()
        fixture(position = 5_000L, seek = { deltas += it })
        timeline.assertHeightIsAtLeast(48.dp)
        // Near the top of the touch target, well outside the thin painted track.
        timeline.performTouchInput { swipe(Offset(width * 0.8f, 4f), Offset(width * 0.2f, 4f), 500L) }
        assertEquals(listOf(-5_000L), deltas)
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun cancelledSwipeDoesNotSeekOrPause() {
        val deltas = mutableListOf<Long>(); var pauses = 0
        fixture(seek = { deltas += it }, pause = { pauses++ })
        timeline.performTouchInput {
            down(Offset(width * 0.2f, centerY))
            moveTo(Offset(width * 0.7f, centerY), 200L)
            cancel()
        }
        assertTrue(deltas.isEmpty()); assertEquals(0, pauses)
    }
}
