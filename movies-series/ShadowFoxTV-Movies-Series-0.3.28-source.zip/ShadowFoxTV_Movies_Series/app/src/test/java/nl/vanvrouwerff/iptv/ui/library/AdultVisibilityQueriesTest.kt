package nl.vanvrouwerff.iptv.ui.library

import android.app.Application
import androidx.paging.PagingSource
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.db.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class)
class AdultVisibilityQueriesTest {
    @Test fun hideAndUnhideFilterMoviesSeriesSearchSavedAndDiscoveryWithoutDeletingAnything()=runBlocking {
        val db=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),IptvDatabase::class.java).allowMainThreadQueries().build()
        try {
            val dao=db.channelDao()
            dao.insertChannels(listOf(
                ChannelEntity("am","Fixture adult movie",null,"XXX Adult",null,null,0,"MOVIE"),
                ChannelEntity("as","Fixture adult series",null,"18+",null,null,1,"SERIES"),
                ChannelEntity("fm","Fixture family movie",null,"Family",null,null,2,"MOVIE"),
                ChannelEntity("fs","Fixture family series",null,"Family",null,null,3,"SERIES")))
            for(id in listOf("am","as","fm","fs"))dao.addFavorite("default",id,1)
            for(show in listOf(true,false,true)) {
                val hide=AdultContent.shouldHide(false,show)
                for(type in listOf("MOVIE","SERIES")) {
                    val expected=if(show)2 else 1
                    assertEquals(expected,dao.observeLibraryCount(type,null,"%Fixture%",false,"default",hide).first())
                    assertEquals(expected,dao.observeLibraryCount(type,null,"%Fixture%",true,"default",hide).first())
                    val page=dao.pagingFilteredLibrary(type,null,"%Fixture%",true,"default",hide)
                        .load(PagingSource.LoadParams.Refresh(null,60,true)) as PagingSource.LoadResult.Page<Int,ChannelEntity>
                    assertEquals(expected,page.data.size)
                    assertEquals(expected,dao.observeDiscoveryCount(type,hide,emptyList()).first())
                    val categories=dao.observeHomeCategories(type,hide).first()
                    if(hide)assertFalse(categories.any{AdultContent.isAdultCategory(it.name)})
                }
                assertEquals(if(show)4 else 2,dao.observeHomeSaved("default",hide,12).first().size)
            }
            assertEquals(4,dao.observeHomeSaved("default",false,12).first().size)
        }finally{db.close()}
    }
}
