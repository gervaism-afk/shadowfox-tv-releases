package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28], application=Application::class, qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SettingsRemoteRegressionTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    private var exits=0
    private var changes=0
    private var refreshing by mutableStateOf(false)
    private var checking by mutableStateOf(false)
    private var username by mutableStateOf("fixture-user")
    private var theme by mutableStateOf(AppearanceTheme.SHADOWFOX_EXCLUSIVE)
    private fun fixture() {
        var category by mutableStateOf(SettingsCategory.Account)
        compose.setContent { IptvTheme(theme) {
            SettingsPage(onBack={exits++},pageKey=category,navigation={SettingsCategories(category){category=it}}) {
                SettingsSection(when(category) {
                    SettingsCategory.Account -> "Your account"
                    SettingsCategory.Appearance -> "Appearance"
                    SettingsCategory.Playback -> "Playback & languages"
                    SettingsCategory.Library -> "Library refresh"
                    SettingsCategory.Updates -> "App updates"
                }) {
                when(category) {
                    SettingsCategory.Account -> {
                        SettingsAccountField("Server","https://fixture.invalid",{},navigationOrder=10)
                        SettingsAccountField("Username",username,{username=it},navigationOrder=20)
                        SettingsAccountField("Password","fixture-password",{},password=true,navigationOrder=30)
                        SettingsActionButton("Save",{changes++},navigationKey="save",navigationOrder=40)
                    }
                    SettingsCategory.Appearance -> AppearanceSettings(theme){theme=it}
                    SettingsCategory.Playback -> {
                        SwitchRow("Autoplay trailers","A long explanation of this option that wraps on smaller screens.",false,{changes++},10)
                        SwitchRow("Hardware sync","Playback timing explanation.",false,{changes++},20)
                        SwitchRow("Frame rate","Frame rate explanation.",false,{changes++},30)
                        ChoiceRow("Aspect ratio","Fit",{changes++},40)
                        ChoiceRow("Audio language","No preference",{changes++},50)
                        ChoiceRow("Subtitle language","No preference",{changes++},60)
                    }
                    SettingsCategory.Library -> {
                        SettingsActionButton(if(refreshing) "Refreshing…" else "Refresh now",{refreshing=true},!refreshing,"refresh",10)
                        SwitchRow("Auto refresh","Daily library update",false,{changes++},20)
                        SettingsActionButton("Earlier",{changes++},navigationKey="earlier",navigationOrder=30)
                        SettingsActionButton("Later",{changes++},navigationKey="later",navigationOrder=40)
                    }
                    SettingsCategory.Updates -> SettingsActionButton("Check for updates",{checking=true},!checking,"check",10)
                }
                }
            }
        } }
    }
    private fun key(key: Key, count: Int=1) {
        repeat(count) { compose.onRoot().performKeyInput { pressKey(key) } }
    }
    private fun menu(label:String)=compose.onNode(hasText(label) and isFocusable())
    private fun section(label:String) {
        menu(label).performSemanticsAction(SemanticsActions.RequestFocus)
        menu(label).assertIsFocused()
    }
    private fun fullyVisible(label:String) {
        val row=compose.onNodeWithText(label).assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        val viewport=compose.onNodeWithTag("settings-viewport").fetchSemanticsNode().boundsInRoot
        assertTrue("$label must be completely inside the content viewport: $row / $viewport",
            row.top>=viewport.top-1f && row.bottom<=viewport.bottom+1f && row.left>=viewport.left-1f && row.right<=viewport.right+1f)
    }
    private fun screenshot(name:String) {
        val dir=requireNotNull(File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile)
        dir.mkdirs()
        compose.runOnUiThread {
            val view=compose.activity.window.decorView
            val image=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            view.draw(Canvas(image))
            dir.resolve(name).outputStream().use { image.compress(Bitmap.CompressFormat.PNG,100,it) }
            image.recycle()
        }
    }
    @Test fun menuMovesVerticallyWithoutChangingPreferencesOrOpeningTheKeyboard() {
        fixture()
        menu("Account").assertIsFocused()
        listOf("Appearance","Playback","Library","Updates","Back").forEach {
            key(Key.DirectionDown);menu(it).assertIsFocused()
        }
        key(Key.DirectionDown);menu("Back").assertIsFocused()
        key(Key.DirectionUp);menu("Updates").assertIsFocused()
        key(Key.DirectionRight);compose.onNodeWithText("Check for updates").assertIsFocused()
        key(Key.DirectionUp);menu("Updates").assertIsFocused()
        assertEquals(0,changes);assertEquals(0,exits);assertFalse(checking)
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
    }
    @Test fun playbackRowsScrollFullyAndStopAtTheBottom() {
        fixture();section("Playback");key(Key.DirectionRight)
        listOf("Autoplay trailers","Hardware sync","Frame rate","Aspect ratio","Audio language","Subtitle language").forEachIndexed { index,label ->
            if(index>0)key(Key.DirectionDown)
            compose.onNodeWithText(label).assertIsFocused();fullyVisible(label)
        }
        key(Key.DirectionDown,20)
        compose.onNodeWithText("Subtitle language").assertIsFocused();fullyVisible("Subtitle language")
        assertEquals(0,changes)
        screenshot("settings-exclusive-tv-bottom.png")
        key(Key.DirectionUp,5);compose.onNodeWithText("Autoplay trailers").assertIsFocused();fullyVisible("Autoplay trailers")
        key(Key.DirectionUp);menu("Playback").assertIsFocused()
    }
    @Test fun sectionReturnRestoresLastControlAndScrollPosition() {
        fixture();section("Playback");key(Key.DirectionRight);key(Key.DirectionDown,5)
        val before=compose.onNodeWithText("Subtitle language").fetchSemanticsNode().boundsInRoot
        key(Key.DirectionLeft);menu("Playback").assertIsFocused()
        key(Key.DirectionUp);menu("Appearance").assertIsFocused()
        key(Key.DirectionRight);compose.onNodeWithText("Cinema").assertIsFocused()
        key(Key.DirectionLeft);key(Key.DirectionDown);key(Key.DirectionRight)
        compose.onNodeWithText("Subtitle language").assertIsFocused();fullyVisible("Subtitle language")
        val after=compose.onNodeWithText("Subtitle language").fetchSemanticsNode().boundsInRoot
        assertEquals(before.top,after.top,1f);assertEquals(before.bottom,after.bottom,1f)
    }
    @Test fun backReturnsToMenuBeforeLeavingSettings() {
        fixture();section("Playback");key(Key.DirectionRight)
        compose.runOnUiThread { compose.activity.onBackPressedDispatcher.onBackPressed() }
        menu("Playback").assertIsFocused();assertEquals(0,exits)
        compose.runOnUiThread { compose.activity.onBackPressedDispatcher.onBackPressed() }
        assertEquals(1,exits)
    }
    @Test fun disablingTheFocusedActionMovesToAnEnabledControl() {
        fixture();section("Library");key(Key.DirectionRight)
        compose.onNodeWithText("Refresh now").assertIsFocused()
        key(Key.DirectionCenter)
        compose.onNodeWithText("Refreshing…").assertIsNotEnabled()
        compose.onNodeWithText("Auto refresh").assertIsFocused()
        key(Key.DirectionDown);compose.onNodeWithText("Earlier").assertIsFocused()
        key(Key.DirectionDown);compose.onNodeWithText("Later").assertIsFocused()
        key(Key.DirectionLeft);section("Updates");key(Key.DirectionRight);key(Key.DirectionCenter)
        menu("Updates").assertIsFocused()
        compose.runOnIdle { checking=false }
        key(Key.DirectionRight);compose.onNodeWithText("Check for updates").assertIsFocused()
    }
    @Test fun cancellingAnEditorRestoresItsRowAndNavigation() {
        fixture();key(Key.DirectionRight);key(Key.DirectionDown)
        compose.onNodeWithText("Username").assertIsFocused();key(Key.DirectionCenter)
        compose.onNode(hasSetTextAction()).performTextReplacement("unsaved-fixture")
        compose.onNodeWithText("Cancel").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Cancel").performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
        compose.onNodeWithText("Username").assertIsFocused()
        assertEquals("fixture-user",username)
        key(Key.DirectionDown);compose.onNodeWithText("Password").assertIsFocused()
        compose.onNodeWithText("fixture-password").assertDoesNotExist()
        key(Key.DirectionLeft);menu("Account").assertIsFocused()
    }
    @Test fun aFastBusyStateDoesNotLeaveFocusStuck() {
        fixture();section("Updates");key(Key.DirectionRight)
        compose.onNodeWithText("Check for updates").assertIsFocused()
        compose.runOnIdle { checking=true }
        compose.runOnIdle { checking=false }
        key(Key.DirectionLeft);menu("Updates").assertIsFocused()
        key(Key.DirectionRight);compose.onNodeWithText("Check for updates").assertIsFocused()
    }
    @Test fun themeChangeKeepsFocusedChoiceAndMenuReturn() {
        fixture();section("Appearance");key(Key.DirectionRight);key(Key.DirectionDown);key(Key.DirectionCenter)
        compose.onNodeWithText("ShadowFox Exclusive").assertIsFocused().assertIsSelected()
        key(Key.DirectionUp);key(Key.DirectionCenter)
        compose.onNodeWithText("Cinema").assertIsFocused().assertIsSelected()
        key(Key.DirectionLeft);menu("Appearance").assertIsFocused()
    }
    @Test
    @Config(qualifiers="w720dp-h480dp-land-television-xhdpi")
    fun smallTvKeepsLongRowsInsideTheViewport() {
        theme=AppearanceTheme.CINEMA
        fixture();section("Playback");key(Key.DirectionRight);key(Key.DirectionDown,5)
        fullyVisible("Subtitle language")
        menu("Playback").assertIsDisplayed()
        screenshot("settings-cinema-small-tv.png")
    }
}
