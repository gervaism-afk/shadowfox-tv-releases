package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.data.settings.SettingsStore
import nl.vanvrouwerff.iptv.ui.theme.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class AppearanceSettingsTest {
    @get:Rule val compose = createComposeRule()

    @Test fun absentOrUnknownPreferenceKeepsCinema() {
        assertEquals(AppearanceTheme.CINEMA, AppearanceTheme.fromId(null))
        assertEquals(AppearanceTheme.CINEMA, AppearanceTheme.fromId("future-theme"))
        AppearanceTheme.entries.forEach { assertEquals(it, AppearanceTheme.fromId(it.id)) }
    }

    @Test fun storedChoiceSurvivesNewStoreWithoutChangingAccountOrPlaybackPreferences() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = SettingsStore(context)
        store.saveXtream("https://fixture.invalid", "fixture-user", "fixture-password")
        store.setPlayerAspect("ZOOM")
        store.setTrailersAutoplay(false)
        val account = store.sourceConfig.first()
        store.setAppearanceTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE)
        val restored = SettingsStore(context)
        assertEquals(AppearanceTheme.SHADOWFOX_EXCLUSIVE, restored.appearanceTheme.first())
        assertEquals(account, restored.sourceConfig.first())
        assertEquals("ZOOM", restored.playerAspect.first())
        assertFalse(restored.trailersAutoplay.first())
        restored.setAppearanceTheme(AppearanceTheme.CINEMA)
        assertEquals(account, restored.sourceConfig.first())
    }

    @Test fun exclusivePaletteHasReadableTextAndAccentControls() {
        val p = appearanceColors(AppearanceTheme.SHADOWFOX_EXCLUSIVE)
        fun contrast(a: Color, b: Color): Float {
            val x = a.luminance(); val y = b.luminance()
            return (maxOf(x, y) + 0.05f) / (minOf(x, y) + 0.05f)
        }
        assertEquals(Color(0xFF58D2FF), p.accent)
        listOf(p.background, p.surface, p.surface2, p.high).forEach { surface ->
            listOf(p.text, p.textSub, p.textDim).forEach { ink -> assertTrue(contrast(ink, surface) >= 4.5f) }
        }
        assertTrue(contrast(p.background, p.accent) >= 4.5f)
        assertTrue(contrast(p.focusRing, p.surface2) >= 3f)
    }

    @Test fun themesAreScopedAndTypographyPreservesLayoutMetrics() {
        var classic: Color? = null
        var exclusive: Color? = null
        var classicStyle: androidx.compose.ui.text.TextStyle? = null
        var exclusiveStyle: androidx.compose.ui.text.TextStyle? = null
        compose.setContent { Column {
            IptvTheme(AppearanceTheme.CINEMA) {
                classic = IptvPalette.Accent
                classicStyle = androidx.tv.material3.MaterialTheme.typography.bodyMedium
            }
            IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
                exclusive = IptvPalette.Accent
                exclusiveStyle = androidx.tv.material3.MaterialTheme.typography.bodyMedium
                assertEquals(IptvPalette.BackgroundDeep, IptvPalette.OnAccent)
            }
        } }
        compose.runOnIdle {
            assertEquals(Color(0xFFE4BD8A), classic)
            assertEquals(Color(0xFF58D2FF), exclusive)
            assertEquals(classicStyle!!.fontSize, exclusiveStyle!!.fontSize)
            assertEquals(classicStyle!!.lineHeight, exclusiveStyle!!.lineHeight)
            assertEquals(ExclusiveFontFamily, exclusiveStyle!!.fontFamily)
        }
    }

    @Test fun remoteCanSwitchThemesImmediatelyWithoutLosingFocus() {
        var selected by mutableStateOf(AppearanceTheme.CINEMA)
        compose.setContent { IptvTheme(selected) { AppearanceSettings(selected) { selected = it } } }
        val exclusive = compose.onNodeWithText("ShadowFox Exclusive")
        exclusive.performSemanticsAction(SemanticsActions.RequestFocus)
        exclusive.performKeyInput { pressKey(Key.DirectionCenter) }
        exclusive.assertIsSelected().assertIsFocused()
        compose.runOnIdle { assertEquals(AppearanceTheme.SHADOWFOX_EXCLUSIVE, selected) }
        val classic = compose.onNodeWithText("Cinema")
        classic.performSemanticsAction(SemanticsActions.RequestFocus)
        classic.performKeyInput { pressKey(Key.DirectionCenter) }
        classic.assertIsSelected().assertIsFocused()
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun phoneChoicesFitAndSupportTouch() {
        var selected by mutableStateOf(AppearanceTheme.CINEMA)
        compose.setContent { IptvTheme(selected) { AppearanceSettings(selected) { selected = it } } }
        compose.onNodeWithText("ShadowFox Exclusive").assertIsDisplayed().performTouchInput { click() }
        compose.onNodeWithText("ShadowFox Exclusive").assertIsSelected()
        val viewport = compose.onRoot().fetchSemanticsNode().boundsInRoot
        listOf("Cinema", "ShadowFox Exclusive").forEach { title ->
            val bounds = compose.onNodeWithText(title).fetchSemanticsNode().boundsInRoot
            assertTrue(bounds.left >= viewport.left && bounds.right <= viewport.right)
        }
    }
}
