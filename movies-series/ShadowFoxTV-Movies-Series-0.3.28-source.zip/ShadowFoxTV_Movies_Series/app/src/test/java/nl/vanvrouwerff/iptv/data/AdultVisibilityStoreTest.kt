package nl.vanvrouwerff.iptv.data

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.settings.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class)
class AdultVisibilityStoreTest {
    @Test fun visibilityDefaultsToShownAndPersistsWithoutChangingAccountThemeOrHistoryKeys()=runBlocking {
        val context=ApplicationProvider.getApplicationContext<Application>()
        val store=SettingsStore(context)
        assertTrue(store.showAdultCategories.first())
        store.saveXtream("https://fixture.invalid","fixture-user","fixture-password")
        store.setAppearanceTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE)
        store.setLastWatched("default","fixture-channel")
        store.setTrailersAutoplay(false)
        val account=store.sourceConfig.first()
        store.setShowAdultCategories(false)
        val reopened=SettingsStore(context)
        assertFalse(reopened.showAdultCategories.first())
        assertEquals(account,reopened.sourceConfig.first())
        assertEquals(AppearanceTheme.SHADOWFOX_EXCLUSIVE,reopened.appearanceTheme.first())
        assertEquals("fixture-channel",reopened.lastWatchedChannelId("default").first())
        assertFalse(reopened.trailersAutoplay.first())
        reopened.setShowAdultCategories(true)
        assertTrue(store.showAdultCategories.first())
        assertEquals(account,store.sourceConfig.first())
    }
}
