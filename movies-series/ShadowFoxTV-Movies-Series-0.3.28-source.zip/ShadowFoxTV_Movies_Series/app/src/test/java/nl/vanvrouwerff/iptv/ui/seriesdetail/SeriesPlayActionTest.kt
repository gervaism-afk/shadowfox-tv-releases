package nl.vanvrouwerff.iptv.ui.seriesdetail

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.db.WatchProgressEntity
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SeriesPlayActionTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    private fun ep(season:Int,number:Int)=Episode("xt-episode:$season-$number","$season-$number",season,number,
        "Episode $number","https://fixture.invalid/$season/$number",null,null,600)
    private val seasons=seriesSeasonsInPlaybackOrder(listOf(
        SeriesSeason(0,"Specials",listOf(ep(0,1))),SeriesSeason(2,"Season 2",listOf(ep(2,1))),
        SeriesSeason(1,"Season 1",listOf(ep(1,1),ep(1,2)))))
    private fun screenshot(name:String) {
        val dir=requireNotNull(File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile);dir.mkdirs()
        compose.runOnUiThread {
            val view=compose.activity.window.decorView
            val image=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            view.draw(Canvas(image));dir.resolve(name).outputStream().use{image.compress(Bitmap.CompressFormat.PNG,100,it)};image.recycle()
        }
    }
    @Test fun mainPlayButtonSendsTheCorrectEpisodeAndPosition() {
        val next=computeNextUp(seasons,emptyList())!!
        var played:String?=null;var position=-1L
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            SeriesPrimaryAction(SeriesDetailState(loading=false,seasons=seasons,nextUp=next)){episode,_,resume->played=episode.id;position=resume}
        } }
        val play=compose.onNodeWithText("Play S1:E1")
        play.performSemanticsAction(SemanticsActions.RequestFocus)
        play.performKeyInput{pressKey(Key.DirectionCenter)}
        assertEquals("xt-episode:1-1",played);assertEquals(0L,position)
    }
    @Test fun continueButtonKeepsTheSavedPositionOfTheFollowingEpisode() {
        val history=listOf(WatchProgressEntity("fixture","xt-episode:1-1",600_000,600_000,20),
            WatchProgressEntity("fixture","xt-episode:1-2",120_000,600_000,10))
        val next=computeNextUp(seasons,history)!!
        var played:String?=null;var position=-1L
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            Column(Modifier.fillMaxSize().background(IptvPalette.BackgroundDeep).padding(32.dp),verticalArrangement=Arrangement.spacedBy(24.dp)) {
                Text("Series · Local preview",color=IptvPalette.TextPrimary)
                SeriesPrimaryAction(SeriesDetailState(loading=false,seasons=seasons,nextUp=next)){episode,_,resume->played=episode.id;position=resume}
                SeasonRow(seasons,1,emptyMap()){}
            }
        } }
        val button=compose.onNodeWithText("Continue S1:E2")
        button.performSemanticsAction(SemanticsActions.RequestFocus);button.performKeyInput{pressKey(Key.DirectionCenter)}
        assertEquals("xt-episode:1-2",played);assertEquals(120_000L,position)
        screenshot("series-resume-tv.png")
    }
    @Test fun loadingToReadyKeepsFocusAndDoesNotStartPlaybackByItself() {
        var state by mutableStateOf(SeriesDetailState())
        var starts=0
        compose.setContent { IptvTheme { SeriesPrimaryAction(state){_,_,_->starts++} } }
        val loading=compose.onNodeWithText("Loading…")
        loading.performSemanticsAction(SemanticsActions.RequestFocus);loading.performKeyInput{pressKey(Key.DirectionCenter)}
        assertEquals(0,starts)
        compose.runOnIdle { state=SeriesDetailState(loading=false,seasons=seasons,nextUp=computeNextUp(seasons,emptyList())) }
        compose.onNodeWithText("Play S1:E1").assertIsFocused()
        assertEquals(0,starts)
    }
    @Test fun remoteCanSelectSpecialsAfterTheMainSeasonsWithoutStartingAnEpisode() {
        var selected by mutableStateOf(1)
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) { SeasonRow(seasons,selected,emptyMap()){selected=it} } }
        val first=compose.onNodeWithText("Season 1")
        first.performSemanticsAction(SemanticsActions.RequestFocus);first.performKeyInput{pressKey(Key.DirectionRight)}
        compose.onNodeWithText("Season 2").assertIsFocused().performKeyInput{pressKey(Key.DirectionRight)}
        compose.onNodeWithText("Specials").assertIsFocused().performKeyInput{pressKey(Key.DirectionCenter)}
        compose.onNodeWithText("Specials").assertIsSelected()
        assertEquals(0,selected)
    }
    @Test
    @Config(qualifiers="w320dp-h640dp-port-notnight-xhdpi")
    fun phoneCanTouchTheMainPlayActionAndSpecials() {
        val compact=listOf(seasons.first(),seasons.last())
        var selected by mutableStateOf(1);var played:String?=null
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            Column(Modifier.fillMaxSize().background(IptvPalette.BackgroundDeep).padding(16.dp),verticalArrangement=Arrangement.spacedBy(24.dp)) {
                Text("Series · Local preview",color=IptvPalette.TextPrimary)
                SeriesPrimaryAction(SeriesDetailState(loading=false,seasons=compact,nextUp=computeNextUp(compact,emptyList()))){episode,_,_->played=episode.id}
                SeasonRow(compact,selected,emptyMap()){selected=it}
            }
        } }
        compose.onNodeWithText("Play S1:E1").assertIsDisplayed().performTouchInput{click()}
        assertEquals("xt-episode:1-1",played)
        compose.onNodeWithText("Specials").assertIsDisplayed().performTouchInput{click()}
        assertEquals(0,selected)
        screenshot("series-start-phone.png")
    }
}
