package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.library.LibraryCategoryPicker
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class AdultCategorySettingTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    private fun screenshot(name:String) {
        val dir=requireNotNull(File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile);dir.mkdirs()
        compose.runOnUiThread {
            val view=compose.activity.window.decorView;val image=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            view.draw(Canvas(image));dir.resolve(name).outputStream().use{image.compress(Bitmap.CompressFormat.PNG,100,it)};image.recycle()
        }
    }
    @Test fun remoteCanToggleTheFirstLibraryOptionAndReturnToTheSameSection() {
        var show by mutableStateOf(true);var selected by mutableStateOf(SettingsCategory.Library)
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            SettingsPage(onBack={},pageKey=selected,navigation={SettingsCategories(selected){selected=it}}) {
                SettingsSection("Library preferences") {
                    AdultCategorySetting(show){show=!show}
                    SettingsActionButton("Refresh library",{},navigationKey="library-refresh",navigationOrder=10)
                }
            }
        } }
        compose.onNodeWithText("Library").assertIsFocused().performKeyInput{pressKey(Key.DirectionRight)}
        val toggle=compose.onNodeWithText("Show Adult categories")
        toggle.assertIsFocused().assertIsOn().performKeyInput{pressKey(Key.DirectionCenter)}
        toggle.assertIsOff().performKeyInput{pressKey(Key.DirectionDown)}
        compose.onNodeWithText("Refresh library").assertIsFocused().performKeyInput{pressKey(Key.DirectionUp)}
        toggle.assertIsFocused().performKeyInput{pressKey(Key.DirectionLeft)}
        compose.onNodeWithText("Library").assertIsFocused().performKeyInput{pressKey(Key.DirectionRight)}
        toggle.assertIsFocused().performKeyInput{pressKey(Key.DirectionCenter)};toggle.assertIsOn();assertTrue(show)
        screenshot("adult-toggle-tv.png")
    }
    @Test @Config(qualifiers="w320dp-h640dp-port-xhdpi")
    fun phoneCanTouchTheWholeVisibilityRowInBothDirections() {
        var show by mutableStateOf(true)
        compose.setContent { IptvTheme {
            SettingsPage(onBack={}) { SettingsSection("Library preferences") { AdultCategorySetting(show){show=!show} } }
        } }
        val row=compose.onNodeWithText("Show Adult categories")
        row.assertIsOn().assertIsDisplayed().performTouchInput{click()};row.assertIsOff()
        row.performTouchInput{click()};row.assertIsOn();assertTrue(show)
        screenshot("adult-toggle-phone.png")
    }
    @Test fun categoryPickerHidesBothTheAdultShortcutAndActualProviderCategories() {
        var show by mutableStateOf(false)
        compose.setContent { IptvTheme {
            LibraryCategoryPicker(listOf("Family","XXX Adult"),show,null,{},{},{},{})
        } }
        compose.onNodeWithText("Adult").assertDoesNotExist();compose.onNodeWithText("XXX Adult").assertDoesNotExist()
        compose.onAllNodesWithText("Family").assertAny(hasText("Family"))
        compose.runOnIdle { show=true }
        compose.onNodeWithText("Adult").assertIsDisplayed();compose.onNodeWithText("XXX Adult").assertExists()
    }
    @Test @Config(qualifiers="w360dp-h800dp-port-xhdpi")
    fun adultShortcutCanBeRestoredEvenWhenTheProviderHasNoAdultCategories() {
        var show by mutableStateOf(false)
        compose.setContent { IptvTheme { LibraryCategoryPicker(emptyList(),show,null,{},{},{},{}) } }
        compose.onNodeWithText("Adult").assertDoesNotExist()
        compose.runOnIdle { show=true };compose.onNodeWithText("Adult").assertIsDisplayed()
    }
}
