package nl.vanvrouwerff.iptv.ui.library

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.*
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AdultVisibilityFlowTest {
    @Test fun kidsRemainRestrictedRegardlessOfTheAdultVisibilityPreference() {
        assertFalse(AdultContent.shouldHide(false, true))
        assertTrue(AdultContent.shouldHide(false, false))
        assertTrue(AdultContent.shouldHide(true, true))
        assertTrue(AdultContent.shouldHide(true, false))
    }
    @Test fun hidingAnAdultSelectionPreservesMediaSearchAndSavedFilter() {
        val selected=LibrarySelection(type=ContentType.SERIES,genre="Adult",genreCategories=listOf("XXX Adult"),query="Fixture",saved=true)
        val cleared=selected.forAdultVisibility(true)
        assertEquals(selected.copy(genre=null,genreCategories=emptyList()),cleared)
        val raw=selected.copy(genre=null,genreCategories=emptyList(),category="18+ Movies")
        assertNull(raw.forAdultVisibility(true).category)
        assertEquals(selected,selected.forAdultVisibility(false))
        val ordinary=LibrarySelection(category="Family",query="Castle")
        assertEquals(ordinary,ordinary.forAdultVisibility(true))
    }
    @Test fun hideAndUnhideUpdateCountsAndCategoriesTogetherWithoutRefreshingTheProvider()=runTest {
        val hidden=MutableStateFlow(false);val states=mutableListOf<LibraryState>();val calls=mutableListOf<Boolean>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(MutableStateFlow(LibrarySelection()),flowOf("default"),hidden,
                {_,_,hide->calls.add(hide);flowOf(if(hide)1 else 3)},
                {flowOf(listOf("Family","XXX Adult","18+ Movies"))},0).collect{states.add(it)}
        }
        runCurrent();assertEquals(3,states.last().count)
        hidden.value=true;runCurrent();assertEquals(listOf("Family"),states.last().categories)
        assertEquals(1,states.last().count);assertTrue(states.last().hideAdult)
        hidden.value=false;runCurrent();assertEquals(3,states.last().count);assertEquals(3,states.last().categories.size)
        assertEquals(listOf(false,true,false),calls)
    }
    @Test fun queriesWaitForTheStoredVisibilityBeforeTheirFirstEmission()=runTest {
        val hidden=MutableSharedFlow<Boolean>(replay=1);val filters=mutableListOf<Triple<LibrarySelection,String,Boolean>>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryFilterFlow(flowOf(LibrarySelection()),flowOf("default"),hidden,0).collect{filters.add(it)}
        }
        runCurrent();assertTrue(filters.isEmpty())
        hidden.emit(true);runCurrent();assertTrue(filters.single().third)
    }
    @Test fun aStaleAdultSelectionCannotBeSentToTheCountOrPagingQueriesWhileHidden()=runTest {
        val selected=LibrarySelection(genre="Adult",genreCategories=listOf("Adult"),query="term")
        val filter=libraryFilterFlow(flowOf(selected),flowOf("default"),flowOf(true),0).first()
        assertNull(filter.first.genre);assertTrue(filter.first.genreCategories.isEmpty());assertEquals("term",filter.first.query)
        assertFalse(usesPlainLibraryQuery(filter.first,filter.third))
    }
}
