package nl.vanvrouwerff.iptv.ui.library

import android.app.Application
import androidx.paging.Pager
import androidx.paging.PagingSource
import androidx.paging.testing.asSnapshot
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.db.ChannelEntity
import nl.vanvrouwerff.iptv.data.db.IptvDatabase
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class ContinuousLibraryQueriesTest {
    @Test fun roomLoadsBoundedAdjacentBatchesAndScrollsBeyondTheOldPageBoundary() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), IptvDatabase::class.java)
            .allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels((0 until 1000).map { ChannelEntity("movie$it", "Title $it", null, "Comedy", null, null, it, "MOVIE") })
            val source = dao.pagingPlainLibrary("MOVIE")
            val first = source.load(PagingSource.LoadParams.Refresh(null, 60, true)) as PagingSource.LoadResult.Page<Int, ChannelEntity>
            assertEquals(60, first.data.size)
            assertEquals(940, first.itemsAfter)
            val second = source.load(PagingSource.LoadParams.Append(requireNotNull(first.nextKey), 60, true)) as PagingSource.LoadResult.Page<Int, ChannelEntity>
            assertEquals("movie60", second.data.first().id)
            assertTrue(first.data.map { it.id }.intersect(second.data.map { it.id }.toSet()).isEmpty())
            val snapshot = Pager(libraryPagingConfig()) { dao.pagingPlainLibrary("MOVIE") }.flow.asSnapshot { scrollTo(125) }
            assertTrue(snapshot.any { it.id == "movie125" })
            assertEquals(snapshot.size, snapshot.map { it.id }.distinct().size)
            assertTrue(snapshot.size < 1000)
            assertEquals(180, libraryPagingConfig().maxSize)
        } finally { db.close() }
    }

    @Test fun adultPagingRespectsTypeAndKidsAndAnEmptyProviderGroupIsEmpty() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), IptvDatabase::class.java)
            .allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels(listOf(
                ChannelEntity("adult-movie", "Fixture movie", null, "Adult", null, null, 0, "MOVIE"),
                ChannelEntity("adult-series", "Fixture series", null, "Adult", null, null, 1, "SERIES"),
                ChannelEntity("family", "Fixture family", null, "Family", null, null, 2, "MOVIE"),
            ))
            suspend fun ids(type: String, kids: Boolean, groups: List<String>) =
                (dao.pagingGenreLibrary(type, groups, "%%", false, "default", kids)
                    .load(PagingSource.LoadParams.Refresh(null, 60, true)) as PagingSource.LoadResult.Page<Int, ChannelEntity>).data.map { it.id }
            assertEquals(listOf("adult-movie"), ids("MOVIE", false, listOf("Adult")))
            assertEquals(listOf("adult-series"), ids("SERIES", false, listOf("Adult")))
            assertTrue(ids("MOVIE", true, listOf("Adult")).isEmpty())
            assertTrue(ids("MOVIE", false, emptyList()).isEmpty())
        } finally { db.close() }
    }
}
