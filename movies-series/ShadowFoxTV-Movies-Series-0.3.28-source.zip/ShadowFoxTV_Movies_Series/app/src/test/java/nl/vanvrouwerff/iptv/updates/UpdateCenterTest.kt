package nl.vanvrouwerff.iptv.updates

import android.app.Application
import androidx.activity.ComponentActivity
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class UpdateCenterTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private val release = UpdateManifest(UPDATE_PACKAGE, 999, "1.0", "https://raw.githubusercontent.com/gervaism-afk/shadowfox-tv-releases/main/movies-series/fixture.apk", "a".repeat(64), 1024, "Clearer navigation and smoother browsing.")

    private fun screenshot(name: String) {
        val dir = requireNotNull(File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile)
        dir.mkdirs()
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            dir.resolve(name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
        }
    }

    @Test fun failedChecksAndDownloadsNeverClaimTheAppIsCurrent() {
        assertEquals(UpdatePhase.ERROR, updatePhase(UpdateState(checked = true, error = "Offline")))
        assertEquals(UpdatePhase.ERROR, updatePhase(UpdateState(checked = true, release = release, error = "Download failed")))
        assertEquals(UpdatePhase.CHECKING, updatePhase(UpdateState(checking = true, checked = true)))
        assertEquals(UpdatePhase.DOWNLOADING, updatePhase(UpdateState(downloading = true, checked = true, release = release)))
        assertEquals(UpdatePhase.READY, updatePhase(UpdateState(release = release, readyFile = File("verified.apk"))))
        assertEquals(UpdatePhase.CURRENT, updatePhase(UpdateState(checked = true)))
    }

    @Test fun failedCheckExposesRetryWithoutFalseSuccess() {
        var checks = 0
        compose.setContent { IptvTheme { UpdateCenterContent(UpdateState(checked = true, error = "Connection unavailable"), "0.3.24", { checks++ }, {}) } }
        compose.onNodeWithText("Your app is up to date").assertDoesNotExist()
        compose.onNodeWithText("Connection unavailable").assertIsDisplayed()
        val retry = compose.onNodeWithText("Check for updates")
        retry.performSemanticsAction(SemanticsActions.RequestFocus)
        retry.performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertEquals(1, checks) }
        screenshot("update-center-error.png")
    }

    @Test fun busyDownloadDisablesDuplicateActionsAndClampsDisplayedProgress() {
        var theme by mutableStateOf(AppearanceTheme.CINEMA)
        compose.setContent { IptvTheme(theme) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                UpdateCenterContent(UpdateState(release = release, downloading = true, percent = 130), "0.3.24", {}, {})
            }
        } }
        compose.onNodeWithText("Downloading update · 100%").assertExists()
        compose.onNodeWithText("Check for updates").assertIsNotEnabled()
        compose.onNodeWithText("Download & install").assertIsNotEnabled()
        screenshot("update-center-cinema.png")
        compose.runOnIdle { theme = AppearanceTheme.SHADOWFOX_EXCLUSIVE }
        compose.onNodeWithText("Download & install").assertIsNotEnabled()
        screenshot("update-center-exclusive.png")
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-xhdpi")
    fun phoneCanReadReleaseNotesAndInstallVerifiedUpdate() {
        var installs = 0
        compose.setContent { IptvTheme {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                UpdateCenterContent(UpdateState(release = release, readyFile = File("verified.apk")), "0.3.24", {}, { installs++ })
            }
        } }
        compose.onNodeWithText("Installed").assertExists()
        compose.onNodeWithText("Available").assertExists()
        compose.onNodeWithText("What’s new").assertExists()
        compose.onNodeWithText("Install update").performScrollTo().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, installs) }
        screenshot("update-center-phone.png")
    }
}
