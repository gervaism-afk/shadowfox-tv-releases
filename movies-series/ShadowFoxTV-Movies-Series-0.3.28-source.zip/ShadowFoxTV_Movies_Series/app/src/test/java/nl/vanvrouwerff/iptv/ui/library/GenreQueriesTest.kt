package nl.vanvrouwerff.iptv.ui.library

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.db.ChannelEntity
import nl.vanvrouwerff.iptv.data.db.IptvDatabase
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class GenreQueriesTest {
    @Test fun groupedGenresKeepTypeSearchCountPaginationAndKidsScope() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), IptvDatabase::class.java)
            .allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels(listOf(
                ChannelEntity("m1", "Test One", null, "US Comedy", null, null, 0, "MOVIE"),
                ChannelEntity("m2", "Test Two", null, "FR Comedy", null, null, 1, "MOVIE"),
                ChannelEntity("adult", "Test Adult", null, "Adult Comedy", null, null, 2, "MOVIE"),
                ChannelEntity("s1", "Test Show", null, "US Comedy", null, null, 3, "SERIES"),
                ChannelEntity("other", "Test Other", null, "Drama", null, null, 4, "MOVIE"),
            ))
            val groups = listOf("US Comedy", "FR Comedy", "Adult Comedy")
            assertEquals(3, dao.observeGenreLibraryCount("MOVIE", groups, "%Test%", false, "default", false).first())
            assertEquals(listOf("m2"), dao.observeGenreLibraryPage("MOVIE", groups, "%Test%", false, "default", false, 1, 1).first().map { it.id })
            assertEquals(2, dao.observeGenreLibraryCount("MOVIE", groups, "%Test%", false, "default", true).first())
            assertEquals(1, dao.observeGenreLibraryCount("SERIES", groups, "%Test%", false, "default", false).first())
            assertEquals(1, dao.observeGenreLibraryCount("MOVIE", groups, "%Two%", false, "default", false).first())
            assertEquals(0, dao.observeGenreLibraryCount("MOVIE", groups, "%Test%", true, "default", false).first())
            assertEquals(0, dao.observeGenreLibraryCount("MOVIE", emptyList(), "%%", false, "default", false).first())
        } finally { db.close() }
    }
}
