package nl.vanvrouwerff.iptv.ui.library

import android.app.Application
import android.view.KeyEvent
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import androidx.paging.PagingData
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.tv.foundation.lazy.grid.rememberTvLazyGridState
import kotlinx.coroutines.flow.flowOf
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.ui.theme.CinemaChip
import nl.vanvrouwerff.iptv.ui.theme.CinemaNavigation
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class ContinuousLibraryNavigationTest {
    @get:Rule val compose = createComposeRule()
    private val fixtures = (0 until 140).map { index ->
        Channel("fixture-$index", "Title${index.toString().padStart(3, '0')}", null, "Fixture", null, null, ContentType.MOVIE)
    }

    @Test fun searchHeaderDownReachesTheEditor() {
        var query = ""
        val input = LibrarySearchInput("")
        compose.setContent { IptvTheme {
            val header = remember { FocusRequester() }
            val editor = remember { FocusRequester() }
            Column {
                CinemaNavigation("Search", selectedFocus = header, onDown = { editor.requestFocus() }) {}
                LibrarySearchField(input, ContentType.MOVIE, { query = it }, Modifier.focusRequester(editor))
            }
        } }
        compose.onNodeWithText("Search").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Search").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNode(hasSetTextAction()).assertIsFocused().performTextInput("Castle")
        assertEquals("Castle", query)
    }

    @Test fun returningFromADetailRestoresTheTitleBeyondTheFirstBatch() {
        compose.setContent { IptvTheme {
            val titles = remember { flowOf(PagingData.from(fixtures)) }.collectAsLazyPagingItems()
            var target by remember { mutableStateOf<String?>("fixture-85") }
            LibraryTitleGrid(titles, rememberTvLazyGridState(), 5, 85, 0, target, false,
                onExitUp = {}, onExitLeft = {}, onFocus = { _, _ -> },
                onRestored = { target = null }, onOpen = { _, _ -> })
        } }
        compose.onNodeWithText("Title085").assertIsDisplayed().assertIsFocused()
        compose.onNodeWithText("Title000").assertDoesNotExist()
    }

    @Test fun adultShortcutIsVisibleAndRemoteSelectableWithoutProviderGroups() {
        var selected: LibraryGenre? = null
        compose.setContent { IptvTheme {
            LibraryCategoryPicker(listOf("Comedy", "Drama"), selected = null, onAll = {},
                onGenre = { selected = it }, onCategory = {}, onDismiss = {})
        } }
        compose.onNodeWithText("All titles").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Adult").assertIsDisplayed().assertIsFocused()
            .performKeyInput { pressKey(Key.DirectionCenter) }
        assertEquals("Adult", selected?.label)
        assertTrue(selected!!.categories.isEmpty())
    }

    @Test fun remoteMovesBetweenHeaderSidebarAndTheSameGridPositionBeyondSixtyTitles() {
        compose.setContent { IptvTheme {
            val titles = remember { flowOf(PagingData.from(fixtures)) }.collectAsLazyPagingItems()
            val grid = rememberTvLazyGridState()
            val header = remember { FocusRequester() }
            val sidebar = remember { FocusRequester() }
            var focused by remember { mutableIntStateOf(0) }
            var entry by remember { mutableIntStateOf(0) }
            Column(Modifier.fillMaxSize()) {
                CinemaNavigation("Movies", selectedFocus = header, onDown = { entry++ }) {}
                Row(Modifier.weight(1f)) {
                    CinemaChip("All titles", modifier = Modifier.width(140.dp).focusRequester(sidebar)
                        .onPreviewKeyEvent {
                            if (it.nativeKeyEvent.action == KeyEvent.ACTION_DOWN && it.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                                entry++; true
                            } else false
                        }, onClick = {})
                    Box(Modifier.weight(1f)) {
                        LibraryTitleGrid(titles, grid, 5, focused, entry, null, false,
                            onExitUp = { header.requestFocus() }, onExitLeft = { sidebar.requestFocus() },
                            onFocus = { _, index -> focused = index }, onRestored = {}, onOpen = { _, _ -> })
                    }
                }
            }
        } }
        compose.onNodeWithText("Movies").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Movies").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Title000").assertIsFocused()
        compose.onNodeWithTag("library-title-grid").performScrollToIndex(70)
        compose.onNodeWithText("Title070").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Title070").performKeyInput { pressKey(Key.DirectionLeft) }
        compose.onNodeWithText("All titles").assertIsFocused()
        compose.onNodeWithText("All titles").performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithText("Title070").assertIsFocused()
        compose.onNodeWithText("Next").assertDoesNotExist()
        compose.onNodeWithText("Previous").assertDoesNotExist()
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun phoneScrollsPastTheOldBoundaryAndOpensATitleWithTouch() {
        var opened: String? = null
        compose.setContent { IptvTheme {
            val titles = remember { flowOf(PagingData.from(fixtures)) }.collectAsLazyPagingItems()
            LibraryTitleGrid(titles, rememberTvLazyGridState(), 2, 0, 0, null, false,
                onExitUp = {}, onExitLeft = {}, onFocus = { _, _ -> }, onRestored = {},
                onOpen = { channel, _ -> opened = channel.id })
        } }
        compose.onNodeWithTag("library-title-grid").performScrollToIndex(64)
        compose.onNodeWithText("Title064").assertIsDisplayed().performClick()
        assertEquals("fixture-64", opened)
    }
}
