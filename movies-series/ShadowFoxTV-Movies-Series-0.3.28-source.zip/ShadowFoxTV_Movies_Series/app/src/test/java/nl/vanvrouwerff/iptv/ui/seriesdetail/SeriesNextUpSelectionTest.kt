package nl.vanvrouwerff.iptv.ui.seriesdetail

import nl.vanvrouwerff.iptv.data.db.WatchProgressEntity
import org.junit.Assert.*
import org.junit.Test

class SeriesNextUpSelectionTest {
    private fun episode(season:Int,number:Int)=Episode("xt-episode:$season-$number","$season-$number",season,number,
        "Episode $number","https://fixture.invalid/$season/$number",null,null,600)
    private fun season(number:Int,vararg episodes:Int)=SeriesSeason(number,"Season $number",episodes.map{episode(number,it)})
    private fun progress(season:Int,number:Int,position:Long,duration:Long=100,updated:Long=1)=
        WatchProgressEntity("fixture","xt-episode:$season-$number",position,duration,updated)

    @Test fun newSeriesStartsWithMainSeasonInsteadOfSpecials() {
        val next=computeNextUp(listOf(season(0,1),season(1,1,2)),emptyList())!!
        assertEquals("xt-episode:1-1",next.episode.id)
        assertEquals(0L,next.resumeMs);assertFalse(next.isResume)
    }
    @Test fun nextEpisodeKeepsItsExistingResumePosition() {
        val next=computeNextUp(listOf(season(1,1,2,3)),listOf(
            progress(1,1,99,updated=20),progress(1,2,40,updated=10)))!!
        assertEquals("xt-episode:1-2",next.episode.id)
        assertEquals(40L,next.resumeMs);assertTrue(next.isResume)
    }
    @Test fun alreadyWatchedFollowingEpisodesAreSkipped() {
        val next=computeNextUp(listOf(season(1,1,2,3)),listOf(
            progress(1,1,99,updated=20),progress(1,2,100,updated=10)))!!
        assertEquals("xt-episode:1-3",next.episode.id)
    }
    @Test fun finishingMainSeriesDoesNotJumpIntoSpecials() {
        val next=computeNextUp(listOf(season(0,1),season(1,1)),listOf(progress(1,1,100)))!!
        assertEquals("xt-episode:1-1",next.episode.id)
        assertEquals(0L,next.resumeMs);assertFalse(next.isResume)
    }
    @Test fun obsoleteProgressDoesNotHideAValidResume() {
        val next=computeNextUp(listOf(season(1,1,2)),listOf(
            progress(1,2,40,updated=10),progress(9,9,50,updated=20)))!!
        assertEquals("xt-episode:1-2",next.episode.id)
        assertEquals(40L,next.resumeMs);assertTrue(next.isResume)
    }
    @Test fun providerOrderingDoesNotChangeMainSeasonAndEpisodeOrder() {
        val next=computeNextUp(listOf(season(2,2,1),season(0,1),season(1,2,1)),emptyList())!!
        assertEquals("xt-episode:1-1",next.episode.id)
    }
    @Test fun explicitSpecialResumeIsPreserved() {
        val next=computeNextUp(listOf(season(0,1),season(1,1)),listOf(progress(0,1,40)))!!
        assertEquals("xt-episode:0-1",next.episode.id)
        assertEquals(40L,next.resumeMs);assertTrue(next.isResume)
    }
    @Test fun intentionallyWatchedSpecialsCanContinueWithinSpecials() {
        val next=computeNextUp(listOf(season(0,1,2),season(1,1)),listOf(progress(0,1,100)))!!
        assertEquals("xt-episode:0-2",next.episode.id)
        assertFalse(next.isResume)
    }
    @Test fun finishingLastSpecialReturnsToSavedMainEpisode() {
        val next=computeNextUp(listOf(season(0,1),season(1,1,2)),listOf(
            progress(1,2,40,updated=10),progress(0,1,100,updated=20)))!!
        assertEquals("xt-episode:1-2",next.episode.id)
        assertEquals(40L,next.resumeMs);assertTrue(next.isResume)
    }
    @Test fun specialsOnlySeriesStillStartAndAdvance() {
        val seasons=listOf(season(0,1,2))
        assertEquals("xt-episode:0-1",computeNextUp(seasons,emptyList())!!.episode.id)
        assertEquals("xt-episode:0-2",computeNextUp(seasons,listOf(progress(0,1,100)))!!.episode.id)
    }
    @Test fun emptyMainSeasonDoesNotHidePlayableSpecials() {
        val seasons=listOf(season(1),season(0,1))
        assertEquals("xt-episode:0-1",computeNextUp(seasons,emptyList())!!.episode.id)
        assertEquals(0,defaultSeriesSeason(seasons)!!.number)
        assertNull(computeNextUp(listOf(season(0),season(1)),emptyList()))
    }
    @Test fun watchedThresholdMatchesEpisodeRows() {
        val seasons=listOf(season(1,1,2))
        assertEquals("xt-episode:1-2",computeNextUp(seasons,listOf(progress(1,1,95)))!!.episode.id)
        val next=computeNextUp(seasons,listOf(progress(1,1,94)))!!
        assertEquals("xt-episode:1-1",next.episode.id);assertEquals(94L,next.resumeMs)
    }
    @Test fun unknownDurationDoesNotDiscardSavedPosition() {
        val next=computeNextUp(listOf(season(1,1)),listOf(progress(1,1,40,duration=0)))!!
        assertEquals(40L,next.resumeMs);assertTrue(next.isResume)
    }
    @Test fun emptyOrRemovedSeriesHaveNoPlayTarget() {
        assertNull(computeNextUp(emptyList(),listOf(progress(1,1,40))))
        assertNull(computeNextUp(listOf(season(1)),emptyList()))
    }
    @Test fun aMoreRecentResetDoesNotReviveOlderDuplicateProgress() {
        val next=computeNextUp(listOf(season(1,1,2)),listOf(
            progress(1,2,40,updated=1),progress(1,1,100,updated=2),progress(1,2,0,updated=3)))!!
        assertEquals("xt-episode:1-2",next.episode.id);assertEquals(0L,next.resumeMs);assertFalse(next.isResume)
    }
    @Test fun stateFallbackUsesFirstPlayableMainSeasonButKeepsAnExplicitSpecialSelection() {
        val seasons=listOf(season(0,1),season(2,1),season(1,1))
        assertEquals(1,SeriesDetailState(seasons=seasons).selectedSeason!!.number)
        assertEquals(0,SeriesDetailState(seasons=seasons,selectedSeasonNumber=0).selectedSeason!!.number)
    }
    @Test fun genericSeasonZeroLabelIsClearAndProviderNamesArePreserved() {
        assertEquals("Specials",seriesSeasonLabel(0,"Season 0"))
        assertEquals("Specials",seriesSeasonLabel(0,"Seizoen 0"))
        assertEquals("Specials",seriesSeasonLabel(0,null))
        assertEquals("Behind the scenes",seriesSeasonLabel(0,"Behind the scenes"))
        assertEquals("Chapter One",seriesSeasonLabel(1,"Chapter One"))
        assertEquals("Season 2",seriesSeasonLabel(2,null))
    }
    @Test fun preparedPlanUpdatesItsChoiceWithoutMutatingSeasonsOrHistory() {
        val seasons=listOf(season(0,1),season(1,2,1))
        val history=listOf(progress(1,1,40))
        val plan=SeriesPlaybackPlan(seasons)
        assertEquals("xt-episode:1-1",plan.nextUp(emptyList())!!.episode.id)
        assertEquals(40L,plan.nextUp(history)!!.resumeMs)
        assertEquals("xt-episode:1-2",plan.nextUp(listOf(progress(1,1,100)))!!.episode.id)
        assertEquals(0,seasons.first().number)
        assertEquals(listOf(2,1),seasons[1].episodes.map{it.episodeNumber})
        assertEquals(40L,history.single().positionMs)
    }
}
