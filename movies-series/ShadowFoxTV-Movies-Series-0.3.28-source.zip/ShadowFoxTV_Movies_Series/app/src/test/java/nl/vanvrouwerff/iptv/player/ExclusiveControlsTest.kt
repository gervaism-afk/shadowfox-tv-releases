package nl.vanvrouwerff.iptv.player

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.media3.exoplayer.ExoPlayer
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.lang.reflect.Proxy

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class ExclusiveControlsTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    // A fixed clock only. No player engine, decoder, network, account or media source is created.
    private val clock = Proxy.newProxyInstance(ExoPlayer::class.java.classLoader, arrayOf(ExoPlayer::class.java)) { _, method, _ ->
        when (method.name) {
            "getCurrentPosition" -> 120_000L
            "getDuration" -> 600_000L
            "getBufferedPosition" -> 300_000L
            "isPlaying" -> true
            else -> null
        }
    } as ExoPlayer

    private fun fixture(clicked: MutableList<String>, theme: AppearanceTheme = AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
        compose.setContent { IptvTheme(theme) {
            PlayerControlsOverlay(ControlsUi("A movie worth watching", "Movie · Local preview", false, true, focusToken = 0),
                playerProvider = { clock }, onPlayPause = { clicked += "Pause" }, onSeekBy = {},
                onOpenTracks = { clicked += "Audio / Subtitles" }, onOpenStreamInfo = { clicked += "Stream info" },
                onFromStart = { clicked += "Play from beginning" }, onNextEpisode = { clicked += "Next episode" },
                onPreviousChannel = {}, onStartOver = {}, onInteraction = {})
        } }
    }
    private fun screenshot(name: String) {
        val directory = requireNotNull(File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile)
        directory.mkdirs()
        // Robolectric uses a software canvas; PixelCopy waits for a physical-window redraw.
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            directory.resolve(name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
        }
    }

    @Test fun remoteActionsRetainTheirCallbacksAndVisibleFocus() {
        val clicks = mutableListOf<String>(); fixture(clicks)
        val actions = listOf("Pause", "Audio / Subtitles", "Stream info", "Play from beginning", "Next episode")
        actions.forEach { label ->
            val node = compose.onNodeWithText(label)
            node.assertIsDisplayed().performSemanticsAction(SemanticsActions.RequestFocus)
            node.performKeyInput { pressKey(Key.DirectionCenter) }
            node.assertIsFocused()
        }
        assertEquals(actions, clicks)
        screenshot("controls-exclusive-tv.png")
    }

    @Test fun cinemaKeepsItsOriginalColorsAndFocusedActionWorks() {
        val clicks = mutableListOf<String>(); fixture(clicks, AppearanceTheme.CINEMA)
        val pause = compose.onNodeWithText("Pause")
        pause.performSemanticsAction(SemanticsActions.RequestFocus)
        pause.performKeyInput { pressKey(Key.DirectionCenter) }
        assertEquals(listOf("Pause"), clicks)
        pause.assertIsFocused()
        screenshot("controls-cinema-tv.png")
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun portraitTimelineAndWrappedActionsFitAndSupportTouch() {
        val clicks = mutableListOf<String>(); fixture(clicks)
        val root = compose.onRoot().fetchSemanticsNode().boundsInRoot
        compose.onNodeWithContentDescription("Playback position").assertIsDisplayed()
        listOf("Pause", "Audio / Subtitles", "Stream info", "Play from beginning", "Next episode").forEach { label ->
            val node = compose.onNodeWithText(label)
            node.assertIsDisplayed()
            val bounds = node.fetchSemanticsNode().boundsInRoot
            assertTrue(bounds.left >= root.left && bounds.right <= root.right && bounds.bottom <= root.bottom)
        }
        compose.onNodeWithText("Stream info").performTouchInput { click() }
        assertEquals(listOf("Stream info"), clicks)
        compose.onNodeWithText("Swipe the timeline to seek · Tap to play or pause").assertIsDisplayed()
        screenshot("controls-exclusive-phone.png")
    }
}
