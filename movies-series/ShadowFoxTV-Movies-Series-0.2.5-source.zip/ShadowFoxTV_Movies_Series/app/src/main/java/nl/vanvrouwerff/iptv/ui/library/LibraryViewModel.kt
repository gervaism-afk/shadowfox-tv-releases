package nl.vanvrouwerff.iptv.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import nl.vanvrouwerff.iptv.IptvApp
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.db.toDomain

internal const val LIBRARY_PAGE_SIZE = 60
internal data class LibrarySelection(
    val type: ContentType = ContentType.MOVIE,
    val category: String? = null,
    val query: String = "",
    val saved: Boolean = false,
    val page: Int = 0,
)
internal data class LibraryState(
    val selection: LibrarySelection = LibrarySelection(),
    val items: List<Channel> = emptyList(),
    val categories: List<String> = emptyList(),
    val count: Int = 0,
    val loading: Boolean = true,
    val error: String? = null,
)
internal fun librarySearchPattern(query: String): String =
    "%${query.trim().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")}%"

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class LibraryViewModel : ViewModel() {
    private val app = IptvApp.get()
    private val dao = app.database.channelDao()
    private val selection = MutableStateFlow(LibrarySelection())
    val refreshing = app.refreshUseCase.refreshing
    val progress = app.refreshUseCase.progress
    val refreshError = app.refreshUseCase.lastError

    private val categories = libraryCategoryFlow(selection) { type -> dao.observeGroupTitlesByType(type.name) }
        .flowOn(Dispatchers.IO)
        .shareIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), replay = 1)

    internal val state: StateFlow<LibraryState> = libraryStateFlow(
        selection = selection, profiles = app.activeProfileId, kidsModes = app.kidsMode,
        pageQuery = { s, profile, kids ->
            val offset = s.page * LIBRARY_PAGE_SIZE
            when {
                usesPlainLibraryQuery(s, kids) && s.category == null ->
                    dao.observePlainLibraryPage(s.type.name, LIBRARY_PAGE_SIZE, offset)
                usesPlainLibraryQuery(s, kids) ->
                    dao.observeCategoryLibraryPage(s.type.name, requireNotNull(s.category), LIBRARY_PAGE_SIZE, offset)
                else -> dao.observeLibraryPage(s.type.name, s.category, librarySearchPattern(s.query),
                    s.saved, profile, kids, LIBRARY_PAGE_SIZE, offset)
            }.map { rows -> rows.map { it.toDomain() } }
        },
        countQuery = { s, profile, kids ->
            when {
                usesPlainLibraryQuery(s, kids) && s.category == null -> dao.observePlainLibraryCount(s.type.name)
                usesPlainLibraryQuery(s, kids) -> dao.observeCategoryLibraryCount(s.type.name, requireNotNull(s.category))
                else -> dao.observeLibraryCount(s.type.name, s.category, librarySearchPattern(s.query), s.saved, profile, kids)
            }
        },
        categoryQuery = { type -> categories.filter { it.first == type }.map { it.second } },
        onPageClamped = { page -> selection.update { it.copy(page = page) } },
    ).flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryState())

    init {
        viewModelScope.launch {
            val last = app.settings.lastRefreshSuccessAt.first()
            if (last == 0L || System.currentTimeMillis() - last > 6 * 3_600_000L) refresh()
        }
    }
    internal var focusedId: String? = null
    internal var focusedIndex: Int = 0
    fun rememberFocus(id: String, index: Int) { focusedId = id; focusedIndex = index }

    fun selectType(type: ContentType) { focusedId = null; focusedIndex = 0; selection.value = LibrarySelection(type = type) }
    fun selectCategory(value: String?) { selection.update { it.copy(category = value, page = 0) } }
    fun search(value: String) { selection.update { it.copy(query = value, page = 0) } }
    fun saved() { selection.update { it.copy(saved = !it.saved, page = 0) } }
    fun page(delta: Int) { selection.update { it.copy(page = (it.page + delta).coerceAtLeast(0)) } }
    fun refresh() {
        if (!refreshing.value) app.appScope.launch { app.refreshUseCase(force = true) }
    }
}
