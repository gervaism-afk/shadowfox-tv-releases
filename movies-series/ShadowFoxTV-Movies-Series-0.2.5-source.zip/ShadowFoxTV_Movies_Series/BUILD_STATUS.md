v0.2.5 release build, unit tests, debug and release lint PASS. API25 signature verification and package checks PASS; see verification/fire-v0.2.5.json. Physical Firestick testing pending.
