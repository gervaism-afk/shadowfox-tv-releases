package nl.vanvrouwerff.iptv.updates

import android.content.pm.PackageManager

/** Fire OS/API 28 only collects archive certificates when the legacy flag is included. */
@Suppress("DEPRECATION")
internal fun updateSigningQueryFlags(sdk: Int): Int = if (sdk >= 28) {
    PackageManager.GET_SIGNING_CERTIFICATES or PackageManager.GET_SIGNATURES
} else PackageManager.GET_SIGNATURES

/** Legacy metadata is a fallback for missing data, never for a nonmatching signer. */
internal fun preferredSigningCertificates(modern: Set<String>, legacy: Set<String>): Set<String> =
    modern.ifEmpty { legacy }
