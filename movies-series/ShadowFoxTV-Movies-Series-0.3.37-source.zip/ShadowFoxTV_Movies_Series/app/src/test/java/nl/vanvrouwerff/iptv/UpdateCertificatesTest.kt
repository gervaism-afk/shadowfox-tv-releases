package nl.vanvrouwerff.iptv

import android.content.pm.PackageManager
import nl.vanvrouwerff.iptv.updates.*
import org.junit.Assert.*
import org.junit.Test

@Suppress("DEPRECATION")
class UpdateCertificatesTest {
    private val original=setOf("c018a048630b67d1b82a80308bb5e5c725fbbd7487eca6c0c461464884984e90")
    @Test fun olderAndroidQueriesItsSupportedLegacyField() {
        for(sdk in listOf(25,26,27))assertEquals(PackageManager.GET_SIGNATURES,updateSigningQueryFlags(sdk))
    }
    @Test fun fireOsAndNewerAndroidRequestBothCertificateFields() {
        for(sdk in listOf(28,29,30,34,35)) {
            val flags=updateSigningQueryFlags(sdk)
            assertTrue(flags and PackageManager.GET_SIGNATURES != 0)
            assertTrue(flags and PackageManager.GET_SIGNING_CERTIFICATES != 0)
        }
    }
    @Test fun aMissingArchiveSigningInfoCanUseItsActualLegacyCertificate() {
        val installed=preferredSigningCertificates(original,original)
        val archive=preferredSigningCertificates(emptySet(),original)
        assertTrue(certificateSetsMatch(installed,archive))
    }
    @Test fun missingCertificateDataNeverBecomesAnAcceptedUpdate() {
        val missing=preferredSigningCertificates(emptySet(),emptySet())
        assertFalse(certificateSetsMatch(original,missing))
        assertFalse(certificateSetsMatch(missing,missing))
    }
    @Test fun aDifferentModernSignerCannotBeHiddenByMatchingLegacyMetadata() {
        val incoming=preferredSigningCertificates(setOf("different-certificate"),original)
        assertFalse(certificateSetsMatch(original,incoming))
    }
    @Test fun legacyOnlyPackagesStillRequireTheSameCompleteCertificateSet() {
        assertTrue(certificateSetsMatch(preferredSigningCertificates(emptySet(),original),original))
        assertFalse(certificateSetsMatch(original,preferredSigningCertificates(emptySet(),setOf("other"))))
        assertFalse(certificateSetsMatch(original,preferredSigningCertificates(emptySet(),original+"extra")))
    }
}
