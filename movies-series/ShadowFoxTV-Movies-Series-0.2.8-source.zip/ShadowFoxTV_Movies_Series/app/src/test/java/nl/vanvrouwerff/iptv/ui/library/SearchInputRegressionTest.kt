package nl.vanvrouwerff.iptv.ui.library

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import kotlinx.coroutines.delay
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SearchInputRegressionTest {
    @get:Rule val compose = androidx.compose.ui.test.junit4.createComposeRule()

    @Test fun slowIncrementalTypingAndCursorSurviveDelayedResultsAndPosterRecreation() {
        val input = LibrarySearchInput("")
        compose.setContent { MaterialTheme {
            var query by remember { mutableStateOf("") }
            var result by remember { mutableStateOf("") }
            var editing by remember { mutableStateOf(false) }
            LaunchedEffect(query) { delay(180); result = query }
            Column {
                LibrarySearchField(input, ContentType.MOVIE, { query = it }, Modifier.testTag("search"), { editing = it })
                key(result) {
                    LibraryPoster(Channel("same", "Castle $result", null, null, null, null, ContentType.MOVIE),
                        restoreFocus = canRestoreLibraryFocus("same", "same", editing, result == query),
                        onFocus = {}, onClick = {})
                }
            }
        } }
        val field = compose.onNodeWithTag("search")
        field.performClick()
        "castle".forEachIndexed { index, letter ->
            field.performTextInput(letter.toString())
            compose.mainClock.advanceTimeBy(500)
            field.assertIsFocused().assert(SemanticsMatcher.expectValue(SemanticsProperties.EditableText,
                AnnotatedString("castle".take(index + 1))))
            compose.runOnIdle { assertEquals(TextRange(index + 1), input.value.selection) }
        }
        field.performSemanticsAction(SemanticsActions.SetSelection) { it(1, 1, false) }
        compose.mainClock.advanceTimeBy(500)
        field.performTextInput("X")
        compose.mainClock.advanceTimeBy(500)
        field.assertIsFocused().assert(SemanticsMatcher.expectValue(SemanticsProperties.EditableText, AnnotatedString("cXastle")))
        compose.runOnIdle { assertEquals(TextRange(2), input.value.selection) }
    }

    @Test fun editorLabelTracksTypeWithoutChangingQuery() {
        val input = LibrarySearchInput("castle")
        var type by mutableStateOf(ContentType.MOVIE)
        compose.setContent { MaterialTheme { LibrarySearchField(input, type, {}, Modifier.testTag("search")) } }
        compose.onNodeWithText("Search movies").assertExists()
        compose.runOnIdle { type = ContentType.SERIES }
        compose.onNodeWithText("Search series").assertExists()
        compose.onNodeWithTag("search").assert(SemanticsMatcher.expectValue(SemanticsProperties.EditableText, AnnotatedString("castle")))
    }

    @Test fun clearingEditorDropsSelectionAndComposition() {
        val input = LibrarySearchInput("castle")
        input.edit(androidx.compose.ui.text.input.TextFieldValue("castle", TextRange(2), TextRange(1, 3)), {})
        input.clear()
        assertEquals("", input.value.text)
        assertEquals(TextRange.Zero, input.value.selection)
        assertNull(input.value.composition)
        assertFalse(canRestoreLibraryFocus("same", "same", true, true))
        assertFalse(canRestoreLibraryFocus("same", "same", false, false))
        assertFalse(canRestoreLibraryFocus(null, "same", false, true))
        assertTrue(canRestoreLibraryFocus("same", "same", false, true))
    }
}
