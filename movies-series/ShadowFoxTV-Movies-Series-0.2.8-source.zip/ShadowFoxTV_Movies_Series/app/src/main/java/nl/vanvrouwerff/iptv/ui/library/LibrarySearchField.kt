package nl.vanvrouwerff.iptv.ui.library

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import nl.vanvrouwerff.iptv.data.ContentType

/** Owns text, selection and IME composition independently of delayed query results. */
@Stable
internal class LibrarySearchInput(initial: String) {
    var value by mutableStateOf(TextFieldValue(initial, TextRange(initial.length)))
        private set
    fun edit(next: TextFieldValue, onQuery: (String) -> Unit) {
        value = next
        onQuery(next.text)
    }
    fun clear() { value = TextFieldValue() }
}

internal fun canRestoreLibraryFocus(target: String?, item: String, editing: Boolean, currentResults: Boolean): Boolean =
    target == item && !editing && currentResults

@Composable
internal fun LibrarySearchField(
    input: LibrarySearchInput, type: ContentType, onQuery: (String) -> Unit,
    modifier: Modifier = Modifier, onEditingChanged: (Boolean) -> Unit = {}, onDone: () -> Unit = {},
) {
    OutlinedTextField(value = input.value, onValueChange = { input.edit(it, onQuery) },
        label = { Text(if (type == ContentType.SERIES) "Search series" else "Search movies") },
        singleLine = true, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onDone() }),
        modifier = modifier.onFocusChanged { onEditingChanged(it.isFocused) })
}
