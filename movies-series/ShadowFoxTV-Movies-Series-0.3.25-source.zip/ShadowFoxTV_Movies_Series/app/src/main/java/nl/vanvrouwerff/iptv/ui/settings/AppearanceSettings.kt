package nl.vanvrouwerff.iptv.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.appearanceColors

@Composable
internal fun AppearanceSettings(selected: AppearanceTheme, onSelect: (AppearanceTheme) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Choose your look. Changes apply immediately and are saved automatically.",
            style = MaterialTheme.typography.bodySmall, color = IptvPalette.TextSecondary)
        AppearanceTheme.entries.forEach { theme ->
            AppearanceChoice(theme, selected == theme) { onSelect(theme) }
        }
    }
}

@Composable
private fun AppearanceChoice(theme: AppearanceTheme, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    val preview = appearanceColors(theme)
    Surface(onClick = onClick,
        modifier = Modifier.fillMaxWidth().settingsControl("theme:${theme.id}", theme.ordinal * 10).semantics { this.selected = selected }
            .onFocusChanged { focused = it.isFocused }
            .border(if (focused) 2.dp else 1.dp,
                if (focused || selected) IptvPalette.Accent else IptvPalette.Border, shape),
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = IptvPalette.SurfaceLift,
            focusedContainerColor = IptvPalette.SurfaceElevated,
            contentColor = IptvPalette.TextPrimary, focusedContentColor = IptvPalette.TextPrimary),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.width(54.dp).height(42.dp)) {
                Box(Modifier.weight(1f).fillMaxHeight().background(preview.background))
                Box(Modifier.weight(1f).fillMaxHeight().background(preview.surface2))
                Box(Modifier.weight(1f).fillMaxHeight().background(preview.accent))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(theme.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(theme.description, style = MaterialTheme.typography.bodySmall, color = IptvPalette.TextSecondary)
                if (selected) Text("Selected", style = MaterialTheme.typography.labelSmall, color = IptvPalette.Accent)
            }
        }
    }
}
