@file:OptIn(androidx.tv.material3.ExperimentalTvMaterial3Api::class)

package nl.vanvrouwerff.iptv.updates

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.SystemUpdate
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.ui.input.Button
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.tvFocus

internal enum class UpdatePhase { CHECKING, DOWNLOADING, ERROR, READY, AVAILABLE, CURRENT, IDLE }

/** A failed request must never be presented as a successful up-to-date check. */
internal fun updatePhase(state: UpdateState): UpdatePhase = when {
    state.downloading -> UpdatePhase.DOWNLOADING
    state.checking -> UpdatePhase.CHECKING
    state.error != null -> UpdatePhase.ERROR
    state.readyFile != null -> UpdatePhase.READY
    state.release != null -> UpdatePhase.AVAILABLE
    state.checked -> UpdatePhase.CURRENT
    else -> UpdatePhase.IDLE
}

/** ShadowFox family update card: versions, clear status, release notes and large actions. */
@Composable
internal fun UpdateCenterContent(state: UpdateState, installedVersion: String,
    onCheck: () -> Unit, onInstall: () -> Unit,
    actionButton: @Composable (String, Boolean, () -> Unit) -> Unit = { label, enabled, action ->
        UpdateActionButton(label, enabled, action)
    }) {
    val phase = updatePhase(state)
    val busy = state.checking || state.downloading
    val shape = RoundedCornerShape(14.dp)
    val icon = when (phase) {
        UpdatePhase.ERROR -> Icons.Outlined.ErrorOutline
        UpdatePhase.CURRENT -> Icons.Outlined.CheckCircle
        UpdatePhase.DOWNLOADING -> Icons.Outlined.CloudDownload
        UpdatePhase.CHECKING -> Icons.Outlined.Refresh
        else -> Icons.Outlined.SystemUpdate
    }
    val title = when (phase) {
        UpdatePhase.CHECKING -> "Checking for updates…"
        UpdatePhase.DOWNLOADING -> "Downloading update · ${state.percent.coerceIn(0, 100)}%"
        UpdatePhase.ERROR -> "Update needs attention"
        UpdatePhase.READY -> "Ready to install"
        UpdatePhase.AVAILABLE -> "Update available"
        UpdatePhase.CURRENT -> "Your app is up to date"
        UpdatePhase.IDLE -> "Keep your cinema up to date"
    }
    val detail = when (phase) {
        UpdatePhase.ERROR -> state.error.orEmpty()
        UpdatePhase.READY -> "Download verified. Android will ask you to confirm installation."
        UpdatePhase.AVAILABLE -> "A newer version of Movies & Series is ready for you."
        UpdatePhase.DOWNLOADING -> "Your account and library will be kept."
        UpdatePhase.CHECKING -> "Looking for the latest ShadowFoxTV Movies & Series release."
        UpdatePhase.CURRENT -> "You have the latest Movies & Series release."
        UpdatePhase.IDLE -> "Get the latest improvements directly from ShadowFoxTV."
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(painterResource(R.drawable.shadowfox_brand_original), null,
                Modifier.size(44.dp), contentScale = ContentScale.Inside)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("ShadowFoxTV", color = Cinema.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("MOVIES & SERIES", color = Cinema.Accent, fontSize = 9.sp, letterSpacing = 1.7.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            VersionTile("Installed", installedVersion, Modifier.weight(1f))
            VersionTile(if (state.release != null) "Available" else "Latest",
                state.release?.versionName ?: if (phase == UpdatePhase.CURRENT) installedVersion else "—", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().clip(shape).background(Cinema.Surface)
            .border(1.dp, Cinema.Line, shape).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, Modifier.size(24.dp), tint = if (phase == UpdatePhase.ERROR) Color(0xFFFCA5A5) else Cinema.Accent)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(title, color = Cinema.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
                Text(detail, color = Cinema.Muted, fontSize = 12.sp, lineHeight = 18.sp)
                if (state.downloading) {
                    val progress by animateFloatAsState(state.percent.coerceIn(0, 100) / 100f, tween(160), label = "update-progress")
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(shape),
                        color = Cinema.Accent, trackColor = Cinema.Line)
                }
            }
        }
        state.release?.notes?.takeIf { it.isNotBlank() }?.let { notes ->
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("What’s new", color = Cinema.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(notes.take(2000), color = Cinema.Muted, fontSize = 12.sp, lineHeight = 18.sp,
                    maxLines = 6, overflow = TextOverflow.Ellipsis)
            }
        }
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            actionButton("Check for updates", !busy, onCheck)
            if (state.release != null) actionButton(
                if (state.readyFile == null) "Download & install" else "Install update", !busy, onInstall)
        }
        Text("Your account, watch history and settings are kept.", color = Cinema.Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun VersionTile(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Cinema.Surface).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Cinema.Muted, fontSize = 11.sp)
        Text(value, color = Cinema.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
internal fun UpdateActionButton(label: String, enabled: Boolean, action: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    val primary = label != "Check for updates"
    Button(onClick = action, enabled = enabled,
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).onFocusChanged { focused = it.isFocused }.tvFocus(focused, shape, 1f),
        shape = ButtonDefaults.shape(shape), scale = ButtonDefaults.scale(focusedScale = 1f),
        colors = ButtonDefaults.colors(containerColor = if (primary) Cinema.Accent else Cinema.Raised,
            contentColor = if (primary) IptvPalette.OnAccent else Cinema.Text,
            focusedContainerColor = Cinema.FocusFill, focusedContentColor = if (Cinema.Exclusive) Cinema.Text else Cinema.Background)) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
