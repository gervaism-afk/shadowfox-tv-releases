package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class HomePresentationTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private fun art(wide: Boolean): String {
        val w = if (wide) 1280 else 400; val h = if (wide) 720 else 600
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap); val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), intArrayOf(0xFF193641.toInt(), 0xFF386E78.toInt(), 0xFF08121C.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null; paint.color = 0xBBE8C78E.toInt(); canvas.drawCircle(w * .73f, h * .32f, h * .17f, paint)
        paint.color = 0xFF13242C.toInt(); canvas.drawOval(-w * .1f, h * .6f, w * 1.1f, h * 1.5f, paint)
        if (!wide) { paint.color = 0xFFF4F4EF.toInt(); paint.textSize = 26f; canvas.drawText("NORTH OF THE SUN", 28f, h * .8f, paint) }
        val f = File.createTempFile("home-art-", ".png"); f.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
        return f.toURI().toString()
    }
    private fun state(): HomeState {
        val movie = Channel("north", "North of the Sun (2024)", art(false), "Adventure", null, null, ContentType.MOVIE)
        val other = movie.copy(id = "other", name = "The Last Horizon (2025)")
        val series = movie.copy(id = "series", name = "After the Tide (2023)", type = ContentType.SERIES)
        return HomeState(movies = listOf(HomeItem(movie), HomeItem(other)), series = listOf(HomeItem(series)),
            continuing = listOf(HomeItem(other, .42f, "Continue movie"), HomeItem(series, .68f, "Season 1 · Episode 3")),
            loading = false, featured = movie, spotlight = HomeSpotlight(movie.id,
                "Beyond the familiar, a quieter world is waiting to be found.", "2024", "8.2", "Adventure / Drama", art(true)))
    }
    private fun screenshot(name: String) {
        val dir = requireNotNull(File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile); dir.mkdirs()
        compose.runOnUiThread {
            val view = compose.activity.window.decorView; val image = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(image)); dir.resolve(name).outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }; image.recycle()
        }
    }
    private fun checkFirstShelfFits() {
        val title = compose.onNodeWithTag("home-spotlight-title").fetchSemanticsNode().boundsInRoot
        val rail = compose.onNodeWithTag("home-rail:Continue Watching").fetchSemanticsNode().boundsInRoot
        val card = compose.onNode(hasTestTag("home-card:other") and hasText("42% watched")).fetchSemanticsNode().boundsInRoot
        val root = compose.onRoot().fetchSemanticsNode().boundsInRoot
        assertEquals(title.left, rail.left, 1f); assertEquals(rail.left, card.left, 1f)
        assertTrue("The complete first Continue card must fit on screen", card.bottom <= root.bottom)
        compose.onNodeWithText("42% watched").assertIsDisplayed(); compose.onNodeWithText("Continue movie").assertIsDisplayed()
    }
    @Test fun smallTvShowsTheWholeFirstContinueCardWithAlignedShelfAndHero() {
        val state = state()
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) { HomeScreen(state, {}, {}, { _, _ -> }, {}) } }
        checkFirstShelfFits(); screenshot("home-compact-tv.png")
    }
    @Test @Config(qualifiers = "w1280dp-h720dp-land-television-xhdpi")
    fun bothThemesUseTheSameBalancedHomeLayout() {
        val state = state(); var theme by mutableStateOf(AppearanceTheme.SHADOWFOX_EXCLUSIVE)
        compose.setContent { IptvTheme(theme) { HomeScreen(state, {}, {}, { _, _ -> }, {}) } }
        checkFirstShelfFits(); screenshot("home-exclusive-tv.png")
        compose.runOnIdle { theme = AppearanceTheme.CINEMA }; checkFirstShelfFits(); screenshot("home-cinema-tv.png")
    }
    @Test fun remoteMovesFromTheHeaderIntoThePrimaryActionAndBackWithoutPlayback() {
        var plays = 0; val state = state()
        compose.setContent { IptvTheme { HomeScreen(state, {}, {}, { _, _ -> }, { plays++ }) } }
        compose.onNodeWithText("Home").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Home").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("▶  Play").assertIsFocused().performKeyInput { pressKey(Key.DirectionUp) }
        compose.onNodeWithText("Home").assertIsFocused(); assertEquals(0, plays)
    }
    @Test fun continueCardOpensTheCorrectDetailsWithoutStartingPlayback() {
        var opened: String? = null; var rail: String? = null; var plays = 0; val state = state()
        compose.setContent { IptvTheme { HomeScreen(state, {}, {}, { c, r -> opened = c.id; rail = r }, { plays++ }) } }
        val card = compose.onNode(hasTestTag("home-card:other") and hasText("42% watched")); card.performSemanticsAction(SemanticsActions.RequestFocus)
        card.performKeyInput { pressKey(Key.DirectionCenter) }
        assertEquals("other", opened); assertEquals("Continue Watching", rail); assertEquals(0, plays)
    }
    @Test fun returningFromDetailsRestoresADeepShelfAndHeaderDownCanReturnToTheHero() {
        val base = state(); val entries = (1..18).map { HomeItem(base.movies.first().channel.copy(id = "movie-$it", name = "Movie $it")) }
        val state = base.copy(movies = entries)
        compose.setContent { IptvTheme { HomeScreen(state, {}, {}, { _, _ -> }, {}, restoreId = "Movies for your evening:movie-16") } }
        compose.onNodeWithTag("home-card:movie-16").assertIsFocused().assertIsDisplayed()
        compose.onNodeWithText("Home").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Home").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("▶  Play").assertIsFocused().assertIsDisplayed()
    }
    @Test fun missingBackdropUsesASeparatePortraitFallbackAndNeverInventsMetadata() {
        val state = state().copy(spotlight = null)
        compose.setContent { IptvTheme { HomeScreen(state, {}, {}, { _, _ -> }, {}) } }
        compose.onNodeWithTag("home-backdrop").assertDoesNotExist(); compose.onNodeWithTag("home-poster-fallback").assertExists()
        compose.onNodeWithText("8.2", substring = true).assertDoesNotExist()
        compose.onNodeWithTag("home-spotlight-title").assertTextEquals("North of the Sun")
    }
    @Test @Config(qualifiers = "w320dp-h720dp-port-xhdpi")
    fun narrowPhoneKeepsTouchActionsAndAWholeContinueCard() {
        var plays = 0; var opened = 0; var refreshed = 0; val state = state()
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            HomeScreen(state, {}, {}, { _, _ -> opened++ }, { plays++ }, onRefreshPicks = { refreshed++ })
        } }
        compose.onNodeWithText("▶  Play").onParent().assertHeightIsAtLeast(48.dp)
        compose.onNodeWithText("Details").assertIsDisplayed().performTouchInput { click() }
        compose.onNodeWithText("↻  New picks").assertIsDisplayed().performTouchInput { click() }
        assertEquals(0, plays); assertEquals(1, opened); assertEquals(1, refreshed); screenshot("home-phone-top.png")
        val card = compose.onNode(hasTestTag("home-card:other") and hasText("42% watched")).performScrollTo().assertIsDisplayed()
        val bounds = card.fetchSemanticsNode().boundsInRoot; val root = compose.onRoot().fetchSemanticsNode().boundsInRoot
        assertTrue(bounds.left >= root.left && bounds.right <= root.right)
        card.performTouchInput { click() }; assertEquals(2, opened); assertEquals(0, plays); screenshot("home-phone-shelf.png")
    }
    @Test @Config(qualifiers = "w360dp-h800dp-port-xhdpi")
    fun enlargedPhoneTextKeepsAllActionsReachable() {
        val base = state(); val state = base.copy(featured = base.featured!!.copy(name = "A long journey to the farthest edge of the world (2024)"))
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 1.5f)) { IptvTheme { HomeScreen(state, {}, {}, { _, _ -> }, {}) } }
        }
        compose.onNodeWithText("▶  Play").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Details").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("↻  New picks").performScrollTo().assertIsDisplayed()
        compose.onNode(hasTestTag("home-card:other") and hasText("42% watched")).performScrollTo().assertIsDisplayed(); screenshot("home-phone-large-text.png")
    }
}
