# ShadowFoxTV Movies & Series 0.3.7 / code 19

A repeat Google TV Streamer check found an additional IME overlap: the TV keyboard
could cover Cancel/Done in the centered field editor even though Settings browsing
itself no longer opened a keyboard.

The field editor now uses a top-aligned, bounded scrolling container in a full
dialog viewport. It consumes the dialog's own keyboard insets and requests resize
instead of relying on the focused text field being panned above the keyboard.
Actions therefore remain visible above the TV keyboard. Cancel still discards
the local draft; Done applies it to the form, with the existing account Save action
required for persistence.

The regression suite includes a lower-half keyboard-inset layout case. Live
verification waits for the keyboard to be shown before checking action positions
and repeats open/cancel cycles without typing or saving account values. Exact
results and APK checksums are in the delivery verification report.

All 0.3.6 browsing fixes, fixed Settings header, phone editing, and the 0.3.5
cinematic Home/fresh discovery remain. Account storage, player, updater, database
schema, orientation policy and original signing identity are retained.
