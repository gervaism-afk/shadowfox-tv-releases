# ShadowFoxTV Movies & Series 0.3.9 / code 21

Home discovery samples eight disjoint regions of the eligible catalogue and
interleaves them into each shelf. Each query returns at most eight rows; no full
catalogue list or random whole-table sort is created. UI-only recent history is
scoped to the source, profile, kids mode and shelf. The latest picks are excluded
when enough alternatives exist; smaller catalogues retain their available titles
and avoid immediately repeating the lead. A visit snapshots history so returning
from details does not reshuffle the shelf.

Known HD/4K variants are de-duplicated by display title and explicit release year.
Recent title identities are also deprioritized within the candidate pool; remakes
with different years remain distinct. Stored channel names and stream choices
in the underlying catalogue are not rewritten. Quality markers remain as separate
labels in collection names and spotlight metadata so stream choices remain clear.

Up to two rotating genre shelves use recognizable genre names supplied in the
service's categories. Generic buckets such as VOD 1 are not labelled as genres.
Saved titles and Continue Watching retain their existing order and persistence.

The spotlight alternates movie/series discovery and asynchronously requests only
that title's metadata. It shows the supplied synopsis, year, rating, genre and
landscape backdrop. Poster artwork remains a separate poster rather than being
stretched into a fake landscape. Missing or failed metadata keeps browsing usable.
The bounded metadata cache is scoped to the source and title, calls are cancelled
when selection changes, and stale metadata cannot render over a newer title.
For episode-heavy series responses, only the info object is streamed into memory.
This works with provider metadata and requires no new TMDB credential.

Display-only cleanup removes known language/quality decorations and duplicate
bracketed year suffixes, preserving numeric film titles and the original stored
names/IDs. The database schema, saved account storage, player, updater, orientation
policy and touch wrappers are unchanged.

Automated and local TV/phone runtime results, checksums and signing verification
are recorded in the delivery report. The physical streamer is left alone while
the user is using it. Local screenshots use fictional titles and test artwork;
they are not bundled in the APK.
