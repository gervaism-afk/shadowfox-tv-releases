package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.tv.material3.MaterialTheme
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class HomeRichSpotlightTest {
    @get:Rule val compose = createComposeRule()
    private val channel = Channel("rich", "|EN| The Journey (2024) (2024)", null, "VOD 1", null, null, ContentType.MOVIE)
    private val details = HomeSpotlight("rich", "A traveller follows an unexpected signal across the ocean.", "2024", "8.2", "Drama / Mystery", "https://example.invalid/wide.jpg")

    @Test fun tvShowsCleanTitleRealMetadataAndBackdropWithoutHidingTheActions() {
        compose.setContent { MaterialTheme { HomeScreen(HomeState(movies = listOf(HomeItem(channel)), loading = false, spotlight = details),
            {}, {}, { _, _ -> }, {}) } }
        compose.onNodeWithTag("home-spotlight-title").assertTextEquals("The Journey").assertIsDisplayed()
        compose.onNodeWithTag("home-spotlight-meta").assertTextContains("2024", substring = true).assertTextContains("8.2", substring = true)
        compose.onNodeWithText(details.synopsis!!).assertIsDisplayed()
        compose.onNodeWithTag("home-backdrop").assertExists()
        compose.onNodeWithText("Details").assertIsDisplayed()
        compose.onNodeWithText("↻  New picks").assertIsDisplayed()
        compose.onNodeWithText(channel.name).assertDoesNotExist()
    }

    @Test fun lateMetadataForThePreviousSpotlightCannotPaintTheNewTitle() {
        compose.setContent { MaterialTheme { HomeScreen(HomeState(movies = listOf(HomeItem(channel)), loading = false,
            spotlight = details.copy(channelId = "old")), {}, {}, { _, _ -> }, {}) } }
        compose.onNodeWithText(details.synopsis!!).assertDoesNotExist()
        compose.onNodeWithTag("home-backdrop").assertDoesNotExist()
        compose.onNodeWithTag("home-spotlight-title").assertTextEquals("The Journey")
    }

    @Test
    @Config(qualifiers = "w360dp-h800dp-port-xhdpi")
    fun richPhoneSpotlightKeepsComfortableTouchTargetsWithLongMetadata() {
        var plays = 0
        var opened = 0
        compose.setContent { MaterialTheme { HomeScreen(HomeState(movies = listOf(HomeItem(channel.copy(name = "A very long title for an unforgettable voyage (2024)"))),
            loading = false, spotlight = details.copy(synopsis = "A long description. ".repeat(30))), {}, {}, { _, _ -> opened++ }, { plays++ }) } }
        compose.onNodeWithText("▶  Play").onParent().assertHeightIsAtLeast(48.dp)
        compose.onNodeWithText("Details").assertIsDisplayed().performTouchInput { click() }
        compose.onNodeWithText("▶  Play").assertIsDisplayed().performTouchInput { click() }
        compose.onNodeWithText("↻  New picks").assertIsDisplayed()
        compose.runOnIdle { assertEquals(1, plays); assertEquals(1, opened) }
    }

    @Test
    @Config(qualifiers = "w360dp-h800dp-port-xhdpi")
    fun enlargedPhoneTextStillLetsUsersReachSpotlightActions() {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, 1.5f)) { MaterialTheme {
                HomeScreen(HomeState(movies = listOf(HomeItem(channel)), loading = false, spotlight = details), {}, {}, { _, _ -> }, {})
            } }
        }
        compose.onNodeWithText("Details").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("↻  New picks").performScrollTo().assertIsDisplayed()
    }
}
