package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.ui.unit.dp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SettingsNavigationTest {
    @get:Rule val compose = createComposeRule()

    @Test fun tvCanScrollPastAccountFieldsWithoutOpeningAnEditorAndReadTheFooter() {
        compose.setContent { IptvTheme {
            SettingsPage(onBack = {}) {
                SettingsAccountField("Server", "https://fixture.invalid", {})
                SettingsAccountField("Username", "fixture-user", {})
                SettingsAccountField("Password", "fixture-password", {}, password = true)
                repeat(6) { index -> SwitchRow("Playback option $index", "An explanation of this option.", false, {}) }
                SettingsInformation { Text("About this app and its attributions.") }
            }
        } }
        compose.onNodeWithText("Server").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
        compose.onNodeWithText("Server").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Username").assertIsFocused()
        repeat(8) { compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) } }
        compose.onNodeWithTag("settings-information").assertIsFocused()
        compose.onNodeWithText("About this app and its attributions.").assertIsDisplayed()
        compose.onNodeWithText("Settings").assertIsDisplayed()
        compose.onNodeWithText("Back").assertIsDisplayed()
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
    }

    @Test fun tvRequiresOkToEditAndCancelDoesNotChangeTheAccountValue() {
        var value by mutableStateOf("fixture-user")
        compose.setContent { IptvTheme { SettingsPage(onBack = {}) { SettingsAccountField("Username", value, { value = it }) } } }
        val row = compose.onNodeWithText("Username")
        row.performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
        row.performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(1)
        compose.onNode(hasSetTextAction()).performTextReplacement("unsaved-edit")
        compose.onNodeWithText("Cancel").performClick()
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
        compose.runOnIdle { assertEquals("fixture-user", value) }
        compose.onNodeWithText("Username").assertIsFocused()
    }

    @Test fun tvDoneAppliesOnlyTheExplicitEditAndPasswordsStayMaskedWhileBrowsing() {
        var value by mutableStateOf("fixture-password")
        compose.setContent { IptvTheme { SettingsPage(onBack = {}) { SettingsAccountField("Password", value, { value = it }, password = true) } } }
        compose.onNodeWithText("fixture-password").assertDoesNotExist()
        compose.onNodeWithText("Password").performClick()
        compose.onNode(hasSetTextAction()).performTextReplacement("new-fixture-password")
        compose.onNodeWithText("Done").performClick()
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
        compose.onNodeWithText("new-fixture-password").assertDoesNotExist()
        compose.runOnIdle { assertEquals("new-fixture-password", value) }
    }

    @Test
    @Config(qualifiers = "w360dp-h800dp-port-notnight-xhdpi")
    fun phoneKeepsDirectTouchEditing() {
        var value by mutableStateOf("fixture-user")
        compose.setContent { IptvTheme { SettingsPage(onBack = {}) { SettingsAccountField("Username", value, { value = it }) } } }
        compose.onNode(hasSetTextAction()).performTextReplacement("phone-edit")
        compose.runOnIdle { assertEquals("phone-edit", value) }
        compose.onNodeWithText("Settings").assertIsDisplayed()
    }

    @Test fun editorActionsRemainAboveTheKeyboardArea() {
        compose.setContent { IptvTheme {
            AccountFieldEditor("Server address", "https://fixture.invalid", false, {}, {},
                keyboardInsets = WindowInsets(bottom = 270.dp))
        } }
        compose.onNodeWithText("Cancel").assertIsDisplayed()
        compose.onNodeWithText("Done").assertIsDisplayed()
        val dialog = compose.onNode(isDialog()).fetchSemanticsNode().boundsInRoot
        val cancel = compose.onNodeWithText("Cancel").fetchSemanticsNode().boundsInRoot
        compose.runOnIdle {
            assertTrue("Cancel must remain above a keyboard occupying the lower half", cancel.bottom <= dialog.top + dialog.height / 2 + 1f)
        }
    }
}
