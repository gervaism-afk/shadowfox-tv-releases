package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import nl.vanvrouwerff.iptv.data.db.ChannelEntity
import nl.vanvrouwerff.iptv.data.db.IptvDatabase
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class HomeDiscoveryRepositoryTest {
    private fun rows(count: Int) = (0 until count).map {
        ChannelEntity("film$it", "Film $it", null, if (it % 2 == 0) "Action" else "Drama", null, null, it, "MOVIE")
    }

    @Test fun fullCatalogueSamplingExcludesPreviousVisitAndStaysStableOnDetailReturn() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = context.getSharedPreferences("spread", Context.MODE_PRIVATE).also { it.edit().clear().commit() }
        val db = Room.inMemoryDatabaseBuilder(context, IptvDatabase::class.java).allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels(rows(1000))
            val repo = HomeDiscoveryRepository(dao, prefs)
            val first = repo.picks("MOVIE", false, "profile-one", 1).first().map { it.channel.id }
            assertEquals(24, first.size)
            assertTrue(first.any { it.removePrefix("film").toInt() < 125 })
            assertTrue(first.any { it.removePrefix("film").toInt() >= 875 })
            assertEquals(first, repo.picks("MOVIE", false, "profile-one", 1).first().map { it.channel.id })
            val second = HomeDiscoveryRepository(dao, prefs).picks("MOVIE", false, "profile-one", 2).first().map { it.channel.id }
            assertTrue(first.toSet().intersect(second.toSet()).isEmpty())
            val other = repo.picks("MOVIE", false, "profile-two", 2).first().map { it.channel.id }
            val clean = context.getSharedPreferences("clean", Context.MODE_PRIVATE).also { it.edit().clear().commit() }
            assertEquals(other, HomeDiscoveryRepository(dao, clean).picks("MOVIE", false, "profile-two", 2).first().map { it.channel.id })
        } finally { db.close() }
    }

    @Test fun discoveryQueriesRespectCategoriesExclusionsAndKidsEvenWhenRecentIdsAreStale() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, IptvDatabase::class.java).allowMainThreadQueries().build()
        try {
            val dao = db.channelDao()
            dao.insertChannels(rows(80) + ChannelEntity("adult", "Adult", null, "XXX Action", null, null, -1, "MOVIE"))
            assertEquals(40, dao.observeDiscoveryCount("MOVIE", true, listOf("removed"), "Action").first())
            val ids = dao.observeDiscoveryTitles("MOVIE", true, listOf("film0", "removed"), 64, 0, "Action").first().map { it.id }
            assertEquals(39, ids.size)
            assertFalse("film0" in ids || "adult" in ids)
            val prefs = context.getSharedPreferences("genres", Context.MODE_PRIVATE).also { it.edit().clear().commit() }
            val shelves = HomeDiscoveryRepository(dao, prefs).genres(true, "kid", 1).first()
            assertEquals(setOf("Action movies", "Drama movies"), shelves.map { it.title }.toSet())
            assertTrue(shelves.all { it.items.size == 12 })
            assertFalse(shelves.flatMap { it.items }.any { it.channel.id == "adult" })
        } finally { db.close() }
    }

    @Test fun smallLibraryKeepsAllTitlesAndRotatesTheLead() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, IptvDatabase::class.java).allowMainThreadQueries().build()
        val prefs = context.getSharedPreferences("small", Context.MODE_PRIVATE).also { it.edit().clear().commit() }
        try {
            db.channelDao().insertChannels(rows(7))
            val repo = HomeDiscoveryRepository(db.channelDao(), prefs)
            val first = repo.picks("MOVIE", false, "small", 1).first()
            val second = repo.picks("MOVIE", false, "small", 2).first()
            assertEquals(7, second.size)
            assertEquals(first.map { it.channel.id }.toSet(), second.map { it.channel.id }.toSet())
            assertNotEquals(first.first().channel.id, second.first().channel.id)
        } finally { db.close() }
    }
}
