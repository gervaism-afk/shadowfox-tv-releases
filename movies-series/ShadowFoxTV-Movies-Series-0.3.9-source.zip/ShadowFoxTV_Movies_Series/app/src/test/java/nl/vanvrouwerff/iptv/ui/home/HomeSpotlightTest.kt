package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import java.io.Reader
import java.io.StringReader
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class HomeSpotlightTest {
    @Test fun providerMetadataSuppliesRealPlotYearRatingAndLandscapeArtwork() {
        val result = parseHomeSpotlight(StringReader("""{"info":{"plot":"<p>A journey &amp; a mystery.</p>","releasedate":"2024-10-01","rating":8.2,"genre":"Drama / Mystery","backdrop_path":[null,"","https://example.invalid/wide.jpg"],"movie_image":"https://example.invalid/poster.jpg"}}"""), "movie")!!
        assertEquals("A journey & a mystery.", result.synopsis)
        assertEquals("2024", result.year)
        assertEquals("8.2", result.rating)
        assertEquals("https://example.invalid/wide.jpg", result.backdropUrl)
        assertEquals("https://example.invalid/poster.jpg", result.posterUrl)
    }

    @Test fun seriesSupportsAlternateDateSpellingAndStringBackdropWithoutInventingMissingFacts() {
        val result = parseHomeSpotlight(StringReader("""{"info":{"plot":"N/A","releaseDate":"2022-01-01","rating":"0","genre":"N/A","backdrop_path":"https://example.invalid/series.jpg"},"episodes":[]}"""), "series")!!
        assertEquals("2022", result.year)
        assertNull(result.rating)
        assertNull(result.genre)
        assertNull(result.synopsis)
        assertEquals("https://example.invalid/series.jpg", result.backdropUrl)
    }

    @Test fun malformedOptionalFieldsDoNotRejectTheOtherMetadataOrLoadLocalFileImages() {
        val result = parseHomeSpotlight(StringReader("""{"info":{"plot":"A real description","rating":{},"year":2021,"genre":false,"backdrop_path":[{},"file:///secret.jpg"],"cover_big":"content://private/image"}}"""), "movie")!!
        assertEquals("A real description", result.synopsis)
        assertEquals("2021", result.year)
        assertNull(result.backdropUrl)
        assertNull(result.posterUrl)
        assertNull(result.rating)
    }

    @Test fun homeStopsReadingAfterInfoInsteadOfMaterializingAWholeSeriesEpisodeList() {
        val payload = """{"info":{"plot":"Story"},"episodes":[""" + "\"episode\",".repeat(100_000) + "null]}"
        var read = 0
        val source = StringReader(payload)
        val counting = object : Reader() {
            override fun read(buffer: CharArray, offset: Int, length: Int): Int = source.read(buffer, offset, length).also { if (it > 0) read += it }
            override fun close() = source.close()
        }
        assertEquals("Story", parseHomeSpotlight(counting, "series")!!.synopsis)
        assertTrue("Home must only read a small prefix of episode-heavy responses", read < 4096)
    }

    @Test fun noInfoIsAnOptionalMetadataMiss() {
        assertNull(parseHomeSpotlight(StringReader("""{"info":[],"episodes":[]}"""), "missing"))
    }
}
