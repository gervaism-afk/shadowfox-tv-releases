package nl.vanvrouwerff.iptv.ui.wizard

import android.app.Application
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import nl.vanvrouwerff.iptv.ui.settings.PhoneSetupContent
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class WelcomeLayoutTest {
    @get:Rule val compose = createComposeRule()
    private val url = "http://192.0.2.1:12345/fixture"
    private val connect = "Connect your account"
    private val panel = "welcome-phone-setup"

    private fun content(fontScale: Float = 1f, onConfigure: () -> Unit = {}) {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, fontScale)) {
                IptvTheme { WelcomeContent(onConfigure) { modifier, size -> PhoneSetupContent(url, size, modifier) } }
            }
        }
    }

    private fun assertPanelFullyVisible() {
        val viewport = compose.onRoot().getUnclippedBoundsInRoot()
        val bounds = compose.onNodeWithTag(panel).getUnclippedBoundsInRoot()
        assertTrue("Phone setup must stay below the top edge", bounds.top >= viewport.top)
        assertTrue("The full QR panel must remain above the bottom edge", bounds.bottom <= viewport.bottom)
        assertTrue("Phone setup must fit horizontally", bounds.right <= viewport.right && bounds.left >= viewport.left)
        compose.onNodeWithText(url).assertIsDisplayed()
    }

    @Test fun shortTvShowsTheWholeQrAndSetupLinkOnFirstDisplay() {
        content()
        compose.onNodeWithText(connect).assertIsDisplayed()
        // Image semantics exclude the 8 dp white quiet-zone padding on each side.
        compose.onNodeWithContentDescription("Enter details on your phone").assertHeightIsEqualTo(80.dp)
        assertPanelFullyVisible()
    }

    @Test fun remoteCanMoveFromConnectToThePhoneSetupPanel() {
        content()
        compose.onNodeWithText(connect).performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText(connect).performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithTag(panel).assertIsFocused()
        assertPanelFullyVisible()
    }

    @Test fun largerTextCanScrollTheWholePhoneSetupPanelIntoViewWithTheRemote() {
        content(fontScale = 1.6f)
        compose.onNodeWithText(connect).performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText(connect).performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithTag(panel).assertIsFocused()
        assertPanelFullyVisible()
    }

    @Test
    @Config(qualifiers = "w960dp-h720dp-land-television-xhdpi")
    fun tallerTvKeepsTheLargerQrInsideTheScreen() {
        content()
        compose.onNodeWithContentDescription("Enter details on your phone").assertHeightIsEqualTo(94.dp)
        assertPanelFullyVisible()
    }

    @Test
    @Config(qualifiers = "w360dp-h800dp-port-xhdpi")
    fun phoneCanScrollToConnectAndOpenTheAccountForm() {
        var configured = 0
        content(onConfigure = { configured++ })
        compose.onNodeWithText(connect).performScrollTo().assertIsDisplayed().performTouchInput { click() }
        compose.runOnIdle { assertEquals(1, configured) }
        compose.onNodeWithTag(panel).assertDoesNotExist()
    }
}
