package nl.vanvrouwerff.iptv.ui.home

import org.junit.Assert.*
import org.junit.Test

class HomeSpreadTest {
    @Test fun boundedSamplesCoverEveryStratumWithoutDuplicatingOffsets() {
        for (count in listOf(0, 1, 7, 12, 24, 64, 65, 250, 50_000)) {
            for (seed in listOf(0L, 1L, 31L, Long.MAX_VALUE)) {
                val windows = homeSamples(count, seed, -17)
                val indices = windows.flatMap { (it.offset until it.offset + it.limit).toList() }
                assertTrue(indices.size <= 64)
                assertEquals(indices.size, indices.toSet().size)
                assertTrue(indices.all { it in 0 until count })
                if (count >= 64) {
                    assertEquals(8, windows.size)
                    assertTrue(windows.first().offset < count / 8)
                    assertTrue(windows.last().offset >= count * 7 / 8)
                }
            }
        }
    }

    @Test fun exclusionsAvoidRecentPicksButKeepSmallLibrariesPopulated() {
        val recent = (0 until 200).map { "id$it" }
        assertEquals(192, homeExclusions(recent, 1000, 24).size)
        assertEquals(26, homeExclusions(recent, 50, 24).size)
        assertTrue(homeExclusions(recent, 12, 24).isEmpty())
        assertTrue(homeExclusions(recent, 0, 24).isEmpty())
    }

    @Test fun shelfInterleavesGroupsAndDoesNotLeadWithThePreviousSpotlight() {
        val items = (0 until 60).toList()
        val first = distributedHomePicks(items, 5, 17, 24, { it.toString() }, { (it / 20).toString() }, null)
        assertEquals(3, first.take(3).map { it / 20 }.toSet().size)
        val next = distributedHomePicks(items, 5, 17, 24, { it.toString() }, { (it / 20).toString() }, first.first().toString())
        assertNotEquals(first.first(), next.first())
        assertEquals(24, next.toSet().size)
    }

    @Test fun titleCleanupRemovesOnlyKnownProviderDecorationsAndDuplicateYearSuffixes() {
        assertEquals("The Journey (2024)", homeDisplayTitle("|EN| 4K: The Journey (2024) (2024) [1080p]"))
        assertEquals("The Journey", homeHeroTitle("The Journey (2024) (2024)"))
        assertEquals("2024", homeTitleYear("The Journey (2024) (2024)"))
        assertEquals("The Journey (2024) · 4K", homeCollectionTitle("|EN| 4K: The Journey (2024) (2024)"))
        assertEquals("1080p", homeQuality("The Journey [1080p]"))
        assertNull(homeQuality("The HD Years"))
        for (title in listOf("1917", "1984", "2001: A Space Odyssey", "Class of 1984", "[REC]", "Spider-Man: No Way Home")) {
            assertEquals(title, homeHeroTitle(title))
        }
    }

    @Test fun genericProviderBucketsAreNotInventedGenres() {
        assertNull(homeGenre("VOD 1"))
        assertNull(homeGenre("US Movies"))
        assertEquals("Sci-Fi", homeGenre("EN | Science Fiction"))
        assertEquals("Action", homeGenre("4K - Action & Adventure"))
    }

    @Test fun qualityVariantsDoNotBecomeDuplicateOrFreshRecommendationsButRemakesStayDistinct() {
        val titles = listOf("HD: The Journey (2024)", "4K: The Journey (2024) (2024)", "Another Film (2023)", "The Journey (1980)")
        val picks = distributedHomePicks(titles, 1, 0, 3, { it }, { "one" }, null, ::homeTitleIdentity,
            setOf(homeTitleIdentity(titles.first())))
        assertEquals(3, picks.size)
        assertEquals(3, picks.map(::homeTitleIdentity).toSet().size)
        assertEquals(setOf("Another Film (2023)", "The Journey (1980)"), picks.take(2).toSet())
        assertEquals(homeTitleIdentity(titles[0]), homeTitleIdentity(titles[1]))
    }
}
