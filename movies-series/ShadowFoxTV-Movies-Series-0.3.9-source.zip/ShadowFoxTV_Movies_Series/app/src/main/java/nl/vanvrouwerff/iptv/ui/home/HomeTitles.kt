package nl.vanvrouwerff.iptv.ui.home

private val languagePrefix = Regex("(?i)^\\s*(?:[|│┃]\\s*(?:EN|ENG|US|USA|UK|FR|FRA|NL|DE|GER|ES|IT|CA)\\s*[|│┃]|\\[(?:EN|ENG|FR|NL|DE|ES|IT)\\])\\s*")
private val qualityPrefix = Regex("(?i)^(?:4K|UHD|FHD|HD|SD)\\s*[:|–-]\\s*")
private val qualitySuffix = Regex("(?i)\\s*(?:\\[(?:4K|UHD|FHD|HD|SD|1080p|720p)\\]|\\((?:4K|UHD|FHD|HD|SD|1080p|720p)\\))\\s*$")
private val repeatedYear = Regex("([\\[(](?:18|19|20)\\d{2}[\\])])(?:\\s*\\1)+\\s*$")
private val trailingYear = Regex("\\s*[\\[(]((?:18|19|20)\\d{2})[\\])]\\s*$")

/** Display-only cleanup: stream IDs, search data and persisted names stay intact. */
internal fun homeDisplayTitle(raw: String): String {
    var title = raw.trim().replace(languagePrefix, "").replace(qualityPrefix, "")
    title = title.replace(qualitySuffix, "").trim().replace(repeatedYear, "$1")
    return title.ifBlank { raw.trim() }
}
internal fun homeTitleYear(raw: String): String? = trailingYear.find(homeDisplayTitle(raw))?.groupValues?.get(1)
internal fun homeHeroTitle(raw: String): String = homeDisplayTitle(raw).let { clean ->
    clean.replace(trailingYear, "").trim().ifBlank { clean }
}
internal fun homeTitleIdentity(raw: String): String =
    homeHeroTitle(raw).lowercase(java.util.Locale.ROOT).replace(Regex("\\s+"), " ").trim().take(300) + "|" + homeTitleYear(raw).orEmpty()

private val qualityToken = Regex("(?i)4k|uhd|fhd|hd|sd|1080p|720p")
internal fun homeQuality(raw: String): String? {
    val clean = raw.trim().replace(languagePrefix, "")
    val tag = qualityPrefix.find(clean)?.value ?: qualitySuffix.find(clean)?.value ?: return null
    val value = qualityToken.find(tag)?.value ?: return null
    return if (value.endsWith("p", true)) value.lowercase() else value.uppercase()
}
internal fun homeCollectionTitle(raw: String): String = homeDisplayTitle(raw) + (homeQuality(raw)?.let { " · $it" } ?: "")
