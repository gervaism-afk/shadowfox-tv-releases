package nl.vanvrouwerff.iptv.ui.home

import kotlin.random.Random

internal data class HomeSample(val offset: Int, val limit: Int)

/** Up to eight disjoint strata cover the entire eligible catalogue, with at most 64 rows read. */
internal fun homeSamples(count: Int, generation: Long, salt: Int = 0): List<HomeSample> {
    if (count <= 0) return emptyList()
    val strata = minOf(8, count)
    return (0 until strata).map { part ->
        val start = (part.toLong() * count / strata).toInt()
        val end = ((part + 1L) * count / strata).toInt()
        val size = minOf(8, end - start)
        val choices = end - start - size + 1
        val offset = Math.floorMod(generation * 11 + salt.toLong() + part * 7L, choices.toLong()).toInt()
        HomeSample(start + offset, size)
    }
}

/** Recent exclusions yield gracefully for small libraries so a shelf is never emptied by history. */
internal fun homeExclusions(recent: List<String>, count: Int, limit: Int): List<String> =
    recent.distinct().takeLast(minOf(192, (count - limit).coerceAtLeast(0)))

internal fun <T> distributedHomePicks(items: List<T>, generation: Long, salt: Int, limit: Int,
    id: (T) -> String, group: (T) -> String?, previousLead: String?, identity: (T) -> String = id,
    recentIdentities: Set<String> = emptySet(), previousIdentity: String? = null): List<T> {
    fun mix(pool: List<T>): List<T> {
        val buckets = pool.shuffled(Random(generation xor salt.toLong()))
            .groupBy { group(it).orEmpty() }.values.map { it.toMutableList() }
        val mixed = mutableListOf<T>()
        while (mixed.size < limit && buckets.any { it.isNotEmpty() }) {
            buckets.forEach { if (it.isNotEmpty() && mixed.size < limit) mixed.add(it.removeAt(0)) }
        }
        return mixed
    }
    val unique = items.distinctBy(id).distinctBy(identity)
    val result = (mix(unique.filterNot { identity(it) in recentIdentities }) +
        mix(unique.filter { identity(it) in recentIdentities })).take(limit).toMutableList()
    if (result.size > 1 && (id(result.first()) == previousLead || identity(result.first()) == previousIdentity)) {
        val alternate = result.indexOfFirst { id(it) != previousLead && identity(it) != previousIdentity }
        if (alternate > 0) java.util.Collections.swap(result, 0, alternate)
    }
    return result
}

private val knownGenres = listOf("Science Fiction" to "Sci-Fi", "Sci-Fi" to "Sci-Fi", "SciFi" to "Sci-Fi",
    "Documentary" to "Documentary", "Animation" to "Animation", "Adventure" to "Adventure", "Thriller" to "Thriller",
    "Mystery" to "Mystery", "Fantasy" to "Fantasy", "Romance" to "Romance", "Comedy" to "Comedy", "Horror" to "Horror",
    "Action" to "Action", "Drama" to "Drama", "Crime" to "Crime", "Family" to "Family")
    .map { (word, label) -> Regex("(?i)(?<![a-z])${Regex.escape(word)}(?![a-z])") to label }

/** Only label a shelf as a genre when the provider category actually identifies one. */
internal fun homeGenre(category: String): String? = knownGenres.mapNotNull { (pattern, label) ->
    pattern.find(category)?.range?.first?.let { it to label }
}.minByOrNull { it.first }?.second

internal data class HomeWindow(val offset: Int, val tailCount: Int, val headCount: Int)

/** A bounded circular catalogue window. A coprime stride visits every anchor before repeating. */
internal fun homeWindow(count: Int, generation: Long, salt: Int = 0): HomeWindow {
    if (count <= 0) return HomeWindow(0, 0, 0)
    fun gcd(a: Int, b: Int): Int {
        var x = a; var y = b
        while (y != 0) { val remainder = x % y; x = y; y = remainder }
        return x
    }
    var stride = HOME_ROW_LIMIT + 7
    while (gcd(stride, count) != 1) stride++
    val offset = ((Math.floorMod(generation, count.toLong()) * stride +
        Math.floorMod(salt.toLong(), count.toLong())) % count).toInt()
    val size = minOf(HOME_ROW_LIMIT, count)
    val tail = minOf(size, count - offset)
    return HomeWindow(offset, tail, size - tail)
}

/** Keep the non-repeating window anchor as the spotlight; vary the remaining bounded shelf. */
internal fun <T> arrangeHomePicks(items: List<T>, generation: Long, salt: Int = 0): List<T> =
    if (items.size < 2) items else listOf(items.first()) + items.drop(1).shuffled(Random(generation xor salt.toLong()))
