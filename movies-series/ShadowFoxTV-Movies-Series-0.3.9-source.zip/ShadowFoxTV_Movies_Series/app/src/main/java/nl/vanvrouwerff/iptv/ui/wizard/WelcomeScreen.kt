package nl.vanvrouwerff.iptv.ui.wizard

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import nl.vanvrouwerff.iptv.ui.input.Button
import androidx.tv.material3.MaterialTheme
import nl.vanvrouwerff.iptv.ui.input.Surface
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import androidx.compose.ui.graphics.Color
import androidx.tv.material3.ButtonDefaults

@Composable
fun WelcomeScreen(onConfigure: () -> Unit) {
    // A form sent from the phone lands in Instellingen: go there so it can be tested/saved.
    val phoneSubmission by nl.vanvrouwerff.iptv.data.settings.PhoneSetupServer.submission.collectAsState()
    androidx.compose.runtime.LaunchedEffect(phoneSubmission) {
        if (phoneSubmission != null) onConfigure()
    }
    WelcomeContent(onConfigure)
}

@Composable
internal fun WelcomeContent(onConfigure: () -> Unit,
    phoneSetup: @Composable (Modifier, Dp) -> Unit = { modifier, size ->
        nl.vanvrouwerff.iptv.ui.settings.PhoneSetupPanel(qrSize = size, modifier = modifier)
    }) {
    Surface(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Cinema.Atmosphere)) {
            val compact = maxWidth < 600.dp
            val shortTv = !compact && maxHeight < 600.dp
            val stepWidth = (maxWidth - 160.dp) / 3
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = if (compact) 24.dp else 64.dp, vertical = if (shortTv) 16.dp else 32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.shadowfox_cutout), null, Modifier.size(if (shortTv) 32.dp else 40.dp))
                Spacer(Modifier.width(14.dp))
                Text(
                    text = stringResource(R.string.app_name).uppercase(),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = IptvPalette.Accent,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 2.sp,
                        fontSize = if (shortTv) 10.sp else MaterialTheme.typography.labelMedium.fontSize,
                    ),
                )
                }
                Spacer(Modifier.height(if (shortTv) 12.dp else 16.dp))
                Text(
                    text = stringResource(R.string.wizard_welcome_title),
                    style = (if (compact) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.displaySmall).copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-1).sp,
                        color = IptvPalette.TextPrimary,
                        fontSize = if (shortTv) 32.sp else if (compact) MaterialTheme.typography.headlineMedium.fontSize else MaterialTheme.typography.displaySmall.fontSize,
                        lineHeight = if (shortTv) 36.sp else if (compact) MaterialTheme.typography.headlineMedium.lineHeight else MaterialTheme.typography.displaySmall.lineHeight,
                    ),
                )
                Spacer(Modifier.height(if (shortTv) 8.dp else 12.dp))
                Text(
                    text = stringResource(R.string.wizard_welcome_body),
                    modifier = Modifier.widthIn(max = 720.dp),
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = IptvPalette.TextSecondary,
                        fontSize = if (shortTv) 14.sp else MaterialTheme.typography.bodyLarge.fontSize,
                        lineHeight = if (shortTv) 20.sp else MaterialTheme.typography.bodyLarge.lineHeight,
                    ),
                )

                Spacer(Modifier.height(if (shortTv) 16.dp else 24.dp))

                val steps: @Composable () -> Unit = {
                    WizardStep(
                        number = "1",
                        title = stringResource(R.string.wizard_step1_title),
                        body = stringResource(R.string.wizard_step1_body),
                        modifier = if (compact) Modifier.fillMaxWidth() else Modifier.width(stepWidth),
                        dense = shortTv,
                    )
                    WizardStep(
                        number = "2",
                        title = stringResource(R.string.wizard_step2_title),
                        body = stringResource(R.string.wizard_step2_body),
                        modifier = if (compact) Modifier.fillMaxWidth() else Modifier.width(stepWidth),
                        dense = shortTv,
                    )
                    WizardStep(
                        number = "3",
                        title = stringResource(R.string.wizard_step3_title),
                        body = stringResource(R.string.wizard_step3_body),
                        modifier = if (compact) Modifier.fillMaxWidth() else Modifier.width(stepWidth),
                        dense = shortTv,
                    )
                }
                if (compact) Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { steps() }
                else Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) { steps() }

                Spacer(Modifier.height(if (shortTv) 16.dp else 32.dp))

                // Typing on a Formuler D-pad is painful; flag the USB-keyboard fallback up-front
                // so users who have one handy reach for it before entering a 60-char URL.
                Text(
                    text = stringResource(R.string.wizard_keyboard_hint),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = IptvPalette.TextTertiary,
                        letterSpacing = if (shortTv) 0.2.sp else 1.sp,
                        fontSize = if (shortTv) 10.sp else MaterialTheme.typography.labelMedium.fontSize,
                        lineHeight = if (shortTv) 14.sp else MaterialTheme.typography.labelMedium.lineHeight,
                    ),
                    modifier = Modifier.widthIn(max = 720.dp),
                )

                Spacer(Modifier.height(if (shortTv) 12.dp else 20.dp))

                val connect: @Composable () -> Unit = {
                    Button(
                        onClick = onConfigure,
                        colors = ButtonDefaults.colors(containerColor = Color(0xFFF1F0EB), contentColor = Cinema.Background,
                            focusedContainerColor = Color.White, focusedContentColor = Cinema.Background),
                        modifier = if (compact) Modifier.fillMaxWidth() else Modifier.width(if (shortTv) 240.dp else 320.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.wizard_configure),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(vertical = 4.dp),
                        )
                    }
                }
                if (compact) connect()
                else Row(verticalAlignment = Alignment.CenterVertically) {
                    connect()
                    Spacer(Modifier.width(if (shortTv) 24.dp else 40.dp))
                    var setupFocused by remember { mutableStateOf(false) }
                    phoneSetup(Modifier.weight(1f).onFocusChanged { setupFocused = it.isFocused }
                        .border(if (setupFocused) 2.dp else 0.dp, if (setupFocused) Color.White else Color.Transparent, RoundedCornerShape(12.dp))
                        .focusable().padding(6.dp).testTag("welcome-phone-setup"), if (shortTv) 96.dp else 110.dp)
                }
            }
        }
    }
}

@Composable
private fun WizardStep(number: String, title: String, body: String, modifier: Modifier, dense: Boolean = false) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(IptvPalette.SurfaceElevated)
            .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(16.dp))
            .padding(if (dense) 12.dp else 18.dp),
        verticalArrangement = Arrangement.Top,
    ) {
        val badge: @Composable () -> Unit = { Box(
            modifier = Modifier
                .size(if (dense) 28.dp else 36.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(IptvPalette.Accent),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = number,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = androidx.compose.ui.graphics.Color.White,
                    fontWeight = FontWeight.Black,
                ),
            )
        } }
        val heading: @Composable () -> Unit = {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(
                color = IptvPalette.TextPrimary,
                fontWeight = FontWeight.Bold,
            ),
        )
        }
        if (dense) Row(verticalAlignment = Alignment.CenterVertically) {
            badge(); Spacer(Modifier.width(8.dp)); heading()
        } else { badge(); Spacer(Modifier.height(12.dp)); heading() }
        Spacer(Modifier.height(6.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodySmall.copy(
                color = IptvPalette.TextSecondary,
                fontSize = if (dense) 12.sp else MaterialTheme.typography.bodySmall.fontSize,
                lineHeight = if (dense) 16.sp else MaterialTheme.typography.bodySmall.lineHeight,
            ),
        )
    }
}
