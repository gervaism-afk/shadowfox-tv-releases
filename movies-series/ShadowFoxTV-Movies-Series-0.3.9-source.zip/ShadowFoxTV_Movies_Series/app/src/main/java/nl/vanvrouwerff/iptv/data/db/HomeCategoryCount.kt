package nl.vanvrouwerff.iptv.data.db

data class HomeCategoryCount(val name: String, val count: Int)
