package nl.vanvrouwerff.iptv.ui.home

import android.content.SharedPreferences
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import nl.vanvrouwerff.iptv.data.db.ChannelDao
import nl.vanvrouwerff.iptv.data.db.toDomain
import java.security.MessageDigest

internal fun homeScopeKey(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

internal data class HomeGenreShelf(val title: String, val items: List<HomeItem>)

/** UI-only history. A visit snapshots exclusions, so returning from details keeps the same picks. */
@OptIn(ExperimentalCoroutinesApi::class)
internal class HomeDiscoveryRepository(private val dao: ChannelDao, private val preferences: SharedPreferences) {
    private data class Plan(val generation: Long, val recent: List<String>, val previousLead: String?,
        val recentTitles: Set<String>, val previousTitle: String?)
    private val plans = object : LinkedHashMap<String, Plan>(16, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Plan>?) = size > 16
    }

    private fun plan(key: String, generation: Long): Plan = synchronized(plans) {
        plans[key]?.takeIf { it.generation == generation } ?: Plan(generation,
            runCatching { Json.decodeFromString<List<String>>(preferences.getString("recent:$key", "[]")!!) }.getOrDefault(emptyList()),
            preferences.getString("lead:$key", null),
            runCatching { Json.decodeFromString<List<String>>(preferences.getString("titles:$key", "[]")!!) }.getOrDefault(emptyList()).toSet(),
            preferences.getString("lead-title:$key", null)).also { plans[key] = it }
    }

    fun picks(type: String, kids: Boolean, scope: String, generation: Long, category: String? = null,
        limit: Int = HOME_ROW_LIMIT): Flow<List<HomeItem>> {
        val key = homeScopeKey("$scope|$type|${category.orEmpty()}")
        val visit = plan(key, generation)
        return dao.observeDiscoveryCount(type, kids, emptyList(), category).distinctUntilChanged().flatMapLatest { total ->
            val excluded = homeExclusions(visit.recent, total, limit)
            dao.observeDiscoveryCount(type, kids, excluded, category).distinctUntilChanged().flatMapLatest { count ->
                val windows = homeSamples(count, generation, key.hashCode())
                if (windows.isEmpty()) flowOf(emptyList()) else combine(windows.map { window ->
                    dao.observeDiscoveryTitles(type, kids, excluded, window.limit, window.offset, category)
                }) { chunks ->
                    val strata = chunks.flatMapIndexed { index, rows -> rows.map { it.id to index } }.toMap()
                    distributedHomePicks(chunks.flatMap { it }.map { HomeItem(it.toDomain()) }, generation, key.hashCode(), limit,
                        { it.channel.id }, { strata[it.channel.id]?.toString() }, visit.previousLead,
                        { homeTitleIdentity(it.channel.name) }, visit.recentTitles, visit.previousTitle)
                }
            }
        }.onEach { picks ->
            if (picks.isNotEmpty()) {
                val ids = picks.map { it.channel.id }
                val old = runCatching { Json.decodeFromString<List<String>>(preferences.getString("recent:$key", "[]")!!) }.getOrDefault(emptyList())
                val recent = (old.filterNot { it in ids } + ids).takeLast(192)
                val titles = picks.map { homeTitleIdentity(it.channel.name) }
                val oldTitles = runCatching { Json.decodeFromString<List<String>>(preferences.getString("titles:$key", "[]")!!) }.getOrDefault(emptyList())
                val recentTitles = (oldTitles.filterNot { it in titles } + titles).takeLast(192)
                preferences.edit().putString("recent:$key", Json.encodeToString(recent)).putString("lead:$key", ids.first())
                    .putString("titles:$key", Json.encodeToString(recentTitles)).putString("lead-title:$key", titles.first()).apply()
            }
        }
    }

    fun genres(kids: Boolean, scope: String, generation: Long): Flow<List<HomeGenreShelf>> =
        combine(dao.observeHomeCategories("MOVIE", kids), dao.observeHomeCategories("SERIES", kids)) { movies, series ->
            val categories = (movies.map { "MOVIE" to it } + series.map { "SERIES" to it })
                .filter { it.second.count >= 2 && homeGenre(it.second.name) != null }
                .distinctBy { it.first to homeGenre(it.second.name) }
                .shuffled(kotlin.random.Random(generation xor scope.hashCode().toLong()))
            val chosen = listOfNotNull(categories.firstOrNull { it.first == "MOVIE" }, categories.firstOrNull { it.first == "SERIES" })
            (chosen + categories).distinct().take(2)
        }.distinctUntilChanged().flatMapLatest { categories ->
            if (categories.isEmpty()) flowOf(emptyList()) else combine(categories.map { (type, category) ->
                picks(type, kids, scope, generation, category.name, 12).map { items ->
                    HomeGenreShelf("${homeGenre(category.name)} ${if (type == "MOVIE") "movies" else "series"}", items)
                }
            }) { it.toList().filter { shelf -> shelf.items.isNotEmpty() } }
        }
}
