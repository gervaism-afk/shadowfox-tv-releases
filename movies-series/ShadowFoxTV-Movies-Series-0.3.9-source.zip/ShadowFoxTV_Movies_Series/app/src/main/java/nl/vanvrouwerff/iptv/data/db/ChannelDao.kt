package nl.vanvrouwerff.iptv.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow
import nl.vanvrouwerff.iptv.data.Channel

@Dao
interface ChannelDao {
    @Query("""SELECT * FROM channels WHERE type = :type AND (:category IS NULL OR groupTitle = :category)
        AND id NOT IN (:excluded)
        AND (:kids = 0 OR (LOWER(COALESCE(groupTitle, '')) NOT LIKE '%adult%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%xxx%' AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%18+%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%porn%')) ORDER BY sortIndex, id LIMIT :limit OFFSET :offset""")
    fun observeDiscoveryTitles(type: String, kids: Boolean, excluded: List<String>, limit: Int, offset: Int,
        category: String? = null): Flow<List<ChannelEntity>>

    @Query("""SELECT COUNT(*) FROM channels WHERE type = :type AND (:category IS NULL OR groupTitle = :category)
        AND id NOT IN (:excluded)
        AND (:kids = 0 OR (LOWER(COALESCE(groupTitle, '')) NOT LIKE '%adult%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%xxx%' AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%18+%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%porn%'))""")
    fun observeDiscoveryCount(type: String, kids: Boolean, excluded: List<String>, category: String? = null): Flow<Int>

    @Query("""SELECT groupTitle AS name, COUNT(*) AS count FROM channels WHERE type = :type AND groupTitle IS NOT NULL
        AND (:kids = 0 OR (LOWER(groupTitle) NOT LIKE '%adult%' AND LOWER(groupTitle) NOT LIKE '%xxx%'
        AND LOWER(groupTitle) NOT LIKE '%18+%' AND LOWER(groupTitle) NOT LIKE '%porn%'))
        GROUP BY groupTitle ORDER BY COUNT(*) DESC, groupTitle LIMIT 64""")
    fun observeHomeCategories(type: String, kids: Boolean): Flow<List<HomeCategoryCount>>

    @Query("""SELECT * FROM channels WHERE type = :type
        AND (:kids = 0 OR (LOWER(COALESCE(groupTitle, '')) NOT LIKE '%adult%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%xxx%' AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%18+%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%porn%')) ORDER BY sortIndex LIMIT :limit OFFSET :offset""")
    fun observeHomeTitles(type: String, kids: Boolean, limit: Int, offset: Int = 0): Flow<List<ChannelEntity>>

    @Query("""SELECT COUNT(*) FROM channels WHERE type = :type
        AND (:kids = 0 OR (LOWER(COALESCE(groupTitle, '')) NOT LIKE '%adult%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%xxx%' AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%18+%'
        AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%porn%'))""")
    fun observeHomeTitleCount(type: String, kids: Boolean): Flow<Int>

    @Query("""SELECT c.* FROM channels c INNER JOIN favorites f ON c.id = f.channelId
        WHERE f.profileId = :profileId AND c.type IN ('MOVIE','SERIES')
        AND (:kids = 0 OR (LOWER(COALESCE(c.groupTitle, '')) NOT LIKE '%adult%'
        AND LOWER(COALESCE(c.groupTitle, '')) NOT LIKE '%xxx%' AND LOWER(COALESCE(c.groupTitle, '')) NOT LIKE '%18+%'
        AND LOWER(COALESCE(c.groupTitle, '')) NOT LIKE '%porn%')) ORDER BY f.addedAt DESC LIMIT :limit""")
    fun observeHomeSaved(profileId: String, kids: Boolean, limit: Int): Flow<List<ChannelEntity>>
    // Fast unfiltered/category paths avoid LIKE '%%' and optional-filter OR clauses.
    @Query("SELECT * FROM channels WHERE type = :type ORDER BY sortIndex ASC LIMIT :limit OFFSET :offset")
    fun observePlainLibraryPage(type: String, limit: Int, offset: Int): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE type = :type AND groupTitle = :category ORDER BY sortIndex ASC LIMIT :limit OFFSET :offset")
    fun observeCategoryLibraryPage(type: String, category: String, limit: Int, offset: Int): Flow<List<ChannelEntity>>

    @Query("SELECT COUNT(*) FROM channels WHERE type = :type")
    fun observePlainLibraryCount(type: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM channels WHERE type = :type AND groupTitle = :category")
    fun observeCategoryLibraryCount(type: String, category: String): Flow<Int>


    @Query("""SELECT * FROM channels WHERE type = :type AND (:category IS NULL OR groupTitle = :category)
        AND name LIKE :pattern ESCAPE '\' COLLATE NOCASE
        AND (:saved = 0 OR id IN (SELECT channelId FROM favorites WHERE profileId = :profileId))
        AND (:kids = 0 OR (LOWER(COALESCE(groupTitle, '')) NOT LIKE '%adult%'
            AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%xxx%'
            AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%18+%'
            AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%porn%')) ORDER BY sortIndex ASC LIMIT :limit OFFSET :offset""")
    fun observeLibraryPage(type: String, category: String?, pattern: String,
        saved: Boolean, profileId: String, kids: Boolean, limit: Int, offset: Int): Flow<List<ChannelEntity>>

    @Query("""SELECT COUNT(*) FROM channels WHERE type = :type AND (:category IS NULL OR groupTitle = :category)
        AND name LIKE :pattern ESCAPE '\' COLLATE NOCASE
        AND (:saved = 0 OR id IN (SELECT channelId FROM favorites WHERE profileId = :profileId))
        AND (:kids = 0 OR (LOWER(COALESCE(groupTitle, '')) NOT LIKE '%adult%'
            AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%xxx%'
            AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%18+%'
            AND LOWER(COALESCE(groupTitle, '')) NOT LIKE '%porn%'))""")
    fun observeLibraryCount(type: String, category: String?, pattern: String,
        saved: Boolean, profileId: String, kids: Boolean): Flow<Int>


    @Query("SELECT * FROM channels ORDER BY sortIndex ASC")
    fun observeChannels(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE type = :type ORDER BY sortIndex ASC LIMIT :limit")
    fun observeChannelsByType(type: String, limit: Int): Flow<List<ChannelEntity>>

    @Query("SELECT COUNT(*) FROM channels")
    fun observeChannelCount(): Flow<Int>

    @Query(
        "SELECT * FROM channels WHERE type = :type AND name LIKE '%' || :query || '%' " +
            "ESCAPE '\\' COLLATE NOCASE ORDER BY sortIndex ASC LIMIT :limit",
    )
    fun searchChannels(type: String, query: String, limit: Int): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels ORDER BY sortIndex ASC")
    suspend fun allChannels(): List<ChannelEntity>

    /** Lightweight projection for the in-memory, accent-insensitive search index. */
    @Query("SELECT id, name, type FROM channels ORDER BY sortIndex ASC")
    suspend fun searchIndexRows(): List<SearchIndexRow>

    @Query("SELECT * FROM channels WHERE id IN (:ids)")
    suspend fun getChannelsByIds(ids: List<String>): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE type = :type AND streamUrl IS NOT NULL ORDER BY sortIndex ASC")
    suspend fun playableByType(type: String): List<ChannelEntity>

    @Query(
        "SELECT * FROM channels WHERE type = :type AND groupTitle = :groupTitle " +
            "AND streamUrl IS NOT NULL ORDER BY sortIndex ASC",
    )
    suspend fun playableByGroup(type: String, groupTitle: String): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE groupTitle IS NULL AND type = :type AND streamUrl IS NOT NULL ORDER BY sortIndex ASC")
    suspend fun playableUncategorized(type: String): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE type = :type ORDER BY sortIndex ASC")
    suspend fun getChannelsByType(type: String): List<ChannelEntity>

    @Query("SELECT * FROM categories ORDER BY sortIndex ASC")
    fun observeCategories(): Flow<List<CategoryEntity>>

    /** Every group title present for a type, in catalogue order. NULL = uncategorised. */
    @Query(
        "SELECT groupTitle FROM channels WHERE type = :type " +
            "GROUP BY groupTitle ORDER BY MIN(sortIndex) ASC",
    )
    fun observeGroupTitlesByType(type: String): Flow<List<String?>>

    @Query("SELECT * FROM channels WHERE type = :type AND groupTitle = :groupTitle ORDER BY sortIndex ASC")
    fun observeByTypeAndGroup(type: String, groupTitle: String): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE type = :type AND groupTitle IS NULL ORDER BY sortIndex ASC")
    fun observeByTypeUncategorized(type: String): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM categories WHERE type = :type ORDER BY sortIndex ASC")
    fun observeCategoriesByType(type: String): Flow<List<CategoryEntity>>

    @Query("DELETE FROM channels")
    suspend fun clearChannels()

    @Query("DELETE FROM categories")
    suspend fun clearCategories()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<ChannelEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)

    @Query("SELECT id, addedAt FROM channels")
    suspend fun getAddedAtSnapshot(): List<ChannelAddedAtRow>

    /**
     * Channels added in the past [windowMs] milliseconds, sorted newest-first, capped to
     * [limit] rows. Drives the "Nieuw in je catalogus" rail on the home screen.
     */
    @Query(
        "SELECT * FROM channels WHERE addedAt > :cutoff AND type = :type " +
            "AND (streamUrl IS NOT NULL OR type = 'SERIES') " +
            "ORDER BY addedAt DESC LIMIT :limit",
    )
    fun observeRecentlyAdded(type: String, cutoff: Long, limit: Int = 30): Flow<List<ChannelEntity>>

    @Transaction
    suspend fun replaceAll(channels: List<Channel>, categories: List<CategoryEntity>) {
        // Preserve addedAt across refreshes: a channel that already existed keeps its
        // original timestamp, only genuinely-new IDs get a fresh `now`. Without this the
        // "Nieuw in je catalogus" rail would re-flood with every catalogue refresh.
        // On the very first import nothing is "new" — stamp 0 so the rail stays empty
        // instead of listing an arbitrary slice of the whole catalogue.
        val now = System.currentTimeMillis()
        val existing = getAddedAtSnapshot().associate { it.id to it.addedAt }
        val firstImport = existing.isEmpty()
        clearChannels()
        clearCategories()
        insertCategories(categories)
        // Only one small batch of timestamp-adjusted entities is retained at a time.
        for (start in channels.indices step 256) {
            val batch = channels.subList(start, minOf(start + 256, channels.size)).mapIndexed { index, ch ->
                ch.toEntity(start + index, existing[ch.id] ?: if (firstImport) 0L else now)
            }
            insertChannels(batch)
        }

    }

    /** Favourite ids in the user's chosen order. */
    @Query("SELECT channelId FROM favorites WHERE profileId = :profileId ORDER BY position ASC, addedAt ASC")
    fun observeFavoriteIds(profileId: String): Flow<List<String>>

    @Query("SELECT * FROM favorites WHERE profileId = :profileId ORDER BY position ASC, addedAt ASC")
    suspend fun favoritesOrdered(profileId: String): List<FavoriteEntity>

    @Query("UPDATE favorites SET position = :position WHERE profileId = :profileId AND channelId = :id")
    suspend fun setFavoritePosition(profileId: String, id: String, position: Long)

    /** Swap a favourite with its neighbour (delta -1 = up, +1 = down). */
    @androidx.room.Transaction
    suspend fun moveFavorite(profileId: String, id: String, delta: Int) {
        val list = favoritesOrdered(profileId)
        val from = list.indexOfFirst { it.channelId == id }
        val to = from + delta
        if (from < 0 || to !in list.indices) return
        // Re-number densely first so equal/legacy positions can't make a swap a no-op.
        val reordered = list.toMutableList().apply { add(to, removeAt(from)) }
        reordered.forEachIndexed { i, fav -> setFavoritePosition(profileId, fav.channelId, i.toLong()) }
    }

    @Query(
        "INSERT OR IGNORE INTO favorites (profileId, channelId, addedAt, position) " +
            "VALUES (:profileId, :id, :now, :now)",
    )
    suspend fun addFavorite(
        profileId: String,
        id: String,
        now: Long = System.currentTimeMillis(),
    )

    @Query("DELETE FROM favorites WHERE profileId = :profileId AND channelId = :id")
    suspend fun removeFavorite(profileId: String, id: String)

    // ── Watchlist ("Bewaar voor later", Phase 7) ─────────────────────────

    @Query("SELECT channelId FROM watchlist WHERE profileId = :profileId")
    fun observeWatchlistIds(profileId: String): Flow<List<String>>

    @Query(
        "INSERT OR IGNORE INTO watchlist (profileId, channelId, addedAt) " +
            "VALUES (:profileId, :id, :now)",
    )
    suspend fun addWatchlist(
        profileId: String,
        id: String,
        now: Long = System.currentTimeMillis(),
    )

    @Query("DELETE FROM watchlist WHERE profileId = :profileId AND channelId = :id")
    suspend fun removeWatchlist(profileId: String, id: String)

    @Query(
        "SELECT c.* FROM channels c " +
            "JOIN watchlist w ON c.id = w.channelId " +
            "WHERE w.profileId = :profileId AND c.type = :type " +
            "ORDER BY w.addedAt DESC LIMIT 30",
    )
    fun observeWatchlistChannels(profileId: String, type: String): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
    suspend fun getChannelById(id: String): ChannelEntity?

    /**
     * Up to `limit` other channels sharing the same groupTitle + type as `excludeId`.
     * Powers the "Meer in X" rail on detail screens.
     */
    @Query(
        "SELECT * FROM channels " +
            "WHERE type = :type AND groupTitle = :groupTitle AND id != :excludeId " +
            "ORDER BY sortIndex ASC LIMIT :limit",
    )
    suspend fun getRelatedByGroup(
        type: String,
        groupTitle: String,
        excludeId: String,
        limit: Int = 20,
    ): List<ChannelEntity>

    @Query("SELECT * FROM watch_progress WHERE profileId = :profileId AND channelId = :id LIMIT 1")
    fun observeProgress(profileId: String, id: String): Flow<WatchProgressEntity?>

    /**
     * Progress rows for a specific set of channel / episode IDs. Used by the series detail
     * screen to compute per-season "X of Y bekeken" badges without polling every episode
     * row individually.
     */
    /**
     * Progress rows for a specific set of channel / episode IDs. Callers must keep `ids`
     * below SQLite's 999-variable limit (Android 10) — chunk larger sets.
     */
    @Query(
        "SELECT * FROM watch_progress WHERE profileId = :profileId AND channelId IN (:ids)",
    )
    fun observeProgressForIds(
        profileId: String,
        ids: List<String>,
    ): Flow<List<WatchProgressEntity>>

    @Query("SELECT * FROM watch_progress WHERE profileId = :profileId AND channelId = :id LIMIT 1")
    suspend fun getProgress(profileId: String, id: String): WatchProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: WatchProgressEntity)

    @Query("DELETE FROM watch_progress WHERE profileId = :profileId AND channelId = :id")
    suspend fun clearProgress(profileId: String, id: String)

    // "Continue watching" — channels the user started but hasn't (nearly) finished, most
    // recently updated first. Series episodes have their progress stored under
    // `xt-episode:…` IDs, which aren't in the channels table, so this query naturally only
    // returns movies. Episode-level continue-watching needs a separate cache — future step.
    @Query(
        "SELECT c.*, w.updatedAt AS progressUpdatedAt, " +
            "w.positionMs AS positionMs, w.durationMs AS durationMs " +
            "FROM channels c " +
            "INNER JOIN watch_progress w ON c.id = w.channelId " +
            "WHERE c.type = :type " +
            "  AND w.profileId = :profileId " +
            "  AND w.positionMs > 0 " +
            "  AND w.durationMs > 0 " +
            "  AND w.positionMs < w.durationMs - :finishThresholdMs " +
            "ORDER BY w.updatedAt DESC " +
            "LIMIT :limit",
    )
    fun observeContinueWatching(
        profileId: String,
        type: String,
        finishThresholdMs: Long,
        limit: Int,
    ): Flow<List<ContinueWatchingMovieRow>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun rememberEpisode(episode: WatchedEpisodeEntity)

    /**
     * Episodes the user has started watching, joined with their current progress. Same
     * "started but not finished" filter as the movie version. Ordered by most-recently
     * updated progress, not by first-watched time.
     */
    @Query(
        "SELECT e.*, w.updatedAt AS progressUpdatedAt, " +
            "w.positionMs AS positionMs, w.durationMs AS durationMs " +
            "FROM watched_episodes e " +
            "INNER JOIN watch_progress w ON e.episodeId = w.channelId AND e.profileId = w.profileId " +
            "WHERE e.profileId = :profileId " +
            "  AND w.positionMs > 0 " +
            "  AND w.durationMs > 0 " +
            "  AND w.positionMs < w.durationMs - :finishThresholdMs " +
            "ORDER BY w.updatedAt DESC " +
            "LIMIT :limit",
    )
    fun observeContinueWatchingEpisodes(
        profileId: String,
        finishThresholdMs: Long,
        limit: Int,
    ): Flow<List<ContinueWatchingEpisodeRow>>

    @Query(
        "SELECT w.updatedAt FROM watch_progress w " +
            "WHERE w.profileId = :profileId AND w.channelId = :channelId LIMIT 1",
    )
    suspend fun getProgressUpdatedAt(profileId: String, channelId: String): Long?

    // Reminders.

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE channelId = :channelId AND startMs = :startMs")
    suspend fun deleteReminder(channelId: String, startMs: Long)

    @Query("SELECT * FROM reminders ORDER BY startMs")
    fun observeReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE startMs <= :dueBy AND startMs >= :notBefore ORDER BY startMs LIMIT 1")
    suspend fun nextDueReminder(dueBy: Long, notBefore: Long): ReminderEntity?

    @Query("DELETE FROM reminders WHERE startMs < :before")
    suspend fun deleteRemindersBefore(before: Long)

    // EPG / programmes.

    @Query("SELECT DISTINCT epgChannelId FROM channels WHERE type = 'TV' AND epgChannelId IS NOT NULL")
    suspend fun liveEpgKeys(): List<String>

    @Transaction
    suspend fun replaceProgrammes(programmes: List<ProgrammeEntity>) {
        clearProgrammes()
        programmes.chunked(1000).forEach { chunk -> insertProgrammes(chunk) }
    }

    @Query("DELETE FROM programmes")
    suspend fun clearProgrammes()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgrammes(programmes: List<ProgrammeEntity>)

    /** Programmes currently airing at `now`, one per channel. */
    @Query(
        "SELECT * FROM programmes " +
            "WHERE startMs <= :now AND stopMs > :now " +
            "LIMIT :limit",
    )
    fun observeNowPlaying(now: Long, limit: Int = 500): Flow<List<ProgrammeEntity>>

    /** One-shot "what's airing now on this specific channel" lookup — for the zap banner. */
    @Query(
        "SELECT * FROM programmes " +
            "WHERE channelKey = :key AND startMs <= :now AND stopMs > :now " +
            "LIMIT 1",
    )
    suspend fun getNowPlayingFor(key: String, now: Long): ProgrammeEntity?

    /** Next programme strictly after `now` on a given channel — used for "Straks"-label. */
    @Query(
        "SELECT * FROM programmes " +
            "WHERE channelKey = :key AND startMs > :now " +
            "ORDER BY startMs ASC LIMIT 1",
    )
    suspend fun getNextProgrammeFor(key: String, now: Long): ProgrammeEntity?

    @Query(
        "SELECT * FROM programmes " +
            "WHERE channelKey IN (:keys) AND startMs <= :now AND stopMs > :now",
    )
    suspend fun nowPlayingForKeys(keys: List<String>, now: Long): List<ProgrammeEntity>

    @Query(
        "SELECT * FROM programmes " +
            "WHERE channelKey IN (:keys) AND stopMs > :from AND startMs < :to " +
            "ORDER BY channelKey, startMs ASC",
    )
    suspend fun programmesForKeys(keys: List<String>, from: Long, to: Long): List<ProgrammeEntity>

    // Series info cache.

    @Query("SELECT * FROM series_info_cache WHERE seriesId = :seriesId LIMIT 1")
    suspend fun getSeriesInfoCache(seriesId: String): SeriesInfoCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSeriesInfoCache(entry: SeriesInfoCacheEntity)

    // TMDB popular cache (one row per list key).

    @Query("SELECT * FROM tmdb_popular_cache WHERE cacheKey = :key LIMIT 1")
    suspend fun getTmdbPopularCache(key: String): TmdbPopularCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putTmdbPopularCache(entry: TmdbPopularCacheEntity)
}

data class SearchIndexRow(
    val id: String,
    val name: String,
    val type: String,
)
