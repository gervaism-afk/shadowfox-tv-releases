package nl.vanvrouwerff.iptv.ui.home

import android.text.Html
import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.suspendCancellableCoroutine
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.data.remote.HttpClient
import nl.vanvrouwerff.iptv.data.settings.SourceConfig
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.io.IOException
import java.io.Reader
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

internal data class HomeSpotlight(val channelId: String, val synopsis: String? = null, val year: String? = null,
    val rating: String? = null, val genre: String? = null, val backdropUrl: String? = null, val posterUrl: String? = null)

/** One best-effort metadata request for the spotlight, never a whole-library network scan. */
internal class HomeSpotlightRepository {
    private data class Entry(val value: HomeSpotlight?, val time: Long)
    private val cache = object : LinkedHashMap<String, Entry>(80, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?) = size > 80
    }
    private val client by lazy { HttpClient.okHttp.newBuilder().callTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build() }

    suspend fun lookup(channel: Channel, source: SourceConfig?): HomeSpotlight? {
        val config = source as? SourceConfig.Xtream ?: return null
        val prefix = if (channel.type == ContentType.MOVIE) "xt-vod:" else if (channel.type == ContentType.SERIES) "xt-series:" else return null
        if (!channel.id.startsWith(prefix)) return null
        val id = channel.id.removePrefix(prefix)
        if (id.isBlank()) return null
        val key = homeScopeKey("${config.host}|${config.username}|${config.password}|${channel.id}")
        val now = System.currentTimeMillis()
        synchronized(cache) { cache[key]?.takeIf { now - it.time < if (it.value == null) 300_000 else 86_400_000 } }?.let { return it.value }
        val url = config.host.toHttpUrlOrNull()?.newBuilder()?.addPathSegment("player_api.php")
            ?.addQueryParameter("username", config.username)?.addQueryParameter("password", config.password)
            ?.addQueryParameter("action", if (channel.type == ContentType.MOVIE) "get_vod_info" else "get_series_info")
            ?.addQueryParameter(if (channel.type == ContentType.MOVIE) "vod_id" else "series_id", id)?.build() ?: return null
        val result = suspendCancellableCoroutine<HomeSpotlight?> { continuation ->
            val call = client.newCall(Request.Builder().url(url).build())
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) { if (continuation.isActive) continuation.resume(null) }
                override fun onResponse(call: Call, response: Response) {
                    val value = response.use { r ->
                        if (!r.isSuccessful) null else runCatching { r.body?.charStream()?.use { parseHomeSpotlight(it, channel.id) } }.getOrNull()
                    }
                    if (continuation.isActive) continuation.resume(value)
                }
            })
        }
        synchronized(cache) { cache[key] = Entry(result, now) }
        return result
    }
}

private fun webImage(value: String?): String? = value?.trim()?.takeIf { it.length <= 2048 && it.toHttpUrlOrNull() != null }
private fun cleanSynopsis(value: String?): String? = value?.let {
    Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim().take(1200)
}?.takeIf { it.isNotBlank() && !it.equals("null", true) && !it.equals("N/A", true) }

/** Stream just `info`; a series' potentially huge episode list is never materialized for Home. */
internal fun parseHomeSpotlight(reader: Reader, channelId: String): HomeSpotlight? {
    val json = JsonReader(reader).apply { isLenient = true }
    if (json.peek() != JsonToken.BEGIN_OBJECT) return null
    json.beginObject()
    while (json.hasNext()) {
        if (json.nextName() != "info" || json.peek() != JsonToken.BEGIN_OBJECT) { json.skipValue(); continue }
        val values = mutableMapOf<String, String>()
        var backdrop: String? = null
        json.beginObject()
        while (json.hasNext()) {
            val name = json.nextName()
            if (name == "backdrop_path" && json.peek() == JsonToken.BEGIN_ARRAY) {
                json.beginArray()
                while (json.hasNext()) {
                    if (json.peek() == JsonToken.STRING) { val url = json.nextString(); if (backdrop == null) backdrop = webImage(url) }
                    else json.skipValue()
                }
                json.endArray()
            } else if (name in setOf("plot", "description", "genre", "rating", "releasedate", "releaseDate", "year", "backdrop_path", "cover_big", "movie_image", "cover") &&
                json.peek() in setOf(JsonToken.STRING, JsonToken.NUMBER)) {
                values[name] = json.nextString().take(if (name == "plot" || name == "description") 8000 else 2048)
            } else json.skipValue()
        }
        json.endObject()
        val year = listOfNotNull(values["releasedate"], values["releaseDate"], values["year"])
            .firstNotNullOfOrNull { Regex("^((?:18|19|20)\\d{2})(?:[-/]|$)").find(it.trim())?.groupValues?.get(1) }
        val score = values["rating"]?.substringBefore('/')?.replace(',', '.')?.toDoubleOrNull()?.takeIf { it > 0 && it <= 10 }
        return HomeSpotlight(channelId, cleanSynopsis(values["plot"]) ?: cleanSynopsis(values["description"]), year,
            score?.let { String.format(Locale.US, "%.1f", it) }, cleanSynopsis(values["genre"])?.take(100)?.takeIf { it.any(Char::isLetter) },
            backdrop ?: webImage(values["backdrop_path"]), listOfNotNull(values["cover_big"], values["movie_image"], values["cover"]).firstNotNullOfOrNull(::webImage))
            .takeIf { it.synopsis != null || it.year != null || it.rating != null || it.genre != null || it.backdropUrl != null || it.posterUrl != null }
    }
    return null
}
