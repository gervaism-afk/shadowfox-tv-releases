# ShadowFoxTV Movies & Series 0.3.8 / code 20

Local TV checks found that the first-run welcome screen clipped the QR code and
phone-setup URL at 1080p. The compact TV layout now uses wider, shorter step cards
and more economical spacing. The full QR panel fits the normal 960 x 540 dp TV
viewport. The phone-setup panel is also a visible remote-focus stop so larger text
can scroll it fully into view. Phone onboarding keeps its vertical touch layout.

A second reproduced issue affected returning to Welcome after opening Settings:
the cached Settings view model could consume a phone submission before Welcome
navigated to the account form. Submission collection now belongs to the visible
Settings screen's coroutine scope. Stored settings still finish loading before
the received form is applied, and saving remains a separate explicit action.
Account persistence, database schema, player, updater and signing identity are
unchanged.

Regression coverage checks the complete QR panel and URL at short/tall TV sizes,
D-pad access with normal and enlarged text, and phone touch access to Connect.
The delivery verification report records the completed build and local runtime
checks. The physical streamer is deliberately left on 0.3.7 while it is in use,
as requested by the user.
