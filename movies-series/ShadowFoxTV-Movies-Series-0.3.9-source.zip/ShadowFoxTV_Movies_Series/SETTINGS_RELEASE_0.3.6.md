# ShadowFoxTV Movies & Series 0.3.6 / code 18

Fixes the TV Settings scroll trap reproduced on Google TV Streamer: merely
D-pad focusing an inline account text field opened the keyboard, resized the
page, and routed subsequent Down presses into the keyboard instead of Settings.

- TV account fields are stable focusable summary rows. Press OK to open a
  deliberate single-field editor. Moving through Settings cannot open an IME.
- Done applies that edit to the settings form; Cancel discards the editor draft.
  The existing account Save action is still required to persist account changes.
  Passwords remain masked. Phone/tablet inline touch editing is retained.
- The Settings title and Back action stay outside the scrolling viewport.
  A subtle scrollbar indicates position, and the final About block is focusable
  so its explanatory text is reachable with a TV remote.

No account-storage, player, Home-discovery, database/schema, orientation-policy,
updater implementation or signing-identity changes. Install over the existing
app without uninstalling. Signing keys and local machine properties are excluded
from public source.

Validation and the exact release APK checksum are in the delivery verification
JSON. Four new UI regression cases cover TV traversal without editors, explicit
OK editing/cancel, deliberate edits/password masking, and direct phone editing.
