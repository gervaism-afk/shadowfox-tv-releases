package nl.vanvrouwerff.iptv.ui.library

import org.junit.Assert.*
import org.junit.Test

class LibraryGenresTest {
    @Test fun genresUseProviderLabelsAndCombinedLabelsCanMatchMoreThanOnce() {
        val genres = libraryGenres(listOf("EN | Action & Comedy", "FR | Comédie", "FR Science-fiction", "2026 Releases"))
        assertEquals(listOf("Action", "Comedy", "Sci-Fi"), genres.map { it.label })
        assertEquals(listOf("EN | Action & Comedy", "FR | Comédie"), genres.single { it.label == "Comedy" }.categories)
    }

    @Test fun adultGroupsOnlyBelongToAdultAndUnknownGroupsAreNotGuessed() {
        val genres = libraryGenres(listOf("XXX Adult Comedy", "Horror", "Dramatic documentaries", "My Collection"))
        assertFalse(genres.any { it.label == "Comedy" || it.label == "Drama" })
        assertEquals(listOf("XXX Adult Comedy"), genres.single { it.label == "Adult" }.categories)
        assertEquals(listOf("Horror", "Documentary", "Adult").toSet(), genres.map { it.label }.toSet())
    }

    @Test fun groupedGenreNeverUsesSingleCategoryOrUnfilteredQuery() {
        assertFalse(usesPlainLibraryQuery(LibrarySelection(genre = "Comedy", genreCategories = listOf("US Comedy", "FR Comedy")), false))
    }
}
