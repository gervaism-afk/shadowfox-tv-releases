package nl.vanvrouwerff.iptv.ui.library

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.*
import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LibraryMetadataTest {
    @Test fun categoryFailureRecoversOnTypeChangeAndSearchDoesNotReloadCategories() = runTest {
        val selection = MutableStateFlow(LibrarySelection())
        val calls = mutableListOf<ContentType>()
        val result = mutableListOf<Pair<ContentType, List<String?>>>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryCategoryFlow(selection) { type ->
                calls.add(type)
                if (type == ContentType.MOVIE) flow { throw IllegalStateException("fixture") }
                else flowOf(listOf("Shows"))
            }.collect { result.add(it) }
        }
        runCurrent()
        assertEquals(emptyList<String?>(), result.last().second)
        selection.value = selection.value.copy(query = "Castle")
        runCurrent()
        assertEquals(1, calls.size)
        selection.value = LibrarySelection(type = ContentType.SERIES)
        runCurrent()
        assertEquals(listOf("Shows"), result.last().second)
    }

    @Test fun profileAndKidsChangesApplyToCountsAndVisibleCategoriesTogether() = runTest {
        val profiles = MutableStateFlow("one")
        val kids = MutableStateFlow(false)
        val calls = mutableListOf<Pair<String, Boolean>>()
        var state: LibraryState? = null
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(MutableStateFlow(LibrarySelection(saved = true)), profiles, kids,
                { _, p, k -> calls.add(p to k); flowOf(if (k) 2 else 3) },
                { flowOf(listOf("Family", "XXX Adult", null)) }, 0).collect { state = it }
        }
        runCurrent()
        profiles.value = "two"; kids.value = true
        runCurrent()
        assertEquals("two" to true, calls.last())
        assertEquals(2, state!!.count)
        assertTrue(state!!.kidsMode)
        assertEquals(listOf("Family"), state!!.categories)
    }

    @Test fun obsoleteSearchResultsCannotReplaceTheNewFilter() = runTest {
        val selection = MutableStateFlow(LibrarySelection(query = "old"))
        val states = mutableListOf<LibraryState>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(selection, flowOf("default"), flowOf(false),
                { s, _, _ -> flow { delay(if (s.query == "old") 100 else 10); emit(if (s.query == "old") 99 else 2) } },
                { flowOf(emptyList()) }, 0).collect { states.add(it) }
        }
        runCurrent()
        selection.value = LibrarySelection(query = "new")
        advanceTimeBy(120); runCurrent()
        assertEquals(listOf("new"), states.map { it.selection.query })
        assertEquals(2, states.single().count)
    }

    @Test fun readFailureHasAnErrorButCancellationIsNotReportedAsFailure() = runTest {
        var state: LibraryState? = null
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(MutableStateFlow(LibrarySelection()), flowOf("default"), flowOf(false),
                { _, _, _ -> flow { throw IllegalStateException("fixture") } },
                { flowOf(emptyList()) }, 0).collect { state = it }
        }
        runCurrent()
        assertNotNull(state!!.error)
        assertFalse(state!!.loading)
        val cancelled = mutableListOf<LibraryState>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            libraryStateFlow(MutableStateFlow(LibrarySelection()), flowOf("default"), flowOf(false),
                { _, _, _ -> flow { throw CancellationException() } },
                { flowOf(emptyList()) }, 0).collect { cancelled.add(it) }
        }
        runCurrent()
        assertTrue(cancelled.isEmpty())
    }

    @Test fun onlyPlainUnrestrictedFiltersUseTheFastQuery() {
        assertTrue(usesPlainLibraryQuery(LibrarySelection(category = "Films"), false))
        assertFalse(usesPlainLibraryQuery(LibrarySelection(query = "100%"), false))
        assertFalse(usesPlainLibraryQuery(LibrarySelection(saved = true), false))
        assertFalse(usesPlainLibraryQuery(LibrarySelection(), true))
    }
}
