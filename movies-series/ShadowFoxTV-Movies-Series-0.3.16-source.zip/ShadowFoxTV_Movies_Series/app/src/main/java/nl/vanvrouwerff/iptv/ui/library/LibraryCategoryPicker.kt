package nl.vanvrouwerff.iptv.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.items
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.CinemaChip

@Composable
internal fun LibraryCategoryPicker(
    categories: List<String>, showAdult: Boolean = true, selected: String?, onAll: () -> Unit,
    onGenre: (LibraryGenre) -> Unit, onCategory: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val genres = remember(categories, showAdult) { libraryGenres(categories, includeEmptyAdult = showAdult).sortedBy { if (it.label == "Adult") 0 else 1 } }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        androidx.compose.runtime.withFrameNanos { }
        first.requestFocus()
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.widthIn(max = 560.dp).fillMaxWidth()
            .background(Cinema.Surface, RoundedCornerShape(20.dp)).padding(20.dp)) {
            Text("Categories", color = androidx.compose.ui.graphics.Color.White, fontSize = 23.sp)
            Spacer(Modifier.height(12.dp))
            TvLazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    CinemaChip("All titles", active = selected == null,
                        modifier = Modifier.fillMaxWidth().focusRequester(first), onClick = onAll)
                }
                items(genres, key = { "genre:${it.label}" }) { genre ->
                    CinemaChip(genre.label, active = selected == genre.label,
                        modifier = Modifier.fillMaxWidth(), onClick = { onGenre(genre) })
                }
                if (categories.isNotEmpty()) item {
                    Text("PROVIDER CATEGORIES", color = Cinema.Muted, fontSize = 11.sp,
                        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                }
                items(categories.distinct(), key = { "provider:$it" }) { category ->
                    CinemaChip(category, active = selected == category,
                        modifier = Modifier.fillMaxWidth(), onClick = { onCategory(category) })
                }
            }
            Spacer(Modifier.height(12.dp))
            CinemaChip("Close", onClick = onDismiss)
        }
    }
}
