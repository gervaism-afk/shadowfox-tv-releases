package nl.vanvrouwerff.iptv.ui.library

import androidx.paging.PagingConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import nl.vanvrouwerff.iptv.data.AdultContent
import nl.vanvrouwerff.iptv.data.ContentType

internal fun usesPlainLibraryQuery(selection: LibrarySelection, kids: Boolean): Boolean =
    selection.genre == null && !kids && !selection.saved && selection.query.isBlank()

internal fun libraryPagingConfig() = PagingConfig(
    pageSize = LIBRARY_PAGE_SIZE, initialLoadSize = LIBRARY_PAGE_SIZE,
    prefetchDistance = 20, maxSize = 180, enablePlaceholders = true,
)

@OptIn(ExperimentalCoroutinesApi::class)
internal fun libraryCategoryFlow(
    selection: Flow<LibrarySelection>,
    categoryQuery: (ContentType) -> Flow<List<String?>>,
): Flow<Pair<ContentType, List<String?>>> = selection.map { it.type }.distinctUntilChanged()
    .flatMapLatest { type ->
        categoryQuery(type).map { type to it }.catch { error ->
            if (error is CancellationException) throw error
            emit(type to emptyList())
        }
    }

@OptIn(FlowPreview::class)
internal fun libraryFilterFlow(selection: Flow<LibrarySelection>, profiles: Flow<String>,
    kidsModes: Flow<Boolean>, debounceMs: Long = 180,
): Flow<Triple<LibrarySelection, String, Boolean>> = combine(
    selection.distinctUntilChanged().debounce(debounceMs), profiles, kidsModes,
) { filter, profile, kids -> Triple(filter, profile, kids) }

/** Scrolling uses a separate bounded Pager, so it never restarts metadata queries. */
@OptIn(ExperimentalCoroutinesApi::class)
internal fun libraryStateFlow(
    selection: StateFlow<LibrarySelection>, profiles: Flow<String>, kidsModes: Flow<Boolean>,
    countQuery: (LibrarySelection, String, Boolean) -> Flow<Int>,
    categoryQuery: (ContentType) -> Flow<List<String?>>,
    debounceMs: Long = 180,
): Flow<LibraryState> = libraryFilterFlow(selection, profiles, kidsModes, debounceMs)
    .flatMapLatest { (filter, profile, kids) ->
        combine(countQuery(filter, profile, kids), categoryQuery(filter.type)) { count, cats ->
            LibraryState(selection = filter, kidsMode = kids,
                categories = cats.filterNotNull().filterNot { kids && AdultContent.isAdultCategory(it) },
                count = count, loading = false)
        }.catch { error ->
            if (error is CancellationException) throw error
            emit(LibraryState(selection = filter, kidsMode = kids, loading = false,
                error = "Could not read library. Try refreshing."))
        }
    }
