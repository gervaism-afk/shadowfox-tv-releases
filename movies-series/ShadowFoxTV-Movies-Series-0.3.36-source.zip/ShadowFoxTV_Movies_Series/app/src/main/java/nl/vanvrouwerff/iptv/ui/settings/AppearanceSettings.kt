package nl.vanvrouwerff.iptv.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.tv.material3.Icon
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.IptvPalette
import nl.vanvrouwerff.iptv.ui.theme.appearanceColors
import nl.vanvrouwerff.iptv.R

@Composable
internal fun AppearanceSettings(selected: AppearanceTheme, onSelect: (AppearanceTheme) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Compare the Home previews. Choose a theme to apply it; your selection is saved automatically.",
            fontSize = 12.sp, lineHeight = 18.sp, color = IptvPalette.TextSecondary)
        AppearanceTheme.entries.forEach { theme ->
            AppearanceChoice(theme, selected == theme) { onSelect(theme) }
        }
    }
}

@Composable
private fun AppearanceChoice(theme: AppearanceTheme, selected: Boolean, onClick: () -> Unit) {
    val phone = LocalConfiguration.current.screenWidthDp < 600
    SettingsOptionSurface(onClick = onClick,
        modifier = Modifier.fillMaxWidth().settingsControl("theme:${theme.id}", theme.ordinal * 10).semantics { this.selected = selected }
    ) { focused ->
        val words: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(theme.title, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold,
                    color = if (focused) IptvPalette.Accent else IptvPalette.TextPrimary)
                Text(if (theme == AppearanceTheme.CINEMA) "Warm gold accents and a classic cinema feel." else "Deep cobalt tones with an ice-blue accent.",
                    fontSize = 12.sp, lineHeight = 18.sp, color = IptvPalette.TextSecondary)
            }
            if (selected) Icon(Icons.Outlined.CheckCircle, "Selected", Modifier.size(22.dp), tint = IptvPalette.Accent)
        }
        }
        if (phone) Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            words()
            ThemeHomePreview(theme, Modifier.fillMaxWidth())
        } else Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Box(Modifier.weight(1f)) { words() }
            ThemeHomePreview(theme, Modifier.width(184.dp))
        }
    }
}

/** A read-only sample of Home: actual palette and original artwork, no media/network or focus targets. */
@Composable
internal fun ThemeHomePreview(theme: AppearanceTheme, modifier: Modifier = Modifier) {
    val p = appearanceColors(theme)
    Column(modifier.aspectRatio(16f / 9).clip(RoundedCornerShape(5.dp)).background(p.background)
        .clearAndSetSemantics { contentDescription = "${theme.title} Home preview" }.padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Home", color = p.accent, fontSize = 7.sp, lineHeight = 8.sp, fontWeight = FontWeight.SemiBold)
            Text("Movies", color = p.textSub, fontSize = 7.sp, lineHeight = 8.sp)
            Text("Series", color = p.textSub, fontSize = 7.sp, lineHeight = 8.sp)
            Spacer(Modifier.weight(1f))
            Text("SAMPLE", color = p.textDim, fontSize = 5.sp, lineHeight = 6.sp)
        }
        Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("YOUR PRIVATE CINEMA", color = p.accent, fontSize = 5.sp, lineHeight = 6.sp, letterSpacing = .5.sp)
                Text("Your front row.\nEvery night.", color = p.text, fontSize = 11.sp, lineHeight = 12.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.background(p.accent).padding(horizontal = 7.dp, vertical = 3.dp)) {
                    Text("Explore movies", color = p.background, fontSize = 5.sp, lineHeight = 6.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Image(painterResource(R.drawable.shadowfox_brand_original), null, Modifier.size(40.dp), contentScale = ContentScale.Inside)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(5) { index ->
                Box(Modifier.weight(1f).height(12.dp).background(Brush.horizontalGradient(
                    listOf(p.surface2, if (index == 0) p.accentDeep else p.surface))))
            }
        }
    }
}
