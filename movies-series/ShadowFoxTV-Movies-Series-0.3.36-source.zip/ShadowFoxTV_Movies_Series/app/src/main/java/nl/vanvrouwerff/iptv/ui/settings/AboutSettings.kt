package nl.vanvrouwerff.iptv.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.BuildConfig
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.ui.theme.Cinema

/** Read-only information uses separate D-pad stops so credits remain reachable. */
@Composable
internal fun AboutSettings() {
    SettingsSection("About this app") {
        SettingsInformation("about-app", 10) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Image(painterResource(R.drawable.shadowfox_brand_original), null,
                    Modifier.size(64.dp), contentScale = ContentScale.Inside)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ShadowFox TV", color = Cinema.Text, fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold)
                    Text("Movies & Series", color = Cinema.Accent, fontSize = 14.sp, lineHeight = 20.sp)
                }
            }
            Text("Movies, series and your personal watchlist. Made for TV and mobile.",
                color = Cinema.Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        SettingsInformation("about-version", 20) {
            Text("App version", color = Cinema.Muted, fontSize = 12.sp, lineHeight = 18.sp)
            Text("${BuildConfig.VERSION_NAME} · Build ${BuildConfig.VERSION_CODE}",
                color = Cinema.Text, fontSize = 16.sp, lineHeight = 22.sp)
        }
        SettingsInformation("about-credits", 30) {
            Text("App Created and Developed", color = Cinema.Muted, fontSize = 12.sp, lineHeight = 18.sp)
            Text("Mandy Gervais", color = Cinema.Text, fontSize = 20.sp, lineHeight = 27.sp, fontWeight = FontWeight.SemiBold)
            Text("Copyright 2026, ShadowFox TV", color = Cinema.Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}
