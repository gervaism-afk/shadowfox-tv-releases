package nl.vanvrouwerff.iptv.ui.library

import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.input.key.onPreviewKeyEvent
import android.view.KeyEvent
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.grid.TvGridCells
import androidx.tv.foundation.lazy.grid.TvLazyVerticalGrid
import androidx.tv.foundation.lazy.grid.itemsIndexed
import androidx.tv.foundation.lazy.grid.rememberTvLazyGridState
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.foundation.lazy.list.items
import androidx.tv.foundation.lazy.list.rememberTvLazyListState
import androidx.tv.material3.*
import nl.vanvrouwerff.iptv.ui.input.Surface
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import kotlinx.coroutines.flow.collect
import nl.vanvrouwerff.iptv.CrashCapture
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.CinemaChip
import nl.vanvrouwerff.iptv.ui.theme.CinemaNavigation
import nl.vanvrouwerff.iptv.ui.theme.tvFocus
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Tv
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import kotlin.math.ceil

private val Ink: Color
    @Composable get() = Cinema.Background
private val Panel: Color
    @Composable get() = Cinema.Surface
private val Ice: Color
    @Composable get() = Cinema.Muted

/** Bounded, poster-first TV library. No rotating hero, WebView or whole-catalogue StateFlow. */
@Composable
fun LibraryScreen(
    onOpenSettings: () -> Unit,
    onOpenDetail: (Channel) -> Unit,
    onOpenHome: (() -> Unit)? = null,
    vm: LibraryViewModel = viewModel(),
) {
    val updates by nl.vanvrouwerff.iptv.IptvApp.get().updates.state.collectAsState()
    val state by vm.state.collectAsState()
    val titles = vm.titles.collectAsLazyPagingItems()
    val requested by vm.requestedSelection.collectAsState()
    val savedSearches by vm.recentSearches.collectAsState()
    val recentSearches = if (savedSearches.first == requested.type) savedSearches.second else emptyList()
    val refreshing by vm.refreshing.collectAsState()
    val progress by vm.progress.collectAsState()
    val refreshError by vm.refreshError.collectAsState()
    var searchVisible by remember { mutableStateOf(vm.searchOpen) }
    val searchInput = remember { LibrarySearchInput(vm.currentQuery) }
    var editing by remember { mutableStateOf(false) }
    val keyboardVisible = rememberLibraryKeyboardVisible()
    val compact = searchVisible && keyboardVisible
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val context = LocalContext.current
    val crash = remember { CrashCapture.summary(context) }
    val grid = rememberTvLazyGridState(vm.gridFirstVisibleIndex, vm.gridFirstVisibleOffset)
    val headerFocus = remember { FocusRequester() }
    val settingsFocus = remember { FocusRequester() }
    val sidebarFocus = remember { FocusRequester() }
    val sidebarState = rememberTvLazyListState()
    val categoriesFocus = remember { FocusRequester() }
    val searchFocus = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    var gridEntryToken by remember { mutableIntStateOf(0) }
    var gridEntryPending by remember { mutableStateOf(false) }
    val enterGrid: () -> Unit = {
        gridEntryPending = true
    }
    LaunchedEffect(gridEntryPending, requested, state.selection, titles.loadState.refresh, titles.itemCount, compact) {
        if (gridEntryPending && !compact && state.selection == requested && !state.loading &&
            titles.loadState.refresh !is LoadState.Loading) {
            withFrameNanos { }
            if (titles.itemCount > 0) gridEntryToken++ else categoriesFocus.requestFocus()
            gridEntryPending = false
        }
    }
    val exitGridLeft: () -> Unit = {
        if (!phone && !compact) scope.launch {
            val index = when {
                requested.genre == "Adult" -> 1
                requested.category != null -> state.categories.indexOf(requested.category).takeIf { it >= 0 }
                    ?.plus(if (state.hideAdult) 1 else 2) ?: 0
                else -> 0
            }
            sidebarState.scrollToItem(index)
            withFrameNanos { }
            sidebarFocus.requestFocus()
        } else if (!compact) headerFocus.requestFocus()
        else { keyboard?.hide(); focusManager.clearFocus() }
    }
    val adultGenre = remember(state.categories) {
        LibraryGenre("Adult", state.categories.filter(nl.vanvrouwerff.iptv.data.AdultContent::isAdultCategory))
    }
    var categoriesVisible by remember { mutableStateOf(false) }
    var crashVisible by remember { mutableStateOf(false) }
    var restoreId by remember { mutableStateOf(vm.takeDetailReturnFocus()) }
    val restoreSettingsFocus = remember { vm.takeSettingsReturnFocus() }
    val openSettings: () -> Unit = {
        vm.rememberSearch(); vm.beforeOpeningSettings(); onOpenSettings()
    }
    LaunchedEffect(grid) {
        snapshotFlow { grid.firstVisibleItemIndex to grid.firstVisibleItemScrollOffset }.collect { (index, offset) ->
            vm.gridFirstVisibleIndex = index
            vm.gridFirstVisibleOffset = offset
        }
    }
    LaunchedEffect(restoreSettingsFocus) {
        if (restoreSettingsFocus) { withFrameNanos { }; settingsFocus.requestFocus() }
    }
    LaunchedEffect(Unit) {
        if (!phone && restoreId == null && !restoreSettingsFocus) {
            withFrameNanos { }
            headerFocus.requestFocus()
        }
    }
    var keyboardWasVisible by remember { mutableStateOf(false) }
    LaunchedEffect(keyboardVisible) {
        if (keyboardWasVisible && !keyboardVisible) {
            vm.rememberSearch()
            // Back closes the IME without dispatching its Search action. Release the
            // editor so the TV remote can reach history, sections and results again.
            focusManager.clearFocus()
            enterGrid()
        }
        keyboardWasVisible = keyboardVisible
    }
    LaunchedEffect(requested) {
        if (editing) restoreId = null
        if (vm.lastDisplayedSelection != requested) {
            if (!editing && restoreId == null) grid.scrollToItem(0)
            vm.lastDisplayedSelection = requested
        }
    }

    Column(Modifier.fillMaxSize().background(Ink)) {
        if (!compact) CinemaNavigation(when {
            searchVisible -> "Search"
            requested.saved -> "My List"
            requested.type == ContentType.SERIES -> "Series"
            else -> "Movies"
        }, selectedFocus = headerFocus, settingsFocus = settingsFocus, onDown = {
            if (searchVisible) searchFocus.requestFocus() else enterGrid()
        }) { label -> when (label) {
            "Home" -> onOpenHome?.invoke()
            "Movies" -> { searchInput.clear(); restoreId = null; searchVisible = false; vm.searchOpen = false; vm.selectType(ContentType.MOVIE) }
            "Series" -> { searchInput.clear(); restoreId = null; searchVisible = false; vm.searchOpen = false; vm.selectType(ContentType.SERIES) }
            "My List" -> { searchInput.clear(); searchVisible = false; vm.searchOpen = false; restoreId = null; vm.showSaved() }
            "Search" -> {
                searchVisible = !searchVisible; vm.searchOpen = searchVisible; restoreId = null
                if (!searchVisible) { vm.rememberSearch(); searchInput.clear(); vm.search(""); keyboard?.hide(); focusManager.clearFocus() }
            }
            "Settings" -> openSettings()
        } }
        Column(Modifier.weight(1f).padding(horizontal = if (phone) 16.dp else 28.dp, vertical = 6.dp)) {
        if (!compact && updates.release != null) LibraryChip("Update available — open Settings", false, onClick = openSettings)
        Spacer(Modifier.height(if (compact) 0.dp else 18.dp))
        if (searchVisible) {
            LibrarySearchField(searchInput, requested.type, vm::search,
                modifier = Modifier.fillMaxWidth().focusRequester(searchFocus).padding(bottom = if (compact) 4.dp else 8.dp),
                onEditingChanged = { editing = it }, onDone = { vm.rememberSearch(); keyboard?.hide(); focusManager.clearFocus(); enterGrid() })
            if (!compact) LibrarySearchHistory(requested.type, recentSearches,
                onRecall = { query ->
                    searchInput.recall(query, vm::search)
                    vm.rememberSearch()
                    keyboard?.hide(); focusManager.clearFocus()
                    enterGrid()
                }, onClear = vm::clearSearchHistory)
        }
        if (phone && !compact) {
            TvLazyRow(Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { LibraryChip("All titles", requested.category == null && requested.genre == null) { vm.selectCategory(null) } }
                if (!state.hideAdult) item { LibraryChip("Adult", requested.genre == "Adult") { vm.selectGenre(adultGenre) } }
                items(state.categories.distinct(), key = { it }) { category ->
                    LibraryChip(category, state.selection.category == category, Modifier.widthIn(max = 200.dp)) { vm.selectCategory(category) }
                }
            }
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            if (!compact && !phone) Column(Modifier.width(154.dp).padding(top = 5.dp).focusGroup().onPreviewKeyEvent { event ->
                if (event.nativeKeyEvent.action == KeyEvent.ACTION_DOWN && event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    enterGrid(); true
                } else false
            }) {
                Text("YOUR COLLECTION", fontSize = 9.sp, letterSpacing = 1.7.sp, color = Cinema.Accent)
                Spacer(Modifier.height(12.dp))
                TvLazyColumn(state = sidebarState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { LibraryChip("All titles", requested.category == null && requested.genre == null,
                        Modifier.fillMaxWidth().focusProperties { up = headerFocus }
                            .then(if (requested.category == null && requested.genre != "Adult") Modifier.focusRequester(sidebarFocus) else Modifier)) { vm.selectCategory(null) } }
                    if (!state.hideAdult) item { LibraryChip("Adult", requested.genre == "Adult",
                        Modifier.fillMaxWidth().then(if (requested.genre == "Adult") Modifier.focusRequester(sidebarFocus) else Modifier)) { vm.selectGenre(adultGenre) } }
                    items(state.categories.distinct(), key = { it }) { cat ->
                        LibraryChip(cat, requested.category == cat, Modifier.fillMaxWidth().then(if (requested.category == cat) Modifier.focusRequester(sidebarFocus) else Modifier)) { vm.selectCategory(cat) }
                    }
                }
            }
            Column(Modifier.weight(1f)) {
                if (compact) {
                    Text("${state.count} ${if (requested.type == ContentType.MOVIE) "movies" else "series"}", color = Ice, fontSize = 12.sp)
                } else Row(Modifier.focusGroup(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(libraryHeading(state.selection, searchVisible),
                            color = Cinema.Text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.7).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (refreshing) "Loading ${progress?.stage?.name?.lowercase() ?: "library"} · ${progress?.count ?: 0} titles"
                            else libraryCountLabel(state.count, state.selection), color = Cinema.Muted, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    LibraryChip("Categories", categoriesVisible || requested.genre != null,
                        Modifier.focusRequester(categoriesFocus).onPreviewKeyEvent { event ->
                            if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false else when (event.nativeKeyEvent.keyCode) {
                                KeyEvent.KEYCODE_DPAD_UP -> { headerFocus.requestFocus(); true }
                                KeyEvent.KEYCODE_DPAD_DOWN -> { enterGrid(); true }
                                KeyEvent.KEYCODE_DPAD_LEFT -> { exitGridLeft(); true }
                                else -> false
                            }
                        },
                        onClick = { categoriesVisible = true })
                    Spacer(Modifier.width(8.dp))
                    LibraryChip(if (refreshing) "Loading…" else "Refresh", false,
                        Modifier.onPreviewKeyEvent { event ->
                            if (event.nativeKeyEvent.action != KeyEvent.ACTION_DOWN) false else when (event.nativeKeyEvent.keyCode) {
                                KeyEvent.KEYCODE_DPAD_UP -> { headerFocus.requestFocus(); true }
                                KeyEvent.KEYCODE_DPAD_DOWN -> { enterGrid(); true }
                                KeyEvent.KEYCODE_DPAD_RIGHT -> true
                                else -> false
                            }
                        }, onClick = vm::refresh)
                }
                Spacer(Modifier.height(if (compact) 4.dp else 12.dp))
                if (state.error != null || refreshError != null) {
                    Text(state.error ?: "Library refresh failed. Check your account or connection in Settings.", color = Color(0xFFFFB195), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                }
                if (state.loading || (titles.itemCount == 0 && titles.loadState.refresh is LoadState.Loading) || state.count == 0) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(if (requested.type == ContentType.MOVIE) Icons.Outlined.Movie else Icons.Outlined.Tv,
                                null, Modifier.size(36.dp), tint = Cinema.Accent)
                            Text(if (state.loading || refreshing) "Preparing your library…" else libraryEmptyMessage(state.selection),
                                color = Cinema.Muted, fontSize = 15.sp)
                        }
                    }
                } else {
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    // Fit complete posters above the keyboard instead of clipping a large first row.
                    val columns = if (phone) phonePosterColumns(maxWidth.value) else if (compact) maxOf(8, ceil(maxWidth.value /
                        (((maxHeight.value - 44f).coerceIn(84f, 144f)) * 2f / 3f + 8f)).toInt()) else if (maxWidth < 800.dp) 4 else 5
                    LibraryTitleGrid(titles, grid, columns, vm.focusedIndex, gridEntryToken,
                        restoreId.takeIf { !editing && state.selection == requested }, compact,
                        onExitUp = {
                            if (searchVisible && !compact) searchFocus.requestFocus()
                            else if (!compact) headerFocus.requestFocus()
                            else { keyboard?.hide(); focusManager.clearFocus() }
                        },
                        onExitLeft = exitGridLeft,
                        onFocus = { item, index -> vm.focusedIndex = index; vm.focusedId = item?.id },
                        onRestored = { restoreId = null },
                        onOpen = { item, index ->
                            vm.rememberSearch(); vm.beforeOpeningDetail(item.id, index)
                            keyboard?.hide(); focusManager.clearFocus()
                            scope.launch { yield(); onOpenDetail(item) }
                        })
                    }
                }
                if (titles.loadState.refresh is LoadState.Error || titles.loadState.append is LoadState.Error || titles.loadState.prepend is LoadState.Error) {
                    LibraryChip("Could not load titles — Retry", false) { titles.retry() }
                }
                if (!compact && !phone) Text("↑ ${if (searchVisible) "Search" else "Sections"}   ·   ← Categories   ·   OK Details",
                    modifier = Modifier.padding(top = 10.dp), fontSize = 10.sp, color = Cinema.Muted)
            }
        }
        if (crash != null) Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Previous crash: $crash", fontSize = 10.sp, color = Cinema.Muted)
            Spacer(Modifier.width(12.dp))
            LibraryChip("Crash details", false) { crashVisible = true }
        }
        if (categoriesVisible) LibraryCategoryPicker(
            categories = state.categories,
            showAdult = !state.hideAdult,
            selected = requested.genre ?: requested.category,
            onAll = { vm.selectCategory(null); categoriesVisible = false },
            onGenre = { vm.selectGenre(it); categoriesVisible = false },
            onCategory = { vm.selectCategory(it); categoriesVisible = false },
            onDismiss = { categoriesVisible = false },
        )
        if (crashVisible) androidx.compose.ui.window.Dialog(onDismissRequest = { crashVisible = false }) {
            Column(Modifier.background(Panel, RoundedCornerShape(12.dp)).padding(20.dp)) {
                Text("Crash report", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(remember { CrashCapture.report(context).orEmpty().take(2500) }, fontSize = 11.sp,
                    lineHeight = 15.sp, maxLines = 16, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                LibraryChip("Close", false) { crashVisible = false }
            }
        }
        }
    }
}

@Composable
private fun rememberLibraryKeyboardVisible(): Boolean {
    val view = LocalView.current
    val orientation = LocalConfiguration.current.orientation
    var visible by remember(view) { mutableStateOf(false) }
    DisposableEffect(view, orientation) {
        var largestHeight = 0
        val frame = android.graphics.Rect()
        // H96 firmware can report IME-visible insets after the keyboard has closed.
        // With adjustResize, the actual unobscured window reliably tracks its presence.
        val listener = android.view.ViewTreeObserver.OnGlobalLayoutListener {
            view.getWindowVisibleDisplayFrame(frame)
            largestHeight = maxOf(largestHeight, frame.height())
            visible = largestHeight > 0 && largestHeight - frame.height() > largestHeight / 6
        }
        view.viewTreeObserver.addOnGlobalLayoutListener(listener)
        listener.onGlobalLayout()
        onDispose { view.viewTreeObserver.removeOnGlobalLayoutListener(listener) }
    }
    return visible
}

@Composable
internal fun LibrarySearchHistory(type: ContentType, recents: List<String>, onRecall: (String) -> Unit, onClear: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (type == ContentType.MOVIE) "Recent movies" else "Recent series", color = Ice, fontSize = 11.sp)
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (recents.isEmpty()) Text("No recent searches", color = Cinema.Muted, fontSize = 11.sp)
            recents.forEach { query -> LibraryChip(query, false, Modifier.widthIn(max = 180.dp)) { onRecall(query) } }
        }
        LibraryChip("Clear history", false, onClick = onClear)
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun LibraryChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    CinemaChip(label, selected, modifier, onClick)
}

internal fun phonePosterColumns(widthDp: Float): Int = maxOf(1, (widthDp / 140f).toInt())

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
internal fun LibraryPoster(item: Channel, restoreFocus: Boolean, compact: Boolean = false, onRestored: () -> Unit = {}, onFocus: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    val context = LocalContext.current
    val requester = remember(item.id) { FocusRequester() }
    LaunchedEffect(item.id, restoreFocus) {
        if (restoreFocus) {
            withFrameNanos { }
            try { requester.requestFocus(); onRestored() } catch (_: IllegalStateException) { }
        }
    }
    Surface(onClick = onClick, modifier = Modifier.fillMaxWidth().focusRequester(requester).onFocusChanged {
        focused = it.isFocused
        if (it.isFocused) onFocus()
    }
        .tvFocus(focused, shape, focusedScale = 1.02f),
        shape = ClickableSurfaceDefaults.shape(shape), scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = Panel, contentColor = Color.White,
            focusedContainerColor = Cinema.Raised, focusedContentColor = Color.White)) {
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(Cinema.Atmosphere), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(if (item.type == ContentType.MOVIE) Icons.Outlined.Movie else Icons.Outlined.Tv,
                        null, Modifier.size(30.dp), tint = Cinema.Accent.copy(alpha = 0.7f))
                    Text(if (item.type == ContentType.MOVIE) "MOVIE" else "SERIES", color = Ice, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                if (item.logoUrl != null) AsyncImage(
                    model = remember(item.logoUrl) { ImageRequest.Builder(context).data(item.logoUrl).size(432, 648).crossfade(false).build() },
                    contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Text(nl.vanvrouwerff.iptv.ui.home.homeCollectionTitle(item.name), Modifier.padding(horizontal = if (compact) 4.dp else 10.dp, vertical = if (compact) 4.dp else 8.dp).height(if (compact) 28.dp else 34.dp), fontSize = if (compact) 10.sp else 12.sp,
                lineHeight = if (compact) 13.sp else 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
