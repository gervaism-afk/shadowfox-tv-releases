package nl.vanvrouwerff.iptv.data.settings

enum class AppearanceTheme(val id: String, val title: String, val description: String) {
    CINEMA("cinema", "Cinema", "Original charcoal and warm gold"),
    SHADOWFOX_EXCLUSIVE("shadowfox_exclusive", "ShadowFox Exclusive", "Cobalt chrome, ice blue and Inter typography");

    companion object {
        val DEFAULT = SHADOWFOX_EXCLUSIVE

        fun fromId(id: String?): AppearanceTheme = entries.firstOrNull { it.id == id } ?: DEFAULT
    }
}
