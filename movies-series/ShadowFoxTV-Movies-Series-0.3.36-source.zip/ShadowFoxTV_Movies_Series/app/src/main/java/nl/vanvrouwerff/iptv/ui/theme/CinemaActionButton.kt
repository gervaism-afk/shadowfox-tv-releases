package nl.vanvrouwerff.iptv.ui.theme

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.unit.dp
import androidx.tv.material3.ButtonColors
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import nl.vanvrouwerff.iptv.ui.input.Button

/** Consistent rounded actions with restrained focus movement in both themes. */
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
internal fun CinemaActionButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    prominent: Boolean = false,
    classicColors: ButtonColors = ButtonDefaults.colors(),
    content: @Composable RowScope.() -> Unit,
) {
    val exclusive = Cinema.Exclusive
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp).onFocusChanged { focused = it.isFocused }
            .tvFocus(focused, shape, focusedScale = 1.025f),
        shape = ButtonDefaults.shape(shape),
        scale = ButtonDefaults.scale(focusedScale = 1f),
        colors = if (prominent) ButtonDefaults.colors(
            containerColor = Color(0xFFF5F7FA), contentColor = Color(0xFF10141B),
            focusedContainerColor = Color.White, focusedContentColor = Color(0xFF10141B),
        ) else if (exclusive) ButtonDefaults.colors(
            containerColor = if (prominent) IptvPalette.SurfaceElevated else IptvPalette.SurfaceLift,
            contentColor = IptvPalette.TextPrimary,
            focusedContainerColor = Cinema.Raised,
            focusedContentColor = IptvPalette.TextPrimary,
        ) else classicColors,
        content = content,
    )
}
