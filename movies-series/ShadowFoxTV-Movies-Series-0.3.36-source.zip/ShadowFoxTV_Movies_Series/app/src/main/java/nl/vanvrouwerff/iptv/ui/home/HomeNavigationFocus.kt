package nl.vanvrouwerff.iptv.ui.home

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

internal enum class HomeReturnAnchor { HOME, SETTINGS, PRIMARY }

/** Transient navigation intent; never stored with account or discovery preferences. */
internal class HomeNavigationFocus {
    private var header: HomeReturnAnchor? = HomeReturnAnchor.HOME
    private var item: String? = null
    private val tokens = MutableStateFlow(0L)
    val requests = tokens.asStateFlow()

    fun requestHome() {
        header = HomeReturnAnchor.HOME
        item = null
        tokens.update { it + 1 }
    }

    fun beforeSettings() { header = HomeReturnAnchor.SETTINGS; item = null }
    fun beforeDetail(id: String?) {
        item = id
        header = if (id == null) HomeReturnAnchor.PRIMARY else null
    }

    fun takeHeader(): HomeReturnAnchor? = header.also { header = null }
    fun takeItem(): String? = item.also { item = null }
}
