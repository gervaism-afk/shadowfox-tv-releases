package nl.vanvrouwerff.iptv.ui.theme

import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.onPreviewKeyEvent
import android.view.KeyEvent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.tv.material3.Icon
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.input.Surface

internal object Cinema {
    val Exclusive: Boolean @Composable get() = LocalAppearanceColors.current.exclusive
    val Background: Color @Composable get() = IptvPalette.BackgroundDeep
    val Surface: Color @Composable get() = IptvPalette.SurfaceLift
    val Raised: Color @Composable get() = LocalAppearanceColors.current.high
    val Muted: Color @Composable get() = if (Exclusive) IptvPalette.TextSecondary else Color(0xFFA9B0BE)
    val Accent: Color @Composable get() = IptvPalette.Accent
    val Line: Color @Composable get() = LocalAppearanceColors.current.line
    val Text: Color @Composable get() = IptvPalette.TextPrimary
    val FocusRing: Color @Composable get() = if (Exclusive) IptvPalette.FocusRing else Color.White
    val SelectedFill: Color @Composable get() = if (Exclusive) IptvPalette.SurfaceElevated else Color(0xFFF1F0EB)
    val SelectedInk: Color @Composable get() = if (Exclusive) Text else Background
    val FocusFill: Color @Composable get() = if (Exclusive) Raised else Color.White
    private val classicAtmosphere = Brush.linearGradient(listOf(Color(0xFF24222A), Color(0xFF131A24), Color(0xFF090B10)))
    private val exclusiveAtmosphere = appearanceColors(AppearanceTheme.SHADOWFOX_EXCLUSIVE).let {
        Brush.linearGradient(listOf(it.surface, it.background))
    }
    val Atmosphere: Brush @Composable get() = if (Exclusive) exclusiveAtmosphere else classicAtmosphere
}

/** One navigation language for Home and the paged library, with a separate phone header. */
@Composable
internal fun CinemaNavigation(selected: String, selectedFocus: FocusRequester? = null,
    settingsFocus: FocusRequester? = null, onDown: (() -> Unit)? = null, onNavigate: (String) -> Unit) {
    val phone = LocalConfiguration.current.screenWidthDp < 600
    Column(Modifier.fillMaxWidth().focusGroup().onPreviewKeyEvent { event ->
        if (event.nativeKeyEvent.action == KeyEvent.ACTION_DOWN && event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && onDown != null) {
            onDown(); true
        } else false
    }.padding(horizontal = if (phone) 20.dp else 32.dp, vertical = if (phone) 14.dp else 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.shadowfox_brand_original), "ShadowFoxTV", Modifier.size(34.dp), contentScale = ContentScale.Inside)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("ShadowFoxTV", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp)
                Text("MOVIES & SERIES", color = Cinema.Accent, fontSize = 8.sp, letterSpacing = 1.7.sp)
            }
            Spacer(Modifier.weight(1f))
            if (!phone) NavigationTabs(selected, selectedFocus, onNavigate)
            Spacer(Modifier.width(if (phone) 8.dp else 20.dp))
            CinemaChip("Settings", selected == "Settings", icon = Icons.Outlined.Settings,
                modifier = if (settingsFocus != null) Modifier.focusRequester(settingsFocus) else Modifier,
                onClick = { onNavigate("Settings") })
        }
        if (phone) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NavigationTabs(selected, selectedFocus, onNavigate)
            }
        }
    }
}

@Composable
private fun NavigationTabs(selected: String, selectedFocus: FocusRequester?, onNavigate: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("Home", "Movies", "Series", "My List", "Search").forEach { label ->
            CinemaChip(label, selected == label, modifier = if (selected == label && selectedFocus != null) Modifier.focusRequester(selectedFocus) else Modifier, onClick = { onNavigate(label) })
        }
    }
}

@Composable
internal fun CinemaChip(label: String, active: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    CinemaChip(label, active, modifier, icon = null, onClick = onClick)
}

@Composable
private fun CinemaChip(label: String, active: Boolean, modifier: Modifier, icon: ImageVector?, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val phone = LocalConfiguration.current.screenWidthDp < 600
    val shape = RoundedCornerShape(12.dp)
    Surface(onClick = onClick,
        modifier = modifier.then(if (icon != null) Modifier.size(48.dp) else Modifier.heightIn(min = if (phone) 48.dp else 40.dp))
            .semantics { selected = active; if (icon != null) contentDescription = label }.onFocusChanged { focused = it.isFocused }
            .tvFocus(focused, shape, focusedScale = 1.015f)
            .then(if (active && !focused && Cinema.Exclusive) Modifier.border(1.dp, Cinema.Line, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (active) Cinema.SelectedFill else Color.Transparent,
            contentColor = if (active) Cinema.SelectedInk else Cinema.Muted,
            focusedContainerColor = if (Cinema.Exclusive) Cinema.Raised else if (active) Color.White else Cinema.Raised,
            focusedContentColor = if (active) Cinema.SelectedInk else Cinema.Text)) {
        Box(if (icon != null) Modifier.fillMaxSize() else Modifier.padding(horizontal = 14.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
            if (icon != null) Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp),
                tint = if (active) Cinema.SelectedInk else if (focused) Cinema.Text else Cinema.Muted)
            else Text(label, color = if (active) Cinema.SelectedInk else if (focused) Cinema.Text else Cinema.Muted,
                fontSize = 12.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
