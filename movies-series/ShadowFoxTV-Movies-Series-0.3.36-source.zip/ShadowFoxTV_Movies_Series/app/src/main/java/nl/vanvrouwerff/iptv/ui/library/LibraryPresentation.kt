package nl.vanvrouwerff.iptv.ui.library

import nl.vanvrouwerff.iptv.data.ContentType

internal fun libraryHeading(selection: LibrarySelection, searchVisible: Boolean): String = when {
    searchVisible -> if (selection.type == ContentType.MOVIE) "Search movies" else "Search series"
    selection.saved -> "My List"
    selection.genre != null -> selection.genre
    selection.category != null -> selection.category
    selection.type == ContentType.MOVIE -> "Discover movies"
    else -> "Discover series"
}

internal fun libraryCountLabel(count: Int, selection: LibrarySelection): String {
    val title = if (count == 1) "title" else "titles"
    return when {
        selection.query.isNotBlank() -> "$count ${if (count == 1) "match" else "matches"} · ${selection.query.trim()}"
        selection.saved -> "$count saved $title"
        selection.category != null || selection.genre != null -> "$count $title in this collection"
        else -> "$count $title in your library"
    }
}

internal fun libraryEmptyMessage(selection: LibrarySelection): String = when {
    selection.query.isNotBlank() -> "No matches for “${selection.query.trim()}”. Try a shorter title or another category."
    selection.genre == "Adult" && selection.genreCategories.isEmpty() -> "Your provider has not supplied Adult ${if (selection.type == ContentType.MOVIE) "movie" else "series"} categories for this account. Refresh your library or ask your provider to enable them."
    selection.saved -> "Your list starts here. Save a movie or series from its detail page."
    else -> "No titles in this collection. Try another category or refresh your library."
}
