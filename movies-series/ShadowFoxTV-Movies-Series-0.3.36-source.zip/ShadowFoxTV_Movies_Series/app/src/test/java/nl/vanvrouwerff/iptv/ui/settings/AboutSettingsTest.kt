package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.Density
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.BuildConfig
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class AboutSettingsTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    private fun information(text:String)=compose.onNode(hasTestTag("settings-information") and hasAnyDescendant(hasText(text)))
    private fun capture(name:String) {
        val dir=File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile!!
        compose.runOnUiThread {
            val view=compose.activity.window.decorView
            val bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap));dir.resolve(name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) };bitmap.recycle()
        }
    }
    @Test fun remoteCanReachReadOnlyCreditsAndStillReachTheFooterBackButton() {
        var category by mutableStateOf(SettingsCategory.Account)
        var theme by mutableStateOf(AppearanceTheme.SHADOWFOX_EXCLUSIVE)
        compose.setContent { IptvTheme(theme) {
            SettingsPage(onBack={},pageKey=category,navigation={SettingsCategories(category){category=it}}) {
                if(category==SettingsCategory.About) AboutSettings()
                else SettingsInformation { Text("Section information") }
            }
        } }
        compose.onNodeWithText("Updates").performSemanticsAction(SemanticsActions.RequestFocus)
            .performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("About").assertIsFocused().performKeyInput { pressKey(Key.DirectionRight) }
        information("ShadowFox TV").assertIsFocused()
        compose.onNodeWithText("${BuildConfig.VERSION_NAME} · Build ${BuildConfig.VERSION_CODE}").assertIsDisplayed()
        capture("about-exclusive-tv.png")
        information("ShadowFox TV").performKeyInput { pressKey(Key.DirectionDown) }
        information("App version").assertIsFocused().performKeyInput { pressKey(Key.DirectionDown) }
        information("Mandy Gervais").assertIsFocused()
        compose.onNodeWithText("App Created and Developed").assertIsDisplayed()
        compose.onNodeWithText("Copyright 2026, ShadowFox TV").assertIsDisplayed()
        val credits=information("Mandy Gervais").fetchSemanticsNode().boundsInRoot
        val viewport=compose.onNodeWithTag("settings-viewport").fetchSemanticsNode().boundsInRoot
        assertTrue(credits.top>=viewport.top-1f && credits.bottom<=viewport.bottom+1f)
        information("Mandy Gervais").performKeyInput { pressKey(Key.DirectionDown) }
        information("Mandy Gervais").assertIsFocused().performKeyInput { pressKey(Key.DirectionLeft) }
        compose.onNodeWithText("About").assertIsFocused().performKeyInput { pressKey(Key.DirectionDown) }
        val back=compose.onNodeWithText("Back").assertIsFocused().assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        assertTrue(back.bottom<=compose.onRoot().fetchSemanticsNode().boundsInRoot.bottom)
        compose.onNodeWithText("Back").performKeyInput { pressKey(Key.DirectionUp) }
        compose.onNodeWithText("About").assertIsFocused()
        compose.runOnIdle { theme=AppearanceTheme.CINEMA }
        capture("about-cinema-tv.png")
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
    }
    @Test @Config(qualifiers="w320dp-h640dp-port-xhdpi")
    fun narrowPhoneWithLargerTextCanScrollToVersionAndExactCreatorCredit() {
        compose.setContent {
            val density=LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density,1.3f)) {
                IptvTheme {
                    SettingsPage(onBack={},pageKey=SettingsCategory.About,
                        navigation={SettingsCategories(SettingsCategory.About){}}) { AboutSettings() }
                }
            }
        }
        compose.onNodeWithText("${BuildConfig.VERSION_NAME} · Build ${BuildConfig.VERSION_CODE}").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Mandy Gervais").performScrollTo().assertIsDisplayed()
        val copyright=compose.onNodeWithText("Copyright 2026, ShadowFox TV").performScrollTo().assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        val root=compose.onRoot().fetchSemanticsNode().boundsInRoot
        assertTrue(copyright.left>=root.left && copyright.right<=root.right && copyright.bottom<=root.bottom)
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
        capture("about-phone-large-text.png")
    }
}
