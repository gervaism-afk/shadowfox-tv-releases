package nl.vanvrouwerff.iptv.ui.detail

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.ui.theme.CinemaActionButton
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class DetailNavigationTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private fun capture(name: String) {
        val dir = File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile!!
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap)); dir.resolve(name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }; bitmap.recycle()
        }
    }
    @Test fun remoteUpReachesBackAndDownReturnsToPlayWithoutPlaying() {
        var backs=0; var plays=0
        compose.setContent { IptvTheme(AppearanceTheme.SHADOWFOX_EXCLUSIVE) {
            val focus=remember { FocusRequester() }
            LaunchedEffect(Unit) { withFrameNanos { }; focus.requestFocus() }
            DetailScaffold(null, "Adventure", "North of the Sun", "2024 · 8.2 · 1h 42m",
                onBack={ backs++ }, primaryFocus=focus,
                actions={ CinemaActionButton({ plays++ }, Modifier.focusRequester(focus), prominent=true) { Text("Play") } }) {
                detailSection("overview","Overview") { FocusableTextBlock("Beyond the familiar, a quieter world is waiting to be found.") }
                for (index in 1..16) detailSection("extra-$index", "More about this title") {
                    FocusableTextBlock("Details section $index")
                }
            }
        } }
        compose.onNodeWithText("Play").assertIsFocused().performKeyInput { pressKey(Key.DirectionUp) }
        compose.onNodeWithText("Back").assertIsFocused().assertHeightIsAtLeast(48.dp)
            .performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Play").assertIsFocused()
        compose.runOnIdle { assertEquals(0,plays); assertEquals(0,backs) }
        capture("detail-refined-tv.png")
        compose.onNodeWithTag("detail-content").performScrollToIndex(17)
        compose.onNodeWithText("Details section 16").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus)
        compose.onNodeWithText("Play").assertIsNotDisplayed()
        compose.onNodeWithText("Back").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus)
        compose.onNodeWithText("Back").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Play").assertIsFocused().assertIsDisplayed()
        compose.onNodeWithText("Back").performTouchInput { click() }
        compose.runOnIdle { assertEquals(1,backs); assertEquals(0,plays) }
    }
    @Test @Config(qualifiers="w393dp-h851dp-port-xhdpi")
    fun phoneLoadingAndUnavailablePagesAlwaysOfferATouchExit() {
        var loading by mutableStateOf(true); var backs=0
        compose.setContent { IptvTheme { DetailStatus(if (loading) "Loading title" else "Title not found", loading) { backs++ } } }
        compose.onNodeWithText("Loading title").assertIsDisplayed()
        capture("detail-loading-phone.png")
        compose.onNodeWithText("Back").performTouchInput { click() }
        compose.runOnIdle { loading=false }
        compose.onNodeWithText("Title not found").assertIsDisplayed()
        compose.onNodeWithText("Back").performTouchInput { click() }
        compose.runOnIdle { assertEquals(2,backs) }
    }
}
