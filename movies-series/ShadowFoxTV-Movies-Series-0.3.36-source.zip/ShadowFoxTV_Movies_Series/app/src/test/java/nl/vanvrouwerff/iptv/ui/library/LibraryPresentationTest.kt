package nl.vanvrouwerff.iptv.ui.library

import nl.vanvrouwerff.iptv.data.ContentType
import org.junit.Assert.*
import org.junit.Test

class LibraryPresentationTest {
    @Test fun searchAndSavedCountsDescribeTheFilteredCollection() {
        assertEquals("Search series", libraryHeading(LibrarySelection(type = ContentType.SERIES, category = "Drama"), true))
        assertEquals("1 match · Moon", libraryCountLabel(1, LibrarySelection(query = " Moon ")))
        assertEquals("0 matches · Moon", libraryCountLabel(0, LibrarySelection(query = "Moon")))
        assertEquals("2 saved titles", libraryCountLabel(2, LibrarySelection(saved = true)))
        assertEquals("1 title in this collection", libraryCountLabel(1, LibrarySelection(category = "Drama")))
    }
    @Test fun emptySearchSuggestsChangingTheQueryWhileMissingAdultCategoriesStayHonest() {
        assertTrue(libraryEmptyMessage(LibrarySelection(query = "Moon")).contains("No matches for “Moon”"))
        assertTrue(libraryEmptyMessage(LibrarySelection(genre = "Adult")).contains("provider has not supplied Adult movie"))
        assertTrue(libraryEmptyMessage(LibrarySelection(type = ContentType.SERIES, genre = "Adult")).contains("Adult series"))
        assertTrue(libraryEmptyMessage(LibrarySelection(saved = true)).contains("Save a movie or series"))
    }
}
