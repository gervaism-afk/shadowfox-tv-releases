package nl.vanvrouwerff.iptv.ui.home

import android.app.Application
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.ui.theme.CinemaActionButton
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class HomeReturnNavigationTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    private val navigation=HomeNavigationFocus()
    private var route by mutableStateOf("home")
    private var state by mutableStateOf(HomeState(loading=false,featured=Channel("one","A Quiet Journey",null,"Drama",null,null,ContentType.MOVIE)))
    private var plays=0

    private fun mount() {
        compose.setContent { IptvTheme {
            if (route=="home") {
                val request by navigation.requests.collectAsState()
                val header=remember(request) { navigation.takeHeader() }
                HomeScreen(state,onSection={ if (it!=HomeSection.HOME) route="library" },
                    onSettings={ navigation.beforeSettings();route="settings" },
                    onDetail={ _,rail->navigation.beforeDetail(if(rail=="featured") null else "$rail:one");route="detail" },
                    onPlay={ plays++ },restoreId=remember { navigation.takeItem() },
                    focusHomeOnEntry=header==HomeReturnAnchor.HOME,homeFocusRequest=request,returnAnchor=header)
            } else CinemaActionButton(onClick={
                if(route=="library") navigation.requestHome()
                route="home"
            }) { Text("Return") }
        } }
    }
    private fun backToHome()=compose.onNodeWithText("Return").performTouchInput { click() }

    @Test fun returningFromLibraryHasAVisibleHomeFocusAndTheNextRightReachesMovies() {
        mount()
        compose.onNodeWithText("Home").assertIsFocused().performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithText("Movies").performKeyInput { pressKey(Key.DirectionCenter) }
        backToHome()
        compose.onNodeWithText("Home").assertIsFocused().performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithText("Movies").assertIsFocused()
        compose.runOnIdle { state=state.copy(spotlight=HomeSpotlight("one","Newly loaded overview","2024",null,null,null)) }
        compose.onNodeWithText("Movies").assertIsFocused()
        compose.runOnIdle { assertEquals(0,plays) }
    }
    @Test fun leavingSettingsReturnsToTheGearAndLaterDataDoesNotMoveFocus() {
        mount()
        compose.onNodeWithContentDescription("Settings").performTouchInput { click() }
        backToHome()
        compose.onNodeWithContentDescription("Settings").assertIsFocused()
        compose.runOnIdle { state=state.copy(loading=true) }
        compose.onNodeWithContentDescription("Settings").assertIsFocused()
        compose.runOnIdle { assertEquals(0,plays) }
    }
    @Test fun featuredDetailReturnFocusesThePrimaryActionWithoutPlaying() {
        mount()
        compose.onNodeWithText("Details").performTouchInput { click() }
        backToHome()
        compose.onNodeWithText("Play").assertIsFocused().assertIsDisplayed()
        compose.runOnIdle { assertEquals(0,plays) }
    }
    @Test @Config(qualifiers="w393dp-h851dp-port-xhdpi")
    fun returnAnchorsDoNotForceTvFocusOntoPhoneControls() {
        compose.setContent { IptvTheme { HomeScreen(state,{}, {},{_,_->},{},
            focusHomeOnEntry=false,returnAnchor=HomeReturnAnchor.SETTINGS) } }
        compose.onNodeWithContentDescription("Settings").assertIsNotFocused()
    }
}
