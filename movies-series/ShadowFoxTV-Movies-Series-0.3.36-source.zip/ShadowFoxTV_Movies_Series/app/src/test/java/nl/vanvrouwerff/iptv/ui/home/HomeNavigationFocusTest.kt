package nl.vanvrouwerff.iptv.ui.home

import org.junit.Assert.*
import org.junit.Test

class HomeNavigationFocusTest {
    @Test fun detailAndSettingsReturnIntentsAreConsumedOnce() {
        val focus=HomeNavigationFocus()
        assertEquals(HomeReturnAnchor.HOME,focus.takeHeader());assertNull(focus.takeHeader())
        focus.beforeDetail("Movies for your evening:one")
        assertNull(focus.takeHeader())
        assertEquals("Movies for your evening:one",focus.takeItem());assertNull(focus.takeItem())
        focus.beforeDetail(null)
        assertEquals(HomeReturnAnchor.PRIMARY,focus.takeHeader());assertNull(focus.takeHeader())
        focus.beforeSettings()
        assertEquals(HomeReturnAnchor.SETTINGS,focus.takeHeader());assertNull(focus.takeHeader())
    }
    @Test fun anExplicitHomeOrLauncherRequestOverridesAStaleDetailReturn() {
        val focus=HomeNavigationFocus();focus.takeHeader()
        focus.beforeDetail("My List:one");focus.requestHome()
        assertNull(focus.takeItem());assertEquals(HomeReturnAnchor.HOME,focus.takeHeader())
        assertEquals(1L,focus.requests.value)
        focus.beforeSettings();focus.requestHome()
        assertEquals(HomeReturnAnchor.HOME,focus.takeHeader());assertEquals(2L,focus.requests.value)
    }
}
