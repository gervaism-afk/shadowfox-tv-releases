package nl.vanvrouwerff.iptv.updates

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import kotlinx.coroutines.launch
import nl.vanvrouwerff.iptv.IptvApp
import java.io.File

@Composable
fun UpdatePanel() {
    val context = LocalContext.current
    val manager = IptvApp.get().updates
    val state by manager.state.collectAsState()
    val scope = rememberCoroutineScope()
    val handler = remember { Handler(Looper.getMainLooper()) }
    fun canInstall() = Build.VERSION.SDK_INT < 26 || context.packageManager.canRequestPackageInstalls()
    fun install(file: File) {
        handler.post {
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.updatefiles", file)
                context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    clipData = ClipData.newRawUri("Verified update", uri)
                })
            } catch (_: Exception) { manager.reportInstallError() }
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (canInstall()) manager.state.value.readyFile?.let(::install)
    }
    fun requestInstall(file: File) {
        if (canInstall()) install(file)
        else handler.post {
            try { permission.launch(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}"))) } catch (_: Exception) { manager.reportInstallError() }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("App updates")
        Text(when {
            state.checking -> "Checking for updates…"
            state.downloading -> "Downloading update · ${state.percent}%"
            state.readyFile != null -> "Update verified and ready to install"
            state.release != null -> "Version ${state.release?.versionName} is available"
            state.checked -> "Your app is up to date"
            else -> "Check for a newer version"
        })
        state.release?.notes?.takeIf { it.isNotBlank() }?.let { Text(it.take(2000)) }
        state.error?.let { Text(it) }
        Button(onClick = { scope.launch { manager.check() } }, enabled = !state.checking && !state.downloading) { Text("Check for updates") }
        if (state.release != null) {
            Button(onClick = { val ready = state.readyFile
                if (ready != null) requestInstall(ready)
                else scope.launch { manager.download()?.let(::requestInstall) }
            }, enabled = !state.checking && !state.downloading) {
                Text(if (state.readyFile == null) "Download & install" else "Install update")
            }
        }
        Text("Android confirms installation. Your account and progress are retained.")
    }
}
