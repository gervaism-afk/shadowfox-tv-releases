package nl.vanvrouwerff.iptv.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.data.settings.SourceTestResult
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date

internal data class ConnectionDraft(val type: SourceType, val address: String, val username: String, val password: String)
internal fun SettingsUiState.connectionDraft() = ConnectionDraft(type,
    if (type == SourceType.M3u) m3uUrl else host, if (type == SourceType.M3u) "" else username,
    if (type == SourceType.M3u) "" else password)

/** An in-flight response belongs to the details that were actually tested. */
internal fun completeConnectionTest(state: SettingsUiState, tested: ConnectionDraft, result: SourceTestResult) =
    state.copy(testing = false, testResult = result.takeIf { state.connectionDraft() == tested })

internal data class SettingsStatusMessage(val title: String, val detail: String, val successful: Boolean = false)

internal fun connectionStatus(state: SettingsUiState): SettingsStatusMessage = when {
    state.testing -> SettingsStatusMessage("Checking connection…", "Checking account access and library availability. Your details are not saved by this check.")
    state.testResult is SourceTestResult.Ok -> {
        val result = state.testResult
        val count = NumberFormat.getIntegerInstance()
        SettingsStatusMessage("Connection verified", "${count.format(result.movies)} movies · ${count.format(result.series)} series available. Choose Save to keep any account changes.", true)
    }
    state.testResult is SourceTestResult.Failed -> SettingsStatusMessage("Connection needs attention", when (state.testResult.reason) {
        SourceTestResult.Reason.BadLogin -> "Check your username and password, then test again."
        SourceTestResult.Reason.Timeout -> "The server took too long to respond. Check your connection and try again."
        SourceTestResult.Reason.HostUnreachable -> "The server could not be reached. Check the server address and your connection."
        SourceTestResult.Reason.NotAPlaylist -> "The address did not return a usable library. Check your account details."
        else -> "The connection check could not finish. Check your account details and try again."
    })
    else -> SettingsStatusMessage("Connection not checked", "Use Test connection to verify the details below. Checking does not save your changes.")
}

internal fun refreshStatus(refreshing: Boolean, error: String?, lastSuccess: Long?): SettingsStatusMessage {
    val last = when {
        lastSuccess == null -> "Previous refresh history is loading."
        lastSuccess > 0 -> "Last successful refresh: ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(lastSuccess))}."
        else -> "No successful refresh has been recorded yet."
    }
    return when {
        refreshing -> SettingsStatusMessage("Refreshing your library…", "Your current library stays available while the refresh runs. $last")
        error != null -> SettingsStatusMessage("Refresh needs attention", "Check your connection and account details, then try Refresh now again. $last")
        lastSuccess == null -> SettingsStatusMessage("Loading refresh history…", last)
        lastSuccess > 0 -> SettingsStatusMessage("Library refreshed", last, true)
        else -> SettingsStatusMessage("Ready to refresh", last)
    }
}

@Composable
internal fun SettingsStatus(message: SettingsStatusMessage) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(message.title, color = if (message.successful) Cinema.Accent else Cinema.Text,
            fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(message.detail, color = Cinema.Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
