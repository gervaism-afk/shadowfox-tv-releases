package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import nl.vanvrouwerff.iptv.data.settings.AppearanceTheme
import nl.vanvrouwerff.iptv.data.settings.SourceTestResult
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28], application=Application::class, qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SettingsExperienceTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    private fun screenshot(name:String) {
        val dir=File(requireNotNull(System.getProperty("shadowfox.preview.path"))).parentFile!!;dir.mkdirs()
        compose.runOnUiThread {
            val v=compose.activity.window.decorView
            val bitmap=Bitmap.createBitmap(v.width,v.height,Bitmap.Config.ARGB_8888)
            v.draw(Canvas(bitmap));dir.resolve(name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) };bitmap.recycle()
        }
    }

    @Test fun connectionResponseCannotVerifyEditedCredentials() {
        val original=SettingsUiState(host="https://fixture.invalid",username="user",password="secret",testing=true)
        val checked=original.connectionDraft();val success=SourceTestResult.Ok(0,120,30)
        listOf(original.copy(host="https://other.invalid"),original.copy(username="new"),original.copy(password="changed"),
            original.copy(type=SourceType.M3u,m3uUrl="https://fixture.invalid/list.m3u")).forEach { changed ->
            val finished=completeConnectionTest(changed,checked,success)
            assertFalse(finished.testing);assertNull(finished.testResult);assertFalse(connectionStatus(finished).successful)
        }
        assertEquals(success,completeConnectionTest(original,checked,success).testResult)
    }

    @Test fun uncheckedAndFailedConnectionsNeverLookVerifiedOrExposeTransportDetails() {
        assertFalse(connectionStatus(SettingsUiState()).successful)
        val failure=connectionStatus(SettingsUiState(testResult=SourceTestResult.Failed(SourceTestResult.Reason.Other,
            "https://fixture.invalid?password=private")))
        assertFalse(failure.successful);assertFalse(failure.detail.contains("private"));assertFalse(failure.detail.contains("https://"))
        val busy=connectionStatus(SettingsUiState(testing=true,testResult=SourceTestResult.Ok(0,10,2)))
        assertFalse(busy.successful)
    }

    @Test fun refreshErrorAndBusyStatesKeepTheActualLastSuccessWithoutClaimingNewSuccess() {
        val last=1_700_000_000_000L
        val previous=refreshStatus(false,null,last)
        val failed=refreshStatus(false,"INTERNAL_ERROR",last)
        val busy=refreshStatus(true,"old error",last)
        assertTrue(previous.successful);assertFalse(failed.successful);assertFalse(busy.successful)
        assertTrue(failed.detail.contains(previous.detail));assertTrue(busy.detail.contains(previous.detail))
        assertFalse(failed.detail.contains("INTERNAL_ERROR"));assertFalse(refreshStatus(false,null,0).successful)
        val loading=refreshStatus(false,null,null)
        assertFalse(loading.successful);assertFalse(loading.detail.contains("No successful refresh"))
    }

    @Test fun previewIsReadOnlyAndRemoteChoosesOnlyTheIntendedTheme() {
        var theme by mutableStateOf(AppearanceTheme.CINEMA);var changes=0
        compose.setContent { IptvTheme {
            SettingsPage({},SettingsCategory.Appearance,navigation={SettingsCategories(SettingsCategory.Appearance){}}) {
                SettingsSection("Appearance") { AppearanceSettings(theme){theme=it;changes++} }
            }
        } }
        compose.onNodeWithContentDescription("Cinema Home preview").assertExists()
        compose.onNodeWithContentDescription("ShadowFox Exclusive Home preview").assertExists()
        compose.onNodeWithText("Cinema").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Cinema").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("ShadowFox Exclusive").assertIsFocused()
        assertEquals(0,changes)
        compose.onNodeWithText("ShadowFox Exclusive").performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onNodeWithText("ShadowFox Exclusive").assertIsSelected().assertIsFocused()
        assertEquals(1,changes);screenshot("settings-home-previews-tv.png")
    }

    @Test fun busyConnectionFeedbackTakesFocusAndKeepsTheResultVisible() {
        var checking by mutableStateOf(false)
        var result by mutableStateOf<SourceTestResult?>(null)
        compose.setContent { IptvTheme {
            SettingsPage({},SettingsCategory.Account,navigation={SettingsCategories(SettingsCategory.Account){}}) {
                SettingsSection("Your account") {
                    repeat(4) { SettingsAccountField("Field $it","fixture",{},navigationOrder=it*10) }
                    SettingsActionButton("Test connection",{checking=true},!checking,"test",60)
                    if(checking || result!=null) SettingsInformation("test-result",65) {
                        SettingsStatus(connectionStatus(SettingsUiState(testing=checking,testResult=result)))
                    }
                    SettingsActionButton("Return",{},navigationKey="return",navigationOrder=70)
                }
            }
        } }
        compose.onNodeWithText("Test connection").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Test connection").performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onNodeWithTag("settings-information").assertIsFocused()
        compose.onNodeWithText("Checking connection…").assertIsDisplayed()
        compose.runOnIdle { result=SourceTestResult.Ok(0,120,12);checking=false }
        compose.onNodeWithTag("settings-information").assertIsFocused()
        compose.onNodeWithText("Connection verified").assertIsDisplayed()
        screenshot("settings-connection-result-tv.png")
    }

    @Test fun actualPlaybackGroupsAreSkippedByTheRemoteAndEveryControlFits() {
        var changes=0
        compose.setContent { IptvTheme {
            SettingsPage({},SettingsCategory.Playback,navigation={SettingsCategories(SettingsCategory.Playback){}}) {
                SettingsSection("Playback & languages") { PlaybackSettings(SettingsUiState(),{changes++},{changes++},{changes++},{changes++},{changes++},{changes++}) }
            }
        } }
        listOf("Picture","Sound","Subtitles","Trailers").forEach { compose.onNodeWithText(it).assertExists() }
        compose.onNodeWithText("Playback").performKeyInput { pressKey(Key.DirectionRight) }
        listOf("Match frame rate","Default aspect ratio","Hardware audio / video sync","Preferred audio language","Preferred subtitle language","Autoplay trailers").forEachIndexed { index,label ->
            if(index>0)compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
            val row=compose.onNodeWithText(label).assertIsFocused().assertIsDisplayed().fetchSemanticsNode().boundsInRoot
            val viewport=compose.onNodeWithTag("settings-viewport").fetchSemanticsNode().boundsInRoot
            assertTrue(row.top>=viewport.top-1 && row.bottom<=viewport.bottom+1)
        }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Autoplay trailers").assertIsFocused();assertEquals(0,changes)
        screenshot("settings-playback-groups-tv.png")
    }

    @Test @Config(qualifiers="w320dp-h640dp-port-notnight-xhdpi")
    fun phoneCanReachAndSelectTheSecondThemeWithItsPreview() {
        var theme by mutableStateOf(AppearanceTheme.CINEMA)
        compose.setContent { IptvTheme {
            SettingsPage({},SettingsCategory.Appearance) { SettingsSection("Appearance") { AppearanceSettings(theme){theme=it} } }
        } }
        compose.onNodeWithText("ShadowFox Exclusive").performScrollTo().performClick().assertIsSelected()
        assertEquals(AppearanceTheme.SHADOWFOX_EXCLUSIVE,theme);screenshot("settings-home-previews-phone.png")
    }
}
