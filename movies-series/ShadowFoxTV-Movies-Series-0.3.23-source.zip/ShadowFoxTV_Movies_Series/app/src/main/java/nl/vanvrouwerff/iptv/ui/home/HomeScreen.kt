package nl.vanvrouwerff.iptv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.foundation.lazy.list.items
import androidx.tv.foundation.lazy.list.rememberTvLazyListState
import androidx.tv.material3.*
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.launch
import nl.vanvrouwerff.iptv.R
import nl.vanvrouwerff.iptv.data.Channel
import nl.vanvrouwerff.iptv.data.ContentType
import nl.vanvrouwerff.iptv.ui.library.LibraryScreen
import nl.vanvrouwerff.iptv.ui.library.LibraryViewModel
import nl.vanvrouwerff.iptv.ui.input.Surface
import nl.vanvrouwerff.iptv.ui.theme.Cinema
import nl.vanvrouwerff.iptv.ui.theme.CinemaNavigation

private val Night: Color
    @Composable get() = Cinema.Background
private val Secondary: Color
    @Composable get() = Cinema.Muted

@Composable
internal fun ShadowFoxBrowseScreen(onOpenSettings: () -> Unit, onOpenDetail: (Channel) -> Unit, onPlay: (Channel) -> Unit,
    vm: LibraryViewModel = viewModel(), home: HomeViewModel = viewModel()) {
    if (vm.browseSection == HomeSection.HOME) {
        val state by home.state.collectAsState()
        HomeScreen(state, onSection = { section ->
            vm.rememberSearch()
            when (section) {
                HomeSection.MOVIES -> { vm.selectType(ContentType.MOVIE); vm.searchOpen = false }
                HomeSection.SERIES -> { vm.selectType(ContentType.SERIES); vm.searchOpen = false }
                HomeSection.SAVED -> { vm.showSaved(); vm.searchOpen = false }
                HomeSection.SEARCH -> vm.searchOpen = true
                HomeSection.HOME -> Unit
            }
            vm.browseSection = section
        }, onSettings = onOpenSettings,
            onDetail = { channel, rail -> home.beforeDetail(if (rail == "featured") null else "$rail:${channel.id}"); onOpenDetail(channel) }, onPlay = onPlay,
            restoreId = remember { home.takeReturnFocus() }, onRefreshPicks = home::refreshPicks)
    } else {
        BackHandler { vm.rememberSearch(); vm.browseSection = HomeSection.HOME }
        LibraryScreen(onOpenSettings, onOpenDetail, onOpenHome = { vm.rememberSearch(); vm.browseSection = HomeSection.HOME }, vm = vm)
    }
}

@Composable
internal fun HomeScreen(state: HomeState, onSection: (HomeSection) -> Unit, onSettings: () -> Unit,
    onDetail: (Channel, String) -> Unit, onPlay: (Channel) -> Unit, restoreId: String? = null,
    onRefreshPicks: () -> Unit = {}) {
    val featured = state.featured ?: state.movies.firstOrNull()?.channel ?: state.series.firstOrNull()?.channel
    val spotlight = state.spotlight?.takeIf { it.channelId == featured?.id }
    var pendingFocus by remember(restoreId, state.profile) { mutableStateOf(restoreId) }
    val sections = listOf("Continue Watching" to state.continuing, "My List" to state.saved,
        "Movies for your evening" to state.movies, "Series to settle into" to state.series)
        .plus(state.genres.map { it.title to it.items }).filter { it.second.isNotEmpty() }
    val primaryFocus = remember { FocusRequester() }
    val homeFocus = remember { FocusRequester() }
    val scroll = rememberTvLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(pendingFocus, sections) {
        val row = sections.indexOfFirst { (rail, entries) -> entries.any { "$rail:${it.channel.id}" == pendingFocus } }
        if (pendingFocus != null && row >= 0) scroll.scrollToItem(row + 1)
    }
    Column(Modifier.fillMaxSize().background(Night)) {
        CinemaNavigation("Home", selectedFocus = homeFocus, onDown = {
            scope.launch { scroll.scrollToItem(0); withFrameNanos { }; primaryFocus.requestFocus() }
        }) { label ->
            when (label) {
                "Settings" -> onSettings()
                "Movies" -> onSection(HomeSection.MOVIES)
                "Series" -> onSection(HomeSection.SERIES)
                "My List" -> onSection(HomeSection.SAVED)
                "Search" -> onSection(HomeSection.SEARCH)
                else -> onSection(HomeSection.HOME)
            }
        }
        TvLazyColumn(state = scroll, modifier = Modifier.weight(1f).testTag("home-content"),
            verticalArrangement = Arrangement.spacedBy(22.dp), contentPadding = PaddingValues(bottom = 40.dp)) {
            item(key = "featured") {
                FeaturedTitle(featured, spotlight, state.loading, { onDetail(it, "featured") }, onPlay,
                    onBrowse = { onSection(HomeSection.MOVIES) }, onRefreshPicks = onRefreshPicks,
                    primaryFocus = primaryFocus, homeFocus = homeFocus)
                state.error?.let { Text(it, Modifier.padding(horizontal = homeGutter(), vertical = 12.dp), color = Secondary, fontSize = 13.sp) }
            }
            items(sections, key = { it.first }) { (title, entries) ->
                HomeRail(title, entries, title == "Continue Watching", pendingFocus?.takeIf { it.startsWith("$title:") }?.removePrefix("$title:"),
                    onRestored = { pendingFocus = null }, onDetail = { onDetail(it, title) })
            }
            if (!state.loading && sections.isEmpty() && state.error == null) item {
                Text("Open Movies or Series to refresh your library or check your account in Settings.",
                    Modifier.padding(horizontal = homeGutter()), color = Secondary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun homeGutter() = if (LocalConfiguration.current.screenWidthDp < 600) 20.dp else 32.dp

/** Artwork and shelves share a single canvas; portrait fallbacks are never stretched into backdrops. */
@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun FeaturedTitle(channel: Channel?, spotlight: HomeSpotlight?, loading: Boolean, onDetail: (Channel) -> Unit, onPlay: (Channel) -> Unit,
    onBrowse: () -> Unit, onRefreshPicks: () -> Unit, primaryFocus: FocusRequester, homeFocus: FocusRequester) {
    val context = LocalContext.current
    val config = LocalConfiguration.current
    val compact = config.screenWidthDp < 600
    val smallLandscape = config.screenHeightDp < 600
    val extraHeight = ((LocalDensity.current.fontScale - 1f).coerceAtLeast(0f) * 220).dp
    val height = (if (compact) 460.dp else if (smallLandscape) 286.dp else 318.dp) + extraHeight
    val background = Night
    val poster = spotlight?.posterUrl ?: channel?.logoUrl
    val metadata = listOfNotNull(channel?.let { if (it.type == ContentType.MOVIE) "MOVIE" else "SERIES" },
        spotlight?.year ?: channel?.let { homeTitleYear(it.name) }, spotlight?.rating?.let { "★ $it" },
        channel?.let { homeQuality(it.name) }, spotlight?.genre ?: channel?.groupTitle).joinToString("   ·   ")
    Box(Modifier.fillMaxWidth().height(height).background(Cinema.Atmosphere).testTag("home-featured")) {
        if (spotlight?.backdropUrl != null) AsyncImage(
            model = remember(spotlight.backdropUrl) { ImageRequest.Builder(context).data(spotlight.backdropUrl).size(1920, 1080).crossfade(false).build() },
            contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth(if (compact) 1f else 0.8f).height(if (compact) 260.dp else height)
                .align(Alignment.TopEnd).testTag("home-backdrop"))
        else if (poster != null) AsyncImage(
            model = remember(poster) { ImageRequest.Builder(context).data(poster).size(480, 720).crossfade(false).build() },
            contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.align(Alignment.TopEnd).fillMaxWidth(if (compact) 0.65f else 0.43f)
                .height(if (compact) 270.dp else height).testTag("home-poster-fallback"))
        else Image(painterResource(R.drawable.shadowfox_brand_original), null,
            Modifier.align(Alignment.CenterEnd).padding(end = homeGutter()).size(if (compact) 140.dp else 180.dp), contentScale = ContentScale.Inside)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(
            0f to background, 0.32f to background.copy(alpha = 0.96f), 0.66f to background.copy(alpha = 0.25f), 1f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0f to background.copy(alpha = 0.15f), 0.45f to Color.Transparent, 1f to background)))
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(if (compact) 1f else 0.68f)
            .padding(horizontal = homeGutter(), vertical = if (compact) 24.dp else 18.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 9.dp else 10.dp)) {
            Text(if (channel == null) "YOUR PRIVATE CINEMA" else "TONIGHT’S SPOTLIGHT", color = Cinema.Accent,
                fontSize = 9.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.SemiBold)
            Text(channel?.let { homeHeroTitle(it.name) } ?: if (loading) "Something great awaits." else "Your front row.\nEvery night.",
                color = Cinema.Text, modifier = Modifier.fillMaxWidth().testTag("home-spotlight-title"),
                fontWeight = FontWeight.Bold, fontSize = if (compact) 30.sp else if (smallLandscape) 32.sp else 38.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, letterSpacing = (-0.9).sp,
                lineHeight = if (compact) 34.sp else if (smallLandscape) 36.sp else 42.sp)
            Text(metadata.ifBlank { "Your collection. Beautifully brought together." }, Modifier.testTag("home-spotlight-meta"),
                color = Secondary, fontSize = 11.sp, lineHeight = 15.sp,
                maxLines = if (compact) 2 else 1, overflow = TextOverflow.Ellipsis)
            Text(spotlight?.synopsis ?: if (channel == null) "Discover a new favourite, or pick up right where you left off."
                else if (channel.type == ContentType.SERIES) "Explore the seasons. Find your next great story." else "Settle in for something worth watching.",
                Modifier.testTag("home-spotlight-synopsis"), color = Secondary, fontSize = 13.sp, lineHeight = 19.sp,
                maxLines = if (compact) 3 else 2, overflow = TextOverflow.Ellipsis)
            FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction(modifier = Modifier.heightIn(min = 48.dp).focusRequester(primaryFocus).focusProperties { up = homeFocus },
                    onClick = { if (channel == null) onBrowse() else if (channel.type == ContentType.MOVIE) onPlay(channel) else onDetail(channel) }, bright = true) {
                    Text(if (channel == null) "Explore movies" else if (channel.type == ContentType.MOVIE) "▶  Play" else "View episodes",
                        Modifier.padding(horizontal = 22.dp, vertical = 11.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF10141B))
                }
                if (channel != null) HomeAction(modifier = Modifier.heightIn(min = 48.dp), onClick = { onDetail(channel) }) {
                    Text("Details", Modifier.padding(horizontal = 22.dp, vertical = 11.dp), fontSize = 13.sp, color = Cinema.Text)
                }
                if (channel != null) HomeAction(modifier = Modifier.heightIn(min = 48.dp), onClick = onRefreshPicks, quiet = true) {
                    Text("↻  New picks", Modifier.padding(horizontal = 16.dp, vertical = 11.dp), fontSize = 12.sp, color = Cinema.Text)
                }
            }
        }
    }
}

@Composable
private fun HomeRail(title: String, entries: List<HomeItem>, wide: Boolean, restoreId: String?, onRestored: () -> Unit, onDetail: (Channel) -> Unit) {
    val row = rememberTvLazyListState()
    LaunchedEffect(restoreId, entries) {
        val index = entries.indexOfFirst { it.channel.id == restoreId }
        if (index >= 0) row.scrollToItem(index)
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, Modifier.padding(horizontal = homeGutter()).testTag("home-rail:$title"),
            color = Cinema.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp)
        TvLazyRow(state = row, contentPadding = PaddingValues(horizontal = homeGutter(), vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(entries, key = { it.channel.id }) { entry ->
                HomePoster(entry, wide, restoreId == entry.channel.id, onRestored) { onDetail(entry.channel) }
            }
        }
    }
}

@Composable
private fun HomePoster(entry: HomeItem, wide: Boolean, restore: Boolean, onRestored: () -> Unit, onClick: () -> Unit) {
    val requester = remember(entry.channel.id) { FocusRequester() }
    LaunchedEffect(restore) { if (restore) { withFrameNanos { }; try { requester.requestFocus(); onRestored() } catch (_: IllegalStateException) { } } }
    val width = if (wide) (LocalConfiguration.current.screenWidthDp - 40).coerceIn(200, 286).dp else 144.dp
    Column(Modifier.width(width), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HomeAction(onClick, Modifier.fillMaxWidth().focusRequester(requester).testTag("home-card:${entry.channel.id}")) {
            if (wide) ContinueCard(entry)
            else Box(Modifier.fillMaxWidth().aspectRatio(2f / 3).background(Cinema.Atmosphere), contentAlignment = Alignment.Center) {
                HomeArtwork(entry, Modifier.fillMaxSize())
            }
        }
        if (!wide) Text(homeCollectionTitle(entry.channel.name), color = Cinema.Text, fontSize = 12.sp,
            fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** A complete portrait plus readable progress, rather than cropping a portrait into a landscape. */
@Composable
private fun ContinueCard(entry: HomeItem) {
    val height = 112.dp + ((LocalDensity.current.fontScale - 1f).coerceAtLeast(0f) * 72).dp
    Row(Modifier.fillMaxWidth().height(height).background(Cinema.Surface).testTag("home-continue:${entry.channel.id}")) {
        Box(Modifier.width(height * (2f / 3)).fillMaxHeight().background(Cinema.Atmosphere), contentAlignment = Alignment.Center) {
            HomeArtwork(entry, Modifier.fillMaxSize())
        }
        Column(Modifier.weight(1f).fillMaxHeight().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(homeCollectionTitle(entry.channel.name), color = Cinema.Text, fontSize = 13.sp, lineHeight = 17.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(entry.caption ?: "Continue watching", color = Secondary, fontSize = 10.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Icon(Icons.Filled.PlayArrow, null, Modifier.size(16.dp), tint = Cinema.Accent)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("${(entry.progress.coerceIn(0f, 1f) * 100).toInt()}% watched", color = Secondary, fontSize = 9.sp)
                    Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)).background(Cinema.Line)) {
                        if (entry.progress > 0f) Box(Modifier.fillMaxHeight().fillMaxWidth(entry.progress.coerceIn(0f, 1f)).background(Cinema.Accent))
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeArtwork(entry: HomeItem, modifier: Modifier) {
    val context = LocalContext.current
    Box(modifier, contentAlignment = Alignment.Center) {
        Icon(if (entry.channel.type == ContentType.MOVIE) Icons.Outlined.Movie else Icons.Outlined.Tv,
            null, Modifier.size(30.dp), tint = Cinema.Accent.copy(alpha = 0.65f))
        if (entry.channel.logoUrl != null) AsyncImage(
            model = remember(entry.channel.logoUrl) { ImageRequest.Builder(context).data(entry.channel.logoUrl)
                .size(432, 648).crossfade(false).build() },
            contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun HomeAction(onClick: () -> Unit, modifier: Modifier = Modifier, bright: Boolean = false, quiet: Boolean = false,
    content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Surface(onClick = onClick, modifier = modifier.onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(2.dp, Cinema.FocusRing, shape) else Modifier),
        shape = ClickableSurfaceDefaults.shape(shape), scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
        colors = ClickableSurfaceDefaults.colors(containerColor = if (bright) Color(0xFFF5F7FA) else if (quiet) Color.Transparent else Cinema.Surface,
            contentColor = if (bright) Color(0xFF10141B) else Cinema.Text,
            focusedContainerColor = if (bright) Color.White else Cinema.Raised,
            focusedContentColor = if (bright) Color(0xFF10141B) else Cinema.Text), content = content)
}
