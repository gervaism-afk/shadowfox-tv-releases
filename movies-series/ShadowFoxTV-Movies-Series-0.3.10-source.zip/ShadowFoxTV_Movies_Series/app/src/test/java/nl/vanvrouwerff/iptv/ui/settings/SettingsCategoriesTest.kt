package nl.vanvrouwerff.iptv.ui.settings

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.tv.material3.Text
import nl.vanvrouwerff.iptv.ui.theme.IptvTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class, qualifiers = "w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@OptIn(ExperimentalTestApi::class)
class SettingsCategoriesTest {
    @get:Rule val compose = createComposeRule()

    @Test fun remoteSelectsPlaybackAndMovesIntoItsControlsWithoutOpeningKeyboard() {
        var selected by mutableStateOf(SettingsCategory.Account)
        compose.setContent { IptvTheme {
            SettingsPage(onBack = {}, pageKey = selected, navigation = {
                SettingsCategories(selected) { selected = it }
            }) {
                if (selected == SettingsCategory.Account) SettingsAccountField("Server", "fixture", {})
                else SwitchRow("Autoplay trailers", "Play trailers automatically", true, {})
            }
        } }
        compose.onNodeWithText("Playback").performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNodeWithText("Playback").performKeyInput { pressKey(Key.DirectionCenter) }
        compose.onNodeWithText("Playback").assertIsSelected()
        compose.onNodeWithText("Server").assertDoesNotExist()
        compose.onNodeWithText("Playback").performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithText("Autoplay trailers").assertIsFocused()
        compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port-notnight-xhdpi")
    fun narrowPhoneFitsCategoriesAndAccountFieldsAndKeepsDraftWhenChangingSection() {
        var selected by mutableStateOf(SettingsCategory.Account)
        var draft by mutableStateOf("fixture")
        compose.setContent { IptvTheme {
            SettingsPage(onBack = {}, pageKey = selected, navigation = {
                SettingsCategories(selected) { selected = it }
            }) {
                if (selected == SettingsCategory.Account) SettingsAccountField("Username", draft, { draft = it })
                else Text("Playback settings")
            }
        } }
        SettingsCategory.entries.forEach { compose.onNodeWithText(it.label).assertIsDisplayed() }
        val field = compose.onNode(hasSetTextAction()).fetchSemanticsNode().boundsInRoot
        val viewport = compose.onRoot().fetchSemanticsNode().boundsInRoot
        assertTrue(field.left >= viewport.left && field.right <= viewport.right)
        compose.onNode(hasSetTextAction()).performTextReplacement("unsaved-draft")
        compose.onNodeWithText("Playback").performClick()
        compose.onNodeWithText("Playback settings").assertIsDisplayed()
        compose.onNodeWithText("Account").performClick()
        compose.onNodeWithText("unsaved-draft").assertIsDisplayed()
    }
}
