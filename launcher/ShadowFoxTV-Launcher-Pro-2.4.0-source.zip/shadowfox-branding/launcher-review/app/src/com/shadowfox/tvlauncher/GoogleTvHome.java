package com.shadowfox.tvlauncher;

import android.content.*;
import android.os.Build;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.function.Consumer;

/** Static-wallpaper TV home with app rows and a category library. */
final class GoogleTvHome extends LinearLayout {
    static final class App {
        final String id,name,category;final Drawable icon,banner;final boolean customArtwork;HomeIconView.Artwork artwork;
        App(String id,String name,String category,Drawable icon,Drawable banner,boolean customArtwork){this.id=id;this.name=name;this.category=category;this.icon=icon;this.banner=banner;this.customArtwork=customArtwork;}
    }
    static final class Group {
        final String id,name;Group(String id,String name){this.id=id;this.name=name;}
    }
    interface Actions {
        void launch(String id);void menu(String id);void selected(String id);
        void choose(String category);
    }
    private final MainActivity host;
    private final SharedPreferences prefs;
    private final View header;
    private final Actions actions;
    private final TextView homeTab,appsTab;
    private final WeatherPill weather;
    private final ArrayList<View> nav=new ArrayList<>();
    private final ScrollView scroll;
    private final LinearLayout body;
    private final LinkedHashMap<String,App> apps=new LinkedHashMap<>();
    private final ArrayList<Group> groups=new ArrayList<>();
    private final LinkedHashMap<String,View> focusViews=new LinkedHashMap<>();
    private final ArrayList<ArrayList<View>> rows=new ArrayList<>();
    private boolean rendering;
    private final ArrayList<HorizontalScrollView> rails=new ArrayList<>();
    private boolean library,closed;
    private String category="",focusedKey;
    private View landingGap,landingBreak,primaryHeading,primaryRail;
    private int landingRestoreY=-1;
    private final ViewTreeObserver.OnGlobalLayoutListener landingLayout=this::layoutLandingPage;
    private static final int TEXT=0xfff1f3f8,MUTED=0xffb0b7ca;

    GoogleTvHome(MainActivity host,SharedPreferences prefs,View header,Actions actions){
        super(host);this.host=host;this.prefs=prefs;this.header=header;this.actions=actions;
        setOrientation(VERTICAL);setClipChildren(false);setClipToPadding(false);
        LinearLayout navigation=new LinearLayout(host);navigation.setGravity(Gravity.CENTER_VERTICAL);navigation.setPadding(dp(40),dp(3),dp(40),dp(3));navigation.setClipChildren(false);addView(navigation,new LayoutParams(-1,dp(56)));
        LinearLayout tabs=new LinearLayout(host);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(shape(0x503c435c,40,0));
        homeTab=tab("Home",()->switchPage(false,true));appsTab=tab("Apps",()->switchPage(true,true));
        decorateTab(homeTab,true);decorateTab(appsTab,false);tabs.addView(homeTab,new LayoutParams(dp(124),dp(42)));tabs.addView(appsTab,new LayoutParams(dp(124),dp(42)));navigation.addView(tabs);
        nav.add(homeTab);nav.add(appsTab);
        navigation.addView(new View(host),new LayoutParams(0,1,1));
        weather=new WeatherPill(host,host.localWeather(),()->{focusedKey=null;actions.selected(null);scrollToTop();header.setNextFocusDownId(weatherId());});
        int weatherWidth=Math.min(dp(284),getResources().getDisplayMetrics().widthPixels-dp(80+256+20));
        navigation.addView(weather,new LayoutParams(Math.max(dp(210),weatherWidth),dp(50)));nav.add(weather);
        for(int i=0;i<nav.size();i++){View v=nav.get(i);v.setNextFocusUpId(header.getId());v.setNextFocusLeftId(nav.get(Math.max(0,i-1)).getId());v.setNextFocusRightId(nav.get(Math.min(nav.size()-1,i+1)).getId());}
        scroll=new ScrollView(host);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);scroll.setOverScrollMode(OVER_SCROLL_NEVER);
        body=new LinearLayout(host);body.setOrientation(VERTICAL);body.setPadding(dp(40),0,dp(40),dp(24));body.setClipChildren(false);body.setClipToPadding(false);scroll.addView(body);addView(scroll,new LayoutParams(-1,0,1));paintTabs();
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void scrollToTop(){scroll.smoothScrollTo(0,0);}
    private int weatherId(){return weather.getId();}
    private TextView label(String title,int size,int colour,boolean bold){TextView v=StudioStyle.label(host,title,size,colour,bold);v.setShadowLayer(dp(2),0,dp(1),0x80000000);return v;}
    private GradientDrawable shape(int fill,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private TextView tab(String title,Runnable action){
        TextView v=label(title,15,TEXT,true);v.setGravity(Gravity.CENTER);v.setShadowLayer(0,0,0,0);focusable(v);
        v.setOnClickListener(w->action.run());v.setOnFocusChangeListener((w,focused)->{if(focused&&!rendering){focusedKey=null;actions.selected(null);scroll.smoothScrollTo(0,0);header.setNextFocusDownId(w.getId());}paintTabs();});return v;
    }
    private void decorateTab(TextView view,boolean home){LandingTabIcon icon=new LandingTabIcon(home);icon.setBounds(0,0,dp(20),dp(20));view.setCompoundDrawables(icon,null,null,null);view.setCompoundDrawablePadding(dp(9));view.setPadding(dp(16),0,dp(16),0);view.setSingleLine(true);view.setContentDescription(home?"Home":"Apps");}
    private void focusable(View v){v.setId(View.generateViewId());v.setFocusable(true);v.setFocusableInTouchMode(true);if(Build.VERSION.SDK_INT>=26)v.setDefaultFocusHighlightEnabled(false);}
    private void paintTabs(){
        for(View item:Arrays.asList(homeTab,appsTab)){boolean active=item==(library?appsTab:homeTab),focus=item.hasFocus();item.setBackground(shape(focus?0xffe5e8f6:active?0x90606a85:0x00232b43,30,0));TextView text=(TextView)item;text.setTextColor(focus?0xff172137:TEXT);Drawable icon=text.getCompoundDrawables()[0];if(icon instanceof LandingTabIcon)((LandingTabIcon)icon).colour(focus?0xff173d5d:active?StudioStyle.BLUE:TEXT);}
    }
    void bind(List<App> items,List<Group> categories){
        apps.clear();for(App app:items)apps.put(app.id,app);groups.clear();groups.addAll(categories);
        if(!category.isEmpty()&&groups.stream().noneMatch(g->g.id.equals(category)))category="";
        render(true);
    }
    private void switchPage(boolean value,boolean focusTab){
        boolean changed=library!=value;library=value;focusedKey=null;landingRestoreY=-1;actions.selected(null);if(changed||body.getChildCount()==0)render(false);scroll.scrollTo(0,0);if(!library)for(HorizontalScrollView rail:rails)rail.scrollTo(0,0);paintTabs();
        if(focusTab)(library?appsTab:homeTab).requestFocusFromTouch();
    }
    void home(){switchPage(false,true);}
    void focusNavigation(){(library?appsTab:homeTab).requestFocusFromTouch();}
    void restoreApp(String id){View remembered=focusViews.get(focusedKey);if(remembered!=null)remembered.requestFocusFromTouch();else focusApp(id);}
    String bookmark(){return focusedKey;}
    void restoreApp(String id,String bookmark){View remembered=focusViews.get(bookmark);if(remembered!=null)remembered.requestFocusFromTouch();else focusApp(id);}
    void focusApp(String id){App app=apps.get(id);if(app==null){focusNavigation();return;}library=true;category=app.category;render(false);paintTabs();View v=focusViews.get("app:"+id);if(v!=null)v.post(()->v.requestFocusFromTouch());}
    boolean back(){home();return true;}
    private void render(boolean restore){
        String remembered=restore?focusedKey:null;int oldScroll=restore?scroll.getScrollY():0;
        rendering=true;
        try{
            landingGap=null;landingBreak=null;primaryHeading=null;primaryRail=null;landingRestoreY=restore?oldScroll:0;body.removeAllViews();focusViews.clear();rows.clear();rails.clear();
            setBackground(library?new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xc00b1020,0xa00b1020,0x600b1020}):null);
            if(library)renderLibrary();else renderHome();linkRows();host.bindSettingsSounds(this);
            if(restore){
                View target=focusViews.get(remembered);if(target!=null)target.requestFocus();
                else if(remembered!=null){focusedKey=null;actions.selected(null);focusNavigation();}
                if(library)scroll.post(()->scroll.scrollTo(0,oldScroll));else if(remembered!=null&&target==null)landingRestoreY=0;
            }
        }finally{rendering=false;}
    }
    private void heading(String title,String detail){
        LinearLayout line=new LinearLayout(host);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(4),dp(8),dp(4),dp(8));
        TextView name=label(title,16,title.equals("Recently opened")?StudioStyle.AMBER:0xffbaddf5,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);line.addView(name,new LayoutParams(0,-2,1));
        if(detail!=null&&!detail.isEmpty()){TextView note=label(detail,10,MUTED,false);line.addView(note);}body.addView(line,new LayoutParams(-1,-2));
    }
    private LinearLayout rail(ArrayList<View> nodes){
        HorizontalScrollView rail=new HorizontalScrollView(host);rail.setFocusable(false);rail.setHorizontalScrollBarEnabled(false);rail.setClipToPadding(false);rail.setOverScrollMode(OVER_SCROLL_NEVER);rail.setPadding(dp(6),dp(8),dp(6),dp(9));rails.add(rail);
        LinearLayout line=new LinearLayout(host);line.setGravity(Gravity.CENTER_VERTICAL);line.setClipChildren(false);line.setClipToPadding(false);rail.addView(line);body.addView(rail,new LayoutParams(-1,-2));rows.add(nodes);return line;
    }
    private void renderHome(){
        if(apps.isEmpty()){empty("Choose apps for Home",()->actions.choose("apps"));return;}
        landingGap=new View(host);body.addView(landingGap,new LayoutParams(-1,0));
        appRow();landingBreak=new View(host);body.addView(landingBreak,new LayoutParams(-1,0));
        recentRow();
    }
    private void recentRow(){
        ArrayList<App> recent=new ArrayList<>();try{org.json.JSONArray saved=new org.json.JSONArray(prefs.getString("recent_apps","[]"));for(int i=0;i<saved.length();i++){App app=apps.get(saved.getString(i));if(app!=null&&!recent.contains(app))recent.add(app);}}catch(org.json.JSONException ignored){}
        if(recent.isEmpty())return;heading("Recently opened",null);ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);for(App app:recent)addCircle(line,row,app,"recent:");
    }
    private void appRow(){int index=body.getChildCount();heading("Your apps",null);primaryHeading=body.getChildAt(index);ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);primaryRail=(View)line.getParent();for(App app:apps.values())addCircle(line,row,app,"home:");}
    private void height(View view,int value){android.view.ViewGroup.LayoutParams size=view.getLayoutParams();if(size.height!=value){size.height=value;view.setLayoutParams(size);}}
    private void layoutLandingPage(){
        if(closed||library||landingGap==null||landingBreak==null||primaryHeading==null||primaryRail==null)return;
        int viewport=scroll.getHeight(),appsHeight=primaryHeading.getMeasuredHeight()+primaryRail.getMeasuredHeight();if(viewport<=0||appsHeight<=0)return;
        int gap=Math.max(dp(8),viewport-appsHeight-dp(24)),end=gap+appsHeight;
        int boundary=Math.max(dp(24),viewport+dp(18)-end);height(landingGap,gap);height(landingBreak,boundary);
        if(landingRestoreY>=0&&landingGap.getMeasuredHeight()==gap&&landingBreak.getMeasuredHeight()==boundary){int y=landingRestoreY;landingRestoreY=-1;scroll.scrollTo(0,y);}
    }
    private String groupName(String id){for(Group group:groups)if(group.id.equals(id))return group.name;return "Your apps";}
    private void renderLibrary(){
        ArrayList<App> visible=new ArrayList<>();for(App app:apps.values())if(category.isEmpty()||category.equals(app.category))visible.add(app);
        heading(category.isEmpty()?"Your apps":groupName(category),visible.size()+ (visible.size()==1?" app":" apps"));ArrayList<View> filters=new ArrayList<>();LinearLayout line=rail(filters);
        filter(line,filters,"All apps","",category.isEmpty());for(Group g:groups)filter(line,filters,g.name,g.id,g.id.equals(category));
        int available=getResources().getDisplayMetrics().widthPixels-body.getPaddingLeft()-body.getPaddingRight()-dp(8);int density=prefs.getInt("app_density",0);int columns=density>=1&&density<=4?density+3:Math.max(4,Math.min(9,available/dp(130)));columns=Math.min(columns,Math.max(3,available/dp(112)));
        LinearLayout gridRow=null;ArrayList<View> nodes=null;
        for(int i=0;i<visible.size();i++){
            if(i%columns==0){gridRow=new LinearLayout(host);gridRow.setClipChildren(false);gridRow.setClipToPadding(false);body.addView(gridRow,new LayoutParams(-1,-2));nodes=new ArrayList<>();rows.add(nodes);}
            View v=circle(visible.get(i),"app:");LayoutParams size=new LayoutParams(available/columns,-2);size.bottomMargin=dp(16);gridRow.addView(v,size);nodes.add(v);
        }
        if(visible.isEmpty())empty("Choose apps for this category",()->actions.choose(category.isEmpty()?"apps":category));
    }
    private void filter(LinearLayout line,ArrayList<View> row,String title,String id,boolean selected){
        TextView chip=label(title,13,TEXT,selected);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(20),dp(11),dp(20),dp(11));focusable(chip);String key="category:"+id;focusViews.put(key,chip);
        chip.setBackground(shape(selected?0x80596381:0x40303950,24,0));
        chip.setOnFocusChangeListener((v,focus)->{chip.setBackground(shape(focus?0xffe5e8f6:selected?0x80596381:0x40303950,24,0));chip.setTextColor(focus?0xff172137:TEXT);if(focus){focusedKey=key;actions.selected(null);}});
        chip.setOnClickListener(v->{category=id;render(false);View next=focusViews.get(key);if(next!=null)next.requestFocusFromTouch();});LayoutParams size=new LayoutParams(-2,dp(42));size.rightMargin=dp(10);line.addView(chip,size);row.add(chip);
    }
    private void empty(String title,Runnable action){TextView v=label(title,16,TEXT,true);v.setPadding(dp(24),dp(20),dp(24),dp(20));focusable(v);v.setBackground(shape(0x70464b65,18,0));v.setOnFocusChangeListener((w,f)->v.setBackground(shape(f?0xb05a6685:0x70464b65,18,f?TEXT:0)));v.setOnClickListener(w->action.run());body.addView(v,new LayoutParams(-1,-2));ArrayList<View> row=new ArrayList<>();row.add(v);rows.add(row);}
    private void addCircle(LinearLayout line,ArrayList<View> row,App app,String prefix){View v=circle(app,prefix);LayoutParams size=new LayoutParams(dp(126),-2);size.rightMargin=dp(12);line.addView(v,size);row.add(v);}
    private View circle(App app,String prefix){
        LinearLayout tile=new LinearLayout(host);tile.setOrientation(VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(4),dp(5),dp(4));
        int[] sizes={72,88,102};int size=sizes[Math.max(0,Math.min(2,prefs.getInt("icon_size",1)))];
        if(app.artwork==null)app.artwork=new HomeIconView.Artwork(host,app.icon,app.customArtwork);
        int fill=HomeTransparency.boxes(prefs)?HomeTransparency.fill(prefs,0xff353d58,true):0;
        HomeIconView icon=new HomeIconView(host,app.artwork,fill);tile.addView(icon,new LayoutParams(dp(size),dp(size)));
        TextView name=label(app.name,12,TEXT,false);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setMinLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(0,dp(6),0,0);
        if(prefs.getBoolean("show_app_names",true))tile.addView(name,new LayoutParams(-1,-2));
        bindApp(tile,app,prefix+app.id,focused->{icon.highlight(focused);name.setTextColor(focused?TEXT:MUTED);});return tile;
    }
    private void bindApp(View v,App app,String key,Consumer<Boolean> paint){
        focusable(v);v.setContentDescription(app.name);focusViews.put(key,v);v.setOnClickListener(w->actions.launch(app.id));v.setOnLongClickListener(w->{actions.menu(app.id);return true;});
        v.setOnFocusChangeListener((w,focused)->{paint.accept(focused);if(focused){focusedKey=key;actions.selected(app.id);}});
    }
    private void linkRows(){
        rows.removeIf(row->row.isEmpty());
        for(int r=0;r<rows.size();r++){ArrayList<View> row=rows.get(r);for(int c=0;c<row.size();c++){
            View v=row.get(c);v.setNextFocusLeftId(row.get(Math.max(0,c-1)).getId());v.setNextFocusRightId(row.get(Math.min(row.size()-1,c+1)).getId());
            v.setNextFocusUpId(r==0?(library?appsTab:homeTab).getId():rows.get(r-1).get(Math.min(c,rows.get(r-1).size()-1)).getId());
            v.setNextFocusDownId(r+1<rows.size()?rows.get(r+1).get(Math.min(c,rows.get(r+1).size()-1)).getId():v.getId());
            // Follow the row links even when a large wallpaper gap separates them from the tabs.
            v.setOnKeyListener((view,code,event)->{
                if(code!=KeyEvent.KEYCODE_DPAD_UP&&code!=KeyEvent.KEYCODE_DPAD_DOWN)return false;
                int id=code==KeyEvent.KEYCODE_DPAD_UP?view.getNextFocusUpId():view.getNextFocusDownId();
                View target=getRootView().findViewById(id);if(target==null)return false;
                if(event.getAction()==KeyEvent.ACTION_DOWN&&target!=view)target.requestFocus();return true;
            });
        }}
        // Category chips are filters, rather than columns aligned with the grid.
        if(library&&rows.size()>1){
            View selected=focusViews.get("category:"+category);
            for(View filter:rows.get(0))filter.setNextFocusDownId(rows.get(1).get(0).getId());
            if(selected!=null)for(View app:rows.get(1))app.setNextFocusUpId(selected.getId());
        }
        for(View v:nav)v.setNextFocusDownId(rows.isEmpty()?v.getId():rows.get(0).get(0).getId());
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();scroll.getViewTreeObserver().addOnGlobalLayoutListener(landingLayout);}
    void close(){if(closed)return;closed=true;weather.close();if(scroll.getViewTreeObserver().isAlive())scroll.getViewTreeObserver().removeOnGlobalLayoutListener(landingLayout);}
    @Override protected void onDetachedFromWindow(){close();super.onDetachedFromWindow();}
}
