package com.shadowfox.tvlauncher;

import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;

/** The weather control uses the same rounded material and focus fill as the tabs. */
final class WeatherPill extends LinearLayout {
    private final MainActivity host;private final LocalWeather weather;
    private final TextView city,condition,temperature;private final Symbol icon;
    private final Runnable changed=this::paint;private boolean closed;
    WeatherPill(MainActivity host,LocalWeather weather,Runnable focused){
        super(host);this.host=host;this.weather=weather;setOrientation(HORIZONTAL);setGravity(Gravity.CENTER_VERTICAL);setPadding(dp(16),dp(5),dp(16),dp(5));
        setId(View.generateViewId());setFocusable(true);setFocusableInTouchMode(true);if(Build.VERSION.SDK_INT>=26)setDefaultFocusHighlightEnabled(false);
        icon=new Symbol();LayoutParams art=new LayoutParams(dp(28),dp(28));art.rightMargin=dp(11);addView(icon,art);
        LinearLayout words=new LinearLayout(host);words.setOrientation(VERTICAL);words.setGravity(Gravity.CENTER_VERTICAL);
        city=StudioStyle.label(host,"Local weather",12,0xfff1f3f8,true);city.setSingleLine(true);city.setEllipsize(TextUtils.TruncateAt.END);words.addView(city,new LayoutParams(-1,-2));
        condition=StudioStyle.label(host,"Set location",10,0xffb0b7ca,false);condition.setSingleLine(true);condition.setEllipsize(TextUtils.TruncateAt.END);LayoutParams note=new LayoutParams(-1,-2);note.topMargin=dp(2);words.addView(condition,note);addView(words,new LayoutParams(0,-2,1));
        temperature=StudioStyle.label(host,"—",20,0xfff1f3f8,true);temperature.setSingleLine(true);LayoutParams degrees=new LayoutParams(-2,-2);degrees.leftMargin=dp(12);addView(temperature,degrees);
        setOnFocusChangeListener((v,focus)->{paint();if(focus)focused.run();});setOnClickListener(v->weather.showMenu(()->requestFocusFromTouch()));
        weather.listen(changed);paint();
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void paint(){
        if(closed)return;boolean focus=hasFocus();GradientDrawable surface=new GradientDrawable();surface.setColor(focus?0xffe5e8f6:0x503c435c);surface.setCornerRadius(dp(40));setBackground(surface);
        WeatherForecast value=weather.forecast();city.setText(weather.placeName());condition.setText(weather.status());temperature.setText(value==null?"—":value.temperature(weather.fahrenheit()));
        city.setTextColor(focus?0xff172137:0xfff1f3f8);temperature.setTextColor(focus?0xff172137:0xfff1f3f8);condition.setTextColor(focus?0xff394a60:0xffb0b7ca);
        icon.symbol=value==null?"unknown":value.symbol;icon.focused=focus;icon.invalidate();setContentDescription("Weather: "+weather.placeName()+", "+temperature.getText()+", "+weather.status());
    }
    void close(){closed=true;weather.unlisten(changed);}
    private final class Symbol extends View {
        String symbol="unknown";boolean focused;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Symbol(){super(host);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);int save=c.save();c.translate(getWidth()/2f,getHeight()/2f);c.scale(getWidth()/32f,getHeight()/32f);
            String s=symbol;int blue=focused?0xff236487:StudioStyle.BLUE,cloud=focused?0xff3c526b:0xffe0e8f3;
            if(s.equals("unknown")){p.setColor(blue);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);c.drawCircle(0,0,9,p);c.drawLine(0,-6,0,2,p);c.drawCircle(0,6,.6f,p);}
            else {
                boolean clear=s.contains("clearsky"),fair=s.contains("fair")||s.contains("partlycloudy");
                if(clear||fair){
                    if(s.endsWith("night")){p.setColor(blue);p.setStyle(Paint.Style.FILL);Path moon=new Path();moon.moveTo(1,-11);moon.cubicTo(-13,-13,-14,11,1,11);moon.cubicTo(5,11,8,9,10,5);moon.cubicTo(-1,8,-7,-4,1,-11);c.drawPath(moon,p);}
                    else {p.setColor(focused?0xffa36616:StudioStyle.AMBER);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.6f);float x=fair?-5:0,y=fair?-5:0;c.drawCircle(x,y,5,p);for(int a=0;a<8;a++){double r=a*Math.PI/4;c.drawLine(x+(float)Math.cos(r)*8,y+(float)Math.sin(r)*8,x+(float)Math.cos(r)*11,y+(float)Math.sin(r)*11,p);}}
                }
                if(!clear){p.setColor(cloud);p.setStyle(Paint.Style.FILL);c.drawCircle(-6,0,5,p);c.drawCircle(0,-3,7,p);c.drawCircle(7,1,5,p);c.drawRoundRect(-10,0,12,7,3,3,p);}
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(blue);
                if(s.contains("snow")||s.contains("sleet"))for(int x=-6;x<=7;x+=6){c.drawLine(x,10,x,15,p);c.drawLine(x-2,11,x+2,14,p);c.drawLine(x+2,11,x-2,14,p);}
                else if(s.contains("rain"))for(int x=-6;x<=7;x+=6)c.drawLine(x,10,x-2,15,p);
                if(s.contains("fog")){c.drawLine(-10,11,11,11,p);c.drawLine(-7,15,8,15,p);}
                if(s.contains("thunder")){p.setColor(focused?0xffa36616:StudioStyle.AMBER);Path bolt=new Path();bolt.moveTo(2,7);bolt.lineTo(-2,12);bolt.lineTo(3,12);bolt.lineTo(0,17);c.drawPath(bolt,p);}
            }
            c.restoreToCount(save);
        }
    }
}
