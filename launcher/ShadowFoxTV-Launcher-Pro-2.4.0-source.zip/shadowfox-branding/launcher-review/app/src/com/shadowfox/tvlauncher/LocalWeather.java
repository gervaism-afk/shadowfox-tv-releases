package com.shadowfox.tvlauncher;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPInputStream;

/** Foreground-only, cached weather with an explicit user-selected location. */
final class LocalWeather {
    private static final long HOUR=3600000L,MAX_AGE=24*HOUR,RETRY=15*60000L;
    private static final String AGENT="ShadowFoxTVLauncher/2.4.0 (+https://www.shadowfoxtv.ca)";
    private final MainActivity host;private final SharedPreferences saved;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final HashSet<Runnable> listeners=new HashSet<>();
    private boolean active,busy,geoBusy;private volatile boolean closed;private int forecastTicket,searchTicket,geoTicket;
    private AlertDialog searchLoading;
    private volatile HttpURLConnection connection;private String payload;private String error="";
    private final Runnable tick=()->{changed();detect(false);refresh();schedule();};
    LocalWeather(MainActivity host){this.host=host;saved=host.getSharedPreferences("local_weather",0);payload=saved.getString("forecast","");}
    void listen(Runnable listener){listeners.add(listener);}void unlisten(Runnable listener){listeners.remove(listener);}
    private void changed(){for(Runnable listener:new ArrayList<>(listeners))listener.run();}
    private void schedule(){main.removeCallbacks(tick);if(active&&!closed)main.postDelayed(tick,60000);}
    void start(){active=true;changed();detect(false);refresh();schedule();}
    void networkChanged(){detect(true);}
    void stop(){active=false;main.removeCallbacks(tick);dismissForHome();}
    void dismissForHome(){searchTicket++;if(searchLoading!=null){searchLoading.dismiss();searchLoading=null;}}
    void close(){closed=true;active=false;forecastTicket++;searchTicket++;geoTicket++;main.removeCallbacksAndMessages(null);HttpURLConnection request=connection;if(request!=null)request.disconnect();worker.shutdownNow();listeners.clear();}
    boolean fahrenheit(){return saved.getBoolean("fahrenheit",false);}
    private WeatherForecast.Place place(){
        try{if(!saved.contains("latitude"))return null;double lat=Double.parseDouble(saved.getString("latitude","")),lon=Double.parseDouble(saved.getString("longitude",""));if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return null;return new WeatherForecast.Place(saved.getString("place","Local weather"),saved.getString("region",""),lat,lon);}catch(RuntimeException ignored){return null;}
    }
    private boolean automatic(){return !saved.getBoolean("manual_location",false);}
    String placeName(){WeatherForecast.Place location=place();return location==null?"Local weather":(automatic()?"Near ":"")+location.name;}
    WeatherForecast forecast(){
        if(place()==null||payload.isEmpty()||System.currentTimeMillis()-saved.getLong("fetched",0)>MAX_AGE)return null;
        try{return WeatherForecast.read(payload,System.currentTimeMillis());}catch(JSONException ignored){return null;}
    }
    String status(){
        if(place()==null)return geoBusy?"Finding your area…":automatic()?"Location unavailable":"Set location";WeatherForecast value=forecast();
        if(value==null)return busy?"Updating…":"Weather unavailable";
        return value.condition()+(!error.isEmpty()||saved.getBoolean("geo_failed",false)&&automatic()||System.currentTimeMillis()>saved.getLong("expires",0)?" · Saved":"");
    }
    private void detect(boolean networkChanged){
        long now=System.currentTimeMillis();if(!active||closed||!automatic()||geoBusy||now-saved.getLong("geo_attempt",0)<60000)return;
        if(!networkChanged&&now-saved.getLong("geo_checked",0)<6*HOUR)return;
        if(!networkChanged&&saved.getBoolean("geo_failed",false)&&now-saved.getLong("geo_attempt",0)<RETRY)return;
        geoBusy=true;saved.edit().putLong("geo_attempt",now).apply();changed();final int ticket=++geoTicket;
        worker.execute(()->{try{
            WeatherForecast.Place location=WeatherForecast.ispPlace(get("https://get.geojs.io/v1/ip/geo.json","").body);
            main.post(()->{if(closed||ticket!=geoTicket||!automatic())return;geoBusy=false;saved.edit().putLong("geo_checked",System.currentTimeMillis()).putBoolean("geo_failed",false).apply();applyPlace(location,"");});
        }catch(Exception failure){main.post(()->{if(closed||ticket!=geoTicket)return;geoBusy=false;saved.edit().putBoolean("geo_failed",true).apply();changed();refresh();});}});
    }
    private void refresh(){
        WeatherForecast.Place location=place();long now=System.currentTimeMillis();
        if(!active||closed||busy||geoBusy||location==null||now<saved.getLong("expires",0)||now-saved.getLong("failed",0)<RETRY)return;
        busy=true;changed();final int ticket=++forecastTicket;final String previous=payload,lastModified=saved.getString("modified","");
        worker.execute(()->{
            try{
                String[] coordinates=location.coordinates().split(",");String url="https://api.met.no/weatherapi/locationforecast/2.0/compact?lat="+coordinates[0]+"&lon="+coordinates[1];
                Reply reply=get(url,previous.isEmpty()?"":lastModified);String body=reply.status==304?previous:reply.body;
                WeatherForecast.read(body,System.currentTimeMillis());
                main.post(()->{
                    if(closed||ticket!=forecastTicket)return;payload=body;busy=false;error="";long fetched=System.currentTimeMillis();
                    saved.edit().putString("forecast",body).putLong("fetched",fetched).putLong("expires",Math.max(fetched+3*HOUR,reply.expires)).putString("modified",reply.modified.isEmpty()?lastModified:reply.modified).remove("failed").apply();cacheCurrent();changed();
                });
            }catch(Exception failure){main.post(()->{if(closed||ticket!=forecastTicket)return;busy=false;error="Weather could not be updated. Check the connection and try again later.";saved.edit().putLong("failed",System.currentTimeMillis()).apply();changed();});}
        });
    }
    void showMenu(Runnable back){
        WeatherForecast.Place location=place();WeatherForecast value=forecast();
        String summary=location==null?status()+". You can also choose a city manually.":placeName()+(location.detail.isEmpty()?"":" · "+location.detail)+"\n"+(value==null?status():value.temperature(fahrenheit())+" · "+status());
        if(automatic())summary+="\nApproximate ISP location. A VPN may change the detected area.";
        long fetched=saved.getLong("fetched",0);if(fetched>0&&location!=null)summary+="\nUpdated "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(fetched));
        panel("Local weather",summary,new String[]{"Weather location","Temperature units","Refresh weather","Weather sources"},new String[]{automatic()?"Automatic · Follow this device’s ISP":"Manual · "+placeName(),fahrenheit()?"Fahrenheit (°F)":"Celsius (°C)","Update when newer weather is available","Forecast and location credits"},0,index->{
            if(index==0)locationMenu(back);
            else if(index==1)panel("Temperature units","Choose the temperature shown on Home",new String[]{"Celsius (°C)","Fahrenheit (°F)"},null,fahrenheit()?1:0,unit->{saved.edit().putBoolean("fahrenheit",unit==1).apply();changed();showMenu(back);},()->showMenu(back));
            else if(index==2){saved.edit().remove("failed").apply();detect(true);refresh();Toast.makeText(host,busy||geoBusy?"Updating weather…":forecast()!=null?"Using the latest available forecast":"Location unavailable. Choose a city in Weather location.",Toast.LENGTH_SHORT).show();back.run();}
            else sources(back);
        },back);
    }
    private void locationMenu(Runnable back){
        panel("Weather location","Follow your device’s internet location, or choose a city.",new String[]{"Automatic (ISP)","Choose a city"},new String[]{"Approximate area from your current public IP; no GPS permission","City or postal code · useful with a VPN"},automatic()?0:1,index->{
            if(index==1){searchDialog(back);return;}cacheCurrent();geoTicket++;geoBusy=false;forecastTicket++;busy=false;payload="";
            saved.edit().putBoolean("manual_location",false).remove("latitude").remove("longitude").remove("place").remove("forecast").remove("fetched").remove("expires").remove("geo_attempt").remove("geo_checked").remove("failed").apply();detect(true);changed();back.run();
        },()->showMenu(back));
    }
    private void panel(String title,String detail,String[] options,String[] notes,int initial,java.util.function.IntConsumer choice,Runnable back){
        TvPanel.show(host,Typeface.DEFAULT,TvSettings.SURFACE,TvSettings.TEXT,TvSettings.MUTED,title,detail,options,notes,-1,initial,choice,back);
    }
    private void sources(Runnable back){
        panel("Weather sources","Forecast: MET Norway (CC BY 4.0). Rounded temperatures and condition labels are adapted for ShadowFox.\nISP location: GeoJS / MaxMind GeoLite2. Manual search: Photon / © OpenStreetMap contributors (ODbL).\nApproximate coordinates are used for weather. No GPS permission is needed.",new String[]{"Forecast licence","Location data licence","ISP location source"},new String[]{"MET Norway · Creative Commons Attribution 4.0","OpenStreetMap contributors · Open Database Licence","GeoJS · MaxMind GeoLite2"},0,index->{
            String url=index==0?"https://docs.api.met.no/doc/License.html":index==1?"https://www.openstreetmap.org/copyright":"https://www.geojs.io/";
            try{host.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(url)));}catch(android.content.ActivityNotFoundException ignored){Toast.makeText(host,url,Toast.LENGTH_LONG).show();}showMenu(back);
        },()->showMenu(back));
    }
    private void searchDialog(Runnable back){
        EditText input=new EditText(host);input.setSingleLine(true);input.setHint("City or postal code");input.setTextColor(TvSettings.TEXT);input.setHintTextColor(TvSettings.MUTED);input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)});input.setText(saved.getString("search_query",""));input.setSelectAllOnFocus(true);
        LinearLayout box=new LinearLayout(host);box.setPadding(dp(24),dp(8),dp(24),dp(8));box.addView(input,new LinearLayout.LayoutParams(-1,-2));
        AlertDialog dialog=new AlertDialog.Builder(host).setTitle("Weather location").setMessage("Enter your city and region, or postal code. Choose a match on the next screen.").setView(box).setPositiveButton("Search",null).setNegativeButton("Cancel",(d,which)->showMenu(back)).create();host.trackDialog(dialog);
        dialog.setOnCancelListener(d->showMenu(back));dialog.setOnShowListener(d->{input.requestFocus();input.selectAll();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String query=input.getText().toString().trim();if(query.length()<2){input.setError("Enter a city or postal code");return;}dialog.dismiss();search(query,back);});});dialog.show();
    }
    private int dp(int n){return Math.round(n*host.getResources().getDisplayMetrics().density);}
    private void search(String query,Runnable back){
        final int ticket=++searchTicket;AlertDialog loading=new AlertDialog.Builder(host).setTitle("Finding location").setMessage("Searching for “"+query+"”…").setNegativeButton("Cancel",(d,which)->{searchTicket++;searchLoading=null;searchDialog(back);}).create();searchLoading=loading;host.trackDialog(loading);loading.setOnCancelListener(d->{searchTicket++;searchLoading=null;searchDialog(back);});loading.show();
        worker.execute(()->{
            try{
                String results;if(query.equalsIgnoreCase(saved.getString("last_query",""))&&System.currentTimeMillis()-saved.getLong("search_time",0)<7*24*HOUR)results=saved.getString("search_results","");
                else{results=get("https://photon.komoot.io/api/?q="+URLEncoder.encode(query,"UTF-8")+"&limit=5&lang=en","").body;saved.edit().putString("last_query",query).putString("search_results",results).putLong("search_time",System.currentTimeMillis()).apply();}
                List<WeatherForecast.Place> places=WeatherForecast.places(results);main.post(()->{
                    if(closed||ticket!=searchTicket||!active)return;loading.dismiss();searchLoading=null;
                    if(places.isEmpty()){panel("Location not found","Try the city with its province, state or country.",new String[]{"Search again"},null,0,i->searchDialog(back),()->showMenu(back));return;}
                    String[] names=new String[places.size()],details=new String[places.size()];for(int i=0;i<places.size();i++){names[i]=places.get(i).name;details[i]=places.get(i).detail;}
                    panel("Choose location","Matches for “"+query+"” · © OpenStreetMap contributors",names,details,0,index->{choose(places.get(index),query);back.run();},()->searchDialog(back));
                });
            }catch(Exception failure){main.post(()->{if(closed||ticket!=searchTicket||!active)return;loading.dismiss();searchLoading=null;panel("Location unavailable","Check your internet connection, then try again.",new String[]{"Search again"},null,0,i->searchDialog(back),()->showMenu(back));});}
        });
    }
    private void choose(WeatherForecast.Place place,String query){
        geoTicket++;geoBusy=false;saved.edit().putBoolean("manual_location",true).apply();applyPlace(place,query);
    }
    private void applyPlace(WeatherForecast.Place place,String query){
        cacheCurrent();forecastTicket++;busy=false;error="";JSONObject cached=new JSONObject();try{cached=new JSONObject(saved.getString("cache:"+place.coordinates(),"{}"));}catch(JSONException ignored){}
        payload=cached.optString("body","");
        saved.edit().putString("place",place.name).putString("region",place.detail).putString("latitude",String.format(Locale.ROOT,"%.4f",place.latitude)).putString("longitude",String.format(Locale.ROOT,"%.4f",place.longitude)).putString("search_query",query).putString("forecast",payload).putLong("expires",cached.optLong("expires",0)).putString("modified",cached.optString("modified","")).putLong("fetched",cached.optLong("fetched",0)).remove("failed").apply();changed();refresh();
    }
    private void cacheCurrent(){
        WeatherForecast.Place place=place();if(place==null||payload.isEmpty())return;
        try{
            JSONObject cache=new JSONObject().put("body",payload).put("fetched",saved.getLong("fetched",0)).put("expires",saved.getLong("expires",0)).put("modified",saved.getString("modified",""));
            String current="cache:"+place.coordinates();SharedPreferences.Editor edit=saved.edit().putString(current,cache.toString());
            ArrayList<String> keys=new ArrayList<>();for(String key:saved.getAll().keySet())if(key.startsWith("cache:")&&!key.equals(current))keys.add(key);
            keys.sort((a,b)->Long.compare(cacheTime(a),cacheTime(b)));while(keys.size()>7)edit.remove(keys.remove(0));edit.apply();
        }catch(JSONException ignored){}
    }
    private long cacheTime(String key){try{return new JSONObject(saved.getString(key,"{}")).optLong("fetched",0);}catch(JSONException ignored){return 0;}}
    private static final class Reply {final int status;final String body,modified;final long expires;Reply(int status,String body,String modified,long expires){this.status=status;this.body=body;this.modified=modified;this.expires=expires;}}
    private Reply get(String address,String modified)throws IOException {
        URL url=new URL(address);
        for(int redirects=0;redirects<4;redirects++){
            if(!url.getProtocol().equals("https")||url.getUserInfo()!=null)throw new IOException("Invalid weather address");
            HttpURLConnection request=(HttpURLConnection)url.openConnection();connection=request;
            try{
                request.setConnectTimeout(8000);request.setReadTimeout(10000);request.setInstanceFollowRedirects(false);request.setRequestProperty("User-Agent",AGENT);request.setRequestProperty("Accept","application/json");request.setRequestProperty("Accept-Encoding","gzip");if(!modified.isEmpty())request.setRequestProperty("If-Modified-Since",modified);
                int status=request.getResponseCode();if(status==301||status==302||status==303||status==307||status==308){String next=request.getHeaderField("Location");if(next==null)throw new IOException("Invalid redirect");url=new URL(url,next);continue;}
                String last=request.getHeaderField("Last-Modified");long expires=request.getHeaderFieldDate("Expires",0);if(status==304)return new Reply(status,"",last==null?"":last,expires);if(status!=200&&status!=203)throw new IOException("Weather request failed");
                InputStream input=request.getInputStream();if("gzip".equalsIgnoreCase(request.getContentEncoding()))input=new GZIPInputStream(input);
                try(InputStream stream=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int n;while((n=stream.read(buffer))!=-1){if(Thread.currentThread().isInterrupted()||closed||out.size()+n>512*1024)throw new IOException("Weather request cancelled");out.write(buffer,0,n);}return new Reply(status,new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8),last==null?"":last,expires);
                }
            }finally{request.disconnect();if(connection==request)connection=null;}
        }
        throw new IOException("Too many weather redirects");
    }
}
