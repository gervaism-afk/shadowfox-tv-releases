package com.shadowfox.tvlauncher;

import org.json.*;
import java.text.*;
import java.util.*;

/** Provider data and presentation shared by the widget and weather options. */
final class WeatherForecast {
    final double celsius;final String symbol;final long time;
    WeatherForecast(double celsius,String symbol,long time){this.celsius=celsius;this.symbol=symbol;this.time=time;}
    static WeatherForecast read(String json,long now)throws JSONException {
        JSONArray hours=new JSONObject(json).getJSONObject("properties").getJSONArray("timeseries");
        JSONObject chosen=null;long chosenTime=Long.MIN_VALUE;
        for(int i=0;i<hours.length();i++){
            JSONObject hour=hours.getJSONObject(i);long time;
            time=parseTime(hour.getString("time"));if(time==Long.MIN_VALUE)continue;
            if(time<=now&&time>chosenTime){chosen=hour;chosenTime=time;}
        }
        if(chosen==null)for(int i=0;i<hours.length();i++){JSONObject hour=hours.getJSONObject(i);long time=parseTime(hour.getString("time"));if(time>now&&(chosen==null||time<chosenTime)){chosen=hour;chosenTime=time;}}
        if(chosen==null||Math.abs(now-chosenTime)>90*60*1000L)throw new JSONException("Forecast is out of date");
        JSONObject data=chosen.getJSONObject("data");double temperature=data.getJSONObject("instant").getJSONObject("details").getDouble("air_temperature");
        if(!Double.isFinite(temperature)||temperature< -100||temperature>70)throw new JSONException("Invalid temperature");
        JSONObject period=data.optJSONObject("next_1_hours");if(period==null)period=data.optJSONObject("next_6_hours");
        JSONObject summary=period==null?null:period.optJSONObject("summary");
        return new WeatherForecast(temperature,summary==null?"unknown":summary.optString("symbol_code","unknown"),chosenTime);
    }
    private static long parseTime(String value){
        if(value.length()!=20||!value.endsWith("Z"))return Long.MIN_VALUE;
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.ROOT);format.setTimeZone(TimeZone.getTimeZone("UTC"));format.setLenient(false);
        ParsePosition position=new ParsePosition(0);Date date=format.parse(value,position);return date!=null&&position.getIndex()==value.length()?date.getTime():Long.MIN_VALUE;
    }
    String temperature(boolean fahrenheit){return Math.round(fahrenheit?celsius*9/5+32:celsius)+"°"+(fahrenheit?"F":"C");}
    String condition(){
        String s=symbol.toLowerCase(Locale.ROOT);
        if(s.contains("thunder"))return "Thunderstorms";
        if(s.contains("sleet"))return "Sleet";
        if(s.contains("snow"))return s.contains("light")?"Light snow":s.contains("heavy")?"Heavy snow":"Snow";
        if(s.contains("rain"))return s.contains("light")?"Light rain":s.contains("heavy")?"Heavy rain":"Rain";
        if(s.contains("fog"))return "Fog";
        if(s.contains("partlycloudy"))return "Partly cloudy";
        if(s.contains("fair"))return "Mostly clear";
        if(s.contains("cloudy"))return "Cloudy";
        if(s.contains("clearsky"))return "Clear";
        return "Local forecast";
    }
    static final class Place {
        final String name,detail;final double latitude,longitude;
        Place(String name,String detail,double lat,double lon){this.name=name;this.detail=detail;latitude=lat;longitude=lon;}
        String coordinates(){return String.format(Locale.ROOT,"%.4f,%.4f",latitude,longitude);}
    }
    static Place ispPlace(String json)throws JSONException {
        JSONObject data=new JSONObject(json);double lat=data.getDouble("latitude"),lon=data.getDouble("longitude");
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new JSONException("Location unavailable");
        String city=data.optString("city","").trim(),region=data.optString("region","").trim(),country=data.optString("country","").trim();
        if(city.isEmpty())city=region.isEmpty()?country:region;if(city.isEmpty())throw new JSONException("Location unavailable");
        String detail=region.equals(city)?country:region+(region.isEmpty()||country.isEmpty()?"":", ")+country;
        return new Place(city,detail,Math.rint(lat*100)/100,Math.rint(lon*100)/100);
    }
    static List<Place> places(String json)throws JSONException {
        JSONArray features=new JSONObject(json).getJSONArray("features");ArrayList<Place> places=new ArrayList<>();HashSet<String> seen=new HashSet<>();
        for(int i=0;i<features.length()&&places.size()<5;i++){
            JSONObject item=features.getJSONObject(i),p=item.getJSONObject("properties");JSONArray point=item.getJSONObject("geometry").getJSONArray("coordinates");
            double lon=point.getDouble(0),lat=point.getDouble(1);if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)continue;
            String name=p.optString("city",p.optString("name",p.optString("postcode",""))).trim();if(name.isEmpty())continue;
            ArrayList<String> parts=new ArrayList<>();for(String key:new String[]{"name","state","country"}){String part=p.optString(key,"").trim();if(!part.isEmpty()&&!part.equalsIgnoreCase(name)&&!parts.contains(part))parts.add(part);}
            StringBuilder detail=new StringBuilder();for(String part:parts){if(detail.length()>0)detail.append(", ");detail.append(part);}
            Place place=new Place(name,detail.toString(),lat,lon);if(seen.add(name+" "+place.coordinates()))places.add(place);
        }
        return places;
    }
}
