package com.shadowfox.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.InputType;
import android.widget.EditText;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntConsumer;
import org.json.JSONObject;

/** Explicit, verified updates; uses Android's installer and retains launcher data. */
final class LauncherUpdates {
    interface Pages { AlertDialog show(String title,String detail,String[] actions,IntConsumer selected,Runnable back); }
    static final int INSTALL_ACCESS=404,INSTALL_RESULT=405;
    private static final long MAX_APK=100L*1024*1024;
    private final Activity host;
    private final SharedPreferences preferences;
    private final Pages pages;
    private final Runnable returnSettings;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicInteger generation=new AtomicInteger();
    private volatile HttpURLConnection connection;
    private AlertDialog page;
    private String defaultSource="";
    private final PackageInfo current;
    private File pendingInstall;
    private static final class Release {
        final long code;final String version,url,sha,notes;
        Release(JSONObject json,String packageName)throws Exception{
            if(!packageName.equals(json.getString("packageName")))throw new IOException("The update feed belongs to a different app.");
            code=json.getLong("versionCode");version=json.getString("versionName");url=json.getString("apkUrl");sha=json.getString("sha256").toLowerCase(Locale.ROOT);notes=json.optString("notes","");
            if(code<=0 || version.isEmpty() || version.length()>80 || !sha.matches("[a-f0-9]{64}") || notes.length()>4000)throw new IOException("The update feed is invalid.");
            https(url);
        }
    }
    LauncherUpdates(Activity host,SharedPreferences preferences,Pages pages,Runnable returnSettings){
        this.host=host;this.preferences=preferences;this.pages=pages;this.returnSettings=returnSettings;
        try{current=host.getPackageManager().getPackageInfo(host.getPackageName(),signatureFlags());}catch(PackageManager.NameNotFoundException failure){throw new IllegalStateException(failure);}
        try(InputStream input=host.getAssets().open("update-config.json")){defaultSource=new JSONObject(new String(read(input,32768),"UTF-8")).optString("feedUrl","");}catch(Exception ignored){}
        String saved=preferences.getString("pending_launcher_update","");
        if(saved.matches("update-[0-9]+-[a-f0-9]{64}\\.apk") && Long.parseLong(saved.split("-")[1])>code(current))pendingInstall=new File(directory(),saved);
    }
    // Fire OS 7 omits archive signingInfo unless GET_SIGNATURES is requested too.
    private static int signatureFlags(){return PackageManager.GET_SIGNATURES|(Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:0);}
    private static long code(PackageInfo info){return Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode;}
    private static URL https(String value)throws IOException{
        URL url=new URL(value);
        if(!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost().isEmpty() || url.getUserInfo()!=null)throw new IOException("Use an HTTPS update URL without login details.");
        return url;
    }
    private String source(){return preferences.getString("launcher_update_source",defaultSource);}
    private File directory(){File directory=new File(host.getCacheDir(),"launcher-updates");directory.mkdirs();return directory;}
    private void show(String title,String detail,String[] actions,IntConsumer selected,Runnable back){
        if(host.isFinishing() || host.isDestroyed())return;
        if(page!=null)page.dismiss();page=pages.show(title,detail,actions,selected,back);
    }
    void showMenu(){
        boolean downloaded=pendingInstall!=null && pendingInstall.isFile();
        show("Launcher updates","Installed version "+current.versionName+(source().isEmpty()?" · Update source not set":""),downloaded?new String[]{"Check for updates","Install downloaded update","Update source"}:new String[]{"Check for updates","Update source"},i->{if(i==0)check();else if(downloaded && i==1)install();else editSource();},returnSettings);
    }
    private void editSource(){
        EditText input=new EditText(host);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);input.setText(source());input.setHint("https://…/launcher-update.json");
        int padding=Math.round(24*host.getResources().getDisplayMetrics().density);input.setPadding(padding,padding,padding,padding);
        if(page!=null)page.dismiss();
        AlertDialog dialog=new AlertDialog.Builder(host).setTitle("Update source").setMessage("The HTTPS feed supplied by your launcher provider.").setView(input).setPositiveButton("Save",null).setNegativeButton("Cancel",(d,w)->showMenu()).create();
        if(host instanceof MainActivity)((MainActivity)host).trackDialog(dialog);
        dialog.setOnCancelListener(d->showMenu());dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String value=input.getText().toString().trim();
            try{if(!value.isEmpty())https(value);}catch(IOException invalid){input.setError(invalid.getMessage());return;}
            cancel();if(value.isEmpty())preferences.edit().remove("launcher_update_source").apply();else preferences.edit().putString("launcher_update_source",value).apply();
            dialog.dismiss();showMenu();
        }));page=dialog;dialog.show();
    }
    private void cancel(){generation.incrementAndGet();HttpURLConnection active=connection;if(active!=null)active.disconnect();}
    private boolean active(int token){return generation.get()==token && !Thread.currentThread().isInterrupted();}
    private void ui(int token,Runnable action){host.runOnUiThread(()->{if(active(token) && !host.isFinishing() && !host.isDestroyed())action.run();});}
    private int busy(String message){
        cancel();int token=generation.get();show("Launcher updates",message,new String[]{"Cancel"},i->{cancel();showMenu();},()->{cancel();showMenu();});return token;
    }
    private HttpURLConnection open(String address,int token)throws IOException{
        URL url=https(address);
        for(int redirects=0;redirects<=5;redirects++){
            if(!active(token))throw new InterruptedIOException();
            HttpURLConnection request=(HttpURLConnection)url.openConnection();connection=request;
            request.setConnectTimeout(15000);request.setReadTimeout(15000);request.setInstanceFollowRedirects(false);request.setRequestProperty("User-Agent","ShadowFoxTV-Launcher/"+current.versionName);request.setRequestProperty("Accept-Encoding","identity");
            int status=request.getResponseCode();
            if(status==301||status==302||status==303||status==307||status==308){String location=request.getHeaderField("Location");request.disconnect();if(location==null)throw new IOException("The update server returned an invalid redirect.");url=https(new URL(url,location).toString());continue;}
            if(status!=200){request.disconnect();throw new IOException("The update server returned HTTP "+status+".");}
            return request;
        }
        throw new IOException("Too many update redirects.");
    }
    private static byte[] read(InputStream input,int limit)throws IOException{
        ByteArrayOutputStream output=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
        while((count=input.read(buffer))!=-1){if(output.size()+count>limit)throw new IOException("The update feed is too large.");output.write(buffer,0,count);}return output.toByteArray();
    }
    void checkNow(){check();}
    private void check(){
        final String address=source();if(address.isEmpty()){show("Set up updates","Your launcher provider needs to supply an update feed.",new String[]{"Set update source"},i->editSource(),this::showMenu);return;}
        int token=busy("Checking for updates…");
        worker.execute(()->{
            try{
                HttpURLConnection request=open(address,token);byte[] data;try(InputStream input=request.getInputStream()){data=read(input,32768);}finally{request.disconnect();}
                Release release=new Release(new JSONObject(new String(data,"UTF-8")),host.getPackageName());
                ui(token,()->{if(release.code<=code(current))show("You’re up to date","Installed version "+current.versionName,new String[]{"Done"},i->showMenu(),this::showMenu);
                    else show("Update available","Version "+release.version+(release.notes.isEmpty()?"":"\n\n"+release.notes),new String[]{"Download update","Later"},i->{if(i==0)download(release);else showMenu();},this::showMenu);});
            }catch(Exception failure){failed(token,"Couldn’t check for updates",failure);}
            finally{connection=null;}
        });
    }
    private static String hash(byte[] value){StringBuilder result=new StringBuilder();for(byte item:value)result.append(String.format(Locale.ROOT,"%02x",item&255));return result.toString();}
    private Set<String> signatures(PackageInfo info)throws Exception{
        Signature[] values=null;
        if(Build.VERSION.SDK_INT>=28&&info.signingInfo!=null)values=info.signingInfo.getApkContentsSigners();
        if(values==null||values.length==0)values=info.signatures;
        if(values==null||values.length==0)throw new IOException("The update has no signing certificate.");
        Set<String> result=new HashSet<>();for(Signature value:values)result.add(hash(MessageDigest.getInstance("SHA-256").digest(value.toByteArray())));return result;
    }
    private void verify(File file,long expectedCode,String expectedSha)throws Exception{
        MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream input=new FileInputStream(file)){byte[] buffer=new byte[32768];int count;while((count=input.read(buffer))!=-1)digest.update(buffer,0,count);}
        if(!hash(digest.digest()).equals(expectedSha))throw new IOException("Download verification failed. Try again.");
        PackageInfo archive=host.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(),signatureFlags());
        if(archive==null || !host.getPackageName().equals(archive.packageName) || code(archive)!=expectedCode || code(archive)<=code(current))throw new IOException("This download is not a newer version of your launcher.");
        if(!signatures(current).equals(signatures(archive)))throw new IOException("The update’s signing certificate does not match your launcher.");
    }
    private void download(Release release){
        int token=busy("Downloading version "+release.version+"…");
        worker.execute(()->{
            File temp=new File(directory(),"download-"+token+".tmp");
            try{
                HttpURLConnection request=open(release.url,token);long expected=request.getContentLengthLong();if(expected>MAX_APK)throw new IOException("The update is too large.");
                long total=0;try(InputStream input=request.getInputStream();OutputStream output=new FileOutputStream(temp)){
                    byte[] buffer=new byte[32768];int count;while((count=input.read(buffer))!=-1){if(!active(token))throw new InterruptedIOException();total+=count;if(total>MAX_APK)throw new IOException("The update is too large.");output.write(buffer,0,count);}
                }finally{request.disconnect();}
                if(total==0 || expected>=0 && total!=expected)throw new IOException("The download was incomplete. Try again.");
                if(!active(token))throw new InterruptedIOException();verify(temp,release.code,release.sha);
                File apk=new File(directory(),"update-"+release.code+"-"+release.sha+".apk");if(!temp.renameTo(apk))throw new IOException("Couldn’t save the verified update.");
                ui(token,()->{pendingInstall=apk;preferences.edit().putString("pending_launcher_update",apk.getName()).apply();show("Ready to install","Version "+release.version+" is verified. Android will ask you to confirm the update. Your launcher settings will be retained.",new String[]{"Install update","Later"},i->{if(i==0)install();else showMenu();},this::showMenu);});
            }catch(Exception failure){failed(token,"Couldn’t download update",failure);}
            finally{temp.delete();HttpURLConnection request=connection;if(request!=null)request.disconnect();connection=null;}
        });
    }
    private void failed(int token,String title,Exception failure){
        String message=failure instanceof IOException?failure.getMessage():"The update information could not be verified.";
        if(message==null||message.isEmpty())message="Check your connection and try again.";
        final String detail=message;ui(token,()->show(title,detail,new String[]{"Back"},i->showMenu(),this::showMenu));
    }
    private void install(){
        File apk=pendingInstall;if(apk==null||!apk.isFile()){show("Update unavailable","The downloaded file is no longer available. Check for updates again.",new String[]{"Back"},i->showMenu(),this::showMenu);return;}
        if(Build.VERSION.SDK_INT>=26 && !host.getPackageManager().canRequestPackageInstalls()){
            show("Allow launcher updates","Allow ShadowFoxTV Launcher Pro to install updates in Android settings, then press Back.",new String[]{"Open permission settings"},i->{
                try{host.startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+host.getPackageName())),INSTALL_ACCESS);}catch(ActivityNotFoundException|SecurityException failure){show("Install permission unavailable","This device does not provide the installation permission page. Enable installation for this launcher in Android settings.",new String[]{"Back"},j->showMenu(),this::showMenu);}
            },this::showMenu);return;
        }
        int token=busy("Verifying update before installation…");
        worker.execute(()->{
            try{
                String[] name=apk.getName().substring(0,apk.getName().length()-4).split("-");verify(apk,Long.parseLong(name[1]),name[2]);
                ui(token,()->{
                    Uri uri=Uri.parse("content://"+host.getPackageName()+".updates/"+apk.getName());
                    Intent intent=new Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).putExtra(Intent.EXTRA_RETURN_RESULT,true);
                    intent.setClipData(ClipData.newRawUri("Launcher update",uri));
                    try{if(page!=null)page.dismiss();host.startActivityForResult(intent,INSTALL_RESULT);}catch(ActivityNotFoundException|SecurityException failure){show("Installer unavailable","Android could not open its package installer on this device.",new String[]{"Back"},i->showMenu(),this::showMenu);}
                });
            }catch(Exception failure){failed(token,"Couldn’t install update",failure);}
        });
    }
    boolean onActivityResult(int request,int result){
        if(request==INSTALL_ACCESS){if(Build.VERSION.SDK_INT<26||host.getPackageManager().canRequestPackageInstalls())install();else show("Installation not allowed","Enable installation for this launcher in Android settings to install the update.",new String[]{"Back"},i->showMenu(),this::showMenu);return true;}
        if(request==INSTALL_RESULT){showMenu();return true;}
        return false;
    }
    void dismissForHome(){cancel();if(page!=null){page.dismiss();page=null;}}
    void close(){dismissForHome();worker.shutdownNow();}
}
