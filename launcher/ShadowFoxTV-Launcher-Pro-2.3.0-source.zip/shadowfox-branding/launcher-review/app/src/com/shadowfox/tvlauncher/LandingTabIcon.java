package com.shadowfox.tvlauncher;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Paired Home/library symbols, drawn at the same optical size. */
final class LandingTabIcon extends Drawable {
    private final boolean home;private int ink=0xfff1f3f8;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    LandingTabIcon(boolean home){this.home=home;}
    void colour(int value){ink=value;invalidateSelf();}
    @Override public void draw(Canvas canvas){
        int save=canvas.save();Rect b=getBounds();canvas.translate(b.left,b.top);canvas.scale(b.width()/24f,b.height()/24f);
        paint.setColor(ink);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.8f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        if(home){Path roof=new Path();roof.moveTo(3,11);roof.lineTo(12,3.5f);roof.lineTo(21,11);canvas.drawPath(roof,paint);Path walls=new Path();walls.moveTo(5,10);walls.lineTo(5,20);walls.lineTo(10,20);walls.lineTo(10,14);walls.lineTo(14,14);walls.lineTo(14,20);walls.lineTo(19,20);walls.lineTo(19,10);canvas.drawPath(walls,paint);}
        else for(int y=4;y<=14;y+=10)for(int x=4;x<=14;x+=10)canvas.drawRoundRect(x,y,x+6,y+6,1.4f,1.4f,paint);
        canvas.restoreToCount(save);
    }
    @Override public void setAlpha(int value){paint.setAlpha(value);}
    @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
