package com.shadowfox.tvlauncher;

/** Uses the device's local hour, including when its timezone changes. */
final class Greeting {
    static String forHour(int hour) {
        return "Welcome, Good "+(hour>=5 && hour<12?"Morning":hour>=12 && hour<18?"Afternoon":"Evening");
    }
}
