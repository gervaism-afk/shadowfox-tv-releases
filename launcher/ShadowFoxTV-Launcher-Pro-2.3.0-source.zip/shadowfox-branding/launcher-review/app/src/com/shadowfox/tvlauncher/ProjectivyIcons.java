package com.shadowfox.tvlauncher;

import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import java.util.*;
import org.xmlpull.v1.XmlPullParser;

/** Reads artwork from the separately installed pack; no third-party artwork is bundled. */
final class ProjectivyIcons {
    static final String PACKAGE="dev.projectivy.blueprint.app";
    private Resources resources;
    private final Map<String,String> components=new HashMap<>();
    private final Map<String,String> packages=new HashMap<>();
    private final Set<String> ambiguous=new HashSet<>();
    final List<String> names=new ArrayList<>();
    private boolean namesLoaded;
    String version="";
    ProjectivyIcons(PackageManager manager) {
        try {
            resources=manager.getResourcesForApplication(PACKAGE);
            version=manager.getPackageInfo(PACKAGE,0).versionName;
            int filter=resources.getIdentifier("appfilter","xml",PACKAGE);
            if(filter!=0) try(XmlResourceParser xml=resources.getXml(filter)) {
                while(xml.next()!=XmlPullParser.END_DOCUMENT) {
                    if(xml.getEventType()!=XmlPullParser.START_TAG || !xml.getName().equals("item")) continue;
                    String component=xml.getAttributeValue(null,"component"), drawable=xml.getAttributeValue(null,"drawable");
                    if(component==null || drawable==null || drawable.isEmpty()) continue;
                    int start=component.indexOf('{'),end=component.lastIndexOf('}');
                    if(start<0 || end<=start) continue;
                    String[] parts=component.substring(start+1,end).split("/",-1);
                    if(parts.length!=2 || parts[0].isEmpty()) continue;
                    String activity=parts[1].startsWith(".")?parts[0]+parts[1]:parts[1];
                    components.put(parts[0]+"/"+activity,drawable);
                    String prior=packages.putIfAbsent(parts[0],drawable);
                    if(prior!=null && !prior.equals(drawable)) ambiguous.add(parts[0]);
                }
            }
        } catch(Exception unavailable) { android.util.Log.w("ShadowFoxIcons","Could not read installed icon pack",unavailable); resources=null; components.clear(); packages.clear(); names.clear(); }
    }
    private void loadNames() {
        if(namesLoaded || resources==null)return;
        namesLoaded=true;
        TreeSet<String> all=new TreeSet<>(components.values());
        for(String group:new String[]{"All_TV_icons","TV_icons_with_no_mapping","Latest_Additions","Generic_TV_Icons","Category_icons"}) all.addAll(group(group));
        for(String name:all) if(resource(name)!=0) names.add(name);
    }
    List<String> allNames() { loadNames();return names; }
    boolean available() { loadNames();return resources!=null && !names.isEmpty(); }
    int mappedCount() { return components.size(); }
    List<String> group(String name) {
        ArrayList<String> result=new ArrayList<>();
        if(resources==null) return result;
        int id=resources.getIdentifier(name,"array",PACKAGE);
        if(id!=0) try { for(String item:resources.getStringArray(id)) if(resource(item)!=0) result.add(item); }
        catch(Resources.NotFoundException ignored) { }
        return result;
    }
    private int resource(String name) { return resources==null?0:resources.getIdentifier(name,"drawable",PACKAGE); }
    Drawable drawable(String name) {
        int id=resource(name); if(id==0) return null;
        try { return resources.getDrawableForDensity(id,640,null); } catch(Resources.NotFoundException ignored) { return null; }
    }
    Drawable icon(ResolveInfo app) {
        String packageName=app.activityInfo.packageName;
        String name=components.get(packageName+"/"+app.activityInfo.name);
        if(name==null && !ambiguous.contains(packageName)) name=packages.get(packageName);
        return name==null?null:drawable(name);
    }
}
