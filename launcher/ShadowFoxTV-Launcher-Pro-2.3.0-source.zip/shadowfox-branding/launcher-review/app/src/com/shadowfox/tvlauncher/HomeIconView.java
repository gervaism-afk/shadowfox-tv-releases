package com.shadowfox.tvlauncher;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Fits the actual artwork, including transparent wordmarks, inside a TV app target. */
final class HomeIconView extends View {
    static final class Artwork {
        final Bitmap bitmap;final Rect content;final boolean plainBackground;
        Artwork(Context host,Drawable original,boolean custom){
            float ratio=original==null?1f:Math.max(.25f,Math.min(4f,original.getIntrinsicWidth()/(float)Math.max(1,original.getIntrinsicHeight())));
            int width=ratio>=1?256:Math.max(64,Math.round(256*ratio)),height=ratio>=1?Math.max(64,Math.round(256/ratio)):256;
            bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
            if(original!=null){Drawable.ConstantState state=original.getConstantState();Drawable draw=state==null?original:state.newDrawable(host.getResources()).mutate();Rect previous=new Rect(draw.getBounds());draw.setBounds(0,0,width,height);draw.draw(new Canvas(bitmap));draw.setBounds(previous);}
            int[] pixels=new int[width*height];bitmap.getPixels(pixels,0,width,0,0,width,height);
            int left=width,top=height,right=-1,bottom=-1;
            for(int y=0;y<height;y++)for(int x=0;x<width;x++)if(Color.alpha(pixels[y*width+x])>16){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);}
            content=right<left?new Rect(0,0,width,height):new Rect(Math.max(0,left-1),Math.max(0,top-1),Math.min(width,right+2),Math.min(height,bottom+2));
            int[] edges={pixels[0],pixels[width-1],pixels[(height-1)*width],pixels[width*height-1],pixels[width/2],pixels[(height-1)*width+width/2]};boolean plain=!custom&&Math.abs(ratio-1)<.08f;
            for(int colour:edges)if(Color.alpha(colour)<250||difference(colour,edges[0])>36)plain=false;
            plainBackground=plain;
        }
        private int difference(int a,int b){return Math.max(Math.abs(Color.red(a)-Color.red(b)),Math.max(Math.abs(Color.green(a)-Color.green(b)),Math.abs(Color.blue(a)-Color.blue(b))));}
    }
    private final Artwork art;private final int fill;private final float density;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);private boolean selected;
    HomeIconView(Context host,Artwork art,int fill){super(host);this.art=art;this.fill=fill;density=getResources().getDisplayMetrics().density;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    void highlight(boolean value){selected=value;invalidate();StudioStyle.focusMotion(this,value,1.065f,0);}
    @Override protected void onDraw(Canvas canvas){
        float width=getWidth(),height=getHeight(),size=Math.min(width,height),cx=width/2,cy=height/2,radius=size/2-3*density;
        paint.setColor(fill);canvas.drawCircle(cx,cy,radius,paint);
        float inset=art.plainBackground?3*density:7*density;
        RectF available=new RectF(cx-size/2+inset,cy-size/2+inset,cx+size/2-inset,cy+size/2-inset);
        float scale=Math.min(available.width()/art.content.width(),available.height()/art.content.height());float w=art.content.width()*scale,h=art.content.height()*scale;
        RectF destination=new RectF(cx-w/2,cy-h/2,cx+w/2,cy+h/2);int saved=canvas.save();
        if(art.plainBackground){Path clip=new Path();clip.addCircle(cx,cy,radius,Path.Direction.CW);canvas.clipPath(clip);}
        paint.setColor(Color.WHITE);canvas.drawBitmap(art.bitmap,art.content,destination,paint);canvas.restoreToCount(saved);
        if(selected){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2*density);paint.setColor(0xffe9edf8);canvas.drawCircle(cx,cy,radius+1*density,paint);paint.setStyle(Paint.Style.FILL);}
    }
}
