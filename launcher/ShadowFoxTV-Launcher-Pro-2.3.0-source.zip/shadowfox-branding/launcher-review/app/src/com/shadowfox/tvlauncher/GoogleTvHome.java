package com.shadowfox.tvlauncher;

import android.content.*;
import android.database.ContentObserver;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/** Static-wallpaper TV home: real program cards, circular apps and category library. */
final class GoogleTvHome extends LinearLayout {
    static final class App {
        final String id,name,category;final Drawable icon,banner;final boolean customArtwork;HomeIconView.Artwork artwork;
        App(String id,String name,String category,Drawable icon,Drawable banner,boolean customArtwork){this.id=id;this.name=name;this.category=category;this.icon=icon;this.banner=banner;this.customArtwork=customArtwork;}
    }
    static final class Group {
        final String id,name;Group(String id,String name){this.id=id;this.name=name;}
    }
    interface Actions {
        void launch(String id);void program(TvHomeFeed.Program program);void menu(String id);void selected(String id);
        void wallpapers();void settings();void choose(String category);
    }
    private final MainActivity host;
    private final SharedPreferences prefs;
    private final View header;
    private final Actions actions;
    private final TextView homeTab,appsTab;
    private final ArrayList<View> nav=new ArrayList<>();
    private final ScrollView scroll;
    private final LinearLayout body;
    private final LinkedHashMap<String,App> apps=new LinkedHashMap<>();
    private final ArrayList<Group> groups=new ArrayList<>();
    private final LinkedHashMap<String,View> focusViews=new LinkedHashMap<>();
    private final ArrayList<ArrayList<View>> rows=new ArrayList<>();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService feedWorker=Executors.newSingleThreadExecutor();
    private final ExecutorService posters=Executors.newFixedThreadPool(2);
    private final android.util.LruCache<String,Bitmap> posterCache=new android.util.LruCache<String,Bitmap>(8*1024*1024){@Override protected int sizeOf(String key,Bitmap bitmap){return bitmap.getByteCount();}};
    private final HashSet<String> queuedPosters=new HashSet<>();
    private final HashMap<String,ArrayList<ImageView>> posterViews=new HashMap<>();
    private TvHomeFeed.Snapshot feed=new TvHomeFeed.Snapshot();
    private CancellationSignal query;
    private int request;
    private boolean rendering;
    private final ArrayList<HorizontalScrollView> rails=new ArrayList<>();
    private TextView heroTitle,heroSource,heroDetail,heroOpen;
    private String heroOwner;
    private TvHomeFeed.Program heroProgram;
    private boolean library,closed,observing;
    private String category="",focusedKey;
    private View landingGap,landingBreak,landingHero,primaryHeading,primaryRail;
    private int landingRestoreY=-1;
    private final ViewTreeObserver.OnGlobalLayoutListener landingLayout=this::layoutLandingPage;
    private final Runnable refreshTask=()->refresh();
    private final ContentObserver observer=new ContentObserver(handler){@Override public void onChange(boolean self){handler.removeCallbacks(refreshTask);handler.postDelayed(refreshTask,600);}};
    private static final int TEXT=0xfff1f3f8,MUTED=0xffb0b7ca;

    GoogleTvHome(MainActivity host,SharedPreferences prefs,View header,Actions actions){
        super(host);this.host=host;this.prefs=prefs;this.header=header;this.actions=actions;
        setOrientation(VERTICAL);setClipChildren(false);setClipToPadding(false);
        LinearLayout navigation=new LinearLayout(host);navigation.setGravity(Gravity.CENTER_VERTICAL);navigation.setPadding(dp(40),dp(3),dp(40),dp(3));navigation.setClipChildren(false);addView(navigation,new LayoutParams(-1,dp(56)));
        LinearLayout tabs=new LinearLayout(host);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(shape(0x503c435c,40,0));
        homeTab=tab("Home",()->switchPage(false,true));appsTab=tab("Apps",()->switchPage(true,true));
        decorateTab(homeTab,true);decorateTab(appsTab,false);tabs.addView(homeTab,new LayoutParams(dp(124),dp(42)));tabs.addView(appsTab,new LayoutParams(dp(124),dp(42)));navigation.addView(tabs);
        nav.add(homeTab);nav.add(appsTab);
        for(int i=0;i<nav.size();i++){View v=nav.get(i);v.setNextFocusUpId(header.getId());v.setNextFocusLeftId(nav.get(Math.max(0,i-1)).getId());v.setNextFocusRightId(nav.get(Math.min(nav.size()-1,i+1)).getId());}
        scroll=new ScrollView(host);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);scroll.setOverScrollMode(OVER_SCROLL_NEVER);
        body=new LinearLayout(host);body.setOrientation(VERTICAL);body.setPadding(dp(40),0,dp(40),dp(24));body.setClipChildren(false);body.setClipToPadding(false);scroll.addView(body);addView(scroll,new LayoutParams(-1,0,1));paintTabs();
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String title,int size,int colour,boolean bold){TextView v=StudioStyle.label(host,title,size,colour,bold);v.setShadowLayer(dp(2),0,dp(1),0x80000000);return v;}
    private GradientDrawable shape(int fill,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private TextView tab(String title,Runnable action){
        TextView v=label(title,15,TEXT,true);v.setGravity(Gravity.CENTER);v.setShadowLayer(0,0,0,0);focusable(v);
        v.setOnClickListener(w->action.run());v.setOnFocusChangeListener((w,focused)->{if(focused&&!rendering){focusedKey=null;actions.selected(null);scroll.smoothScrollTo(0,0);header.setNextFocusDownId(w.getId());}paintTabs();});return v;
    }
    private void decorateTab(TextView view,boolean home){LandingTabIcon icon=new LandingTabIcon(home);icon.setBounds(0,0,dp(20),dp(20));view.setCompoundDrawables(icon,null,null,null);view.setCompoundDrawablePadding(dp(9));view.setPadding(dp(16),0,dp(16),0);view.setSingleLine(true);view.setContentDescription(home?"Home":"Apps");}
    private void focusable(View v){v.setId(View.generateViewId());v.setFocusable(true);v.setFocusableInTouchMode(true);if(Build.VERSION.SDK_INT>=26)v.setDefaultFocusHighlightEnabled(false);}
    private void paintTabs(){
        for(View item:nav){boolean active=item==(library?appsTab:homeTab),focus=item.hasFocus();item.setBackground(shape(focus?0xffe5e8f6:active?0x90606a85:0x00232b43,30,0));TextView text=(TextView)item;text.setTextColor(focus?0xff172137:TEXT);Drawable icon=text.getCompoundDrawables()[0];if(icon instanceof LandingTabIcon)((LandingTabIcon)icon).colour(focus?0xff173d5d:active?StudioStyle.BLUE:TEXT);}
    }
    void bind(List<App> items,List<Group> categories){
        apps.clear();for(App app:items)apps.put(app.id,app);groups.clear();groups.addAll(categories);
        if(!category.isEmpty()&&groups.stream().noneMatch(g->g.id.equals(category)))category="";
        if(apps.isEmpty()){request++;if(query!=null)query.cancel();feed=new TvHomeFeed.Snapshot();}
        render(true);refresh();
    }
    void refresh(){
        if(closed||apps.isEmpty())return;
        final int ticket=++request;if(query!=null)query.cancel();final CancellationSignal signal=new CancellationSignal();query=signal;
        Set<String> visible=new HashSet<>(apps.keySet());visible.removeIf(GoogleTvHome::spotifySource);
        feedWorker.execute(()->{TvHomeFeed.Snapshot result=TvHomeFeed.read(host,visible,signal);handler.post(()->{
            if(closed||ticket!=request||signal.isCanceled())return;
            if(!feed.signature().equals(result.signature())){feed=result;if(!library)render(true);}
        });});
    }
    private void switchPage(boolean value,boolean focusTab){
        boolean changed=library!=value;library=value;focusedKey=null;landingRestoreY=-1;actions.selected(null);if(changed||body.getChildCount()==0)render(false);scroll.scrollTo(0,0);if(!library){for(HorizontalScrollView rail:rails)rail.scrollTo(0,0);showDefaultHero();}paintTabs();
        if(focusTab)(library?appsTab:homeTab).requestFocusFromTouch();
    }
    void home(){switchPage(false,true);}
    void focusNavigation(){(library?appsTab:homeTab).requestFocusFromTouch();}
    void restoreApp(String id){View remembered=focusViews.get(focusedKey);if(remembered!=null)remembered.requestFocusFromTouch();else focusApp(id);}
    String bookmark(){return focusedKey;}
    void restoreApp(String id,String bookmark){View remembered=focusViews.get(bookmark);if(remembered!=null)remembered.requestFocusFromTouch();else focusApp(id);}
    void focusApp(String id){App app=apps.get(id);if(app==null){focusNavigation();return;}library=true;category=app.category;render(false);paintTabs();View v=focusViews.get("app:"+id);if(v!=null)v.post(()->v.requestFocusFromTouch());}
    boolean back(){home();return true;}
    private void render(boolean restore){
        String remembered=restore?focusedKey:null;int oldScroll=restore?scroll.getScrollY():0;
        String previousOwner=heroOwner;TvHomeFeed.Program previousProgram=heroProgram;
        rendering=true;
        try{
            landingGap=null;landingBreak=null;landingHero=null;primaryHeading=null;primaryRail=null;landingRestoreY=restore?oldScroll:0;posterViews.clear();body.removeAllViews();focusViews.clear();rows.clear();rails.clear();heroTitle=null;heroSource=null;heroDetail=null;heroOpen=null;
            setBackground(library?new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xc00b1020,0xa00b1020,0x600b1020}):null);
            if(library)renderLibrary();else renderHome();linkRows();host.bindSettingsSounds(this);
            if(restore){
                if("hero:open".equals(remembered)){if(previousProgram!=null&&apps.containsKey(previousProgram.owner))showProgramHero(previousProgram);else if(apps.containsKey(previousOwner))showAppHero(apps.get(previousOwner));}
                View target=focusViews.get(remembered);if(target!=null)target.requestFocus();
                else if(remembered!=null){focusedKey=null;actions.selected(null);focusNavigation();}
                if(library)scroll.post(()->scroll.scrollTo(0,oldScroll));else if(remembered!=null&&target==null)landingRestoreY=0;
            }
        }finally{rendering=false;}
    }
    private void heading(String title,String detail){
        LinearLayout line=new LinearLayout(host);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(4),dp(8),dp(4),dp(8));
        TextView name=label(title,16,title.equals("Recently opened")?StudioStyle.AMBER:0xffbaddf5,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);line.addView(name,new LayoutParams(0,-2,1));
        if(detail!=null&&!detail.isEmpty()){TextView note=label(detail,10,MUTED,false);line.addView(note);}body.addView(line,new LayoutParams(-1,-2));
    }
    private LinearLayout rail(ArrayList<View> nodes){
        HorizontalScrollView rail=new HorizontalScrollView(host);rail.setFocusable(false);rail.setHorizontalScrollBarEnabled(false);rail.setClipToPadding(false);rail.setOverScrollMode(OVER_SCROLL_NEVER);rail.setPadding(dp(6),dp(8),dp(6),dp(9));rails.add(rail);
        LinearLayout line=new LinearLayout(host);line.setGravity(Gravity.CENTER_VERTICAL);line.setClipChildren(false);line.setClipToPadding(false);rail.addView(line);body.addView(rail,new LayoutParams(-1,-2));rows.add(nodes);return line;
    }
    private static boolean spotifySource(String owner){return "com.spotify.tv.android".equals(owner)||"com.spotify.music".equals(owner);}
    private void renderHome(){
        buildHero();if(apps.isEmpty())return;
        landingGap=new View(host);body.addView(landingGap,new LayoutParams(-1,0));
        appRow();landingBreak=new View(host);body.addView(landingBreak,new LayoutParams(-1,0));
        boolean recentFirst=prefs.getBoolean("home_apps_first",false);
        if(recentFirst)recentRow();
        if(!feed.continuing.isEmpty())programRow("Continue watching",feed.continuing);
        for(TvHomeFeed.Channel channel:feed.channels)programRow(channel.title,channel.programs);
        if(!recentFirst)recentRow();
    }
    private void recentRow(){
        ArrayList<App> recent=new ArrayList<>();try{org.json.JSONArray saved=new org.json.JSONArray(prefs.getString("recent_apps","[]"));for(int i=0;i<saved.length();i++){App app=apps.get(saved.getString(i));if(app!=null&&!recent.contains(app))recent.add(app);}}catch(org.json.JSONException ignored){}
        if(recent.isEmpty())return;heading("Recently opened",null);ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);for(App app:recent)addCircle(line,row,app,"recent:");
    }
    private void appRow(){int index=body.getChildCount();heading("Your apps",null);primaryHeading=body.getChildAt(index);ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);primaryRail=(View)line.getParent();for(App app:apps.values())addCircle(line,row,app,"home:");}
    private void height(View view,int value){android.view.ViewGroup.LayoutParams size=view.getLayoutParams();if(size.height!=value){size.height=value;view.setLayoutParams(size);}}
    private void layoutLandingPage(){
        if(closed||library||landingGap==null||landingBreak==null||landingHero==null||primaryHeading==null||primaryRail==null)return;
        int viewport=scroll.getHeight(),hero=landingHero.getMeasuredHeight(),appsHeight=primaryHeading.getMeasuredHeight()+primaryRail.getMeasuredHeight();if(viewport<=0||hero<=0||appsHeight<=0)return;
        int gap=Math.max(dp(8),viewport-hero-appsHeight-dp(24)),end=hero+gap+appsHeight;
        int boundary=Math.max(dp(24),viewport+dp(18)-end);height(landingGap,gap);height(landingBreak,boundary);
        if(landingRestoreY>=0&&landingGap.getMeasuredHeight()==gap&&landingBreak.getMeasuredHeight()==boundary){int y=landingRestoreY;landingRestoreY=-1;scroll.scrollTo(0,y);}
    }
    private void buildHero(){
        FrameLayout hero=new FrameLayout(host);landingHero=hero;body.addView(hero,new LayoutParams(-1,dp(142*host.interfaceScale())));
        LinearLayout words=new LinearLayout(host);words.setOrientation(VERTICAL);words.setGravity(Gravity.CENTER_VERTICAL);words.setPadding(dp(4),dp(6),dp(4),dp(8));
        int width=Math.max(dp(320),Math.round(getResources().getDisplayMetrics().widthPixels*.63f)-dp(72));hero.addView(words,new FrameLayout.LayoutParams(width,-1));
        heroSource=label("",10,0xffc5cde0,true);heroSource.setLetterSpacing(.12f);heroSource.setSingleLine(true);heroSource.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(heroSource);
        heroTitle=label("",28,TEXT,true);heroTitle.setMaxLines(2);heroTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);heroTitle.setPadding(0,dp(4),0,dp(7));words.addView(heroTitle,new LayoutParams(-1,-2));
        LinearLayout lower=new LinearLayout(host);lower.setGravity(Gravity.CENTER_VERTICAL);heroDetail=label("",11,MUTED,false);heroDetail.setSingleLine(true);heroDetail.setEllipsize(android.text.TextUtils.TruncateAt.END);
        heroOpen=label("Open",13,TEXT,true);heroOpen.setGravity(Gravity.CENTER);heroOpen.setShadowLayer(0,0,0,0);heroOpen.setPadding(dp(22),0,dp(22),0);focusable(heroOpen);heroOpen.setBackground(shape(0x803d4964,24,0));lower.addView(heroOpen,new LayoutParams(-2,dp(34)));LayoutParams detailSize=new LayoutParams(0,-2,1);detailSize.leftMargin=dp(14);lower.addView(heroDetail,detailSize);words.addView(lower,new LayoutParams(-1,-2));
        heroOpen.setOnClickListener(v->{if(heroProgram!=null)actions.program(heroProgram);else if(heroOwner!=null)actions.launch(heroOwner);});
        heroOpen.setOnLongClickListener(v->{if(heroOwner!=null)actions.menu(heroOwner);return true;});
        heroOpen.setOnFocusChangeListener((v,focus)->{heroOpen.setBackground(shape(focus?0xffe7ecfa:0x803d4964,24,0));heroOpen.setTextColor(focus?0xff142039:TEXT);if(focus){focusedKey="hero:open";actions.selected(heroOwner);}});
        focusViews.put("hero:open",heroOpen);ArrayList<View> row=new ArrayList<>();row.add(heroOpen);rows.add(row);showDefaultHero();
        if(apps.isEmpty()){heroOwner=null;heroProgram=null;heroTitle.setText("Your home starts here");heroSource.setText("SHADOWFOX HOME");heroDetail.setText("Choose the apps you want on Home");heroOpen.setText("Choose apps");heroOpen.setContentDescription("Choose apps for Home");heroOpen.setOnClickListener(v->actions.choose("apps"));}
    }
    private String groupName(String id){for(Group group:groups)if(group.id.equals(id))return group.name;return "Your apps";}
    private App defaultApp(){App chosen=apps.get(prefs.getString("home_quick_launch",""));return chosen!=null?chosen:apps.isEmpty()?null:apps.values().iterator().next();}
    private void showDefaultHero(){App app=defaultApp();if(app!=null){showAppHero(app);if(heroSource!=null){heroSource.setText("QUICK LAUNCH");heroSource.setTextColor(StudioStyle.AMBER);}}}
    private void showAppHero(App app){if(heroTitle==null)return;heroProgram=null;heroOwner=app.id;heroSource.setTextColor(StudioStyle.BLUE);heroSource.setText(groupName(app.category).toUpperCase(java.util.Locale.getDefault()));heroTitle.setText(app.name);heroDetail.setText(groupName(app.category));heroOpen.setContentDescription("Open "+app.name);}
    private void showProgramHero(TvHomeFeed.Program program){App app=apps.get(program.owner);if(heroTitle==null||app==null)return;heroProgram=program;heroOwner=program.owner;heroSource.setTextColor(StudioStyle.BLUE);heroSource.setText(app.name.toUpperCase(java.util.Locale.getDefault()));heroTitle.setText(program.title);heroDetail.setText("Open in "+app.name);heroOpen.setContentDescription("Open "+program.title+" in "+app.name);}
    private void renderLibrary(){
        ArrayList<App> visible=new ArrayList<>();for(App app:apps.values())if(category.isEmpty()||category.equals(app.category))visible.add(app);
        heading(category.isEmpty()?"Your apps":groupName(category),visible.size()+ (visible.size()==1?" app":" apps"));ArrayList<View> filters=new ArrayList<>();LinearLayout line=rail(filters);
        filter(line,filters,"All apps","",category.isEmpty());for(Group g:groups)filter(line,filters,g.name,g.id,g.id.equals(category));
        int available=getResources().getDisplayMetrics().widthPixels-body.getPaddingLeft()-body.getPaddingRight()-dp(8);int density=prefs.getInt("app_density",0);int columns=density>=1&&density<=4?density+3:Math.max(4,Math.min(9,available/dp(130)));columns=Math.min(columns,Math.max(3,available/dp(112)));
        LinearLayout gridRow=null;ArrayList<View> nodes=null;
        for(int i=0;i<visible.size();i++){
            if(i%columns==0){gridRow=new LinearLayout(host);gridRow.setClipChildren(false);gridRow.setClipToPadding(false);body.addView(gridRow,new LayoutParams(-1,-2));nodes=new ArrayList<>();rows.add(nodes);}
            View v=circle(visible.get(i),"app:");LayoutParams size=new LayoutParams(available/columns,-2);size.bottomMargin=dp(16);gridRow.addView(v,size);nodes.add(v);
        }
        if(visible.isEmpty())empty("Choose apps for this category",()->actions.choose(category.isEmpty()?"apps":category));
    }
    private void filter(LinearLayout line,ArrayList<View> row,String title,String id,boolean selected){
        TextView chip=label(title,13,TEXT,selected);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(20),dp(11),dp(20),dp(11));focusable(chip);String key="category:"+id;focusViews.put(key,chip);
        chip.setBackground(shape(selected?0x80596381:0x40303950,24,0));
        chip.setOnFocusChangeListener((v,focus)->{chip.setBackground(shape(focus?0xffe5e8f6:selected?0x80596381:0x40303950,24,0));chip.setTextColor(focus?0xff172137:TEXT);if(focus){focusedKey=key;actions.selected(null);}});
        chip.setOnClickListener(v->{category=id;render(false);View next=focusViews.get(key);if(next!=null)next.requestFocusFromTouch();});LayoutParams size=new LayoutParams(-2,dp(42));size.rightMargin=dp(10);line.addView(chip,size);row.add(chip);
    }
    private void empty(String title,Runnable action){TextView v=label(title,16,TEXT,true);v.setPadding(dp(24),dp(20),dp(24),dp(20));focusable(v);v.setBackground(shape(0x70464b65,18,0));v.setOnFocusChangeListener((w,f)->v.setBackground(shape(f?0xb05a6685:0x70464b65,18,f?TEXT:0)));v.setOnClickListener(w->action.run());body.addView(v,new LayoutParams(-1,-2));ArrayList<View> row=new ArrayList<>();row.add(v);rows.add(row);}
    private void addCircle(LinearLayout line,ArrayList<View> row,App app,String prefix){View v=circle(app,prefix);LayoutParams size=new LayoutParams(dp(126),-2);size.rightMargin=dp(12);line.addView(v,size);row.add(v);}
    private View circle(App app,String prefix){
        LinearLayout tile=new LinearLayout(host);tile.setOrientation(VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(4),dp(5),dp(4));
        int[] sizes={72,88,102};int size=sizes[Math.max(0,Math.min(2,prefs.getInt("icon_size",1)))];
        if(app.artwork==null)app.artwork=new HomeIconView.Artwork(host,app.icon,app.customArtwork);
        int fill=HomeTransparency.boxes(prefs)?HomeTransparency.fill(prefs,0xff353d58,true):0;
        HomeIconView icon=new HomeIconView(host,app.artwork,fill);tile.addView(icon,new LayoutParams(dp(size),dp(size)));
        TextView name=label(app.name,12,TEXT,false);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setMinLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(0,dp(6),0,0);
        if(prefs.getBoolean("show_app_names",true))tile.addView(name,new LayoutParams(-1,-2));
        bindApp(tile,app,prefix+app.id,focused->{icon.highlight(focused);name.setTextColor(focused?TEXT:MUTED);});return tile;
    }
    private Drawable copy(Drawable drawable){if(drawable==null)return null;Drawable.ConstantState state=drawable.getConstantState();return state==null?drawable:state.newDrawable(getResources()).mutate();}
    private FrameLayout card(){FrameLayout card=new FrameLayout(host);card.setBackground(shape(0xb01a2438,12,0));card.setClipToOutline(true);return card;}
    private int posterHeight(){float width=getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density;return Math.round(Math.max(106,Math.min(120,(width-100)/9.6f)));}
    private int cardWidth(){return Math.round(posterHeight()*16f/9);}
    private LinearLayout captionCard(FrameLayout image,String title,int width){
        LinearLayout root=new LinearLayout(host);root.setOrientation(VERTICAL);root.setClipChildren(false);root.setClipToPadding(false);root.addView(image,new LayoutParams(dp(width),dp(posterHeight())));
        TextView caption=label(title,12,MUTED,false);caption.setSingleLine(true);caption.setEllipsize(android.text.TextUtils.TruncateAt.END);caption.setPadding(dp(3),dp(7),dp(3),dp(1));root.addView(caption,new LayoutParams(-1,-2));return root;
    }
    private void paintCard(LinearLayout root,FrameLayout frame,boolean focus){frame.setForeground(shape(0,12,focus?TEXT:0));StudioStyle.focusMotion(frame,focus,1.025f,0);((TextView)root.getChildAt(1)).setTextColor(focus?TEXT:MUTED);}
    private void addWideApp(LinearLayout line,ArrayList<View> row,App app,String prefix){
        FrameLayout frame=card();ImageView art=new ImageView(host);art.setScaleType(ImageView.ScaleType.FIT_CENTER);art.setImageDrawable(copy(app.banner==null?app.icon:app.banner));if(app.banner==null)art.setPadding(dp(24),dp(12),dp(24),dp(12));frame.addView(art,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout root=captionCard(frame,app.name,cardWidth());bindApp(root,app,prefix+app.id,focus->paintCard(root,frame,focus));addCard(line,row,root,cardWidth());
    }
    private void addCard(LinearLayout line,ArrayList<View> row,View card,int width){LayoutParams size=new LayoutParams(dp(width),-2);size.rightMargin=dp(18);line.addView(card,size);row.add(card);}
    private void bindApp(View v,App app,String key,Consumer<Boolean> paint){
        focusable(v);v.setContentDescription(app.name);focusViews.put(key,v);v.setOnClickListener(w->actions.launch(app.id));v.setOnLongClickListener(w->{actions.menu(app.id);return true;});
        v.setOnFocusChangeListener((w,focused)->{paint.accept(focused);if(focused){focusedKey=key;actions.selected(app.id);showAppHero(app);}});
    }
    private int programWidth(TvHomeFeed.Program program){
        float ratio=program.aspect==3?1f:program.aspect==4?2f/3:program.aspect==2?4f/3:program.aspect==1?3f/2:16f/9;
        return Math.max(82,Math.round(posterHeight()*ratio));
    }
    private void programRow(String title,List<TvHomeFeed.Program> programs){
        if(programs.isEmpty())return;heading(title==null||title.isEmpty()?"From your apps":title,null);ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);
        for(TvHomeFeed.Program program:programs){
            App app=apps.get(program.owner);if(app==null)continue;FrameLayout frame=card();ImageView image=new ImageView(host);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setImageDrawable(copy(app.icon));image.setPadding(dp(24),dp(20),dp(24),dp(20));frame.addView(image,new FrameLayout.LayoutParams(-1,-1));
            if(program.duration>0&&program.position>0){ProgressBar progress=new ProgressBar(host,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgress((int)Math.min(1000,program.position*1000d/program.duration));progress.setProgressTintList(android.content.res.ColorStateList.valueOf(StudioStyle.BLUE));frame.addView(progress,new FrameLayout.LayoutParams(-1,dp(3),Gravity.BOTTOM));}
            Bitmap known=program.poster==null?null:posterCache.get(program.poster);int width=known==null?programWidth(program):posterWidth(known);LinearLayout root=captionCard(frame,program.title,width);image.setTag(root);loadPoster(program.poster,image);focusable(root);root.setContentDescription(program.title+" · "+app.name);focusViews.put(program.key,root);root.setOnClickListener(v->actions.program(program));root.setOnLongClickListener(v->{actions.menu(app.id);return true;});
            root.setOnFocusChangeListener((v,focus)->{paintCard(root,frame,focus);if(focus){focusedKey=program.key;actions.selected(app.id);showProgramHero(program);}});addCard(line,row,root,width);
        }
    }
    private void linkRows(){
        rows.removeIf(row->row.isEmpty());
        for(int r=0;r<rows.size();r++){ArrayList<View> row=rows.get(r);for(int c=0;c<row.size();c++){
            View v=row.get(c);v.setNextFocusLeftId(row.get(Math.max(0,c-1)).getId());v.setNextFocusRightId(row.get(Math.min(row.size()-1,c+1)).getId());
            v.setNextFocusUpId(r==0?(library?appsTab:homeTab).getId():rows.get(r-1).get(Math.min(c,rows.get(r-1).size()-1)).getId());
            v.setNextFocusDownId(r+1<rows.size()?rows.get(r+1).get(Math.min(c,rows.get(r+1).size()-1)).getId():v.getId());
        }}
        // Category chips are filters, rather than columns aligned with the grid.
        if(library&&rows.size()>1){
            View selected=focusViews.get("category:"+category);
            for(View filter:rows.get(0))filter.setNextFocusDownId(rows.get(1).get(0).getId());
            if(selected!=null)for(View app:rows.get(1))app.setNextFocusUpId(selected.getId());
        }
        for(View v:nav)v.setNextFocusDownId(rows.isEmpty()?v.getId():rows.get(0).get(0).getId());
    }
    private void loadPoster(String uri,ImageView target){
        if(uri==null||uri.isEmpty()||closed)return;Bitmap cached=posterCache.get(uri);if(cached!=null){applyPoster(target,cached);return;}
        posterViews.computeIfAbsent(uri,k->new ArrayList<>()).add(target);if(!queuedPosters.add(uri))return;
        posters.execute(()->{Bitmap bitmap=null;try{byte[] bytes=posterBytes(uri);if(bytes!=null){BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);if(options.outWidth>0&&options.outHeight>0){options.inSampleSize=1;while(options.outWidth/options.inSampleSize>640||options.outHeight/options.inSampleSize>400)options.inSampleSize*=2;options.inJustDecodeBounds=false;bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);}}}catch(Exception|OutOfMemoryError ignored){}
            final Bitmap decoded=bitmap;handler.post(()->{queuedPosters.remove(uri);if(closed)return;ArrayList<ImageView> targets=posterViews.remove(uri);if(decoded!=null){posterCache.put(uri,decoded);if(targets!=null)for(ImageView v:targets)applyPoster(v,decoded);}});
        });
    }
    private int posterWidth(Bitmap bitmap){return Math.max(82,Math.min(cardWidth(),Math.round(posterHeight()*bitmap.getWidth()/(float)Math.max(1,bitmap.getHeight()))));}
    private void applyPoster(ImageView view,Bitmap bitmap){
        view.setPadding(0,0,0,0);view.setScaleType(ImageView.ScaleType.FIT_CENTER);view.setImageBitmap(bitmap);
        if(view.getTag() instanceof LinearLayout){
            LinearLayout card=(LinearLayout)view.getTag();int width=dp(posterWidth(bitmap));android.view.ViewGroup.LayoutParams artSize=card.getChildAt(0).getLayoutParams();artSize.width=width;card.getChildAt(0).setLayoutParams(artSize);
            android.view.ViewGroup.LayoutParams cardSize=card.getLayoutParams();if(cardSize!=null&&cardSize.width!=width){cardSize.width=width;card.setLayoutParams(cardSize);}
            View selected=findFocus();if(selected!=null&&selected!=heroOpen&&!nav.contains(selected))selected.post(()->{if(selected.isAttachedToWindow()&&selected.hasFocus())selected.requestRectangleOnScreen(new Rect(0,0,selected.getWidth(),selected.getHeight()),true);});
        }
    }
    private byte[] posterBytes(String value)throws IOException{
        Uri uri=Uri.parse(value);String scheme=uri.getScheme();InputStream input;HttpURLConnection connection=null;
        if("https".equalsIgnoreCase(scheme)){
            URL url=new URL(value);input=null;
            for(int redirects=0;redirects<=3;redirects++){
                if(!"https".equalsIgnoreCase(url.getProtocol())||url.getHost().isEmpty()||url.getUserInfo()!=null)return null;
                connection=(HttpURLConnection)url.openConnection();connection.setConnectTimeout(4500);connection.setReadTimeout(4500);connection.setInstanceFollowRedirects(false);int status=connection.getResponseCode();
                if(status==301||status==302||status==303||status==307||status==308){String next=connection.getHeaderField("Location");connection.disconnect();connection=null;if(next==null)return null;url=new URL(url,next);continue;}
                if(status!=200){connection.disconnect();return null;}input=connection.getInputStream();break;
            }
            if(input==null)return null;
        }else if("content".equalsIgnoreCase(scheme)||"android.resource".equalsIgnoreCase(scheme))input=host.getContentResolver().openInputStream(uri);else return null;
        try(InputStream stream=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(stream==null)return null;byte[] buffer=new byte[8192];int n;while((n=stream.read(buffer))!=-1){if(Thread.currentThread().isInterrupted()||out.size()+n>3*1024*1024)return null;out.write(buffer,0,n);}return out.toByteArray();
        }finally{if(connection!=null)connection.disconnect();}
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();scroll.getViewTreeObserver().addOnGlobalLayoutListener(landingLayout);try{host.getContentResolver().registerContentObserver(Uri.parse("content://android.media.tv"),true,observer);observing=true;}catch(RuntimeException ignored){}}
    void close(){if(closed)return;closed=true;if(scroll.getViewTreeObserver().isAlive())scroll.getViewTreeObserver().removeOnGlobalLayoutListener(landingLayout);request++;if(query!=null)query.cancel();handler.removeCallbacksAndMessages(null);if(observing){host.getContentResolver().unregisterContentObserver(observer);observing=false;}feedWorker.shutdownNow();posters.shutdownNow();posterCache.evictAll();posterViews.clear();}
    @Override protected void onDetachedFromWindow(){close();super.onDetachedFromWindow();}
}
