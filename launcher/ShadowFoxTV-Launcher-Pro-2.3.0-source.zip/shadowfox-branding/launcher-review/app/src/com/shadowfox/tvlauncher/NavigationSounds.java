package com.shadowfox.tvlauncher;

import android.app.Activity;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

/** Uses the device's UI-effects setting; never changes playback volume or routing. */
final class NavigationSounds {
    private final Activity host;
    private final ArrayList<WeakReference<View>> roots=new ArrayList<>();
    private boolean enabled,watching;
    private final ContentObserver observer=new ContentObserver(new Handler(Looper.getMainLooper())) {
        @Override public void onChange(boolean selfChange){refresh();}
    };
    NavigationSounds(Activity host){this.host=host;refresh();}
    boolean enabled(){refresh();return enabled;}
    boolean canChange(){return Settings.System.canWrite(host);}
    void configure(View view){view.setSoundEffectsEnabled(enabled);}
    void bind(View root){
        for(WeakReference<View> entry:roots)if(entry.get()==root){apply(root);return;}
        roots.add(new WeakReference<>(root));apply(root);
    }
    private void apply(View view){
        configure(view);
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)apply(group.getChildAt(i));}
    }
    private void refresh(){
        enabled=Settings.System.getInt(host.getContentResolver(),Settings.System.SOUND_EFFECTS_ENABLED,0)!=0;
        Iterator<WeakReference<View>> entries=roots.iterator();while(entries.hasNext()){View root=entries.next().get();if(root==null)entries.remove();else apply(root);}
    }
    boolean setEnabled(boolean value){
        if(!canChange())return false;
        try{
            if(!Settings.System.putInt(host.getContentResolver(),Settings.System.SOUND_EFFECTS_ENABLED,value?1:0))return false;
            refresh();
            if(enabled!=value)return false;
            if(value){try{AudioManager audio=(AudioManager)host.getSystemService(Activity.AUDIO_SERVICE);if(audio!=null)audio.loadSoundEffects();}catch(RuntimeException failure){android.util.Log.w("ShadowFoxSounds","Sound setting saved; sound effects could not be loaded",failure);}}
            return true;
        }catch(SecurityException failure){return false;}
    }
    void start(){
        refresh();if(!watching){host.getContentResolver().registerContentObserver(Settings.System.getUriFor(Settings.System.SOUND_EFFECTS_ENABLED),false,observer);watching=true;}
    }
    void stop(){if(watching){host.getContentResolver().unregisterContentObserver(observer);watching=false;}}
}
