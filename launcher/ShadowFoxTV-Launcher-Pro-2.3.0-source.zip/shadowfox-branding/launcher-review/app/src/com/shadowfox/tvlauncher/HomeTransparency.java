package com.shadowfox.tvlauncher;

import android.content.SharedPreferences;

/** Home material opacity is independent of text, icons and the focus outline. */
final class HomeTransparency {
    static final String ENABLED="home_transparency",BANNER="banner_transparency",APPS="app_box_transparency",TILES="app_tile_boxes";
    static final int DEFAULT=75;
    static final int[] LEVELS={0,25,50,75,90,100};
    static final String[] NAMES={"0% · Solid","25%","50%","75%","90%","100% · Clear"};
    static boolean enabled(SharedPreferences preferences){return preferences.getBoolean(ENABLED,true);}
    static boolean boxes(SharedPreferences preferences){return preferences.getBoolean(TILES,false);}
    static String key(boolean appBoxes){return appBoxes?APPS:BANNER;}
    static int percent(SharedPreferences preferences,boolean appBoxes){return Math.max(0,Math.min(100,preferences.getInt(key(appBoxes),DEFAULT)));}
    static int fill(SharedPreferences preferences,int colour,boolean appBoxes){
        int alpha=enabled(preferences)?Math.round(255*(100-percent(preferences,appBoxes))/100f):255;
        return (colour&0x00ffffff)|(alpha<<24);
    }
    static String value(SharedPreferences preferences,boolean appBoxes){return percent(preferences,appBoxes)+"%"+(enabled(preferences)?"":" saved");}
}
