package com.shadowfox.tvlauncher;

import android.app.AlertDialog;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** A TV settings workspace. The rail and each page retain separate focus positions. */
final class TvSettings {
    static final int BG=0xff0c121c, SURFACE=0xff131d2b, TEXT=0xffeff4fa,
        MUTED=0xffa7b7c9, ACCENT=StudioStyle.BLUE;
    static final class Row {
        final String title,detail,value,group; final Runnable action;
        boolean closeOnSelect=true;
        Row(String group,String title,String detail,String value,Runnable action){
            this.group=group;this.title=title;this.detail=detail;this.value=value;this.action=action;
        }
        Row keepOpen(){closeOnSelect=false;return this;}
    }
    static final class Page {
        final String title,description; final Row[] rows;
        Page(String title,String description,Row... rows){this.title=title;this.description=description;this.rows=rows;}
    }
    private final MainActivity host;
    private final AlertDialog dialog;
    private final Page[] pages;
    private final LinearLayout content;
    private final TextView heading,description;
    private final ScrollView scroll;
    private final ArrayList<View> rail=new ArrayList<>(),rows=new ArrayList<>();
    private final int[] remembered;
    private int selected=-1;
    private TvSettings(MainActivity host,Page[] pages,int page,int row,Runnable close){
        this.host=host;this.pages=pages;remembered=new int[pages.length];
        int start=Math.max(0,Math.min(page,pages.length-1));remembered[start]=row;
        LinearLayout shell=new LinearLayout(host);shell.setOrientation(LinearLayout.HORIZONTAL);shell.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout nav=new LinearLayout(host);nav.setOrientation(LinearLayout.VERTICAL);nav.setPadding(dp(22),dp(24),dp(18),dp(22));nav.setBackground(StudioStyle.surface(host,0xad0b121d,0,false));
        shell.addView(nav,new LinearLayout.LayoutParams(dp(228),-1));
        LinearLayout identity=new LinearLayout(host);identity.setGravity(Gravity.CENTER_VERTICAL);
        ImageView fox=new ImageView(host);fox.setImageResource(R.drawable.shadowfox_logo);fox.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams emblem=new LinearLayout.LayoutParams(dp(36),dp(36));emblem.rightMargin=dp(10);identity.addView(fox,emblem);
        LinearLayout names=new LinearLayout(host);names.setOrientation(LinearLayout.VERTICAL);TextView brand=label("SHADOWFOX",12,TEXT,true);brand.setLetterSpacing(.10f);names.addView(brand);TextView edition=label("LAUNCHER PRO",9,ACCENT,true);edition.setLetterSpacing(.13f);edition.setPadding(0,dp(4),0,0);names.addView(edition);identity.addView(names);nav.addView(identity);
        TextView title=label("Settings",28,TEXT,true);title.setPadding(0,dp(15),0,dp(19));nav.addView(title);
        FrameLayout glass=new FrameLayout(host);glass.setMinimumHeight(host.getResources().getDisplayMetrics().heightPixels);glass.addView(host.createSettingsBackdrop(),new FrameLayout.LayoutParams(-1,-1));glass.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        dialog=host.trackDialog(new AlertDialog.Builder(host).create());
        dialog.setOnCancelListener(d->close.run());
        for(int i=0;i<pages.length;i++){
            final int index=i;
            LinearLayout item=new LinearLayout(host);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(12),0,dp(10),0);item.setContentDescription(pages[i].title);
            ImageView icon=new ImageView(host);icon.setImageDrawable(new Symbol(i));icon.setPadding(dp(6),dp(6),dp(6),dp(6));icon.setBackground(shape(0x163d9ad3,Color.TRANSPARENT,10));LinearLayout.LayoutParams art=new LinearLayout.LayoutParams(dp(30),dp(30));art.rightMargin=dp(11);item.addView(icon,art);
            item.addView(label(pages[i].title,15,TEXT,true));
            focusable(item);item.setOnFocusChangeListener((v,focused)->{if(focused)render(index);paintRail();});
            item.setOnClickListener(v->{render(index);focusContent();});
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(-1,dp(46));size.bottomMargin=dp(6);nav.addView(item,size);rail.add(item);
        }
        View spacer=new View(host);nav.addView(spacer,new LinearLayout.LayoutParams(1,0,1));
        TextView exit=label("‹  Back to Home",14,MUTED,true);exit.setPadding(dp(12),dp(12),dp(8),dp(12));focusable(exit);
        exit.setOnFocusChangeListener((v,f)->v.setBackground(shape(f?0xff25364a:Color.TRANSPARENT,f?ACCENT:Color.TRANSPARENT,10)));
        exit.setOnClickListener(v->dialog.cancel());nav.addView(exit);rail.add(exit);
        for(int i=0;i<rail.size();i++){
            View v=rail.get(i);v.setNextFocusUpId(rail.get(Math.max(0,i-1)).getId());v.setNextFocusDownId(rail.get(Math.min(rail.size()-1,i+1)).getId());v.setNextFocusLeftId(v.getId());
            v.setOnKeyListener((view,code,event)->{if(code==KeyEvent.KEYCODE_DPAD_RIGHT){if(event.getAction()==KeyEvent.ACTION_DOWN)focusContent();return true;}return false;});
        }
        LinearLayout main=new LinearLayout(host);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(dp(28),dp(24),dp(28),dp(18));shell.addView(main,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout hero=new LinearLayout(host);hero.setGravity(Gravity.CENTER_VERTICAL);hero.setPadding(dp(3),dp(8),dp(3),dp(10));
        LinearLayout intro=new LinearLayout(host);intro.setOrientation(LinearLayout.VERTICAL);TextView eyebrow=label("MAKE IT YOURS",9,StudioStyle.AMBER,true);eyebrow.setLetterSpacing(.18f);intro.addView(eyebrow);
        heading=label("",26,TEXT,true);heading.setPadding(0,dp(8),0,0);intro.addView(heading);
        description=label("",12,MUTED,false);description.setPadding(0,dp(8),dp(15),0);intro.addView(description);hero.addView(intro,new LinearLayout.LayoutParams(0,-2,1));
        main.addView(hero,new LinearLayout.LayoutParams(-1,-2));
        View gap=new View(host);main.addView(gap,new LinearLayout.LayoutParams(1,dp(18)));
        scroll=new ScrollView(host);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);scroll.setPadding(dp(3),dp(3),dp(3),dp(6));
        content=new LinearLayout(host);content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=label("↑ ↓  Navigate     OK  Select     ←  Categories     Back  Home",10,MUTED,false);hint.setPadding(dp(6),dp(12),0,0);main.addView(hint);
        dialog.setOnShowListener(d->{
            // Own the content frame; Fire OS constrains AlertController's custom panel.
            dialog.setContentView(glass,new ViewGroup.LayoutParams(-1,-1));
            Window window=dialog.getWindow();window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));window.getDecorView().setPadding(0,0,0,0);
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
            window.setLayout(-1,-1);window.setDimAmount(0);window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            render(start);if(row<0)rail.get(start).requestFocusFromTouch();else focusContent();
        });
    }
    static AlertDialog show(MainActivity host,Page[] pages,int page,int row,Runnable close){TvSettings settings=new TvSettings(host,pages,page,row,close);settings.dialog.show();return settings.dialog;}
    private void render(int index){
        if(index==selected)return;selected=index;Page page=pages[index];heading.setText(page.title);description.setText(page.description);content.removeAllViews();rows.clear();
        String group="";
        for(int i=0;i<page.rows.length;i++){
            final int position=i;Row data=page.rows[i];
            if(!data.group.equals(group)){
                group=data.group;TextView section=label(group.toUpperCase(Locale.ROOT),9,MUTED,true);section.setLetterSpacing(.16f);section.setPadding(dp(3),i==0?0:dp(13),0,dp(8));content.addView(section);
            }
            LinearLayout item=new LinearLayout(host);item.setOrientation(LinearLayout.HORIZONTAL);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(18),dp(13),dp(16),dp(13));item.setMinimumHeight(dp(64));focusable(item);item.setContentDescription(data.title);
            TextView glyph=label(controlGlyph(data.title),12,ACCENT,true);glyph.setGravity(Gravity.CENTER);LinearLayout.LayoutParams glyphSize=new LinearLayout.LayoutParams(dp(29),dp(29));glyphSize.rightMargin=dp(14);item.addView(glyph,glyphSize);
            LinearLayout words=new LinearLayout(host);words.setOrientation(LinearLayout.VERTICAL);TextView name=label(data.title,15,TEXT,true);words.addView(name);
            if(!data.detail.isEmpty()){TextView sub=label(data.detail,12,MUTED,false);sub.setPadding(0,dp(4),0,0);words.addView(sub);}
            item.addView(words,new LinearLayout.LayoutParams(0,-2,1));
            if(!data.value.isEmpty()){
                TextView value=label(data.value,11,ACCENT,true);value.setMaxWidth(dp(158));value.setGravity(Gravity.CENTER);value.setPadding(dp(11),dp(7),dp(11),dp(7));LinearLayout.LayoutParams pill=new LinearLayout.LayoutParams(-2,-2);pill.leftMargin=dp(10);pill.rightMargin=dp(12);item.addView(value,pill);
            }
            item.addView(label("›",23,MUTED,false));item.setBackground(StudioStyle.optionSurface(host,false,false));
            item.setOnFocusChangeListener((v,focused)->{v.setBackground(StudioStyle.optionSurface(host,false,focused));v.setElevation(0);StudioStyle.focusMotion(v,focused,1f,0);if(focused){remembered[selected]=position;paintRail();}});
            item.setOnClickListener(v->{if(data.closeOnSelect)dialog.dismiss();data.action.run();});
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(-1,-2);size.bottomMargin=dp(6);content.addView(item,size);rows.add(item);
        }
        for(int i=0;i<rows.size();i++){
            View v=rows.get(i);v.setNextFocusUpId(rows.get(Math.max(0,i-1)).getId());v.setNextFocusDownId(rows.get(Math.min(rows.size()-1,i+1)).getId());v.setNextFocusLeftId(rail.get(index).getId());v.setNextFocusRightId(v.getId());
        }
        scroll.scrollTo(0,0);paintRail();host.bindSettingsSounds(content);
    }
    private void focusContent(){if(!rows.isEmpty())rows.get(Math.max(0,Math.min(remembered[selected],rows.size()-1))).requestFocusFromTouch();}
    private String controlGlyph(String title){
        switch(title){
            case "Colour theme":case "Theme background":return "◈";
            case "Font":return "Aa";case "Text size":return "Tt";case "Brand lettering":case "Studio wallpaper":case "Original artwork":return "SF";
            case "ShadowFox Exclusive Wallpapers":return "SF";
            case "Home layout":case "Manage apps":return "▦";case "Apps across":return "↔";case "Icon size":return "↗";
            case "Home transparency":case "Banner transparency":case "App box transparency":return "◐";
            case "App tile boxes":return "▣";
            case "App names":return "Ab";case "Date & time":return "◷";case "Icon pack":return "◇";
            case "Choose an image":return "▧";case "Wallpaper dimming":return "◐";case "Categories":return "≡";
            case "Refresh apps":case "Restore appearance defaults":return "↻";case "Navigation sounds":return "♪";
            case "Default Home":return "⌂";case "Android settings":return "⚙";case "Check for updates":return "↓";default:return "⋯";
        }
    }
    private void paintRail(){
        for(int i=0;i<pages.length;i++){
            View item=rail.get(i);item.setBackground(i==selected||item.hasFocus()?StudioStyle.surface(host,i==selected?0xb52b4058:0x60405b73,12,item.hasFocus()):shape(Color.TRANSPARENT,Color.TRANSPARENT,12));
        }
    }
    private void focusable(View v){v.setId(View.generateViewId());v.setFocusable(true);v.setClickable(true);}
    private TextView label(String text,int size,int color,boolean bold){return StudioStyle.label(host,text,size,color,bold);}
    private int dp(int value){return Math.round(value*host.getResources().getDisplayMetrics().density);}
    private GradientDrawable shape(int fill,int stroke,int radius){GradientDrawable shape=new GradientDrawable();shape.setColor(fill);shape.setCornerRadius(dp(radius));shape.setStroke(dp(1),stroke);return shape;}
    /** Small vector symbols stay sharp at every TV resolution. */
    private static final class Symbol extends Drawable {
        private final int kind;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        Symbol(int kind){this.kind=kind;}
        @Override public void draw(Canvas canvas){
            canvas.save();canvas.translate(getBounds().left,getBounds().top);canvas.scale(getBounds().width()/24f,getBounds().height()/24f);paint.setColor(ACCENT);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.6f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
            if(kind==0){canvas.drawCircle(12,12,8,paint);canvas.drawCircle(9,9,1,paint);canvas.drawCircle(15,8,1,paint);canvas.drawCircle(7,14,1,paint);canvas.drawLine(13,19,16,14,paint);}
            else if(kind==1){canvas.drawRoundRect(3,4,21,18,2,2,paint);canvas.drawLine(8,22,16,22,paint);canvas.drawLine(12,18,12,22,paint);canvas.drawLine(7,8,17,8,paint);canvas.drawLine(7,12,12,12,paint);}
            else if(kind==2){canvas.drawRoundRect(3,3,21,21,3,3,paint);canvas.drawCircle(8,8,1.5f,paint);Path p=new Path();p.moveTo(4,18);p.lineTo(10,12);p.lineTo(14,16);p.lineTo(17,12);p.lineTo(21,17);canvas.drawPath(p,paint);}
            else if(kind==3){for(int y=4;y<=14;y+=10)for(int x=4;x<=14;x+=10)canvas.drawRoundRect(x,y,x+6,y+6,1,1,paint);}
            else if(kind==4){Path p=new Path();p.moveTo(4,9);p.lineTo(8,9);p.lineTo(13,5);p.lineTo(13,19);p.lineTo(8,15);p.lineTo(4,15);p.close();canvas.drawPath(p,paint);canvas.drawArc(12,5,22,19,-55,110,false,paint);}
            else{canvas.drawArc(4,4,20,20,35,285,false,paint);canvas.drawLine(20,4,20,10,paint);canvas.drawLine(15,10,20,10,paint);canvas.drawLine(12,8,12,13,paint);canvas.drawLine(12,13,9,15,paint);}
            canvas.restore();
        }
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
}
