package com.shadowfox.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Path;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.io.*;
import org.json.*;

/** TV home with explicit update checks and a network connection indicator. */
public final class MainActivity extends Activity {
    private PackageManager packages;
    private LinearLayout grid;
    private View firstApp;
    private ScrollView homeScroll;
    private final Set<View> topRowApps=new HashSet<>();
    private View appearance;
    private View customizeControl;
    private int columns;
    private int tileWidth;
    private SharedPreferences preferences;
    private final Set<AlertDialog> openDialogs=new HashSet<>();
    private final java.util.concurrent.ExecutorService imageWorker=java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean imageSaving;
    private final ArrayList<Theme> themes = new ArrayList<>();
    private Theme theme;
    private Typeface font;
    private float fontScale;
    private int foreground, secondary;
    private android.graphics.drawable.Drawable homeWallpaperArtwork;
    private ConnectivityManager connectivity;
    private NavigationSounds navigationSounds;
    private LauncherUpdates launcherUpdates;
    private Boolean pendingNavigationSounds;
    private static final int SOUND_ACCESS=403;
    private boolean networkWatching;
    private StatusIcon networkIcon;
    private final ConnectivityManager.NetworkCallback networkChanges=new ConnectivityManager.NetworkCallback() {
        @Override public void onAvailable(Network network) { refreshNetwork(); }
        @Override public void onLost(Network network) { refreshNetwork(); }
        @Override public void onCapabilitiesChanged(Network network,NetworkCapabilities caps) { refreshNetwork(); }
    };
    private final Map<String,ResolveInfo> installed = new LinkedHashMap<>();
    private final Map<String,String> appLabels=new HashMap<>();
    private final ArrayList<String> appOrder = new ArrayList<>();
    private final ArrayList<Category> categories=new ArrayList<>();
    private String pendingIcon;
    private Uri pendingImagePermissionUri;
    private String pendingImagePermissionIcon;
    private boolean pendingImagePermissionWallpaper;
    private static final int IMAGE_ACCESS=406;
    private ProjectivyIcons iconPack;
    private static final int PICK_ICON=401;
    private static final int PICK_WALLPAPER=402;
    private static final String[] DIM_NAMES={"Light", "Medium", "Dark"};
    private static final int[] DIM_COLOURS={0x55000000,0x8c000000,0xbf000000};
    private static final String[] FONT_NAMES = {"Default", "Condensed", "Rounded"};
    private static final String[] FONT_FAMILIES = {"sans-serif", "sans-serif-condensed", "sans-serif-rounded"};
    private static final String[] SIZE_NAMES = {"Small", "Standard", "Large"};
    private static final float[] FONT_SCALES = {.9f, 1f, 1.12f};
    private static final String[] BRAND_NAMES = {"ShadowFox colours", "All silver", "Theme accent"};
    private static final String[] TILE_NAMES = {"Transparent", "Glass", "Solid"};
    private static final String[] ICON_SIZE_NAMES={"Compact","Standard","Large"};
    private static final int[] ICON_SIZES={48,64,76};
    private final Map<String,View> appViews=new LinkedHashMap<>();
    private final ArrayList<ArrayList<View>> shelfViews=new ArrayList<>();
    private String selectedApp;
    private String movingApp;
    private ArrayList<String> orderBeforeMove;
    private TextView homeHint;
    private View shelfSpacer;
    private static final String[] HOME_LAYOUT_NAMES={"Wallpaper showcase","App dashboard"};
    private static final String[] DENSITY_NAMES={"Automatic","4 apps across","5 apps across","6 apps across","7 apps across"};
    private static final int[] DENSITIES={0,4,5,6,7};
    private static final class Category {
        final String id; String name;
        Category(String id,String name) { this.id=id; this.name=name; }
    }
    private void loadCategories() {
        categories.clear();
        try {
            JSONArray saved=new JSONArray(preferences.getString("categories","[]"));
            for(int i=0;i<saved.length();i++) {
                JSONObject entry=saved.getJSONObject(i); categories.add(new Category(entry.getString("id"),entry.getString("name")));
            }
        } catch(JSONException error) { categories.clear(); }
        if(categories.stream().noneMatch(c->c.id.equals("apps"))) categories.add(0,new Category("apps","Your Apps"));
    }
    private void saveCategories() {
        JSONArray values=new JSONArray();
        try { for(Category category:categories) values.put(new JSONObject().put("id",category.id).put("name",category.name)); }
        catch(JSONException error) { throw new IllegalStateException(error); }
        preferences.edit().putString("categories",values.toString()).apply();
    }
    private String appCategory(String id) {
        String saved=preferences.getString("category_"+id,"apps");
        for(Category category:categories) if(category.id.equals(saved)) return saved;
        return "apps";
    }

    private static final class Theme {
        final String id, name;
        final int bg, surface, surface2, accent;
        final boolean light, metallic;
        Theme(JSONObject value) throws JSONException {
            id=value.getString("id"); name=value.getString("name");
            bg=Color.parseColor(value.getString("bg")); surface=Color.parseColor(value.getString("s"));
            surface2=Color.parseColor(value.getString("s2")); accent=Color.parseColor(value.getString("accent"));
            light=value.optBoolean("light"); metallic=value.optBoolean("metallic");
        }
    }
    private void loadThemes() {
        try (InputStream stream=getAssets().open("themes.json")) {
            ByteArrayOutputStream bytes=new ByteArrayOutputStream(); byte[] buffer=new byte[4096]; int n;
            while((n=stream.read(buffer))!=-1) bytes.write(buffer,0,n);
            JSONArray values=new JSONArray(bytes.toString("UTF-8"));
            for(int i=0;i<values.length();i++) themes.add(new Theme(values.getJSONObject(i)));
        } catch(IOException | JSONException error) { throw new IllegalStateException("Missing home themes",error); }
        if(themes.isEmpty()) throw new IllegalStateException("No home themes");
    }
    private int choice(String key, int defaultValue, int length) {
        int saved=preferences.getInt(key,defaultValue);
        return saved>=0 && saved<length ? saved : defaultValue;
    }
    private void applyAppearance() {
        String id=preferences.getString("theme","carbon"); theme=themes.get(0);
        for(Theme item:themes) if(item.id.equals(id)) theme=item;
        font=Typeface.create(FONT_FAMILIES[choice("font",0,FONT_FAMILIES.length)],Typeface.NORMAL);
        fontScale=FONT_SCALES[choice("text_size",1,FONT_SCALES.length)];
        boolean wallpaperOn=!preferences.getString("wallpaper_mode","stock").equals("theme");
        foreground=theme.light && !wallpaperOn ? 0xff0f172a : 0xfff8fafc;
        secondary=theme.light && !wallpaperOn ? 0xff475569 : 0xff94a3b8;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private LinearLayout row() {
        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.HORIZONTAL);
        result.setGravity(Gravity.CENTER_VERTICAL);
        return result;
    }
    private TextView text(String value, int size, int color) {
        TextView result = new TextView(this);
        result.setText(value); result.setTextSize(size*fontScale); result.setTextColor(color);
        result.setTypeface(font); result.setLetterSpacing(.007f);
        return result;
    }
    private GradientDrawable panel(int fill) {
        GradientDrawable result = new GradientDrawable();
        boolean glass=!preferences.getString("wallpaper_mode","stock").equals("theme");
        int normalAlpha=new int[]{0x00,0x55,0xff}[choice("tile_background",0,TILE_NAMES.length)];
        int alpha=glass ? (fill==theme.surface2 && normalAlpha!=0 ? Math.max(0x99,normalAlpha) : normalAlpha) : 0xff;
        if(theme.metallic) {
            result.setOrientation(GradientDrawable.Orientation.TL_BR);
            result.setColors(new int[]{(blend(fill, theme.light ? Color.WHITE : 0xffaeb8c2, .045f)&0xffffff)|(alpha<<24),(fill&0xffffff)|(alpha<<24)});
        } else result.setColor((fill&0xffffff)|(alpha<<24));
        result.setCornerRadius(dp(14));
        return result;
    }
    private int blend(int a, int b, float amount) {
        return Color.rgb(Math.round(Color.red(a)*(1-amount)+Color.red(b)*amount),
            Math.round(Color.green(a)*(1-amount)+Color.green(b)*amount),
            Math.round(Color.blue(a)*(1-amount)+Color.blue(b)*amount));
    }
    private void focusable(View view) {
        focusable(view,false);
    }
    private void focusable(View view,boolean appTile) {
        view.setFocusable(true); view.setClickable(true);
        if(navigationSounds!=null)navigationSounds.configure(view);
        view.setBackground(appTile?panel(theme.surface):StudioStyle.surface(this,0x5c26364a,12,false));
        view.setOnFocusChangeListener((v, focus) -> {
            if(focus && appTile && v.getTag() instanceof String) {
                selectedApp=(String)v.getTag();
                if(topRowApps.contains(v) && customizeControl!=null)customizeControl.setNextFocusDownId(v.getId());
                updateHomeHint();
            }
            if(focus)v.setBackground(StudioStyle.surface(this,0xec203a50,14,true));
            else v.setBackground(appTile?panel(theme.surface):StudioStyle.surface(this,0x5c26364a,12,false));
            if(v instanceof TextView)((TextView)v).setTextColor(focus?0xfff8fafc:foreground);
            if(appTile&&v instanceof LinearLayout){LinearLayout tile=(LinearLayout)v;for(int i=0;i<tile.getChildCount();i++)if(tile.getChildAt(i) instanceof TextView)((TextView)tile.getChildAt(i)).setTextColor(focus?0xfff8fafc:foreground);}
            v.invalidate();
            v.setElevation(focus?dp(appTile?7:3):0);
            float scale=focus?(appTile?1.045f:1.035f):1f;
            v.animate().scaleX(scale).scaleY(scale).translationY(focus&&appTile?-dp(3):0).setDuration(160).start();
        });
    }
    private TextView button(String title, Runnable action) {
        TextView result = text(title, 17, foreground);
        result.setGravity(Gravity.CENTER); result.setPadding(dp(22), dp(13), dp(22), dp(13));
        focusable(result); result.setOnClickListener(v -> action.run());
        return result;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); packages = getPackageManager();
        connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        preferences=getSharedPreferences("appearance",MODE_PRIVATE); loadThemes();
        navigationSounds=new NavigationSounds(this);
        launcherUpdates=new LauncherUpdates(this,preferences,(title,detail,actions,selected,back)->sidePanel(title,detail,actions,null,-1,0,selected,back),()->showLauncherSettings(9));
        if(state!=null&&state.containsKey("pendingNavigationSounds"))pendingNavigationSounds=state.getBoolean("pendingNavigationSounds");
        if(state!=null) {
            pendingIcon=state.getString("pendingIcon");
            pendingImagePermissionUri=state.getParcelable("pendingImagePermissionUri");
            pendingImagePermissionIcon=state.getString("pendingImagePermissionIcon");
            pendingImagePermissionWallpaper=state.getBoolean("pendingImagePermissionWallpaper");
        }
        if(state!=null) selectedApp=state.getString("selectedApp");
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        build();
    }
    private void build() {
        applyAppearance();
        ScrollView scroll = new ScrollView(this);
        homeScroll=scroll;
        scroll.setFillViewport(true); scroll.setClipToPadding(false);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);
        String wallpaperMode=preferences.getString("wallpaper_mode","stock");
        boolean customWallpaper=wallpaperMode.equals("custom") && new File(getFilesDir(),"wallpaper.png").exists();
        boolean wallpaperOn=!wallpaperMode.equals("theme");
        FrameLayout canvas=new FrameLayout(this); canvas.setBackgroundColor(theme.bg);homeWallpaperArtwork=null;
        if(wallpaperOn) {
            ImageView wallpaper=new ImageView(this);
            if(customWallpaper) wallpaper.setImageURI(Uri.fromFile(new File(getFilesDir(),"wallpaper.png"))); else wallpaper.setImageResource(R.drawable.stock_wallpaper);
            homeWallpaperArtwork=wallpaper.getDrawable();
            wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP); canvas.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));
            View dim=new View(this); dim.setBackgroundColor(DIM_COLOURS[choice("wallpaper_dim",0,DIM_NAMES.length)]); canvas.addView(dim,new FrameLayout.LayoutParams(-1,-1));
            View readability=new View(this);
            readability.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x20050c17,0x00000000,0x65050b14}));
            canvas.addView(readability,new FrameLayout.LayoutParams(-1,-1));
        }
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(28),0,dp(28),dp(20));
        scroll.addView(main);
        FrameLayout.LayoutParams bodyParams=new FrameLayout.LayoutParams(-1,-1); bodyParams.topMargin=dp(100); canvas.addView(scroll,bodyParams); setContentView(canvas);
        FrameLayout header = new FrameLayout(this);
        header.setPadding(dp(16),dp(8),dp(16),dp(8));header.setBackground(StudioStyle.surface(this,wallpaperOn?0x641c2737:theme.surface,20,false));header.setElevation(dp(3));
        LinearLayout controls=row();
        FrameLayout.LayoutParams headerParams=new FrameLayout.LayoutParams(-1,dp(72)); headerParams.setMargins(dp(28),dp(16),dp(28),0); canvas.addView(header,headerParams);
        LinearLayout identity=row();
        ImageView emblem=new ImageView(this);emblem.setImageResource(R.drawable.shadowfox_logo);emblem.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams emblemSize=new LinearLayout.LayoutParams(dp(44),dp(44));emblemSize.rightMargin=dp(10);identity.addView(emblem,emblemSize);
        LinearLayout branding=new LinearLayout(this); branding.setOrientation(LinearLayout.VERTICAL);branding.setGravity(Gravity.CENTER_VERTICAL);identity.addView(branding);
        TextView wordmark = text("ShadowFox TV", 21, foreground);
        wordmark.setTypeface(font, Typeface.BOLD); wordmark.setLetterSpacing(.007f);
        int brand=choice("brand",0,BRAND_NAMES.length);
        SpannableString name=new SpannableString("ShadowFox TV");
        int shadow=brand==1 ? (theme.light && !wallpaperOn ? 0xff5b6472 : 0xffcad4de) : brand==2 ? theme.accent : wallpaperOn ? 0xfff8fafc : foreground;
        int fox=brand==0 ? 0xffff780a : shadow, tv=brand==0 ? 0xff23a8ec : shadow;
        name.setSpan(new ForegroundColorSpan(shadow),0,6,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        name.setSpan(new ForegroundColorSpan(fox),6,9,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        name.setSpan(new ForegroundColorSpan(tv),9,12,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        wordmark.setText(name); branding.addView(wordmark);
        TextView brandSub=text("LAUNCHER PRO",9,wallpaperOn?0xffcbd5e1:secondary);brandSub.setLetterSpacing(.18f);brandSub.setPadding(0,dp(4),0,0);branding.addView(brandSub);
        header.addView(identity,new FrameLayout.LayoutParams(-2,dp(54),Gravity.LEFT|Gravity.CENTER_VERTICAL));
        View customize=new GearIcon(); customize.setContentDescription("Launcher settings"); focusable(customize);
        customize.setOnClickListener(v->showLauncherSettings());
        customize.setId(View.generateViewId());
        customizeControl=customize;
        LinearLayout.LayoutParams customizeParams=new LinearLayout.LayoutParams(dp(44),dp(44)); customizeParams.rightMargin=dp(10); controls.addView(customize,customizeParams);
        StatusIcon bell=new StatusIcon(false); bell.setContentDescription("Notifications");
        focusable(bell); bell.setOnClickListener(v->openNotifications());
        LinearLayout.LayoutParams statusParams=new LinearLayout.LayoutParams(dp(44),dp(44)); statusParams.rightMargin=dp(10); controls.addView(bell,statusParams);
        networkIcon=new StatusIcon(true); focusable(networkIcon);
        networkIcon.setOnClickListener(v->{
            Intent networkSettings=new Intent(Settings.ACTION_WIFI_SETTINGS);
            startSafe(networkSettings.resolveActivity(packages)!=null?networkSettings:new Intent(Settings.ACTION_SETTINGS));
        });
        LinearLayout.LayoutParams networkParams=new LinearLayout.LayoutParams(dp(44),dp(44)); networkParams.rightMargin=dp(18); controls.addView(networkIcon,networkParams);
        updateNetwork();
        LinearLayout dateTime=new LinearLayout(this); dateTime.setOrientation(LinearLayout.VERTICAL); dateTime.setGravity(Gravity.RIGHT);dateTime.setPadding(dp(10),0,0,0);
        TextClock clock = new TextClock(this); clock.setFormat12Hour("h:mm a"); clock.setFormat24Hour("HH:mm");
        clock.setTextSize(20*fontScale); clock.setTypeface(font); clock.setTextColor(wallpaperOn?0xfff8fafc:foreground);
        TextClock date=new TextClock(this); date.setFormat12Hour("EEE, MMM d"); date.setFormat24Hour("EEE, MMM d");
        date.setTextSize(12*fontScale); date.setTypeface(font); date.setTextColor(wallpaperOn?0xffcbd5e1:secondary);
        dateTime.addView(clock); dateTime.addView(date);
        if(preferences.getBoolean("clock",true)) controls.addView(dateTime);

        header.addView(controls,new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL));
        LinearLayout slogans=new LinearLayout(this);slogans.setOrientation(LinearLayout.VERTICAL);slogans.setGravity(Gravity.CENTER);
        slogans.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView subtitle=text("MORE THAN ENTERTAINMENT",15,wallpaperOn?0xffe2e8f0:foreground);subtitle.setGravity(Gravity.CENTER);subtitle.setTypeface(font,Typeface.BOLD);subtitle.setLetterSpacing(.07f);subtitle.setSingleLine(true);subtitle.setIncludeFontPadding(false);slogans.addView(subtitle,new LinearLayout.LayoutParams(-1,-2));
        TextView motto=text("STREAM • DISCOVER • ENJOY",10,theme.light&&!wallpaperOn?0xff0369a1:0xff9cdcff);motto.setGravity(Gravity.CENTER);motto.setLetterSpacing(.13f);motto.setPadding(0,dp(5),0,0);motto.setSingleLine(true);motto.setIncludeFontPadding(false);
        SpannableString mottoText=new SpannableString("STREAM • DISCOVER • ENJOY");
        for(int index=0;index<mottoText.length();index++)if(mottoText.charAt(index)=='•')mottoText.setSpan(new ForegroundColorSpan(0xff23a8ec),index,index+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        motto.setText(mottoText);slogans.addView(motto,new LinearLayout.LayoutParams(-1,-2));
        header.addView(slogans,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
        header.post(()->{
            // Use matching reserves on either side so the text is centered on the TV.
            int reserved=Math.max(identity.getMeasuredWidth(),controls.getMeasuredWidth());
            int available=Math.max(dp(90),header.getWidth()-header.getPaddingLeft()-header.getPaddingRight()-2*(reserved+dp(14)));
            android.view.ViewGroup.LayoutParams size=slogans.getLayoutParams();size.width=available;slogans.setLayoutParams(size);
            float fit=Math.min(1f,(available-dp(4))/Math.max(1f,subtitle.getPaint().measureText(subtitle.getText().toString())));
            subtitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX,subtitle.getTextSize()*fit);
            motto.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX,motto.getTextSize()*fit);
        });

        shelfSpacer=new View(this);main.addView(shelfSpacer,new LinearLayout.LayoutParams(-1,0));
        grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); grid.setClipChildren(false);grid.setPadding(dp(16),dp(8),dp(16),dp(6));grid.setBackground(StudioStyle.surface(this,wallpaperOn?0x5e122033:theme.surface,20,false));grid.setElevation(dp(5)); main.addView(grid);
        int available = getResources().getDisplayMetrics().widthPixels - dp(88);
        int density=DENSITIES[choice("app_density",0,DENSITY_NAMES.length)];
        columns = density==0?Math.max(3,Math.min(6,available/dp(142))):Math.max(3,Math.min(density,available/dp(110)));
        tileWidth = available/columns;
        homeHint=text("",11,secondary);homeHint.setVisibility(View.GONE);homeHint.setGravity(Gravity.CENTER_VERTICAL);homeHint.setPadding(dp(38),0,dp(38),0);
        FrameLayout.LayoutParams hintParams=new FrameLayout.LayoutParams(-1,dp(28),Gravity.BOTTOM);canvas.addView(homeHint,hintParams);
        loadApps();
        canvas.post(()->{adjustShelfDock();focusHome();});
        navigationSounds.bind(getWindow().getDecorView());
    }
    private void loadApps() {
        long started=android.os.SystemClock.elapsedRealtime();
        boolean usePack=preferences.getString("icon_pack","").equals(ProjectivyIcons.PACKAGE);
        grid.removeAllViews();
        firstApp=null; topRowApps.clear();appViews.clear();shelfViews.clear(); String firstVisibleCategory=null;
        loadCategories();
        installed.clear();
        for(String category : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}) {
            Intent query = new Intent(Intent.ACTION_MAIN); query.addCategory(category);
            for(ResolveInfo info : packages.queryIntentActivities(query,0)) {
                if(!getPackageName().equals(info.activityInfo.packageName) && !"com.shadowfox.tvlauncher".equals(info.activityInfo.packageName)) installed.putIfAbsent(info.activityInfo.packageName,info);
            }
        }
        appLabels.clear();
        for(Map.Entry<String,ResolveInfo> app:installed.entrySet()) appLabels.put(app.getKey(),app.getValue().loadLabel(packages).toString());
        appOrder.clear();
        try {
            JSONArray saved=new JSONArray(preferences.getString("apps_order","[]"));
            for(int i=0;i<saved.length();i++) { String id=saved.getString(i); if(installed.containsKey(id) && !appOrder.contains(id)) appOrder.add(id); }
        } catch(JSONException error) { /* A missing layout uses alphabetical order. */ }
        ArrayList<String> remaining=new ArrayList<>(installed.keySet());
        remaining.removeAll(appOrder);
        remaining.sort((a,b)->appLabels.get(a).compareToIgnoreCase(appLabels.get(b)));
        appOrder.addAll(remaining);
        ArrayList<String> visibleIds=visibleApps();
        for(Category category:categories) {
        boolean wallpaperOn=!preferences.getString("wallpaper_mode","stock").equals("theme");
        ArrayList<String> visible=new ArrayList<>(); for(String id:visibleIds) if(appCategory(id).equals(category.id)) visible.add(id);
        LinearLayout heading=row();heading.setPadding(dp(3),dp(7),dp(3),dp(6));
        View accent=new View(this);accent.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{StudioStyle.BLUE,StudioStyle.AMBER}));LinearLayout.LayoutParams accentSize=new LinearLayout.LayoutParams(dp(3),dp(17));accentSize.rightMargin=dp(10);heading.addView(accent,accentSize);
        TextView section=text(category.name,16,wallpaperOn?0xffe2e8f0:foreground);section.setTypeface(font,Typeface.BOLD);section.setLetterSpacing(.025f);heading.addView(section,new LinearLayout.LayoutParams(0,-2,1));
        TextView count=text(String.format(Locale.ROOT,"%02d APPS",visible.size()),9,wallpaperOn?0xffa9bdd0:secondary);count.setLetterSpacing(.14f);heading.addView(count);
        grid.addView(heading);
        if(firstVisibleCategory==null && !visible.isEmpty()) firstVisibleCategory=category.id;
        HorizontalScrollView rail=new HorizontalScrollView(this);rail.setHorizontalScrollBarEnabled(false);rail.setFocusable(false);rail.setClipToPadding(false);rail.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout line=row();line.setClipChildren(false);line.setClipToPadding(false);line.setPadding(0,dp(10),0,dp(10));rail.addView(line);grid.addView(rail,new LinearLayout.LayoutParams(-1,-2));
        ArrayList<View> shelf=new ArrayList<>();
        for(int index=0;index<visible.size();index++) {
            String id=visible.get(index); ResolveInfo info=installed.get(id);
            LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER); tile.setPadding(dp(7),dp(8),dp(7),dp(5)); focusable(tile,true);
            tile.setId(View.generateViewId());tile.setTag(id);appViews.put(id,tile);shelf.add(tile);
            if(firstApp==null) firstApp=tile;
            if(category.id.equals(firstVisibleCategory)) { topRowApps.add(tile); tile.setNextFocusUpId(customizeControl.getId()); }
            int iconSize=ICON_SIZES[choice("icon_size",1,ICON_SIZE_NAMES.length)];
            ImageView icon=new ImageView(this); icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            boolean packArtwork=false;
            File custom=iconFile(id);
            if(custom.exists()) icon.setImageURI(Uri.fromFile(custom));
            else if(preferences.getBoolean("fox_icon_"+id,false)) icon.setImageResource(R.drawable.shadowfox_logo);
            else {
                String override=preferences.getString("pack_icon_"+id,"");
                android.graphics.drawable.Drawable packed=override.isEmpty()?null:getIconPack().drawable(override);
                if(packed==null && !preferences.getBoolean("original_icon_"+id,false) && usePack) packed=getIconPack().icon(info);
                packArtwork=packed!=null;
                icon.setImageDrawable(packed==null?highResolutionIcon(info):packed);
            }
            tile.addView(icon,new LinearLayout.LayoutParams(dp(packArtwork?Math.min(120,tileWidth/dp(1)-30):iconSize),dp(iconSize)));
            TextView label=text(appLabel(id),13,wallpaperOn?0xfff8fafc:foreground);label.setGravity(Gravity.CENTER);label.setMaxLines(2);label.setMinLines(2);label.setIncludeFontPadding(false);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setPadding(0,dp(8),0,0);
            int labelHeight=preferences.getBoolean("show_app_names",true)?label.getLineHeight()*2+dp(8):0;
            if(labelHeight>0)tile.addView(label,new LinearLayout.LayoutParams(-1,labelHeight));
            LinearLayout.LayoutParams dimensions = new LinearLayout.LayoutParams(tileWidth-dp(10),dp(iconSize+22)+labelHeight);dimensions.setMargins(dp(3),dp(4),dp(7),dp(4));line.addView(tile,dimensions);
            tile.setContentDescription(appLabel(id)); tile.setOnClickListener(v -> launchPackage(id));
            tile.setOnLongClickListener(v->{showAppActions(id); return true;});
        }
        if(!shelf.isEmpty())shelfViews.add(shelf);
        if(visible.isEmpty()) { TextView empty=button("Choose apps for "+category.name,()->chooseCategoryApps(category));grid.addView(empty); }
        }
        linkShelves();
        grid.post(()->{adjustShelfDock();if(selectedApp!=null && appViews.containsKey(selectedApp))appViews.get(selectedApp).requestFocusFromTouch();});
        android.util.Log.i("ShadowFoxPerformance","Home rows: "+(android.os.SystemClock.elapsedRealtime()-started)+" ms; apps="+installed.size()+"; packLoaded="+(iconPack!=null));
    }
    private ProjectivyIcons getIconPack() { if(iconPack==null)iconPack=new ProjectivyIcons(packages);return iconPack; }
    private void adjustShelfDock() {
        if(shelfSpacer==null || homeScroll.getHeight()==0)return;
        int height=dp(36);
        if(choice("home_layout",0,HOME_LAYOUT_NAMES.length)==0 && grid.getChildCount()>=2) {
            int firstShelf=grid.getChildAt(0).getMeasuredHeight()+grid.getChildAt(1).getMeasuredHeight()+grid.getPaddingTop()+grid.getPaddingBottom();
            height=Math.max(dp(12),homeScroll.getHeight()-firstShelf-dp(28));
        }
        android.view.ViewGroup.LayoutParams params=shelfSpacer.getLayoutParams();
        if(params.height!=height){params.height=height;shelfSpacer.setLayoutParams(params);}
    }
    private void linkShelves() {
        for(int r=0;r<shelfViews.size();r++) for(int i=0;i<shelfViews.get(r).size();i++) {
            View tile=shelfViews.get(r).get(i);
            if(r>0)tile.setNextFocusUpId(shelfViews.get(r-1).get(Math.min(i,shelfViews.get(r-1).size()-1)).getId());
            if(r+1<shelfViews.size())tile.setNextFocusDownId(shelfViews.get(r+1).get(Math.min(i,shelfViews.get(r+1).size()-1)).getId());
        }
        customizeControl.setNextFocusDownId(firstApp==null?View.NO_ID:firstApp.getId());
    }
    private android.graphics.drawable.Drawable highResolutionIcon(ResolveInfo info) {
        try {
            int resource=info.activityInfo.getIconResource();
            if(resource!=0)return packages.getResourcesForApplication(info.activityInfo.applicationInfo).getDrawableForDensity(resource,640,null);
        } catch(PackageManager.NameNotFoundException | android.content.res.Resources.NotFoundException ignored) { }
        return info.loadIcon(packages);
    }
    private AlertDialog sidePanel(String title,String subtitle,String[] choices,String[] details,java.util.function.IntConsumer selected) {
        return sidePanel(title,subtitle,choices,details,-1,0,selected,this::focusHome);
    }
    private AlertDialog sidePanel(String title,String subtitle,String[] choices,String[] details,int checked,int initial,java.util.function.IntConsumer selected,Runnable back) {
        AlertDialog dialog=TvPanel.show(this,Typeface.create("sans-serif",Typeface.NORMAL),TvSettings.SURFACE,TvSettings.TEXT,TvSettings.MUTED,title,subtitle,choices,details,checked,initial,selected,back);
        navigationSounds.bind(dialog.getWindow().getDecorView());return dialog;
    }
    AlertDialog trackDialog(AlertDialog dialog) {
        openDialogs.add(dialog);dialog.setOnDismissListener(d->openDialogs.remove(dialog));return dialog;
    }
    void bindSettingsSounds(View root){navigationSounds.bind(root);}
    View createSettingsBackdrop(){
        FrameLayout background=new FrameLayout(this);background.setBackgroundColor(homeWallpaperArtwork==null?blend(theme.bg,0xff0c1420,.78f):0xff0c1420);background.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        if(homeWallpaperArtwork!=null){
            ImageView artwork=new ImageView(this);android.graphics.drawable.Drawable.ConstantState state=homeWallpaperArtwork.getConstantState();artwork.setImageDrawable(state==null?homeWallpaperArtwork:state.newDrawable(getResources()));artwork.setScaleType(ImageView.ScaleType.CENTER_CROP);artwork.setAlpha(.38f);background.addView(artwork,new FrameLayout.LayoutParams(-1,-1));
            View dim=new View(this);dim.setBackgroundColor(DIM_COLOURS[choice("wallpaper_dim",0,DIM_NAMES.length)]);background.addView(dim,new FrameLayout.LayoutParams(-1,-1));
        }
        return background;
    }
    Bitmap createHomePreview(){
        View home=getWindow().getDecorView();int width=home.getWidth(),height=home.getHeight();
        if(width<1||height<1)return null;
        float scale=Math.min(640f/width,1f);Bitmap preview=Bitmap.createBitmap(Math.max(1,Math.round(width*scale)),Math.max(1,Math.round(height*scale)),Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(preview);canvas.scale(scale,scale);home.draw(canvas);return preview;
    }
    private void dismissLauncherDialogs() {
        if(launcherUpdates!=null)launcherUpdates.dismissForHome();
        for(AlertDialog dialog:new ArrayList<>(openDialogs))dialog.dismiss();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);setIntent(intent);
        if(Intent.ACTION_MAIN.equals(intent.getAction())||intent.hasCategory(Intent.CATEGORY_HOME)) {
            dismissLauncherDialogs();
            if(movingApp!=null)finishRemoteMove(false);
            focusHome();
        }
    }
    private void showLauncherSettings(){showLauncherSettings(0);}
    private void showLauncherSettings(int selection) {
        int[] sections={0,3,3,2,1,4,3,4,4,5};
        int[] positions={-1,0,1,0,6,2,2,1,0,0};
        int index=Math.max(0,Math.min(selection,sections.length-1));showSettingsPage(sections[index],positions[index]);
    }
    private TvSettings.Row settingsRow(String group,String title,String detail,String value,Runnable action){return new TvSettings.Row(group,title,detail,value,action);}
    private TvSettings.Row appearanceRow(String group,String title,String detail,String value,int index){return settingsRow(group,title,detail,value,()->onAppearanceChoice(index));}
    private void showSettingsPage(int section,int row){
        String mode=preferences.getString("wallpaper_mode","stock");
        String wallpaper=mode.equals("custom")?"Your image":mode.equals("theme")?"Theme background":"ShadowFox artwork";
        String pack=preferences.getString("icon_pack","").equals(ProjectivyIcons.PACKAGE)?"Projectivy":"Original icons";
        String version="";try{version=packages.getPackageInfo(getPackageName(),0).versionName;}catch(PackageManager.NameNotFoundException ignored){}
        TvSettings.Page[] pages={
            new TvSettings.Page("Appearance","Set the look of Home. Your changes are saved as you go.",
                appearanceRow("Style","Colour theme","Choose the colours used on Home",theme.name,0),
                appearanceRow("Style","Font","Choose a typeface for Home",FONT_NAMES[choice("font",0,FONT_NAMES.length)],1),
                appearanceRow("Style","Text size","Keep app labels readable from your seat",SIZE_NAMES[choice("text_size",1,SIZE_NAMES.length)],2),
                appearanceRow("Style","Brand lettering","Set the ShadowFox title colours",BRAND_NAMES[choice("brand",0,BRAND_NAMES.length)],3),
                appearanceRow("Reset","Restore appearance defaults","Reset the look of Home; keep your apps and groups","",7)),
            new TvSettings.Page("Home screen","Arrange the shelves, artwork and information on Home.",
                appearanceRow("Layout","Home layout","Choose the balance between wallpaper and apps",HOME_LAYOUT_NAMES[choice("home_layout",0,HOME_LAYOUT_NAMES.length)],10),
                appearanceRow("Layout","Apps across","Set the number of apps on each row",DENSITY_NAMES[choice("app_density",0,DENSITY_NAMES.length)],11),
                appearanceRow("Artwork","Icon size","Set how large app artwork appears",ICON_SIZE_NAMES[choice("icon_size",1,ICON_SIZE_NAMES.length)],9),
                appearanceRow("Artwork","Tile background","Choose the surface behind app icons",TILE_NAMES[choice("tile_background",0,TILE_NAMES.length)],6),
                appearanceRow("Information","App names","Display the saved name beneath each icon",preferences.getBoolean("show_app_names",true)?"Shown":"Hidden",12),
                appearanceRow("Information","Date & time","Display the clock and date on Home",preferences.getBoolean("clock",true)?"On":"Off",4),
                appearanceRow("Icon source","Icon pack","Choose artwork for your installed apps",pack,8)),
            new TvSettings.Page("Wallpaper","Give Home a backdrop and keep your apps easy to see.",
                settingsRow("Background","Choose an image","Browse pictures on your device or a USB drive",wallpaper,()->{if(!launchImagePicker(PICK_WALLPAPER,"Choose wallpaper"))showSettingsPage(2,0);}),
                settingsRow("Background","Wallpaper dimming","Adjust the contrast behind text and icons",DIM_NAMES[choice("wallpaper_dim",0,DIM_NAMES.length)],()->pickChoice("Wallpaper dimming","wallpaper_dim",DIM_NAMES,0,()->showSettingsPage(2,1))),
                settingsRow("Built-in backgrounds","ShadowFox artwork","Use the supplied 4K wallpaper",mode.equals("stock")?"Current":"",()->{preferences.edit().putString("wallpaper_mode","stock").apply();rebuildThen(()->showSettingsPage(2,2));}),
                settingsRow("Built-in backgrounds","Theme background","Use a plain background in your Home theme",mode.equals("theme")?"Current":"",()->{preferences.edit().putString("wallpaper_mode","theme").apply();rebuildThen(()->showSettingsPage(2,3));})),
            new TvSettings.Page("Apps & groups","Choose what appears on Home and keep your apps organised.",
                settingsRow("Your apps","Manage apps","Add, rename, hide or rearrange apps","",()->showManageApps(0)),
                settingsRow("Your apps","Categories","Create groups and choose the apps in each","",()->showCategories(0)),
                settingsRow("Maintenance","Refresh apps","Look for newly installed applications","",()->{iconPack=null;loadApps();Toast.makeText(this,"Apps refreshed",Toast.LENGTH_SHORT).show();showSettingsPage(3,2);})),
            new TvSettings.Page("Sound & device","Control navigation clicks and open your Android settings.",
                settingsRow("Sound","Navigation sounds","Remote focus and click sounds in supported apps",navigationSounds.enabled()?"On":"Off",this::showNavigationSounds),
                settingsRow("Device","Default Home","Choose which launcher opens when you press Home","",()->startSafe(new Intent(Settings.ACTION_HOME_SETTINGS))).keepOpen(),
                settingsRow("Device","Android settings","Network, display, Bluetooth and other device controls","",()->startSafe(new Intent(Settings.ACTION_SETTINGS))).keepOpen()),
            new TvSettings.Page("Updates","Keep ShadowFoxTV Launcher Pro up to date.",
                settingsRow("Launcher","Check for updates","Find a newer version of your launcher","v"+version,()->launcherUpdates.checkNow()),
                settingsRow("Advanced","Update options","Downloaded updates and the update source","",()->launcherUpdates.showMenu()))
        };
        AlertDialog dialog=TvSettings.show(this,pages,section,row,()->customizeControl.requestFocusFromTouch());
        navigationSounds.bind(dialog.getWindow().getDecorView());
    }
    private void showNavigationSounds(){
        int selected=navigationSounds.enabled()?0:1;
        sidePanel("Navigation sounds","Android navigation clicks across supported apps. Video and music volume stays unchanged.",new String[]{"On","Off"},
            new String[]{"Enable Android’s remote focus and click effects","Silence Android’s remote focus and click effects"},selected,selected,index->{
                boolean enabled=index==0;
                if(navigationSounds.canChange())applyNavigationSounds(enabled);
                else requestNavigationSoundAccess(enabled);
            },()->showLauncherSettings(8));
    }
    private void applyNavigationSounds(boolean enabled){
        if(!navigationSounds.setEnabled(enabled))Toast.makeText(this,"Android did not allow the sound setting to change.",Toast.LENGTH_LONG).show();
        showLauncherSettings(8);
    }
    private void requestNavigationSoundAccess(boolean enabled){
        Intent access=new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName()));
        if(access.resolveActivity(packages)==null){
            sidePanel("Sound control","This device does not expose access for the launcher to change system sounds.",new String[]{"Open Android sound settings"},null,-1,0,index->{
                Intent sound=new Intent(Settings.ACTION_SOUND_SETTINGS);startSafe(sound.resolveActivity(packages)!=null?sound:new Intent(Settings.ACTION_SETTINGS));
            },this::showNavigationSounds);return;
        }
        sidePanel("Allow sound control","Allow Modify system settings for ShadowFoxTV Launcher Pro to control navigation sounds across apps.",new String[]{"Open permission settings"},null,-1,0,index->{
            pendingNavigationSounds=enabled;
            try{startActivityForResult(access,SOUND_ACCESS);}catch(ActivityNotFoundException|SecurityException failure){pendingNavigationSounds=null;Toast.makeText(this,"Open Android settings to change sound effects.",Toast.LENGTH_LONG).show();showNavigationSounds();}
        },this::showNavigationSounds);
    }
    private void updateHomeHint() {
        if(homeHint==null)return;
        if(movingApp!=null){homeHint.setText("Move "+appLabel(movingApp)+" · Left / Right to arrange · OK to save · Back to cancel");homeHint.setVisibility(View.VISIBLE);}
        else{homeHint.setText("");homeHint.setVisibility(View.GONE);}
    }
    private String appLabel(String id) { return preferences.getString("label_"+id,appLabels.getOrDefault(id,id)); }
    private ArrayList<String> visibleApps() {
        Set<String> hidden=preferences.getStringSet("hidden_apps",Collections.emptySet());
        ArrayList<String> visible=new ArrayList<>();
        for(Category category:categories) for(String id:appOrder) if(!hidden.contains(id) && appCategory(id).equals(category.id)) visible.add(id);
        return visible;
    }
    private File iconFile(String id) { File dir=new File(getFilesDir(),"icons"); dir.mkdirs(); return new File(dir,id+".png"); }
    private void saveOrder() { preferences.edit().putString("apps_order",new JSONArray(appOrder).toString()).apply(); }
    private void setHidden(String id,boolean hide) {
        Set<String> hidden=new HashSet<>(preferences.getStringSet("hidden_apps",Collections.emptySet()));
        if(hide) hidden.add(id); else hidden.remove(id);
        preferences.edit().putStringSet("hidden_apps",hidden).apply(); loadApps();
    }
    private void showManageApps(int selection) {
        ArrayList<String> visible=visibleApps(); String[] labels=new String[visible.size()+2];
        labels[0]="+ Add an app";
        for(int i=0;i<visible.size();i++) {
            String id=visible.get(i), categoryName=""; for(Category c:categories) if(c.id.equals(appCategory(id))) categoryName=c.name;
            labels[i+1]=(i+1)+". "+appLabel(id)+" · "+categoryName;
        }
        labels[labels.length-1]="Restore original app layout";
        sidePanel("Manage apps","Hold OK on any home icon to edit it directly",labels,null,-1,Math.min(selection,labels.length-1),index-> {
                if(index==0) showAddApps();
                else if(index==labels.length-1) {
                    trackDialog(new AlertDialog.Builder(this).setTitle("Restore original layout?").setMessage("Reset category groups, app order and hidden apps. Your renamed labels, chosen icons and wallpaper will remain.").setPositiveButton("Restore",(confirm,which)->{
                        SharedPreferences.Editor edit=preferences.edit().remove("apps_order").remove("hidden_apps").remove("categories");
                        for(String id:installed.keySet())edit.remove("category_"+id);
                        edit.apply();loadApps();showManageApps(0);
                    }).setNegativeButton("Cancel",null).show());
                } else showAppActions(visible.get(index-1),()->showManageApps(index));
            },()->showLauncherSettings(1));
    }
    private void showAddApps() {
        Set<String> hidden=preferences.getStringSet("hidden_apps",Collections.emptySet());
        ArrayList<String> candidates=new ArrayList<>();for(String id:appOrder)if(hidden.contains(id))candidates.add(id);
        if(candidates.isEmpty()) {
            sidePanel("Add apps","Every installed app is already on Home",new String[]{"Refresh apps"},new String[]{"Check for applications installed since Home opened"},-1,0,index->{iconPack=null;loadApps();showManageApps(0);},()->showManageApps(0));return;
        }
        String[] labels=new String[candidates.size()],details=new String[candidates.size()];android.graphics.drawable.Drawable[] artwork=new android.graphics.drawable.Drawable[candidates.size()];boolean[] checked=new boolean[candidates.size()];
        for(int i=0;i<candidates.size();i++){String id=candidates.get(i);labels[i]=appLabel(id);details[i]="Hidden from Home · "+categoryName(appCategory(id));artwork[i]=highResolutionIcon(installed.get(id));}
        TvPanel.checklist(this,Typeface.create("sans-serif",Typeface.NORMAL),TvSettings.SURFACE,TvSettings.TEXT,TvSettings.MUTED,"Add apps to Home",labels,details,artwork,checked,selection->{
            Set<String> nextHidden=new HashSet<>(hidden);for(int i=0;i<selection.length;i++)if(selection[i])nextHidden.remove(candidates.get(i));
            preferences.edit().putStringSet("hidden_apps",nextHidden).apply();loadApps();showManageApps(0);
        },()->showManageApps(0));
    }
    private String categoryName(String id){for(Category c:categories)if(c.id.equals(id))return c.name;return "Your Apps";}
    private void showAppActions(String id){showAppActions(id,this::focusHome);}
    private void showAppActions(String id,Runnable back) {
        String[] options={"Open app","Reorder with remote","Rename label","Change icon","Move to category","Remove from home","App info"};
        int[] actions={0,7,3,4,5,6,8};
        sidePanel(appLabel(id),"App options",options,new String[]{"Launch this application","Arrange apps with Left / Right, then OK","Change the name shown on Home","Choose artwork or an icon pack","Move this app to another group","Hide the icon; keep the app installed","Open Android's app settings"},-1,0,choice-> {
            int index=actions[choice];
            if(index==0) launchPackage(id);
            else if(index==3) {
                EditText input=new EditText(this); input.setSingleLine(true); input.setSelectAllOnFocus(true); input.setText(appLabel(id));
                input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(40)});
                AlertDialog renameDialog=new AlertDialog.Builder(this).setTitle("App label").setView(input).setPositiveButton("Save",(d,which)-> {
                    String label=input.getText().toString().trim(); SharedPreferences.Editor edit=preferences.edit();
                    if(label.isEmpty()) edit.remove("label_"+id); else edit.putString("label_"+id,label);
                    edit.apply(); loadApps(); showAppActions(id,back);
                }).setNegativeButton("Cancel",(d,which)->showAppActions(id,back)).create();
                trackDialog(renameDialog);
                renameDialog.setOnCancelListener(d->showAppActions(id,back)); renameDialog.setOnShowListener(d->{input.requestFocus(); input.selectAll();}); renameDialog.show();
            } else if(index==4) {
                sidePanel("Change icon","Artwork for "+appLabel(id),new String[]{"Choose an image","ShadowFox logo","Original app icon","Projectivy Icon Pack","Use selected icon pack"},new String[]{"Choose a PNG or JPG","Use the supplied brand artwork","Keep this app’s own icon","Browse the installed TV icon collection","Remove this app’s individual override"},-1,0,item-> {
                    if(item==0) {
                        pendingIcon=id;
                        if(!launchImagePicker(PICK_ICON,"Choose app icon"))pendingIcon=null;
                    } else if(item==3) showPackIcons(id,()->showAppActions(id,back));
                    else {
                        iconFile(id).delete(); preferences.edit().putBoolean("fox_icon_"+id,item==1).putBoolean("original_icon_"+id,item==2).remove("pack_icon_"+id).apply(); loadApps(); showAppActions(id,back);
                    }
                },()->showAppActions(id,back));
            } else if(index==5) {
                String[] names=new String[categories.size()]; int selected=0;
                for(int i=0;i<names.length;i++) { names[i]=categories.get(i).name; if(categories.get(i).id.equals(appCategory(id))) selected=i; }
                sidePanel("Move to category","Choose a shelf for "+appLabel(id),names,null,selected,selected,item-> {
                    preferences.edit().putString("category_"+id,categories.get(item).id).apply(); loadApps(); showAppActions(id,back);
                },()->showAppActions(id,back));
            } else if(index==6) { setHidden(id,true); showManageApps(0); }
            else if(index==7)beginRemoteMove(id);
            else startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+id)));
        },back);
    }
    private void showCategories(int selected) {
        String[] names=new String[categories.size()+1]; names[0]="+ Add category";
        for(int i=0;i<categories.size();i++) names[i+1]=(i+1)+". "+categories.get(i).name;
        sidePanel("Categories","Create groups, choose apps and arrange your shelves",names,null,-1,Math.min(selected,names.length-1),index-> {
            if(index==0) editCategory(null); else showCategoryActions(categories.get(index-1));
        },()->showLauncherSettings(2));
    }
    private void editCategory(Category category) {
        EditText input=new EditText(this); input.setSingleLine(true); input.setSelectAllOnFocus(true); input.setHint("Tools, Music, Streaming Video…");
        input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(32)});
        if(category!=null) input.setText(category.name);
        AlertDialog editDialog=new AlertDialog.Builder(this).setTitle(category==null?"New category":"Category name").setView(input).setPositiveButton("Save",(d,index)-> {
            String name=input.getText().toString().trim();
            if(name.isEmpty()) { Toast.makeText(this,"Enter a category name",Toast.LENGTH_SHORT).show(); showCategories(0); return; }
            for(Category other:categories) if(other!=category && other.name.equalsIgnoreCase(name)) {
                Toast.makeText(this,"That category already exists",Toast.LENGTH_SHORT).show(); showCategories(0); return;
            }
            if(category==null) categories.add(new Category(UUID.randomUUID().toString(),name)); else category.name=name;
            saveCategories(); loadApps(); showCategories(0);
        }).setNegativeButton("Cancel",(d,which)->showCategories(0)).create();
        trackDialog(editDialog);
        editDialog.setOnCancelListener(d->showCategories(0));editDialog.setOnShowListener(d->{input.requestFocus(); input.selectAll();}); editDialog.show();
    }
    private void showCategoryActions(Category category) {
        String[] choices=category.id.equals("apps")?new String[]{"Choose apps","Rename category","Move earlier","Move later"}:
            new String[]{"Choose apps","Rename category","Move earlier","Move later","Remove category"};
        sidePanel(category.name,"Category options",choices,new String[]{"Select several apps and save them together","Change the heading on Home","Move this shelf up","Move this shelf down","Return its apps to the main shelf"},-1,0,item-> {
            if(item==0)chooseCategoryApps(category);
            else if(item==1) editCategory(category);
            else if(item==4) {
                categories.remove(category); SharedPreferences.Editor edit=preferences.edit();
                for(String id:installed.keySet()) if(preferences.getString("category_"+id,"apps").equals(category.id)) edit.remove("category_"+id);
                edit.apply(); saveCategories(); loadApps(); showCategories(0);
                Toast.makeText(this,"Apps moved to the main category",Toast.LENGTH_SHORT).show();
            } else {
                int before=categories.indexOf(category),after=before+(item==2?-1:1);
                if(after>=0 && after<categories.size()) { Collections.swap(categories,before,after); saveCategories(); loadApps(); showCategories(after+1); }
                else { Toast.makeText(this,item==2?"Already first":"Already last",Toast.LENGTH_SHORT).show(); showCategoryActions(category); }
            }
        },()->showCategories(categories.indexOf(category)+1));
    }
    private void chooseCategoryApps(Category category) {
        ArrayList<String> ids=new ArrayList<>(appOrder);String[] labels=new String[ids.size()],details=new String[ids.size()];boolean[] checked=new boolean[ids.size()];
        android.graphics.drawable.Drawable[] artwork=new android.graphics.drawable.Drawable[ids.size()];
        Set<String> hidden=preferences.getStringSet("hidden_apps",Collections.emptySet());Set<String> initial=new HashSet<>();
        // Keep the current shelf together; hidden candidates remain available below it.
        ids.sort(Comparator.comparingInt(id->hidden.contains(id)?2:appCategory(id).equals(category.id)?0:1));
        for(int i=0;i<ids.size();i++) {
            String id=ids.get(i);labels[i]=appLabel(id);checked[i]=!hidden.contains(id)&&appCategory(id).equals(category.id);
            details[i]=(hidden.contains(id)?"Hidden from Home · ":"")+categoryName(appCategory(id));artwork[i]=highResolutionIcon(installed.get(id));
            if(checked[i])initial.add(id);
        }
        TvPanel.checklist(this,Typeface.create("sans-serif",Typeface.NORMAL),TvSettings.SURFACE,TvSettings.TEXT,TvSettings.MUTED,"Apps in "+category.name,labels,details,artwork,checked,selection->{
            Set<String> nextHidden=new HashSet<>(hidden);SharedPreferences.Editor edit=preferences.edit();
            for(int i=0;i<ids.size();i++) {
                String id=ids.get(i);if(selection[i]){edit.putString("category_"+id,category.id);nextHidden.remove(id);}else if(initial.contains(id))nextHidden.add(id);
            }
            edit.putStringSet("hidden_apps",nextHidden).apply();loadApps();showCategoryActions(category);
            Toast.makeText(this,"Category updated",Toast.LENGTH_SHORT).show();
        },()->showCategoryActions(category));
    }
    private void beginRemoteMove(String id) {
        orderBeforeMove=new ArrayList<>(appOrder);movingApp=id;selectedApp=id;
        appViews.get(id).requestFocus();updateHomeHint();
    }
    private void moveRemote(int direction) {
        ArrayList<String> ids=new ArrayList<>();for(String id:visibleApps())if(appCategory(id).equals(appCategory(movingApp)))ids.add(id);
        int position=ids.indexOf(movingApp),next=position+direction;
        if(next<0||next>=ids.size())return;
        String other=ids.get(next);Collections.swap(appOrder,appOrder.indexOf(movingApp),appOrder.indexOf(other));
        View view=appViews.get(movingApp);LinearLayout parent=(LinearLayout)view.getParent();int target=parent.indexOfChild(appViews.get(other));
        parent.removeView(view);parent.addView(view,target);view.requestFocus();
        for(ArrayList<View> shelf:shelfViews)if(shelf.contains(view))Collections.swap(shelf,position,next);
        if(!shelfViews.isEmpty())firstApp=shelfViews.get(0).get(0);
        updateHomeHint();
    }
    private void finishRemoteMove(boolean save) {
        String focus=movingApp;movingApp=null;
        if(save){saveOrder();linkShelves();Toast.makeText(this,"App order saved",Toast.LENGTH_SHORT).show();}
        else {loadApps();selectedApp=focus;}
        orderBeforeMove=null;updateHomeHint();
        grid.post(()->{View view=appViews.get(focus);if(view!=null)view.requestFocus();});
    }
    @Override public void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putString("pendingIcon",pendingIcon);
        state.putString("selectedApp",selectedApp);
        state.putParcelable("pendingImagePermissionUri",pendingImagePermissionUri);
        state.putString("pendingImagePermissionIcon",pendingImagePermissionIcon);
        state.putBoolean("pendingImagePermissionWallpaper",pendingImagePermissionWallpaper);
        if(pendingNavigationSounds!=null)state.putBoolean("pendingNavigationSounds",pendingNavigationSounds);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(launcherUpdates.onActivityResult(request,result))return;
        if(request==SOUND_ACCESS){
            Boolean selected=pendingNavigationSounds;pendingNavigationSounds=null;
            if(selected!=null&&navigationSounds.canChange())applyNavigationSounds(selected);
            else showNavigationSounds();
            return;
        }
        if(request!=PICK_ICON && request!=PICK_WALLPAPER) return;
        android.util.Log.i("ShadowFoxImageImport","Picker result request="+request+" result="+result+" hasData="+(data!=null));
        boolean wallpaper=request==PICK_WALLPAPER;
        if(!wallpaper && pendingIcon==null) return;
        String id=pendingIcon; pendingIcon=null;
        if(result!=RESULT_OK || data==null) return;
        Uri image=data.getData();
        if(image==null && data.getClipData()!=null && data.getClipData().getItemCount()>0)
            image=data.getClipData().getItemAt(0).getUri();
        if(image==null) {
            android.util.Log.w("ShadowFoxImageImport","Picker returned no image URI");
            Toast.makeText(this,"The file picker did not return an image. Choose a different file picker.",Toast.LENGTH_LONG).show();
            return;
        }
        android.util.Log.i("ShadowFoxImageImport","Image access scheme="+image.getScheme()+" authority="+image.getAuthority());
        savePickedImage(image,id,wallpaper);
    }
    private void savePickedImage(Uri uri,String id,boolean wallpaper) {
        savePickedImage(uri,id,wallpaper,true);
    }
    private boolean requestImageReadAccess(Uri uri,String id,boolean wallpaper) {
        if(!"media".equals(uri.getAuthority()))return false;
        String permission=android.os.Build.VERSION.SDK_INT>=33
            ?android.Manifest.permission.READ_MEDIA_IMAGES:android.Manifest.permission.READ_EXTERNAL_STORAGE;
        if(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED)return false;
        pendingImagePermissionUri=uri;
        pendingImagePermissionIcon=id;
        pendingImagePermissionWallpaper=wallpaper;
        String[] permissions=android.os.Build.VERSION.SDK_INT>=34
            ?new String[]{permission,android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}
            :new String[]{permission};
        requestPermissions(permissions,IMAGE_ACCESS);
        return true;
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(request,permissions,results);
        if(request!=IMAGE_ACCESS)return;
        Uri uri=pendingImagePermissionUri;
        String id=pendingImagePermissionIcon;
        boolean wallpaper=pendingImagePermissionWallpaper;
        pendingImagePermissionUri=null;
        pendingImagePermissionIcon=null;
        pendingImagePermissionWallpaper=false;
        boolean granted=false;
        for(int result:results)if(result==PackageManager.PERMISSION_GRANTED)granted=true;
        if(uri!=null && granted)savePickedImage(uri,id,wallpaper,false);
        else Toast.makeText(this,"Photo access was not granted. Choose an image with X-plore or allow photo access.",Toast.LENGTH_LONG).show();
    }
    private void savePickedImage(Uri uri,String id,boolean wallpaper,boolean allowPermissionRequest) {
        if(imageSaving){Toast.makeText(this,"An image is still saving. Try again in a moment.",Toast.LENGTH_SHORT).show();return;}
        imageSaving=true;
        AlertDialog progress=trackDialog(new AlertDialog.Builder(this).setTitle(wallpaper?"Saving wallpaper":"Saving icon")
            .setMessage("You can return Home while your image saves.").setCancelable(false)
            .setPositiveButton("Return Home",(dialog,which)->focusHome()).create());progress.show();
        imageWorker.execute(()->savePickedImageInBackground(uri,id,wallpaper,progress,allowPermissionRequest));
    }
    private void savePickedImageInBackground(Uri uri,String id,boolean wallpaper,AlertDialog progress,boolean allowPermissionRequest) {
        File target=wallpaper?new File(getFilesDir(),"wallpaper.png"):iconFile(id);
        File temp=new File(target.getParentFile(),wallpaper?"wallpaper.tmp":id+".tmp");
        Bitmap image=null,square=null;boolean saved=false,permissionDenied=false;
        try {
            BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
            try(InputStream stream=getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(stream,null,bounds); }
            if(bounds.outWidth<=0 || bounds.outHeight<=0) throw new IOException("Invalid image");
            BitmapFactory.Options options=new BitmapFactory.Options(); options.inSampleSize=1;
            while(Math.max(bounds.outWidth,bounds.outHeight)/options.inSampleSize>(wallpaper?4096:512)) options.inSampleSize*=2;
            try(InputStream stream=getContentResolver().openInputStream(uri)) { image=BitmapFactory.decodeStream(stream,null,options); }
            if(image==null) throw new IOException("Unsupported image");
            int iconEdge=Math.min(512,Math.max(image.getWidth(),image.getHeight()));
            float scale=wallpaper?Math.min(3840f/Math.max(image.getWidth(),image.getHeight()),1f):(float)iconEdge/Math.max(image.getWidth(),image.getHeight());
            float w=image.getWidth()*scale,h=image.getHeight()*scale;
            int outWidth=wallpaper?Math.max(1,Math.round(w)):iconEdge,outHeight=wallpaper?Math.max(1,Math.round(h)):iconEdge;
            if(wallpaper&&outWidth==image.getWidth()&&outHeight==image.getHeight())square=image;
            else {
                square=Bitmap.createBitmap(outWidth,outHeight,Bitmap.Config.ARGB_8888);
                new Canvas(square).drawBitmap(image,null,new RectF((outWidth-w)/2,(outHeight-h)/2,(outWidth+w)/2,(outHeight+h)/2),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
            }
            try(FileOutputStream stream=new FileOutputStream(temp)) { if(!square.compress(Bitmap.CompressFormat.PNG,100,stream)) throw new IOException("Cannot save icon"); }
            if(Thread.currentThread().isInterrupted())throw new IOException("Image import interrupted");
            if(!temp.renameTo(target)) throw new IOException("Cannot replace icon");
            if(wallpaper)preferences.edit().putString("wallpaper_mode","custom").apply();
            else preferences.edit().putBoolean("fox_icon_"+id,false).apply();
            saved=true;
        } catch(IOException | RuntimeException error) {
            permissionDenied=error instanceof SecurityException;
            android.util.Log.w("ShadowFoxImageImport","Image import failed: "+error.getClass().getSimpleName());
            temp.delete();
        } finally {
            if(square!=null&&square!=image&&!square.isRecycled())square.recycle();
            if(image!=null&&!image.isRecycled())image.recycle();
        }
        final boolean complete=saved;
        final boolean askForAccess=permissionDenied && allowPermissionRequest;
        runOnUiThread(()->{
            imageSaving=false;progress.dismiss();
            if(isFinishing()||isDestroyed())return;
            if(complete){if(wallpaper)rebuildAppearance();else loadApps();Toast.makeText(this,wallpaper?"Wallpaper saved":"Icon saved",Toast.LENGTH_SHORT).show();}
            else if(!askForAccess || !requestImageReadAccess(uri,id,wallpaper))
                Toast.makeText(this,"Could not read this image. Choose an image with X-plore or check photo access.",Toast.LENGTH_LONG).show();
        });
    }
    private void showWallpaper(){showWallpaper(()->showLauncherSettings(3));}
    private boolean launchImagePicker(int request,String title) {
        // Prefer folder/USB browsing over Android's gallery takeover of GET_CONTENT.
        for(String action:new String[]{Intent.ACTION_OPEN_DOCUMENT,Intent.ACTION_GET_CONTENT}) {
            Intent picker=new Intent(action);picker.addCategory(Intent.CATEGORY_OPENABLE);picker.setType("image/*");
            picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            List<ResolveInfo> choices=packages.queryIntentActivities(picker,0);
            if(choices.isEmpty())continue;
            String preferred=preferences.getString("image_picker_package","");
            String[] labels=new String[choices.size()];
            int selected=0;
            for(int i=0;i<choices.size();i++) {
                ResolveInfo choice=choices.get(i);
                labels[i]=packages.getApplicationLabel(choice.activityInfo.applicationInfo).toString();
                if(choice.activityInfo.packageName.equals(preferred))selected=i;
            }
            java.util.function.IntConsumer open=index->{
                ResolveInfo choice=choices.get(index);
                Intent chosen=new Intent(picker);
                chosen.setClassName(choice.activityInfo.packageName,choice.activityInfo.name);
                try {
                    startActivityForResult(chosen,request);
                    preferences.edit().putString("image_picker_package",choice.activityInfo.packageName).apply();
                } catch(ActivityNotFoundException|SecurityException unavailable) {
                    Toast.makeText(this,"Could not open this file picker. Choose another one.",Toast.LENGTH_LONG).show();
                }
            };
            if(choices.size()==1)open.accept(0);
            else sidePanel(title,"Choose a file picker",labels,null,-1,selected,open,()->focusHome());
            return true;
        }
        Toast.makeText(this,"No image picker is available. Install a file manager to choose an image.",Toast.LENGTH_LONG).show();
        return false;
    }
    private void showWallpaper(Runnable back) {
        String mode=preferences.getString("wallpaper_mode","stock");
        sidePanel("Wallpaper","Current: "+(mode.equals("custom")?"Your image":mode.equals("theme")?"Theme background":"ShadowFox 4K artwork"),new String[]{"Choose an image","Wallpaper dimming","Restore stock wallpaper","Use theme background"},
            new String[]{"Browse local storage or a USB drive","Adjust contrast behind text and apps","Use the supplied 3840 × 2160 image","Use the selected colour theme"},mode.equals("stock")?2:mode.equals("theme")?3:-1,0,index->{
            if(index==0) {
                if(!launchImagePicker(PICK_WALLPAPER,"Choose wallpaper"))showWallpaper(back);
            }else if(index==1)pickChoice("Wallpaper dimming","wallpaper_dim",DIM_NAMES,0,()->showWallpaper(back));
            else{preferences.edit().putString("wallpaper_mode",index==2?"stock":"theme").apply();rebuildThen(()->showWallpaper(back));}
        },back);
    }
    private void rebuildAppearance(){build();}
    private void rebuildThen(Runnable next){build();grid.post(next);}
    private void focusHome() {
        View remembered=selectedApp==null?null:appViews.get(selectedApp);
        (remembered!=null?remembered:firstApp==null?customizeControl:firstApp).requestFocusFromTouch();
    }
    private void pickChoice(String title,String key,String[] options,int defaultValue,Runnable back) {
        int current=choice(key,defaultValue,options.length);
        sidePanel(title,"Choose an option · ✓ marks the current setting",options,null,current,current,index->{preferences.edit().putInt(key,index).apply();rebuildThen(back);},back);
    }
    private void showAppearance(){showSettingsPage(0,0);}
    private void showAppearance(int selection) {
        int[] home={10,11,9,6,12,4,8};
        for(int i=0;i<home.length;i++)if(home[i]==selection){showSettingsPage(1,i);return;}
        showSettingsPage(0,selection==7?4:Math.min(selection,3));
    }
    private void onAppearanceChoice(int index){
            Runnable back=()->showAppearance(index);
            if(index==0){
                String[] names=new String[themes.size()];int selected=0;
                for(int i=0;i<themes.size();i++){Theme t=themes.get(i);names[i]=t.name+(t.metallic?" · Metallic":"");if(t.id.equals(theme.id))selected=i;}
                sidePanel("Colour theme","Choose a colour palette for Home",names,null,selected,selected,item->{preferences.edit().putString("theme",themes.get(item).id).apply();rebuildThen(back);},back);
            }else if(index==1)pickChoice("Font","font",FONT_NAMES,0,back);
            else if(index==2)pickChoice("Text size","text_size",SIZE_NAMES,1,back);
            else if(index==3)pickChoice("Brand lettering","brand",BRAND_NAMES,0,back);
            else if(index==4){preferences.edit().putBoolean("clock",!preferences.getBoolean("clock",true)).apply();rebuildThen(back);}
            else if(index==5)showWallpaper(back);
            else if(index==6)pickChoice("Tile background","tile_background",TILE_NAMES,0,back);
            else if(index==8)showIconPackChoice(back);
            else if(index==9)pickChoice("Icon size","icon_size",ICON_SIZE_NAMES,1,back);
            else if(index==10)pickChoice("Home layout","home_layout",HOME_LAYOUT_NAMES,0,back);
            else if(index==11)pickChoice("Apps across","app_density",DENSITY_NAMES,0,back);
            else if(index==12){
                int selected=preferences.getBoolean("show_app_names",true)?0:1;
                sidePanel("App names","Renaming remains available by holding OK on an icon",new String[]{"Show names","Hide names"},new String[]{"Display each app’s saved name beneath its icon","Use icons only; keep names for app options and accessibility"},selected,selected,item->{preferences.edit().putBoolean("show_app_names",item==0).apply();rebuildThen(back);},back);
            }
            else trackDialog(new AlertDialog.Builder(this).setTitle("Restore appearance defaults?").setMessage("Reset theme, fonts, wallpaper and tile settings. Your app names, icons and categories will remain.").setPositiveButton("Restore",(d,which)->{
                SharedPreferences.Editor edit=preferences.edit();for(String key:new String[]{"theme","font","text_size","brand","clock","wallpaper_mode","wallpaper_dim","tile_background","icon_size","home_layout","app_density","show_app_names"})edit.remove(key);edit.apply();rebuildThen(back);
            }).setNegativeButton("Cancel",(d,which)->back.run()).setOnCancelListener(d->back.run()).show());
    }
    private void showIconPackChoice(){showIconPackChoice(()->showLauncherSettings(4));}
    private void showIconPackChoice(Runnable back) {
        iconPack=new ProjectivyIcons(packages);String[] choices={"Original app icons",iconPack.available()?"Projectivy Icon Pack · "+iconPack.version:"Projectivy Icon Pack · Not installed"};
        int current=preferences.getString("icon_pack","").isEmpty()?0:1;
        sidePanel("Icon pack","Individual app overrides are retained",choices,new String[]{"Use each application’s original artwork","Use matching artwork from the installed pack"},current,current,index->{
            if(index==1&&!iconPack.available()){Toast.makeText(this,"Install Projectivy Icon Pack to use its icons.",Toast.LENGTH_LONG).show();showIconPackChoice(back);return;}
            preferences.edit().putString("icon_pack",index==0?"":ProjectivyIcons.PACKAGE).apply();rebuildThen(back);
        },back);
    }
    private void showPackIcons(String id,Runnable back) {
        if(iconPack==null)iconPack=new ProjectivyIcons(packages);
        if(!iconPack.available()){Toast.makeText(this,"Install Projectivy Icon Pack to choose an icon.",Toast.LENGTH_LONG).show();back.run();return;}
        String[] groups={"All icons","Latest additions","Generic TV icons","Category icons","Icons without automatic mapping"};
        String[] arrays={"All_TV_icons","Latest_Additions","Generic_TV_Icons","Category_icons","TV_icons_with_no_mapping"};
        sidePanel("Projectivy Icon Pack","Browse artwork for "+appLabel(id),groups,new String[]{"Search the complete artwork collection","Recently added artwork","General app artwork","Artwork for app groups","Choose a match yourself"},-1,0,index->{
            List<String> names=index==0?new ArrayList<>(iconPack.allNames()):iconPack.group(arrays[index]);
            TvIconBrowser.show(this,Typeface.create("sans-serif",Typeface.NORMAL),TvSettings.SURFACE,TvSettings.TEXT,TvSettings.MUTED,groups[index],names,iconPack,preferences.getString("pack_icon_"+id,""),name->{
                iconFile(id).delete();preferences.edit().putString("pack_icon_"+id,name).remove("original_icon_"+id).remove("fox_icon_"+id).apply();loadApps();back.run();
            },()->showPackIcons(id,back));
        },back);
    }
    private void launchPackage(String name) {
        Intent intent=packages.getLeanbackLaunchIntentForPackage(name);
        if(intent==null) intent=packages.getLaunchIntentForPackage(name);
        if(intent==null) { Toast.makeText(this,"ShadowFox TV is not installed yet. Choose another app below.",Toast.LENGTH_LONG).show(); return; }
        startSafe(intent);
    }
    private void startSafe(Intent intent) {
        try { startActivity(intent); }
        catch(ActivityNotFoundException | SecurityException error) { Toast.makeText(this,"This app cannot be opened.",Toast.LENGTH_SHORT).show(); }
    }
    private void openNotifications() {
        Intent panel=new Intent("com.android.tvlauncher.NOTIFICATIONS");
        if(panel.resolveActivity(packages)!=null) { startSafe(panel); return; }
        new AlertDialog.Builder(this).setTitle("Notifications")
            .setMessage("The TV notification panel is unavailable on this system. You can manage app notifications in Settings.")
            .setPositiveButton("Open Settings",(dialog,which)->startSafe(new Intent(Settings.ACTION_SETTINGS)))
            .setNegativeButton("Close",null).show();
    }
    private void refreshNetwork() { runOnUiThread(this::updateNetwork); }
    private void updateNetwork() {
        if(networkIcon==null || connectivity==null) return;
        NetworkCapabilities caps=connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());
        networkIcon.kind=caps==null?"offline":caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"wifi":caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)?"ethernet":"network";
        networkIcon.online=caps!=null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        networkIcon.setContentDescription((networkIcon.kind.equals("wifi")?"Wi-Fi":networkIcon.kind.equals("ethernet")?"Ethernet":networkIcon.kind.equals("offline")?"Offline":"Network")+(caps==null?"":networkIcon.online?" connected":" · limited connection")+" · Network settings");
        networkIcon.invalidate();
    }
    @Override protected void onStart() {
        super.onStart();
        navigationSounds.start();
        if(connectivity!=null && !networkWatching) { connectivity.registerDefaultNetworkCallback(networkChanges); networkWatching=true; }
        updateNetwork();
    }
    @Override protected void onStop() {
        navigationSounds.stop();
        if(networkWatching) { connectivity.unregisterNetworkCallback(networkChanges); networkWatching=false; }
        super.onStop();
    }
    @Override protected void onDestroy(){dismissLauncherDialogs();imageWorker.shutdownNow();if(launcherUpdates!=null)launcherUpdates.close();super.onDestroy();}
    private final class GearIcon extends View {
        GearIcon() { super(MainActivity.this); }
        @Override protected void onDraw(Canvas raw) {
            super.onDraw(raw); int saved=raw.save(); raw.translate(getWidth()/2f,getHeight()/2f); raw.scale(dp(1),dp(1));
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); paint.setColor(hasFocus()?0xfff8fafc:foreground); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.8f); paint.setStrokeJoin(Paint.Join.ROUND);
            Path gear=new Path();
            for(int tooth=0;tooth<8;tooth++) for(int corner=0;corner<4;corner++) {
                double angle=Math.toRadians(tooth*45+corner*11.25-90); float radius=corner==1||corner==2?11:8.3f;
                float x=(float)Math.cos(angle)*radius,y=(float)Math.sin(angle)*radius;
                if(tooth==0 && corner==0) gear.moveTo(x,y); else gear.lineTo(x,y);
            }
            gear.close(); raw.drawPath(gear,paint); raw.drawCircle(0,0,3.6f,paint); raw.restoreToCount(saved);
        }
    }
    private final class StatusIcon extends View {
        private final boolean connection; private String kind="offline"; private boolean online;
        StatusIcon(boolean connection) { super(MainActivity.this); this.connection=connection; }
        @Override protected void onDraw(Canvas raw) {
            super.onDraw(raw); int saved=raw.save(); raw.translate(getWidth()/2f,getHeight()/2f); raw.scale(dp(1),dp(1));
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(hasFocus()?0xfff8fafc:foreground); p.setStrokeWidth(1.8f); p.setStrokeCap(Paint.Cap.ROUND); p.setStyle(Paint.Style.STROKE);
            if(!connection) {
                Path bell=new Path(); bell.moveTo(-8,6); bell.lineTo(-6,3); bell.lineTo(-6,-3); bell.cubicTo(-6,-12,6,-12,6,-3); bell.lineTo(6,3); bell.lineTo(8,6); bell.close(); raw.drawPath(bell,p); raw.drawArc(new RectF(-3,5,3,11),0,180,false,p); raw.drawLine(0,-11,0,-9,p);
            } else if(kind.equals("ethernet")) {
                raw.drawRoundRect(new RectF(-7,-9,7,2),1,1,p); raw.drawLine(0,2,0,7,p); raw.drawLine(-9,7,9,7,p); raw.drawLine(-9,7,-9,10,p); raw.drawLine(9,7,9,10,p);
            } else {
                raw.drawArc(new RectF(-13,-8,13,18),225,90,false,p); raw.drawArc(new RectF(-8,-3,8,13),225,90,false,p); p.setStyle(Paint.Style.FILL); raw.drawCircle(0,7,1.8f,p); p.setStyle(Paint.Style.STROKE);
                if(kind.equals("offline")) raw.drawLine(-10,-10,10,10,p);
            }
            if(connection && !online && !kind.equals("offline")) { p.setColor(0xffff780a); p.setStyle(Paint.Style.FILL); raw.drawCircle(11,10,2.4f,p); }
            raw.restoreToCount(saved);
        }
    }
    @Override public boolean onKeyDown(int code,KeyEvent event) {
        if(code==KeyEvent.KEYCODE_MENU && selectedApp!=null){if(movingApp!=null)finishRemoteMove(false);showAppActions(selectedApp);return true;}
        if(code==KeyEvent.KEYCODE_BACK && movingApp!=null){finishRemoteMove(false);return true;}
        if(code==KeyEvent.KEYCODE_BACK) { focusHome(); return true; }
        return super.onKeyDown(code,event);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if(movingApp!=null && event.getAction()==KeyEvent.ACTION_DOWN) {
            int code=event.getKeyCode();
            if(code==KeyEvent.KEYCODE_DPAD_LEFT||code==KeyEvent.KEYCODE_DPAD_RIGHT){moveRemote(code==KeyEvent.KEYCODE_DPAD_LEFT?-1:1);return true;}
            if(code==KeyEvent.KEYCODE_DPAD_CENTER||code==KeyEvent.KEYCODE_ENTER){finishRemoteMove(true);return true;}
            if(code==KeyEvent.KEYCODE_DPAD_UP||code==KeyEvent.KEYCODE_DPAD_DOWN)return true;
        }
        if(event.getAction()==KeyEvent.ACTION_DOWN && event.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP && topRowApps.contains(getCurrentFocus())) {
            customizeControl.requestFocus(); return true;
        }
        return super.dispatchKeyEvent(event);
    }
}
