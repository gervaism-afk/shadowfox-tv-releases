package com.shadowfox.tvlauncher;

import android.app.AlertDialog;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** A TV settings workspace. The rail and each page retain separate focus positions. */
final class TvSettings {
    static final int BG=0xff0c121c, SURFACE=0xff131d2b, TEXT=0xffeff4fa,
        MUTED=0xffa0aec1, ACCENT=0xff9ae1d2;
    static final class Row {
        final String title,detail,value,group; final Runnable action;
        boolean closeOnSelect=true;
        Row(String group,String title,String detail,String value,Runnable action){
            this.group=group;this.title=title;this.detail=detail;this.value=value;this.action=action;
        }
        Row keepOpen(){closeOnSelect=false;return this;}
    }
    static final class Page {
        final String title,description; final Row[] rows;
        Page(String title,String description,Row... rows){this.title=title;this.description=description;this.rows=rows;}
    }
    private final MainActivity host;
    private final AlertDialog dialog;
    private final Page[] pages;
    private final LinearLayout content;
    private final TextView heading,description;
    private final ScrollView scroll;
    private final ArrayList<View> rail=new ArrayList<>(),rows=new ArrayList<>();
    private final int[] remembered;
    private int selected=-1;
    private TvSettings(MainActivity host,Page[] pages,int page,int row,Runnable close){
        this.host=host;this.pages=pages;remembered=new int[pages.length];
        int start=Math.max(0,Math.min(page,pages.length-1));remembered[start]=row;
        LinearLayout shell=new LinearLayout(host);shell.setOrientation(LinearLayout.HORIZONTAL);shell.setBackgroundColor(BG);
        LinearLayout nav=new LinearLayout(host);nav.setOrientation(LinearLayout.VERTICAL);nav.setPadding(dp(24),dp(30),dp(18),dp(24));nav.setBackgroundColor(0xff090f18);
        shell.addView(nav,new LinearLayout.LayoutParams(dp(236),-1));
        TextView brand=label("SHADOWFOX TV",12,ACCENT,true);brand.setLetterSpacing(.15f);nav.addView(brand);
        TextView title=label("Settings",30,TEXT,true);title.setPadding(0,dp(8),0,dp(26));nav.addView(title);
        dialog=host.trackDialog(new AlertDialog.Builder(host).setView(shell).create());
        dialog.setOnCancelListener(d->close.run());
        for(int i=0;i<pages.length;i++){
            final int index=i;
            LinearLayout item=new LinearLayout(host);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(12),0,dp(10),0);item.setContentDescription(pages[i].title);
            ImageView icon=new ImageView(host);icon.setImageDrawable(new Symbol(i));LinearLayout.LayoutParams art=new LinearLayout.LayoutParams(dp(20),dp(20));art.rightMargin=dp(12);item.addView(icon,art);
            item.addView(label(pages[i].title,15,TEXT,true));
            focusable(item);item.setOnFocusChangeListener((v,focused)->{if(focused)render(index);paintRail();});
            item.setOnClickListener(v->{render(index);focusContent();});
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(-1,dp(48));size.bottomMargin=dp(5);nav.addView(item,size);rail.add(item);
        }
        View spacer=new View(host);nav.addView(spacer,new LinearLayout.LayoutParams(1,0,1));
        TextView exit=label("‹  Back to Home",14,MUTED,true);exit.setPadding(dp(12),dp(12),dp(8),dp(12));focusable(exit);
        exit.setOnFocusChangeListener((v,f)->v.setBackground(shape(f?0xff25364a:Color.TRANSPARENT,f?ACCENT:Color.TRANSPARENT,10)));
        exit.setOnClickListener(v->dialog.cancel());nav.addView(exit);rail.add(exit);
        for(int i=0;i<rail.size();i++){
            View v=rail.get(i);v.setNextFocusUpId(rail.get(Math.max(0,i-1)).getId());v.setNextFocusDownId(rail.get(Math.min(rail.size()-1,i+1)).getId());v.setNextFocusLeftId(v.getId());
            v.setOnKeyListener((view,code,event)->{if(code==KeyEvent.KEYCODE_DPAD_RIGHT){if(event.getAction()==KeyEvent.ACTION_DOWN)focusContent();return true;}return false;});
        }
        LinearLayout main=new LinearLayout(host);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(dp(36),dp(30),dp(36),dp(20));shell.addView(main,new LinearLayout.LayoutParams(0,-1,1));
        TextView eyebrow=label("LAUNCHER PREFERENCES",10,MUTED,true);eyebrow.setLetterSpacing(.15f);main.addView(eyebrow);
        heading=label("",28,TEXT,true);heading.setPadding(0,dp(7),0,0);main.addView(heading);
        description=label("",13,MUTED,false);description.setPadding(0,dp(6),0,dp(17));main.addView(description);
        scroll=new ScrollView(host);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);scroll.setPadding(dp(3),dp(3),dp(3),dp(6));
        content=new LinearLayout(host);content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=label("↑ ↓  Navigate     OK  Select     ←  Categories     Back  Home",11,MUTED,false);hint.setPadding(0,dp(12),0,0);main.addView(hint);
        dialog.setOnShowListener(d->{
            Window window=dialog.getWindow();window.setBackgroundDrawable(new ColorDrawable(BG));window.getDecorView().setPadding(0,0,0,0);
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
            window.setLayout(-1,-1);window.setDimAmount(0);window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            render(start);if(row<0)rail.get(start).requestFocusFromTouch();else focusContent();
        });
    }
    static AlertDialog show(MainActivity host,Page[] pages,int page,int row,Runnable close){TvSettings settings=new TvSettings(host,pages,page,row,close);settings.dialog.show();return settings.dialog;}
    private void render(int index){
        if(index==selected)return;selected=index;Page page=pages[index];heading.setText(page.title);description.setText(page.description);content.removeAllViews();rows.clear();
        String group="";
        for(int i=0;i<page.rows.length;i++){
            final int position=i;Row data=page.rows[i];
            if(!data.group.equals(group)){
                group=data.group;TextView section=label(group.toUpperCase(Locale.ROOT),10,MUTED,true);section.setLetterSpacing(.12f);section.setPadding(dp(2),i==0?0:dp(16),0,dp(8));content.addView(section);
            }
            LinearLayout item=new LinearLayout(host);item.setOrientation(LinearLayout.HORIZONTAL);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(18),dp(13),dp(16),dp(13));item.setMinimumHeight(dp(64));focusable(item);item.setContentDescription(data.title);
            LinearLayout words=new LinearLayout(host);words.setOrientation(LinearLayout.VERTICAL);TextView name=label(data.title,16,TEXT,true);words.addView(name);
            if(!data.detail.isEmpty()){TextView sub=label(data.detail,12,MUTED,false);sub.setPadding(0,dp(4),0,0);words.addView(sub);}
            item.addView(words,new LinearLayout.LayoutParams(0,-2,1));
            if(!data.value.isEmpty()){
                TextView value=label(data.value,12,ACCENT,true);value.setMaxWidth(dp(174));value.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);value.setPadding(dp(14),0,dp(14),0);item.addView(value);
            }
            item.addView(label("›",23,MUTED,false));item.setBackground(shape(SURFACE,0xff223044,12));
            item.setOnFocusChangeListener((v,focused)->{v.setBackground(shape(focused?0xff233b49:SURFACE,focused?ACCENT:0xff223044,12));v.setElevation(focused?dp(3):0);if(focused){remembered[selected]=position;paintRail();}});
            item.setOnClickListener(v->{if(data.closeOnSelect)dialog.dismiss();data.action.run();});
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(-1,-2);size.bottomMargin=dp(6);content.addView(item,size);rows.add(item);
        }
        for(int i=0;i<rows.size();i++){
            View v=rows.get(i);v.setNextFocusUpId(rows.get(Math.max(0,i-1)).getId());v.setNextFocusDownId(rows.get(Math.min(rows.size()-1,i+1)).getId());v.setNextFocusLeftId(rail.get(index).getId());v.setNextFocusRightId(v.getId());
        }
        scroll.scrollTo(0,0);paintRail();host.bindSettingsSounds(content);
    }
    private void focusContent(){if(!rows.isEmpty())rows.get(Math.max(0,Math.min(remembered[selected],rows.size()-1))).requestFocusFromTouch();}
    private void paintRail(){
        for(int i=0;i<pages.length;i++){
            View item=rail.get(i);item.setBackground(shape(item.hasFocus()?0xff243d49:i==selected?0xff172936:Color.TRANSPARENT,item.hasFocus()?ACCENT:Color.TRANSPARENT,10));
        }
    }
    private void focusable(View v){v.setId(View.generateViewId());v.setFocusable(true);v.setClickable(true);}
    private TextView label(String text,int size,int color,boolean bold){TextView v=new TextView(host);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));v.setIncludeFontPadding(false);return v;}
    private int dp(int value){return Math.round(value*host.getResources().getDisplayMetrics().density);}
    private GradientDrawable shape(int fill,int stroke,int radius){GradientDrawable shape=new GradientDrawable();shape.setColor(fill);shape.setCornerRadius(dp(radius));shape.setStroke(dp(1),stroke);return shape;}
    /** Small vector symbols stay sharp at every TV resolution. */
    private static final class Symbol extends Drawable {
        private final int kind;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        Symbol(int kind){this.kind=kind;}
        @Override public void draw(Canvas canvas){
            canvas.save();canvas.translate(getBounds().left,getBounds().top);canvas.scale(getBounds().width()/24f,getBounds().height()/24f);paint.setColor(ACCENT);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.6f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
            if(kind==0){canvas.drawCircle(12,12,8,paint);canvas.drawCircle(9,9,1,paint);canvas.drawCircle(15,8,1,paint);canvas.drawCircle(7,14,1,paint);canvas.drawLine(13,19,16,14,paint);}
            else if(kind==1){canvas.drawRoundRect(3,4,21,18,2,2,paint);canvas.drawLine(8,22,16,22,paint);canvas.drawLine(12,18,12,22,paint);canvas.drawLine(7,8,17,8,paint);canvas.drawLine(7,12,12,12,paint);}
            else if(kind==2){canvas.drawRoundRect(3,3,21,21,3,3,paint);canvas.drawCircle(8,8,1.5f,paint);Path p=new Path();p.moveTo(4,18);p.lineTo(10,12);p.lineTo(14,16);p.lineTo(17,12);p.lineTo(21,17);canvas.drawPath(p,paint);}
            else if(kind==3){for(int y=4;y<=14;y+=10)for(int x=4;x<=14;x+=10)canvas.drawRoundRect(x,y,x+6,y+6,1,1,paint);}
            else if(kind==4){Path p=new Path();p.moveTo(4,9);p.lineTo(8,9);p.lineTo(13,5);p.lineTo(13,19);p.lineTo(8,15);p.lineTo(4,15);p.close();canvas.drawPath(p,paint);canvas.drawArc(12,5,22,19,-55,110,false,paint);}
            else{canvas.drawArc(4,4,20,20,35,285,false,paint);canvas.drawLine(20,4,20,10,paint);canvas.drawLine(15,10,20,10,paint);canvas.drawLine(12,8,12,13,paint);canvas.drawLine(12,13,9,15,paint);}
            canvas.restore();
        }
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
}
