# ShadowFox TV wallpaper collection

Mode: built-in imagegen, one background-edit call per style. All edits use the Studio wallpaper as the logo reference. Native generated PNGs are preserved without resizing.

## Cosmic Eclipse

Use case: style-transfer / stylized-concept.
Edit target: the supplied ShadowFox TV wallpaper.
Preserve the existing central ShadowFox TV shield logo: its fox artwork, blue eyes, chrome/blue shield, silver/orange "ShadowFox" and silver "TV" lettering. Keep the user's logo, not a redesigned fox. Preserve its colours, shapes, proportions, size and position as closely as possible. The complete logo stays horizontally centred, approximately x=36–64%, y=18–55% of the canvas, above the launcher dock.
Replace ONLY the surrounding background with the distinctly different style below. Do not reuse the current blue/amber glass ribbons unless the specified style calls for them.
Output one finished opaque 16:9 landscape wallpaper, highest native resolution available. This is a background asset for a real TV launcher, not a UI mockup. Keep the top 16% and bottom 33% dark and low-detail for white header text and a transparent app dock. The logo remains the sharp focal point. No added text, labels, slogans, watermark, UI controls, app icons, clocks, border, or second logo.

Background style: Cinematic space: deep indigo-black space, a large shadowed eclipse off to the right with a thin warm golden corona, very subtle violet nebula haze and sparse distant stars. Atmospheric, photographic lighting and depth, restrained cinematic colour grading. Keep the eclipse behind and away from the preserved logo, and the lower third mostly black. No glass ribbons, no industrial plates.

## Obsidian Silk

Use case: style-transfer / stylized-concept.
Edit target: the supplied ShadowFox TV wallpaper.
Preserve the existing central ShadowFox TV shield logo: its fox artwork, blue eyes, chrome/blue shield, silver/orange "ShadowFox" and silver "TV" lettering. Keep the user's logo, not a redesigned fox. Preserve its colours, shapes, proportions, size and position as closely as possible. The complete logo stays horizontally centred, approximately x=36–64%, y=18–55% of the canvas, above the launcher dock.
Replace ONLY the surrounding background with the distinctly different style below. Do not reuse the current blue/amber glass ribbons unless the specified style calls for them.
Output one finished opaque 16:9 landscape wallpaper, highest native resolution available. This is a background asset for a real TV launcher, not a UI mockup. Keep the top 16% and bottom 33% dark and low-detail for white header text and a transparent app dock. The logo remains the sharp focal point. No added text, labels, slogans, watermark, UI controls, app icons, clocks, border, or second logo.

Background style: Minimal luxury: near-black silk or satin fabric in broad, soft sculptural folds with a restrained cool silver edge light and velvety charcoal depth. Almost monochrome, tactile and understated; the preserved coloured logo supplies the main colour. Keep folds spacious and low contrast, no neon, no glass ribbons, no machinery, no stars.

## Forged Titanium

Use case: style-transfer / stylized-concept.
Edit target: the supplied ShadowFox TV wallpaper.
Preserve the existing central ShadowFox TV shield logo: its fox artwork, blue eyes, chrome/blue shield, silver/orange "ShadowFox" and silver "TV" lettering. Keep the user's logo, not a redesigned fox. Preserve its colours, shapes, proportions, size and position as closely as possible. The complete logo stays horizontally centred, approximately x=36–64%, y=18–55% of the canvas, above the launcher dock.
Replace ONLY the surrounding background with the distinctly different style below. Do not reuse the current blue/amber glass ribbons unless the specified style calls for them.
Output one finished opaque 16:9 landscape wallpaper, highest native resolution available. This is a background asset for a real TV launcher, not a UI mockup. Keep the top 16% and bottom 33% dark and low-detail for white header text and a transparent app dock. The logo remains the sharp focal point. No added text, labels, slogans, watermark, UI controls, app icons, clocks, border, or second logo.

Background style: Industrial precision: photorealistic machined gunmetal and forged titanium surfaces, subtle brushed grain, broad architectural bevels, dark carbon-fibre inserts and restrained copper edge highlights. Substantial, engineered and clean, like precision high-end hardware. Balanced composition framing the unchanged logo; avoid busy perforations, screws everywhere, warning labels, glass ribbons or neon.

## Synthwave Night

Use case: style-transfer / stylized-concept.
Edit target: the supplied ShadowFox TV wallpaper.
Preserve the existing central ShadowFox TV shield logo: its fox artwork, blue eyes, chrome/blue shield, silver/orange "ShadowFox" and silver "TV" lettering. Keep the user's logo, not a redesigned fox. Preserve its colours, shapes, proportions, size and position as closely as possible. The complete logo stays horizontally centred, approximately x=36–64%, y=18–55% of the canvas, above the launcher dock.
Replace ONLY the surrounding background with the distinctly different style below. Do not reuse the current blue/amber glass ribbons unless the specified style calls for them.
Output one finished opaque 16:9 landscape wallpaper, highest native resolution available. This is a background asset for a real TV launcher, not a UI mockup. Keep the top 16% and bottom 33% dark and low-detail for white header text and a transparent app dock. The logo remains the sharp focal point. No added text, labels, slogans, watermark, UI controls, app icons, clocks, border, or second logo.

Background style: Retro-futurist 1980s synthwave: deep midnight plum and black, a soft magenta/purple horizon glow, a subtle cyan perspective grid fading into the lower darkness, and a subdued segmented sunset disc in the distance behind the logo. Airbrushed nostalgic atmosphere with controlled neon edges. The background stays dark enough for the launcher, especially the top and bottom UI areas. Keep the logo itself unchanged, not pixelated or recoloured. No blue/amber glass ribbons.

## Midnight Forest

Use case: style-transfer / stylized-concept.
Edit target: the supplied ShadowFox TV wallpaper.
Preserve the existing central ShadowFox TV shield logo: its fox artwork, blue eyes, chrome/blue shield, silver/orange "ShadowFox" and silver "TV" lettering. Keep the user's logo, not a redesigned fox. Preserve its colours, shapes, proportions, size and position as closely as possible. The complete logo stays horizontally centred, approximately x=36–64%, y=18–55% of the canvas, above the launcher dock.
Replace ONLY the surrounding background with the distinctly different style below. Do not reuse the current blue/amber glass ribbons unless the specified style calls for them.
Output one finished opaque 16:9 landscape wallpaper, highest native resolution available. This is a background asset for a real TV launcher, not a UI mockup. Keep the top 16% and bottom 33% dark and low-detail for white header text and a transparent app dock. The logo remains the sharp focal point. No added text, labels, slogans, watermark, UI controls, app icons, clocks, border, or second logo.

Background style: Organic photographic landscape: a tranquil midnight evergreen forest, deep emerald and blue-black silhouettes, subtle cool moonlit mist between distant trees, softly receding depth and a dark quiet foreground. Natural, atmospheric and realistic. The original logo floats crisply in the open upper-middle negative space; no tree branches cross it. No glass ribbons, machinery, magical creatures, buildings, neon or added animals.



## Noir Gold

File: `ShadowFoxTV-Noir-Gold.png`

```text
Use case: compositing / stylized-concept.
Edit the supplied ShadowFox TV wallpaper into a distinctly art-directed alternative.
Keep the existing ShadowFox TV shield logo's fox artwork, eyes, chrome/blue shield, colours and silver/orange "ShadowFox" plus silver "TV" lettering unchanged. You may reposition and uniformly scale the complete existing logo as one unit according to the composition below. Do not redraw the fox or replace the logo.
Replace the entire background, not just its colours. Produce a cohesive, polished wallpaper with a strong composition and believable materials, avoiding a generic badge-on-gradient appearance.
This is an opaque 16:9 landscape background for a TV launcher, highest native resolution available. Keep the top 16% and bottom 32% quiet and dark for the header and app dock. The complete logo must sit between those UI zones, with approximate height 34–36% of the canvas and no cropping. No added text, captions, watermarks, UI mockup, buttons, app icons, clocks or duplicate logo.

Art direction: Art Deco luxury. A deep black and dark emerald architectural composition with elegant stepped forms, radiating fan geometry, fine champagne-gold metal inlays and soft grazing light. Sophisticated craftsmanship, restrained ornament, rich matte stone and polished brass. Place the preserved logo at x=30%, y=37%, occupying the left open space. Let the gold geometry sweep through the centre/right with dimensional depth. Keep the logo its original colours. No wallpaper border, no writing, no blue/amber glass waves, no screws or carbon fibre.
```

## Ink and Ember

File: `ShadowFoxTV-Ink-and-Ember.png`

```text
Use case: compositing / stylized-concept.
Edit the supplied ShadowFox TV wallpaper into a distinctly art-directed alternative.
Keep the existing ShadowFox TV shield logo's fox artwork, eyes, chrome/blue shield, colours and silver/orange "ShadowFox" plus silver "TV" lettering unchanged. You may reposition and uniformly scale the complete existing logo as one unit according to the composition below. Do not redraw the fox or replace the logo.
Replace the entire background, not just its colours. Produce a cohesive, polished wallpaper with a strong composition and believable materials, avoiding a generic badge-on-gradient appearance.
This is an opaque 16:9 landscape background for a TV launcher, highest native resolution available. Keep the top 16% and bottom 32% quiet and dark for the header and app dock. The complete logo must sit between those UI zones, with approximate height 34–36% of the canvas and no cropping. No added text, captions, watermarks, UI mockup, buttons, app icons, clocks or duplicate logo.

Art direction: A striking contemporary ink-wash landscape in charcoal, smoke and muted vermilion. Expressive sumi-e brush mountains and drifting ink mist on subtly textured near-black paper; an understated ember-red sun on the right, with deliberate negative space and painterly edges. Place the original full-colour logo at x=30%, y=37%, crisp against the open dark mist on the left. Background art should feel gallery-quality and tactile. No calligraphy, no seals, no Japanese characters, no glass waves, no stars or neon.
```

## Glacial Prism

File: `ShadowFoxTV-Glacial-Prism.png`

```text
Use case: compositing / stylized-concept.
Edit the supplied ShadowFox TV wallpaper into a distinctly art-directed alternative.
Keep the existing ShadowFox TV shield logo's fox artwork, eyes, chrome/blue shield, colours and silver/orange "ShadowFox" plus silver "TV" lettering unchanged. You may reposition and uniformly scale the complete existing logo as one unit according to the composition below. Do not redraw the fox or replace the logo.
Replace the entire background, not just its colours. Produce a cohesive, polished wallpaper with a strong composition and believable materials, avoiding a generic badge-on-gradient appearance.
This is an opaque 16:9 landscape background for a TV launcher, highest native resolution available. Keep the top 16% and bottom 32% quiet and dark for the header and app dock. The complete logo must sit between those UI zones, with approximate height 34–36% of the canvas and no cropping. No added text, captions, watermarks, UI mockup, buttons, app icons, clocks or duplicate logo.

Art direction: Photorealistic sculptural ice and crystal, dramatic yet refined. Huge translucent glacial facets fill the left side, with frosted microtexture, deep navy shadows, pale arctic blue internal scattering and narrow silver highlights. Let the facets recede naturally into a clean dark opening on the right. Place the preserved logo at x=69%, y=37% in that opening, with the complete wordmark visible. Cold, precise and spacious; not a diamond pattern or glass-ribbon variant. Keep bright facets away from the top and bottom UI areas. No snowflakes, castles, lettering or extra foxes.
```

## Liquid Copper

File: `ShadowFoxTV-Liquid-Copper.png`

```text
Use case: compositing / stylized-concept.
Edit the supplied ShadowFox TV wallpaper into a distinctly art-directed alternative.
Keep the existing ShadowFox TV shield logo's fox artwork, eyes, chrome/blue shield, colours and silver/orange "ShadowFox" plus silver "TV" lettering unchanged. You may reposition and uniformly scale the complete existing logo as one unit according to the composition below. Do not redraw the fox or replace the logo.
Replace the entire background, not just its colours. Produce a cohesive, polished wallpaper with a strong composition and believable materials, avoiding a generic badge-on-gradient appearance.
This is an opaque 16:9 landscape background for a TV launcher, highest native resolution available. Keep the top 16% and bottom 32% quiet and dark for the header and app dock. The complete logo must sit between those UI zones, with approximate height 34–36% of the canvas and no cropping. No added text, captions, watermarks, UI mockup, buttons, app icons, clocks or duplicate logo.

Art direction: A high-end macro 3D material study of liquid copper and black chrome. Broad molten-metal folds, flowing sculptural surfaces, warm copper reflections and deep black negative space; carefully controlled studio highlights, silky smooth material transitions and convincing depth. An asymmetrical composition with the main flowing form sweeping from lower-left toward the upper-right behind the hero region. Place the unchanged logo at x=56%, y=36%, separated cleanly from the reflective form. Mostly black at the header and app dock. No flames, sparks, lava landscape, blue/amber ribbons, heavy lens flare or added text.
```

