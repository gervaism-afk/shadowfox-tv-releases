package com.shadowfox.tvlauncher;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;

/** Category labels and apps float directly over the wallpaper. */
final class CategoryShelf extends LinearLayout {
    static final int LABEL_WIDTH=132,LABEL_GAP=16;
    private final TextView title,count;
    private final int total,foreground,secondary,accent;
    private final LinearLayout apps;
    CategoryShelf(Context host,Typeface font,float fontScale,String name,int total,int foreground,int secondary,int accent,HorizontalScrollView rail,LinearLayout apps){
        super(host);this.total=total;this.foreground=foreground;this.secondary=secondary;this.accent=accent;this.apps=apps;
        setOrientation(HORIZONTAL);setGravity(Gravity.CENTER_VERTICAL);setPadding(dp(12),dp(8),dp(12),dp(8));setClipChildren(false);setClipToPadding(false);
        LinearLayout identity=new LinearLayout(host);identity.setOrientation(VERTICAL);identity.setGravity(Gravity.CENTER_VERTICAL);
        title=new TextView(host);title.setText(name);title.setTextSize(14*fontScale);title.setTypeface(Typeface.create(font,Typeface.BOLD));title.setTextColor(foreground);title.setIncludeFontPadding(false);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);identity.addView(title,new LinearLayout.LayoutParams(-1,-2));
        count=new TextView(host);count.setTextSize(10*fontScale);count.setTypeface(font);count.setIncludeFontPadding(false);count.setPadding(dp(7),dp(4),dp(7),dp(4));
        LinearLayout.LayoutParams badge=new LinearLayout.LayoutParams(-2,-2);badge.topMargin=dp(9);identity.addView(count,badge);
        LinearLayout.LayoutParams leading=new LinearLayout.LayoutParams(dp(LABEL_WIDTH),-2);leading.rightMargin=dp(LABEL_GAP);addView(identity,leading);addView(rail,new LinearLayout.LayoutParams(0,-2,1));setActive(null);
    }
    void setActive(View focused){
        boolean active=focused!=null;int position=active?apps.indexOfChild(focused):-1;
        title.setTextColor(active?accent:foreground);
        count.setText(active&&position>=0&&total>0?(position+1)+" / "+total:total==0?"No apps":total==1?"1 app":total+" apps");count.setTextColor(active?accent:secondary);
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
