package com.shadowfox.tvlauncher;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Lightweight vector materials, shared by Home, settings and option panels. */
final class StudioStyle {
    static final int BLUE=0xff85d4ff, AMBER=0xffffb668;
    static Drawable surface(Context host,int fill,float radius,boolean focused){
        return new Surface(host.getResources().getDisplayMetrics().density,fill,radius,focused);
    }
    static Drawable backdrop(){return new Backdrop();}
    private static final class Surface extends Drawable {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density,radius;private final int fill;private final boolean focused;
        Surface(float density,int fill,float radius,boolean focused){this.density=density;this.fill=fill;this.radius=radius*density;this.focused=focused;}
        @Override public void draw(Canvas canvas){
            Rect b=getBounds();RectF rect=new RectF(b);float stroke=density*(focused?1.4f:.7f);rect.inset(stroke/2,stroke/2);
            int top=focused?0xf02c455b:fill;
            int bottom=focused?0xf0122437:Color.argb(Color.alpha(fill),Math.round(Color.red(fill)*.65f),Math.round(Color.green(fill)*.72f),Math.round(Color.blue(fill)*.80f));
            paint.setStyle(Paint.Style.FILL);paint.setShader(new LinearGradient(rect.left,rect.top,rect.right,rect.bottom,new int[]{top,bottom},null,Shader.TileMode.CLAMP));canvas.drawRoundRect(rect,radius,radius,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(stroke);paint.setShader(new LinearGradient(rect.left,rect.top,rect.right,rect.bottom,focused?new int[]{BLUE,0xff4b7896,AMBER}:new int[]{0x507c96b4,0x102d3d50,0x30475a70},null,Shader.TileMode.CLAMP));canvas.drawRoundRect(rect,radius,radius,paint);
            paint.setShader(null);paint.setStyle(Paint.Style.FILL);
            // A short highlight adds depth without a blur or an animated render loop.
            Path clip=new Path();clip.addRoundRect(rect,radius,radius,Path.Direction.CW);canvas.save();canvas.clipPath(clip);
            paint.setShader(new LinearGradient(0,rect.top,0,rect.top+Math.min(rect.height()*.42f,36*density),0x13ffffff,Color.TRANSPARENT,Shader.TileMode.CLAMP));canvas.drawRect(rect,paint);canvas.restore();paint.setShader(null);
        }
        @Override public void setAlpha(int alpha){}
        @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
    private static final class Backdrop extends Drawable {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        @Override public void draw(Canvas canvas){
            Rect r=getBounds();float w=r.width(),h=r.height();
            paint.setShader(new LinearGradient(0,0,w,h,new int[]{0xff172131,0xff0d1420,0xff11161e},new float[]{0,.55f,1},Shader.TileMode.CLAMP));canvas.drawRect(r,paint);
            paint.setShader(new RadialGradient(w*.82f,h*.05f,w*.60f,new int[]{0x332c8cbd,0x00182a3d},null,Shader.TileMode.CLAMP));canvas.drawRect(r,paint);
            paint.setShader(new RadialGradient(w,h*1.2f,w*.50f,new int[]{0x20e88c36,Color.TRANSPARENT},null,Shader.TileMode.CLAMP));canvas.drawRect(r,paint);
            paint.setShader(null);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);paint.setColor(0x0bf0f6ff);
            for(int i=0;i<3;i++)canvas.drawCircle(w*1.01f,h*.02f,w*(.26f+i*.075f),paint);
            paint.setStyle(Paint.Style.FILL);
        }
        @Override public void setAlpha(int alpha){}
        @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return PixelFormat.OPAQUE;}
    }
    static final class Preview extends View {
        private Bitmap bitmap;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        Preview(Context host,Bitmap bitmap){super(host);this.bitmap=bitmap;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas canvas){
            float d=getResources().getDisplayMetrics().density;RectF frame=new RectF(1,1,getWidth()-1,getHeight()-1);Path clip=new Path();clip.addRoundRect(frame,12*d,12*d,Path.Direction.CW);
            canvas.save();canvas.clipPath(clip);paint.setColor(0xff0a1018);canvas.drawRect(frame,paint);
            if(bitmap!=null&&!bitmap.isRecycled())canvas.drawBitmap(bitmap,null,frame,paint);
            paint.setShader(new LinearGradient(0,getHeight()*.6f,0,getHeight(),Color.TRANSPARENT,0xee080e18,Shader.TileMode.CLAMP));canvas.drawRect(frame,paint);paint.setShader(null);
            paint.setColor(0xffedf6ff);paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));paint.setTextSize(9*d);canvas.drawText("YOUR HOME",12*d,getHeight()-12*d,paint);canvas.restore();
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d);paint.setColor(0x80678ba7);canvas.drawRoundRect(frame,12*d,12*d,paint);paint.setStyle(Paint.Style.FILL);
        }
        @Override protected void onDetachedFromWindow(){super.onDetachedFromWindow();if(bitmap!=null){bitmap.recycle();bitmap=null;}}
    }
}
