package com.shadowfox.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.*;
import java.util.*;
import java.util.function.Consumer;

/** Recycled, searchable artwork browser; drawables are loaded only for visible cells. */
final class TvIconBrowser {
    static void show(Activity host,Typeface font,int surface,int foreground,int secondary,String title,List<String> catalog,ProjectivyIcons pack,String current,Consumer<String> selected,Runnable back){
        float density=host.getResources().getDisplayMetrics().density;
        java.util.function.IntUnaryOperator dp=n->Math.round(n*density);
        int focusColor=0xff29445d;
        LinearLayout page=new LinearLayout(host);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp.applyAsInt(24),dp.applyAsInt(25),dp.applyAsInt(24),dp.applyAsInt(18));page.setBackground(StudioStyle.backdrop());
        page.setMinimumHeight(host.getResources().getDisplayMetrics().heightPixels);
        TextView heading=new TextView(host);heading.setText(title);heading.setTypeface(font,Typeface.BOLD);heading.setTextColor(foreground);heading.setTextSize(25);page.addView(heading);
        TextView count=new TextView(host);count.setTextColor(secondary);count.setTextSize(13);count.setTypeface(font);count.setPadding(0,dp.applyAsInt(7),0,dp.applyAsInt(14));page.addView(count);
        EditText search=new EditText(host);search.setSingleLine(true);search.setTextSize(16);search.setTypeface(font);search.setTextColor(foreground);search.setHintTextColor(secondary);search.setHint("Search icons");search.setContentDescription("Search icons");search.setId(View.generateViewId());page.addView(search,new LinearLayout.LayoutParams(-1,dp.applyAsInt(44)));
        search.setBackground(StudioStyle.surface(host,0xb01b2d40,10,false));search.setPadding(dp.applyAsInt(14),0,dp.applyAsInt(14),0);
        GridView grid=new GridView(host);grid.setNumColumns(3);grid.setVerticalSpacing(dp.applyAsInt(12));grid.setHorizontalSpacing(dp.applyAsInt(12));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setPadding(0,dp.applyAsInt(16),0,dp.applyAsInt(8));grid.setClipToPadding(false);grid.setVerticalScrollBarEnabled(false);grid.setId(View.generateViewId());grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        page.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        ArrayList<String> names=new ArrayList<>(catalog);names.sort(String.CASE_INSENSITIVE_ORDER);ArrayList<String> filtered=new ArrayList<>(names);
        BaseAdapter adapter=new BaseAdapter(){
            public int getCount(){return filtered.size();}public Object getItem(int position){return filtered.get(position);}public long getItemId(int position){return position;}
            public View getView(int position,View recycled,ViewGroup parent){
                LinearLayout tile;
                if(recycled instanceof LinearLayout)tile=(LinearLayout)recycled;
                else{tile=new LinearLayout(host);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp.applyAsInt(8),dp.applyAsInt(10),dp.applyAsInt(8),dp.applyAsInt(8));
                    ImageView icon=new ImageView(host);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);tile.addView(icon,new LinearLayout.LayoutParams(-1,dp.applyAsInt(60)));
                    TextView label=new TextView(host);label.setTextColor(foreground);label.setTextSize(12);label.setTypeface(font);label.setGravity(Gravity.CENTER);label.setMaxLines(2);label.setMinLines(2);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setPadding(0,dp.applyAsInt(7),0,0);tile.addView(label,new LinearLayout.LayoutParams(-1,-2));
                    tile.setLayoutParams(new AbsListView.LayoutParams(-1,dp.applyAsInt(115)));}
                String name=filtered.get(position);tile.setContentDescription(name.replace('_',' '));((ImageView)tile.getChildAt(0)).setImageDrawable(pack.drawable(name));
                ((TextView)tile.getChildAt(1)).setText((name.equals(current)?"✓ ":"")+name.replace('_',' '));
                tile.setBackground(StudioStyle.surface(host,0x90203044,12,grid.hasFocus()&&position==grid.getSelectedItemPosition()));return tile;
            }
        };
        grid.setAdapter(adapter);grid.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){for(int i=0;i<grid.getChildCount();i++)grid.getChildAt(i).setBackground(StudioStyle.surface(host,0x90203044,12,false));if(grid.hasFocus()&&view!=null)view.setBackground(StudioStyle.surface(host,0x90203044,12,true));}
            public void onNothingSelected(AdapterView<?> parent){}
        });
        grid.setOnFocusChangeListener((v,focused)->{for(int i=0;i<grid.getChildCount();i++)grid.getChildAt(i).setBackground(StudioStyle.surface(host,0x90203044,12,false));View cell=grid.getSelectedView();if(focused&&cell!=null)cell.setBackground(StudioStyle.surface(host,0x90203044,12,true));});
        search.setNextFocusDownId(grid.getId());grid.setNextFocusUpId(search.getId());
        AlertDialog dialog=new AlertDialog.Builder(host).setView(page).create();
        if(host instanceof MainActivity)((MainActivity)host).trackDialog(dialog);
        dialog.setOnCancelListener(d->back.run());
        TextView close=new TextView(host);close.setText("Back to icon groups");close.setContentDescription("Back to icon groups");close.setTextColor(foreground);close.setTypeface(font);close.setTextSize(15);close.setGravity(Gravity.CENTER);close.setPadding(0,dp.applyAsInt(12),0,dp.applyAsInt(12));close.setFocusable(true);close.setClickable(true);close.setId(View.generateViewId());close.setOnClickListener(v->dialog.cancel());close.setOnFocusChangeListener((v,focus)->v.setBackgroundColor(focus?focusColor:Color.TRANSPARENT));page.addView(close);grid.setNextFocusDownId(close.getId());close.setNextFocusUpId(grid.getId());
        grid.setOnItemClickListener((parent,view,position,id)->{String choice=filtered.get(position);dialog.dismiss();selected.accept(choice);});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void afterTextChanged(Editable e){}public void onTextChanged(CharSequence value,int start,int before,int length){
            String query=value.toString().trim().toLowerCase(Locale.ROOT);filtered.clear();for(String name:names)if(name.replace('_',' ').toLowerCase(Locale.ROOT).contains(query))filtered.add(name);adapter.notifyDataSetChanged();grid.setSelection(0);count.setText(filtered.size()+(filtered.size()==1?" icon":" icons")+" · OK applies artwork"+(filtered.isEmpty()?" · No matches":""));
        }});
        count.setText(filtered.size()+" icons · OK applies artwork");
        dialog.setOnShowListener(d->{dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));dialog.getWindow().setLayout(Math.min(dp.applyAsInt(570),Math.round(host.getResources().getDisplayMetrics().widthPixels*.72f)),-1);dialog.getWindow().setGravity(Gravity.RIGHT);dialog.getWindow().setDimAmount(.38f);dialog.getWindow().getDecorView().setPadding(0,0,0,0);dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);grid.requestFocusFromTouch();grid.setSelection(0);});dialog.show();
    }
}
