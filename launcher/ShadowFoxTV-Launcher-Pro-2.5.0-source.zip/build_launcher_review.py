from pathlib import Path
import subprocess,zipfile,xml.etree.ElementTree as ET,hashlib,os
ROOT=Path(__file__).resolve().parent
APP=ROOT/'shadowfox-branding/launcher-review/app'
BUILD=ROOT/'shadowfox-branding/launcher-review/build';BUILD.mkdir(exist_ok=True)
JAVA=Path(os.environ.get('JAVA_HOME',r'C:\Program Files\Android\Android Studio\jbr'))/'bin'
SDK=Path(os.environ.get('ANDROID_HOME',str(Path(os.environ['LOCALAPPDATA'])/'Android/Sdk')))
TOOLS=SDK/'build-tools/35.0.0';ANDROID=SDK/'platforms/android-35/android.jar'
NS='{http://schemas.android.com/apk/res/android}'
manifest=APP/'AndroidManifest.xml';tree=ET.parse(manifest);root=tree.getroot()
root.set('package','com.shadowfox.tvlauncher.review');root.set(NS+'versionCode','42');root.set(NS+'versionName','2.5.0')
for permission in ('android.permission.WRITE_SETTINGS','android.permission.INTERNET','android.permission.REQUEST_INSTALL_PACKAGES'):
    if not any(p.get(NS+'name')==permission for p in root.findall('uses-permission')):ET.SubElement(root,'uses-permission',{NS+'name':permission})
application=root.find('application');application.set(NS+'label','ShadowFoxTV Launcher Pro')
application.set(NS+'usesCleartextTraffic','false')
if not any(p.get(NS+'name')=='com.shadowfox.tvlauncher.UpdateFileProvider' for p in application.findall('provider')):
    ET.SubElement(application,'provider',{NS+'name':'com.shadowfox.tvlauncher.UpdateFileProvider',NS+'authorities':'com.shadowfox.tvlauncher.review.updates',NS+'exported':'false',NS+'grantUriPermissions':'true'})
activity=application.find('activity');activity.set(NS+'name','com.shadowfox.tvlauncher.MainActivity')
activity.set(NS+'launchMode','singleTask')
intent=activity.find('intent-filter')
for name in ('android.intent.category.HOME','android.intent.category.DEFAULT'):
    if not any(c.get(NS+'name')==name for c in intent.findall('category')):ET.SubElement(intent,'category',{NS+'name':name})
if not any(c.get(NS+'name')=='android.intent.category.LAUNCHER' for c in intent.findall('category')):ET.SubElement(intent,'category',{NS+'name':'android.intent.category.LAUNCHER'})
queries=root.find('queries')
for action in ('android.settings.HOME_SETTINGS','android.settings.APPLICATION_DETAILS_SETTINGS','android.settings.action.MANAGE_WRITE_SETTINGS','android.settings.SOUND_SETTINGS'):
    if not any(i.find('action').get(NS+'name')==action for i in queries.findall('intent')):ET.SubElement(ET.SubElement(queries,'intent'),'action',{NS+'name':action})
for action in ('android.intent.action.OPEN_DOCUMENT','android.intent.action.GET_CONTENT'):
    if not any(i.find('action').get(NS+'name')==action for i in queries.findall('intent')):
        image_query=ET.SubElement(queries,'intent')
        ET.SubElement(image_query,'action',{NS+'name':action})
        ET.SubElement(image_query,'category',{NS+'name':'android.intent.category.OPENABLE'})
        ET.SubElement(image_query,'data',{NS+'mimeType':'image/*'})
tree.write(manifest,encoding='utf-8',xml_declaration=True)
def run(*args):
    result=subprocess.run([str(a) for a in args],capture_output=True,text=True)
    if result.returncode:raise RuntimeError(result.stderr or result.stdout)
    if result.stdout.strip():print(result.stdout.strip())
resourceHash=hashlib.sha256()
for resource in sorted((APP/'res').rglob('*')):
    if resource.is_file():resourceHash.update(str(resource.relative_to(APP)).encode());resourceHash.update(resource.read_bytes())
resourceStamp=BUILD/'resources.sha256'
if not (BUILD/'resources.zip').exists() or not resourceStamp.exists() or resourceStamp.read_text()!=resourceHash.hexdigest():
    run(TOOLS/'aapt2.exe','compile','--dir',APP/'res','-o',BUILD/'resources.zip')
    resourceStamp.write_text(resourceHash.hexdigest())
run(TOOLS/'aapt2.exe','link','-o',BUILD/'unsigned.apk','--manifest',manifest,'-I',ANDROID,'--java',BUILD/'generated','--custom-package','com.shadowfox.tvlauncher','-A',APP/'assets',BUILD/'resources.zip')
classes=BUILD/'classes';classes.mkdir(exist_ok=True)
run(JAVA/'javac.exe','-encoding','UTF-8','-source','8','-target','8','-classpath',ANDROID,'-d',classes,*list((APP/'src').rglob('*.java')),*list((BUILD/'generated').rglob('*.java')))
run(JAVA/'java.exe','-cp',TOOLS/'lib/d8.jar','com.android.tools.r8.D8','--lib',ANDROID,'--min-api','24','--output',BUILD,*list(classes.rglob('*.class')))
with zipfile.ZipFile(BUILD/'unsigned.apk','a') as z:z.write(BUILD/'classes.dex','classes.dex')
run(TOOLS/'zipalign.exe','-f','4',BUILD/'unsigned.apk',BUILD/'aligned.apk')
KEYS=Path(os.environ.get('SHADOWFOX_SIGNING_DIR',str(ROOT/'shadowfox-branding/signing')))
APK=ROOT/'shadowfox-branding/launcher-review/ShadowFoxTV-Launcher-Pro-2.5.0.apk'
run(JAVA/'java.exe','-jar',TOOLS/'lib/apksigner.jar','sign','--ks',KEYS/'shadowfox-home.p12','--ks-pass','file:'+str(KEYS/'password.txt'),'--out',APK,BUILD/'aligned.apk')
run(JAVA/'java.exe','-jar',TOOLS/'lib/apksigner.jar','verify','--verbose',APK)
with zipfile.ZipFile(APK) as z:
    assert z.testzip() is None
    assert z.read('res/drawable-nodpi-v4/stock_wallpaper.png')==(APP/'res/drawable-nodpi/stock_wallpaper.png').read_bytes()
print('REVIEW_APK',APK)
print('SHA256',hashlib.sha256(APK.read_bytes()).hexdigest())
