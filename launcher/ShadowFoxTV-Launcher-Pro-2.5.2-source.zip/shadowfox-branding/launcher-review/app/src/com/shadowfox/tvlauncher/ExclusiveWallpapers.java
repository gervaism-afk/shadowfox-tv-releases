package com.shadowfox.tvlauncher;

import android.app.AlertDialog;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.concurrent.*;

/** Curated, offline wallpaper previews. Browsing never changes Home until Apply. */
final class ExclusiveWallpapers {
    static final class Entry {
        final String id,name,detail;final int resource,thumbnail;
        Entry(String id,String name,String detail,int resource){this(id,name,detail,resource,resource);}
        Entry(String id,String name,String detail,int resource,int thumbnail){this.id=id;this.name=name;this.detail=detail;this.resource=resource;this.thumbnail=thumbnail;}
    }
    static final Entry[] ENTRIES={
        new Entry("midnight","Midnight Flow","Smoky indigo and blue light, composed for the Home and Apps layout",R.drawable.midnight_flow),
        new Entry("cosmic","Cosmic Horizon","Blue-violet planets and mountains, composed for the logo dock",R.drawable.cosmic_horizon),
        new Entry("studio","Studio","Blue and amber light on smoked glass",R.drawable.studio_wallpaper),
        new Entry("silk","Obsidian Silk","Black satin with soft silver highlights",R.drawable.obsidian_silk),
        new Entry("titanium","Forged Titanium","Brushed gunmetal and copper detailing",R.drawable.forged_titanium),
        new Entry("glacier","Glacial Prism","Sculpted blue ice and deep navy shadows",R.drawable.glacial_prism),
        new Entry("copper","Liquid Copper","Flowing copper and polished black chrome",R.drawable.liquid_copper),
        new Entry("collection_043d3839081f6624","Cyan Wave","From your ShadowFox Wallpapers collection",R.drawable.collection_043d3839081f6624,R.drawable.collection_043d3839081f6624_thumb),
        new Entry("collection_c30022b4916e3506","Pearl & Amber","From your ShadowFox Wallpapers collection",R.drawable.collection_c30022b4916e3506,R.drawable.collection_c30022b4916e3506_thumb),
        new Entry("collection_72c94cf9cfd03423","Circuit Crest Large","From your ShadowFox Wallpapers collection",R.drawable.collection_72c94cf9cfd03423,R.drawable.collection_72c94cf9cfd03423_thumb),
        new Entry("collection_29eee9480d96a832","Carbon Crest","From your ShadowFox Wallpapers collection",R.drawable.collection_29eee9480d96a832,R.drawable.collection_29eee9480d96a832_thumb),
        new Entry("collection_37f2f872c411a419","Blue Halo","From your ShadowFox Wallpapers collection",R.drawable.collection_37f2f872c411a419,R.drawable.collection_37f2f872c411a419_thumb),
        new Entry("collection_925c1c599f758ab6","Electric Circuit Hall","From your ShadowFox Wallpapers collection",R.drawable.collection_925c1c599f758ab6,R.drawable.collection_925c1c599f758ab6_thumb),
        new Entry("collection_2526377a58ed6f69","Moonlit Lake","From your ShadowFox Wallpapers collection",R.drawable.collection_2526377a58ed6f69,R.drawable.collection_2526377a58ed6f69_thumb),
        new Entry("collection_ce183a959e159cdd","Sapphire Wave","From your ShadowFox Wallpapers collection",R.drawable.collection_ce183a959e159cdd,R.drawable.collection_ce183a959e159cdd_thumb),
        new Entry("collection_7fea28a8c0fb555f","Neon Columns","From your ShadowFox Wallpapers collection",R.drawable.collection_7fea28a8c0fb555f,R.drawable.collection_7fea28a8c0fb555f_thumb),
        new Entry("collection_e42c988334542312","Amber Wave","From your ShadowFox Wallpapers collection",R.drawable.collection_e42c988334542312,R.drawable.collection_e42c988334542312_thumb),
        new Entry("collection_423144238a52219e","Blue Reflection","From your ShadowFox Wallpapers collection",R.drawable.collection_423144238a52219e,R.drawable.collection_423144238a52219e_thumb),
        new Entry("collection_95e0307022dda1d7","Electric Silk","From your ShadowFox Wallpapers collection",R.drawable.collection_95e0307022dda1d7,R.drawable.collection_95e0307022dda1d7_thumb),
        new Entry("collection_874322dfd25b5ae4","Midnight Lounge","From your ShadowFox Wallpapers collection",R.drawable.collection_874322dfd25b5ae4,R.drawable.collection_874322dfd25b5ae4_thumb),
        new Entry("collection_149361fc6f37b059","Violet Steel","From your ShadowFox Wallpapers collection",R.drawable.collection_149361fc6f37b059,R.drawable.collection_149361fc6f37b059_thumb),
        new Entry("collection_c38ea5b38c0af41a","Fire & Ice Globe","From your ShadowFox Wallpapers collection",R.drawable.collection_c38ea5b38c0af41a,R.drawable.collection_c38ea5b38c0af41a_thumb),
        new Entry("collection_3029449fcb81da47","Neon Fox Stage","From your ShadowFox Wallpapers collection",R.drawable.collection_3029449fcb81da47,R.drawable.collection_3029449fcb81da47_thumb),
        new Entry("collection_ee866456be871055","Brushed Midnight","From your ShadowFox Wallpapers collection",R.drawable.collection_ee866456be871055,R.drawable.collection_ee866456be871055_thumb),
        new Entry("collection_a4dc9c8987f884f0","Android TV Blue","From your ShadowFox Wallpapers collection",R.drawable.collection_a4dc9c8987f884f0,R.drawable.collection_a4dc9c8987f884f0_thumb),
        new Entry("collection_a0ae94e94a42fd9b","Orbital Lounge","From your ShadowFox Wallpapers collection",R.drawable.collection_a0ae94e94a42fd9b,R.drawable.collection_a0ae94e94a42fd9b_thumb),
        new Entry("collection_a2b982af7b166e1d","Classic Midnight","From your ShadowFox Wallpapers collection",R.drawable.collection_a2b982af7b166e1d,R.drawable.collection_a2b982af7b166e1d_thumb),
        new Entry("collection_67892cbec54a668c","Midnight Signature","From your ShadowFox Wallpapers collection",R.drawable.collection_67892cbec54a668c,R.drawable.collection_67892cbec54a668c_thumb),
        new Entry("collection_06044584d37a337b","Classic Midnight 5K","From your ShadowFox Wallpapers collection",R.drawable.collection_06044584d37a337b,R.drawable.collection_06044584d37a337b_thumb),
        new Entry("collection_cf0580ea9d1ea6f1","Sky Blue Crest","From your ShadowFox Wallpapers collection",R.drawable.collection_cf0580ea9d1ea6f1,R.drawable.collection_cf0580ea9d1ea6f1_thumb),
        new Entry("collection_30f9bc8e873b0a2b","Azure Crest","From your ShadowFox Wallpapers collection",R.drawable.collection_30f9bc8e873b0a2b,R.drawable.collection_30f9bc8e873b0a2b_thumb),
        new Entry("collection_0c99b992ac96aa33","Carbon Ribbon","From your ShadowFox Wallpapers collection",R.drawable.collection_0c99b992ac96aa33,R.drawable.collection_0c99b992ac96aa33_thumb),
        new Entry("collection_9f50c32276365693","Blue Light Columns","From your ShadowFox Wallpapers collection",R.drawable.collection_9f50c32276365693,R.drawable.collection_9f50c32276365693_thumb),
        new Entry("collection_3af6aadc22f5aab4","Neon Arena","From your ShadowFox Wallpapers collection",R.drawable.collection_3af6aadc22f5aab4,R.drawable.collection_3af6aadc22f5aab4_thumb),
        new Entry("collection_2efe3e50980fdd7a","Circuit Crest","From your ShadowFox Wallpapers collection",R.drawable.collection_2efe3e50980fdd7a,R.drawable.collection_2efe3e50980fdd7a_thumb),
        new Entry("collection_a8ee49649722a598","Circuit Crest Compact","From your ShadowFox Wallpapers collection",R.drawable.collection_a8ee49649722a598,R.drawable.collection_a8ee49649722a598_thumb),
        new Entry("collection_ea86196441e512cf","Circuit Crest Clean","From your ShadowFox Wallpapers collection",R.drawable.collection_ea86196441e512cf,R.drawable.collection_ea86196441e512cf_thumb),
        new Entry("collection_75627ca305d1d23c","Sapphire Spotlight","From your ShadowFox Wallpapers collection",R.drawable.collection_75627ca305d1d23c,R.drawable.collection_75627ca305d1d23c_thumb),
        new Entry("collection_aff6b65ed6b53b6a","Carbon Fox 4K","From your ShadowFox Wallpapers collection",R.drawable.collection_aff6b65ed6b53b6a,R.drawable.collection_aff6b65ed6b53b6a_thumb)
    };
    static Entry find(String id){for(Entry entry:ENTRIES)if(entry.id.equals(id))return entry;return null;}
    private static final int TEXT=0xffeff4fa,MUTED=0xffa7b7c9;
    private final MainActivity host;
    private final String current;
    private final AlertDialog dialog;
    private final ImageView artwork;
    private final TextView name,detail,status,apply;
    private final ArrayList<View> cards=new ArrayList<>();
    private final ArrayList<Bitmap> thumbnails=new ArrayList<>();
    private Bitmap preview;
    private final ExecutorService decoder=Executors.newSingleThreadExecutor();
    private Future<?> previewTask;
    private int previewRequest;
    private boolean closed;
    private int selected=-1;

    private ExclusiveWallpapers(MainActivity host,String current,Consumer<String> save,Runnable back){
        this.host=host;this.current=current;
        FrameLayout root=new FrameLayout(host);root.addView(host.createSettingsBackdrop(),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout shell=new LinearLayout(host);shell.setOrientation(LinearLayout.VERTICAL);shell.setPadding(dp(28),dp(22),dp(28),dp(16));root.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(host);header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles=new LinearLayout(host);titles.setOrientation(LinearLayout.VERTICAL);
        TextView brand=label("SHADOWFOX EXCLUSIVE",11,StudioStyle.AMBER,true);brand.setLetterSpacing(.16f);titles.addView(brand);
        TextView title=label("Wallpaper selector",26,TEXT,true);title.setPadding(0,dp(5),0,0);titles.addView(title);header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView collection=label(ENTRIES.length+" EXCLUSIVE WALLPAPERS",10,StudioStyle.BLUE,true);collection.setLetterSpacing(.08f);header.addView(collection);shell.addView(header,new LinearLayout.LayoutParams(-1,-2));
        TextView intro=label("Find your look. Preview it, then make it yours.",12,MUTED,false);intro.setPadding(0,dp(8),0,dp(16));shell.addView(intro);

        LinearLayout body=new LinearLayout(host);body.setOrientation(LinearLayout.HORIZONTAL);shell.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout hero=new LinearLayout(host);hero.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams heroSize=new LinearLayout.LayoutParams(0,-1,1);heroSize.rightMargin=dp(18);body.addView(hero,heroSize);
        FrameLayout frame=new FrameLayout(host);frame.setBackground(StudioStyle.surface(host,0xc009111b,14,false));frame.setPadding(dp(2),dp(2),dp(2),dp(2));
        artwork=new ImageView(host);artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);artwork.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);frame.addView(artwork,new FrameLayout.LayoutParams(-1,-1));
        hero.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout caption=new LinearLayout(host);caption.setGravity(Gravity.CENTER_VERTICAL);caption.setPadding(dp(2),dp(12),dp(2),dp(10));
        LinearLayout words=new LinearLayout(host);words.setOrientation(LinearLayout.VERTICAL);name=label("",21,TEXT,true);words.addView(name);detail=label("",11,MUTED,false);detail.setPadding(0,dp(4),0,0);words.addView(detail);caption.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        status=label("",10,StudioStyle.BLUE,true);status.setPadding(dp(12),dp(7),dp(12),dp(7));status.setBackground(StudioStyle.surface(host,0x60345267,8,false));caption.addView(status);hero.addView(caption);
        LinearLayout actions=new LinearLayout(host);actions.setGravity(Gravity.CENTER_VERTICAL);
        apply=button("Apply wallpaper");LinearLayout.LayoutParams applySize=new LinearLayout.LayoutParams(0,dp(45),1);applySize.rightMargin=dp(10);actions.addView(apply,applySize);
        TextView cancel=button("Back");actions.addView(cancel,new LinearLayout.LayoutParams(dp(96),dp(45)));hero.addView(actions);

        ScrollView scroll=new ScrollView(host);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);scroll.setPadding(dp(3),dp(3),dp(3),dp(3));body.addView(scroll,new LinearLayout.LayoutParams(dp(250),-1));
        LinearLayout list=new LinearLayout(host);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);
        int initial=0;
        for(int i=0;i<ENTRIES.length;i++){
            final int index=i;Entry entry=ENTRIES[i];if(entry.id.equals(current))initial=i;
            LinearLayout card=new LinearLayout(host);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(9),dp(9),dp(9),dp(9));focusable(card);card.setContentDescription("Preview "+entry.name);
            ImageView thumb=new ImageView(host);Bitmap thumbnail=decode(entry.thumbnail,240);thumbnails.add(thumbnail);thumb.setImageBitmap(thumbnail);thumb.setScaleType(ImageView.ScaleType.FIT_CENTER);thumb.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);LinearLayout.LayoutParams thumbSize=new LinearLayout.LayoutParams(dp(91),dp(52));thumbSize.rightMargin=dp(10);card.addView(thumb,thumbSize);
            LinearLayout text=new LinearLayout(host);text.setOrientation(LinearLayout.VERTICAL);TextView cardName=label(entry.name,15,TEXT,true);cardName.setMaxLines(2);cardName.setEllipsize(android.text.TextUtils.TruncateAt.END);text.addView(cardName);TextView note=label(entry.id.equals(current)?"Current wallpaper":"Preview",10,entry.id.equals(current)?StudioStyle.AMBER:MUTED,false);note.setPadding(0,dp(5),0,0);text.addView(note);card.addView(text,new LinearLayout.LayoutParams(0,-2,1));
            card.setOnFocusChangeListener((v,focused)->{StudioStyle.focusMotion(v,focused,1f,0);if(focused)select(index);paintCards();});
            card.setOnClickListener(v->{select(index);apply.requestFocusFromTouch();});
            LinearLayout.LayoutParams cardSize=new LinearLayout.LayoutParams(-1,dp(74));cardSize.bottomMargin=dp(8);list.addView(card,cardSize);cards.add(card);
        }
        for(int i=0;i<cards.size();i++){
            View card=cards.get(i);card.setNextFocusUpId(cards.get(Math.max(0,i-1)).getId());card.setNextFocusDownId(cards.get(Math.min(cards.size()-1,i+1)).getId());card.setNextFocusLeftId(apply.getId());card.setNextFocusRightId(card.getId());
        }
        apply.setNextFocusLeftId(apply.getId());apply.setNextFocusDownId(apply.getId());apply.setNextFocusRightId(cancel.getId());cancel.setNextFocusLeftId(apply.getId());cancel.setNextFocusDownId(cancel.getId());
        View.OnKeyListener returnToList=(v,code,event)->{if(code==KeyEvent.KEYCODE_DPAD_UP||(v==cancel&&code==KeyEvent.KEYCODE_DPAD_RIGHT)){if(event.getAction()==KeyEvent.ACTION_DOWN)cards.get(Math.max(0,selected)).requestFocusFromTouch();return true;}return false;};apply.setOnKeyListener(returnToList);cancel.setOnKeyListener(returnToList);
        TextView hint=label("↑ ↓  Browse     OK  Preview / apply     Back  Cancel",10,MUTED,false);hint.setPadding(dp(2),dp(13),0,0);shell.addView(hint);

        dialog=host.trackDialog(new AlertDialog.Builder(host).create());
        dialog.setOnCancelListener(d->back.run());cancel.setOnClickListener(v->dialog.cancel());
        apply.setOnClickListener(v->{String id=ENTRIES[selected].id;dialog.dismiss();save.accept(id);});
        final int start=initial;
        dialog.setOnShowListener(d->{dialog.setContentView(root,new ViewGroup.LayoutParams(-1,-1));Window window=dialog.getWindow();window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));window.getDecorView().setPadding(0,0,0,0);window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);window.setLayout(-1,-1);window.setDimAmount(0);window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);select(start);cards.get(start).requestFocusFromTouch();host.bindSettingsSounds(root);});
        root.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){
            @Override public void onViewAttachedToWindow(View v){}
            @Override public void onViewDetachedFromWindow(View v){closed=true;previewRequest++;if(previewTask!=null)previewTask.cancel(true);decoder.shutdownNow();artwork.setImageDrawable(null);if(preview!=null){preview.recycle();preview=null;}for(Bitmap bitmap:thumbnails)if(bitmap!=null)bitmap.recycle();thumbnails.clear();}
        });
    }
    static void show(MainActivity host,String current,Consumer<String> save,Runnable back){new ExclusiveWallpapers(host,current,save,back).dialog.show();}
    static Bitmap background(MainActivity host,int resource){
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeResource(host.getResources(),resource,bounds);
        android.util.DisplayMetrics display=host.getResources().getDisplayMetrics();BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;options.inSampleSize=1;
        while(bounds.outWidth/options.inSampleSize>display.widthPixels*1.5f||bounds.outHeight/options.inSampleSize>display.heightPixels*1.5f)options.inSampleSize*=2;
        return BitmapFactory.decodeResource(host.getResources(),resource,options);
    }
    private void select(int index){
        if(selected==index)return;selected=index;Entry entry=ENTRIES[index];artwork.setImageBitmap(thumbnails.get(index));Bitmap old=preview;preview=null;if(old!=null)old.recycle();
        name.setText(entry.name);detail.setText(entry.detail);status.setText(entry.id.equals(current)?"CURRENT":"PREVIEW");apply.setContentDescription("Apply "+entry.name);paintCards();
        int ticket=++previewRequest;if(previewTask!=null)previewTask.cancel(true);
        previewTask=decoder.submit(()->{Bitmap decoded;try{decoded=decode(entry.resource,1800);}catch(RuntimeException|OutOfMemoryError unavailable){return;}host.runOnUiThread(()->{if(closed||ticket!=previewRequest){if(decoded!=null)decoded.recycle();return;}artwork.setImageBitmap(decoded);Bitmap previous=preview;preview=decoded;if(previous!=null)previous.recycle();});});
    }
    private void paintCards(){for(int i=0;i<cards.size();i++){View card=cards.get(i);card.setBackground(StudioStyle.optionSurface(host,i==selected,card.hasFocus()));}}
    private Bitmap decode(int resource,int maxWidth){BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeResource(host.getResources(),resource,bounds);BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;options.inSampleSize=1;while(bounds.outWidth/options.inSampleSize>maxWidth*2)options.inSampleSize*=2;return BitmapFactory.decodeResource(host.getResources(),resource,options);}
    private TextView button(String text){TextView v=label(text,14,TEXT,true);v.setGravity(Gravity.CENTER);focusable(v);v.setBackground(StudioStyle.optionSurface(host,false,false));v.setOnFocusChangeListener((view,focused)->{view.setBackground(StudioStyle.optionSurface(host,false,focused));StudioStyle.focusMotion(view,focused,1f,0);});return v;}
    private void focusable(View view){view.setId(View.generateViewId());view.setFocusable(true);view.setClickable(true);}
    private TextView label(String value,int size,int color,boolean bold){return StudioStyle.label(host,value,size,color,bold);}
    private int dp(int value){return Math.round(value*host.getResources().getDisplayMetrics().density);}
}
