package com.shadowfox.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Shared TV controls: focus stays visible, Back returns to the previous page. */
final class TvPanel {
    private final Activity host;
    private final Typeface font;
    private final int foreground,secondary,focusColor;
    private final LinearLayout page,list,footer;
    private final AlertDialog dialog;
    private final ArrayList<View> options=new ArrayList<>();
    private final TextView note;
    private final ScrollView scroll;
    private TvPanel(Activity host,Typeface font,int surface,int foreground,int secondary,String title,String subtitle,Runnable back) {
        this.host=host;this.font=font;this.foreground=foreground;this.secondary=secondary;
        focusColor=0xff233b49;
        page=new LinearLayout(host);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(28),dp(30),dp(28),dp(20));
        page.setMinimumHeight(host.getResources().getDisplayMetrics().heightPixels);
        page.setBackground(host instanceof MainActivity?new ColorDrawable(Color.TRANSPARENT):StudioStyle.backdrop());
        TextView brand=label("SHADOWFOX TV",10,TvSettings.ACCENT,true);brand.setLetterSpacing(.15f);brand.setPadding(0,0,0,dp(12));page.addView(brand);
        TextView heading=label(title,27,foreground,true);page.addView(heading);
        note=label(subtitle,13,secondary,false);note.setPadding(0,dp(8),0,dp(20));page.addView(note);
        scroll=new ScrollView(host);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);
        list=new LinearLayout(host);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        footer=new LinearLayout(host);footer.setOrientation(LinearLayout.HORIZONTAL);footer.setPadding(0,dp(12),0,0);page.addView(footer);
        FrameLayout glass=new FrameLayout(host);glass.setMinimumHeight(host.getResources().getDisplayMetrics().heightPixels);if(host instanceof MainActivity)glass.addView(((MainActivity)host).createSettingsBackdrop(),new FrameLayout.LayoutParams(-1,-1));glass.addView(page,new FrameLayout.LayoutParams(-1,-1));
        dialog=new AlertDialog.Builder(host).create();
        if(host instanceof MainActivity)((MainActivity)host).trackDialog(dialog);
        dialog.setOnCancelListener(d->{if(back!=null)back.run();});
        dialog.setOnShowListener(d->{
            dialog.setContentView(glass,new android.view.ViewGroup.LayoutParams(-1,-1));
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width=Math.min(dp(530),Math.round(host.getResources().getDisplayMetrics().widthPixels*.72f));
            dialog.getWindow().setLayout(width,-1);dialog.getWindow().setGravity(Gravity.RIGHT);dialog.getWindow().setDimAmount(.28f);
            dialog.getWindow().getDecorView().setPadding(0,0,0,0);
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        });
    }
    private int dp(int n){return Math.round(n*host.getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size,int color,boolean bold){
        TextView v=new TextView(host);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setTypeface(font,bold?Typeface.BOLD:Typeface.NORMAL);return v;
    }
    private void focusable(View view){
        view.setFocusable(true);view.setClickable(true);view.setId(View.generateViewId());
        view.setOnFocusChangeListener((v,focused)->{
            v.setBackground(StudioStyle.surface(host,0x781d2c3e,12,focused));v.setElevation(focused?dp(3):0);
        });
    }
    private LinearLayout option(String name,String detail,Drawable artwork){
        LinearLayout item=new LinearLayout(host);item.setOrientation(LinearLayout.HORIZONTAL);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(12),dp(13),dp(12),dp(13));
        focusable(item);item.setContentDescription(name);item.setBackground(StudioStyle.surface(host,0x781d2c3e,12,false));item.setMinimumHeight(dp(56));
        if(artwork!=null){ImageView icon=new ImageView(host);icon.setImageDrawable(artwork);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams art=new LinearLayout.LayoutParams(dp(42),dp(42));art.rightMargin=dp(14);item.addView(icon,art);}
        LinearLayout words=new LinearLayout(host);words.setOrientation(LinearLayout.VERTICAL);words.addView(label(name,16,foreground,true));
        if(detail!=null&&!detail.isEmpty()){TextView sub=label(detail,12,secondary,false);sub.setPadding(0,dp(5),0,0);words.addView(sub);}
        item.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams row=new LinearLayout.LayoutParams(-1,-2);row.bottomMargin=dp(7);list.addView(item,row);options.add(item);return item;
    }
    private TextView action(String name,Runnable click){
        TextView v=label(name,15,foreground,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(12),dp(8),dp(12));v.setContentDescription(name);focusable(v);
        v.setOnClickListener(view->click.run());footer.addView(v,new LinearLayout.LayoutParams(0,-2,1));return v;
    }
    private void link(View before,View after){
        for(int i=0;i<options.size();i++){
            View v=options.get(i);v.setNextFocusUpId(i==0?(before==null?v.getId():before.getId()):options.get(i-1).getId());
            v.setNextFocusDownId(i+1<options.size()?options.get(i+1).getId():after.getId());
            v.setNextFocusLeftId(v.getId());v.setNextFocusRightId(v.getId());
        }
        if(before!=null)before.setNextFocusDownId(options.isEmpty()?after.getId():options.get(0).getId());
        after.setNextFocusUpId(options.isEmpty()?(before==null?after.getId():before.getId()):options.get(options.size()-1).getId());
    }
    static AlertDialog show(Activity host,Typeface font,int surface,int foreground,int secondary,String title,String subtitle,String[] choices,String[] details,int checked,int initial,IntConsumer selected,Runnable back){
        TvPanel panel=new TvPanel(host,font,surface,foreground,secondary,title,subtitle,back);
        for(int i=0;i<choices.length;i++){
            final int index=i;LinearLayout item=panel.option(choices[i],details!=null&&i<details.length?details[i]:null,null);item.setTag("panel-choice-"+i);
            if(i==checked){TextView mark=panel.label("✓",20,TvSettings.ACCENT,true);mark.setPadding(panel.dp(16),0,0,0);mark.setContentDescription("Current selection");item.addView(mark);}
            if(checked>=0)item.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setCheckable(true);info.setChecked(index==checked);}});
            item.setOnClickListener(v->{panel.dialog.dismiss();selected.accept(index);});
        }
        TextView close=panel.action("Back",()->panel.dialog.cancel());panel.link(null,close);panel.dialog.show();
        (panel.options.isEmpty()?close:panel.options.get(Math.max(0,Math.min(initial,panel.options.size()-1)))).requestFocusFromTouch();return panel.dialog;
    }
    static AlertDialog checklist(Activity host,Typeface font,int surface,int foreground,int secondary,String title,String[] labels,String[] details,Drawable[] artwork,boolean[] checked,Consumer<boolean[]> saved,Runnable back){
        TvPanel panel=new TvPanel(host,font,surface,foreground,secondary,title,"Select apps, then Save. Changes apply together.",back);
        boolean[] selection=checked.clone();
        EditText search=new EditText(host);search.setSingleLine(true);search.setHint("Search apps");search.setTextColor(foreground);search.setHintTextColor(secondary);search.setTextSize(16);search.setTypeface(font);search.setId(View.generateViewId());search.setContentDescription("Search apps");
        search.setBackground(StudioStyle.surface(host,0x701b2d40,10,false));search.setPadding(panel.dp(14),0,panel.dp(14),0);
        LinearLayout.LayoutParams searchSize=new LinearLayout.LayoutParams(-1,panel.dp(48));searchSize.bottomMargin=panel.dp(12);panel.page.addView(search,3,searchSize);
        TextView cancel=panel.action("Cancel",()->panel.dialog.cancel());
        TextView save=panel.action("Save",()->{panel.dialog.dismiss();saved.accept(selection);});
        cancel.setNextFocusRightId(save.getId());save.setNextFocusLeftId(cancel.getId());
        Runnable count=()->{int total=0;for(boolean chosen:selection)if(chosen)total++;panel.note.setText(total+" selected · Right to Save · Back cancels");};
        Runnable filter=()->{
            panel.list.removeAllViews();panel.options.clear();String query=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            for(int i=0;i<labels.length;i++){
                if(!labels[i].toLowerCase(Locale.ROOT).contains(query))continue;
                final int index=i;LinearLayout item=panel.option(labels[i],details[i],artwork[i]);item.setTag("app-selection-"+i);
                CheckBox check=new CheckBox(host);check.setButtonTintList(android.content.res.ColorStateList.valueOf(StudioStyle.BLUE));check.setFocusable(false);check.setClickable(false);check.setChecked(selection[i]);check.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);item.addView(check);
                item.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setCheckable(true);info.setChecked(selection[index]);}});
                item.setOnClickListener(v->{selection[index]=!selection[index];check.setChecked(selection[index]);count.run();});
            }
            if(panel.options.isEmpty()){TextView empty=panel.label("No apps match this search",15,secondary,false);empty.setPadding(0,panel.dp(18),0,0);panel.list.addView(empty);}
            panel.link(search,save);cancel.setNextFocusUpId(save.getNextFocusUpId());
            for(View item:panel.options){
                item.setNextFocusRightId(save.getId());item.setNextFocusLeftId(cancel.getId());
                View.OnFocusChangeListener highlight=item.getOnFocusChangeListener();
                item.setOnFocusChangeListener((v,focused)->{highlight.onFocusChange(v,focused);if(focused){save.setNextFocusUpId(v.getId());cancel.setNextFocusUpId(v.getId());}});
            }
            count.run();
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){filter.run();}public void afterTextChanged(Editable e){}});
        filter.run();panel.dialog.show();(panel.options.isEmpty()?search:panel.options.get(0)).requestFocusFromTouch();return panel.dialog;
    }
    private static int blend(int a,int b,float ratio){return Color.rgb(Math.round(Color.red(a)*(1-ratio)+Color.red(b)*ratio),Math.round(Color.green(a)*(1-ratio)+Color.green(b)*ratio),Math.round(Color.blue(a)*(1-ratio)+Color.blue(b)*ratio));}
}
