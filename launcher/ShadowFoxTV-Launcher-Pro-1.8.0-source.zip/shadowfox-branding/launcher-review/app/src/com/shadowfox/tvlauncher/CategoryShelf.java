package com.shadowfox.tvlauncher;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;

/** A translucent glass shelf with a category label beside its app rail. */
final class CategoryShelf extends LinearLayout {
    static final int LABEL_WIDTH=132,LABEL_GAP=16;
    private final TextView title,count;
    private final int total,foreground,secondary,accent;
    private final RailMaterial material;
    private final LinearLayout apps;
    CategoryShelf(Context host,Typeface font,float fontScale,String name,int total,int fill,int foreground,int secondary,int accent,HorizontalScrollView rail,LinearLayout apps){
        super(host);this.total=total;this.foreground=foreground;this.secondary=secondary;this.accent=accent;this.apps=apps;
        setOrientation(HORIZONTAL);setGravity(Gravity.CENTER_VERTICAL);setPadding(dp(12),dp(8),dp(12),dp(8));setClipChildren(false);setClipToPadding(false);
        material=new RailMaterial(getResources().getDisplayMetrics().density,fill,accent);setBackground(material);
        LinearLayout identity=new LinearLayout(host);identity.setOrientation(VERTICAL);identity.setGravity(Gravity.CENTER_VERTICAL);
        title=new TextView(host);title.setText(name);title.setTextSize(14*fontScale);title.setTypeface(Typeface.create(font,Typeface.BOLD));title.setTextColor(foreground);title.setIncludeFontPadding(false);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);identity.addView(title,new LinearLayout.LayoutParams(-1,-2));
        count=new TextView(host);count.setTextSize(10*fontScale);count.setTypeface(font);count.setIncludeFontPadding(false);count.setPadding(dp(7),dp(4),dp(7),dp(4));
        LinearLayout.LayoutParams badge=new LinearLayout.LayoutParams(-2,-2);badge.topMargin=dp(9);identity.addView(count,badge);
        LinearLayout.LayoutParams leading=new LinearLayout.LayoutParams(dp(LABEL_WIDTH),-2);leading.rightMargin=dp(LABEL_GAP);addView(identity,leading);addView(rail,new LinearLayout.LayoutParams(0,-2,1));setActive(null);
    }
    void setActive(View focused){
        boolean active=focused!=null;int position=active?apps.indexOfChild(focused):-1;
        title.setTextColor(active?accent:foreground);
        count.setText(active&&position>=0&&total>0?(position+1)+" / "+total:total==0?"No apps":total==1?"1 app":total+" apps");count.setTextColor(active?accent:secondary);
        GradientDrawable chip=new GradientDrawable();chip.setColor(active?0x183e9dc9:0x0c8ca2b8);chip.setCornerRadius(dp(5));count.setBackground(chip);
        material.active=active;material.invalidateSelf();
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private static final class RailMaterial extends Drawable {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final float density;private final int fill,accent;boolean active;
        RailMaterial(float density,int fill,int accent){this.density=density;this.fill=fill;this.accent=accent;}
        @Override public void draw(Canvas canvas){
            Rect b=getBounds();int alpha=Color.alpha(fill);float radius=16*density;
            RectF glass=new RectF(b.left+density,b.top+density,b.right-density,b.bottom-4*density);
            paint.setStyle(Paint.Style.FILL);paint.setShader(null);
            // Layered underside and a crisp lit rim give depth without blurring TV icons.
            for(int i=3;i>0;i--){RectF shadow=new RectF(glass);shadow.offset(0,i*density);paint.setColor(tint(Color.BLACK,Math.max(8,alpha*.18f)));canvas.drawRoundRect(shadow,radius,radius,paint);}
            paint.setColor(Color.WHITE);
            paint.setShader(new LinearGradient(0,glass.top,0,glass.bottom,new int[]{tint(0xff253c55,alpha),fill,tint(0xff0a1424,alpha)},new float[]{0,.42f,1},Shader.TileMode.CLAMP));canvas.drawRoundRect(glass,radius,radius,paint);paint.setShader(null);
            int saved=canvas.save();Path clip=new Path();clip.addRoundRect(glass,radius,radius,Path.Direction.CW);canvas.clipPath(clip);
            paint.setShader(new LinearGradient(glass.left,glass.top,glass.right,glass.bottom,new int[]{tint(0xffb9dbff,alpha==0?0:18+alpha*.22f),0x00b9dbff,0x00b9dbff},new float[]{0,.42f,1},Shader.TileMode.CLAMP));canvas.drawRect(glass,paint);paint.setShader(null);canvas.restoreToCount(saved);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(density);
            // Keep the structural edge readable even when the surface is set fully clear.
            paint.setShader(new LinearGradient(0,glass.top,0,glass.bottom,new int[]{tint(active?accent:0xffbdd5ed,Math.max(active?128:72,alpha*(active?1.1f:.65f))),tint(0xff6a8bac,Math.max(22,alpha*.2f)),tint(0xffb9d3ee,Math.max(40,alpha*.3f))},new float[]{0,.55f,1},Shader.TileMode.CLAMP));canvas.drawRoundRect(glass,radius,radius,paint);paint.setShader(null);paint.setStyle(Paint.Style.FILL);
            float divider=glass.left+(LABEL_WIDTH+LABEL_GAP/2f+10)*density;
            paint.setStrokeWidth(density);paint.setShader(new LinearGradient(0,glass.top+18*density,0,glass.bottom-18*density,new int[]{0x009cbcd8,tint(0xff9cbcd8,Math.max(42,alpha*.45f)),0x009cbcd8},new float[]{0,.5f,1},Shader.TileMode.CLAMP));canvas.drawLine(divider,glass.top+18*density,divider,glass.bottom-18*density,paint);paint.setShader(null);
            if(active){float centre=glass.centerY();paint.setShader(new LinearGradient(0,centre-17*density,0,centre+17*density,accent,StudioStyle.AMBER,Shader.TileMode.CLAMP));canvas.drawRoundRect(glass.left+5*density,centre-17*density,glass.left+7*density,centre+17*density,density,density,paint);paint.setShader(null);}
        }
        private static int tint(int colour,float alpha){return (colour&0x00ffffff)|(Math.max(0,Math.min(255,Math.round(alpha)))<<24);}
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
}
