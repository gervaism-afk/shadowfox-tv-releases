package com.shadowfox.tvlauncher;

import android.content.*;
import android.database.ContentObserver;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/** Static-wallpaper TV home: real program cards, circular apps and category library. */
final class GoogleTvHome extends LinearLayout {
    static final class App {
        final String id,name,category;final Drawable icon,banner;final boolean customArtwork;
        App(String id,String name,String category,Drawable icon,Drawable banner,boolean customArtwork){this.id=id;this.name=name;this.category=category;this.icon=icon;this.banner=banner;this.customArtwork=customArtwork;}
    }
    static final class Group {
        final String id,name;Group(String id,String name){this.id=id;this.name=name;}
    }
    interface Actions {
        void launch(String id);void program(TvHomeFeed.Program program);void menu(String id);void selected(String id);
        void wallpapers();void settings();void choose(String category);
    }
    private final MainActivity host;
    private final SharedPreferences prefs;
    private final View header;
    private final Actions actions;
    private final TextView homeTab,appsTab;
    private final ArrayList<View> nav=new ArrayList<>();
    private final ScrollView scroll;
    private final LinearLayout body;
    private final LinkedHashMap<String,App> apps=new LinkedHashMap<>();
    private final ArrayList<Group> groups=new ArrayList<>();
    private final LinkedHashMap<String,View> focusViews=new LinkedHashMap<>();
    private final ArrayList<ArrayList<View>> rows=new ArrayList<>();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService feedWorker=Executors.newSingleThreadExecutor();
    private final ExecutorService posters=Executors.newFixedThreadPool(2);
    private final android.util.LruCache<String,Bitmap> posterCache=new android.util.LruCache<String,Bitmap>(8*1024*1024){@Override protected int sizeOf(String key,Bitmap bitmap){return bitmap.getByteCount();}};
    private final HashSet<String> queuedPosters=new HashSet<>();
    private final HashMap<String,ArrayList<ImageView>> posterViews=new HashMap<>();
    private TvHomeFeed.Snapshot feed=new TvHomeFeed.Snapshot();
    private CancellationSignal query;
    private int request,generation;
    private boolean library,closed,observing;
    private String category="",focusedKey;
    private final Runnable refreshTask=()->refresh();
    private final ContentObserver observer=new ContentObserver(handler){@Override public void onChange(boolean self){handler.removeCallbacks(refreshTask);handler.postDelayed(refreshTask,600);}};
    private static final int TEXT=0xfff1f3f8,MUTED=0xffb0b7ca;

    GoogleTvHome(MainActivity host,SharedPreferences prefs,View header,Actions actions){
        super(host);this.host=host;this.prefs=prefs;this.header=header;this.actions=actions;
        setOrientation(VERTICAL);setClipChildren(false);setClipToPadding(false);
        LinearLayout navigation=new LinearLayout(host);navigation.setGravity(Gravity.CENTER_VERTICAL);navigation.setPadding(dp(34),dp(3),dp(34),dp(3));navigation.setClipChildren(false);addView(navigation,new LayoutParams(-1,dp(56)));
        LinearLayout tabs=new LinearLayout(host);tabs.setPadding(dp(4),dp(4),dp(4),dp(4));tabs.setBackground(shape(0x503c435c,40,0));
        homeTab=tab("Home",()->switchPage(false,true));appsTab=tab("Apps",()->switchPage(true,true));tabs.addView(homeTab,new LayoutParams(dp(104),dp(42)));tabs.addView(appsTab,new LayoutParams(dp(104),dp(42)));navigation.addView(tabs);
        TextView wallpapers=tab("▧  Wallpapers",actions::wallpapers);LayoutParams utility=new LayoutParams(dp(146),dp(42));utility.leftMargin=dp(16);navigation.addView(wallpapers,utility);
        TextView settings=tab("⚙  Settings",actions::settings);navigation.addView(settings,new LayoutParams(dp(126),dp(42)));
        View space=new View(host);navigation.addView(space,new LayoutParams(0,1,1));
        TextView hint=label("HOME · APPS · YOUR WAY",10,MUTED,false);hint.setLetterSpacing(.12f);navigation.addView(hint);
        nav.add(homeTab);nav.add(appsTab);nav.add(wallpapers);nav.add(settings);
        for(int i=0;i<nav.size();i++){View v=nav.get(i);v.setNextFocusUpId(header.getId());v.setNextFocusLeftId(nav.get(Math.max(0,i-1)).getId());v.setNextFocusRightId(nav.get(Math.min(nav.size()-1,i+1)).getId());}
        scroll=new ScrollView(host);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setFocusable(false);scroll.setClipToPadding(false);scroll.setOverScrollMode(OVER_SCROLL_NEVER);
        body=new LinearLayout(host);body.setOrientation(VERTICAL);body.setPadding(dp(34),0,dp(34),dp(28));body.setClipChildren(false);body.setClipToPadding(false);scroll.addView(body);addView(scroll,new LayoutParams(-1,0,1));paintTabs();
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String title,int size,int colour,boolean bold){TextView v=StudioStyle.label(host,title,size,colour,bold);v.setShadowLayer(dp(2),0,dp(1),0x80000000);return v;}
    private GradientDrawable shape(int fill,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private TextView tab(String title,Runnable action){
        TextView v=label(title,15,TEXT,true);v.setGravity(Gravity.CENTER);v.setShadowLayer(0,0,0,0);focusable(v);
        v.setOnClickListener(w->action.run());v.setOnFocusChangeListener((w,focused)->{if(focused){focusedKey=null;actions.selected(null);scroll.smoothScrollTo(0,0);header.setNextFocusDownId(w.getId());}paintTabs();});return v;
    }
    private void focusable(View v){v.setId(View.generateViewId());v.setFocusable(true);v.setFocusableInTouchMode(true);if(Build.VERSION.SDK_INT>=26)v.setDefaultFocusHighlightEnabled(false);}
    private void paintTabs(){
        for(View item:nav){boolean active=item==(library?appsTab:homeTab),focus=item.hasFocus();item.setBackground(shape(focus?0xffe5e8f6:active?0x90606a85:0x00232b43,30,0));((TextView)item).setTextColor(focus?0xff172137:TEXT);}
    }
    void bind(List<App> items,List<Group> categories){
        apps.clear();for(App app:items)apps.put(app.id,app);groups.clear();groups.addAll(categories);
        if(!category.isEmpty()&&groups.stream().noneMatch(g->g.id.equals(category)))category="";
        render(true);refresh();
    }
    void refresh(){
        if(closed||apps.isEmpty())return;
        final int ticket=++request;if(query!=null)query.cancel();final CancellationSignal signal=new CancellationSignal();query=signal;
        Set<String> visible=new HashSet<>(apps.keySet());
        feedWorker.execute(()->{TvHomeFeed.Snapshot result=TvHomeFeed.read(host,visible,signal);handler.post(()->{
            if(closed||ticket!=request||signal.isCanceled())return;
            if(!feed.signature().equals(result.signature())){feed=result;if(!library)render(true);}
        });});
    }
    private void switchPage(boolean value,boolean focusTab){
        library=value;focusedKey=null;render(false);scroll.scrollTo(0,0);paintTabs();
        if(focusTab)(library?appsTab:homeTab).requestFocusFromTouch();
    }
    void home(){switchPage(false,true);}
    void focusNavigation(){(library?appsTab:homeTab).requestFocusFromTouch();}
    void restoreApp(String id){View remembered=focusViews.get(focusedKey);if(remembered!=null)remembered.requestFocusFromTouch();else focusApp(id);}
    void focusApp(String id){App app=apps.get(id);if(app==null){focusNavigation();return;}library=true;category=app.category;render(false);paintTabs();View v=focusViews.get("app:"+id);if(v!=null)v.post(()->v.requestFocusFromTouch());}
    boolean back(){if(library||scroll.getScrollY()>0||!homeTab.hasFocus()){home();return true;}return true;}
    private void render(boolean restore){
        String remembered=restore?focusedKey:null;int oldScroll=restore?scroll.getScrollY():0;
        generation++;posterViews.clear();body.removeAllViews();focusViews.clear();rows.clear();
        setBackground(library?new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xc00b1020,0xa00b1020,0x600b1020}):null);
        if(library)renderLibrary();else renderHome();linkRows();host.bindSettingsSounds(this);
        if(restore){View target=focusViews.get(remembered);if(target!=null)target.requestFocus();scroll.post(()->scroll.scrollTo(0,oldScroll));}
    }
    private void heading(String title,String detail){
        LinearLayout line=new LinearLayout(host);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(4),dp(16),dp(4),dp(13));
        TextView name=label(title,18,TEXT,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);line.addView(name,new LayoutParams(0,-2,1));
        if(detail!=null&&!detail.isEmpty()){TextView note=label(detail,10,MUTED,false);line.addView(note);}body.addView(line,new LayoutParams(-1,-2));
    }
    private LinearLayout rail(ArrayList<View> nodes){
        HorizontalScrollView rail=new HorizontalScrollView(host);rail.setFocusable(false);rail.setHorizontalScrollBarEnabled(false);rail.setClipToPadding(false);rail.setOverScrollMode(OVER_SCROLL_NEVER);rail.setPadding(dp(5),dp(7),dp(5),dp(9));
        LinearLayout line=new LinearLayout(host);line.setGravity(Gravity.CENTER_VERTICAL);line.setClipChildren(false);line.setClipToPadding(false);rail.addView(line);body.addView(rail,new LayoutParams(-1,-2));rows.add(nodes);return line;
    }
    private void renderHome(){
        // Reserve a quiet region for the static wallpaper and its owner's logo.
        int height=Math.round(getResources().getDisplayMetrics().heightPixels/getResources().getDisplayMetrics().density);
        View panorama=new View(host);body.addView(panorama,new LayoutParams(-1,dp(Math.max(54,Math.min(160,height*.40f-138)))));
        if(!feed.channels.isEmpty())programRow(feed.channels.get(0).title,feed.channels.get(0).programs);
        else{
            heading("Featured apps","OPEN AN APP");ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);
            // Banner-capable TV apps lead the fallback; every card is a real installed app.
            ArrayList<App> featured=new ArrayList<>(apps.values());featured.sort((a,b)->Boolean.compare(b.banner!=null,a.banner!=null));
            for(App app:featured){if(row.size()==10)break;addWideApp(line,row,app,"featured:");}
        }
        heading("Your apps","HOLD OK FOR OPTIONS");ArrayList<View> appRow=new ArrayList<>();LinearLayout line=rail(appRow);for(App app:apps.values())addCircle(line,appRow,app,"home:");
        if(!feed.continuing.isEmpty())programRow("Continue watching",feed.continuing);
        else{
            ArrayList<App> recent=new ArrayList<>();try{org.json.JSONArray saved=new org.json.JSONArray(prefs.getString("recent_apps","[]"));for(int i=0;i<saved.length();i++){App app=apps.get(saved.getString(i));if(app!=null&&!recent.contains(app))recent.add(app);}}catch(org.json.JSONException ignored){}
            if(!recent.isEmpty()){heading("Recently opened",null);ArrayList<View> recentRow=new ArrayList<>();LinearLayout recentLine=rail(recentRow);for(App app:recent)addWideApp(recentLine,recentRow,app,"recent:");}
        }
        for(int i=1;i<feed.channels.size();i++)programRow(feed.channels.get(i).title,feed.channels.get(i).programs);
        if(apps.isEmpty())empty("Add your favourite apps",()->actions.choose("apps"));
    }
    private void renderLibrary(){
        heading("Your apps",apps.size()+" APPS");ArrayList<View> filters=new ArrayList<>();LinearLayout line=rail(filters);
        filter(line,filters,"All apps","",category.isEmpty());for(Group g:groups)filter(line,filters,g.name,g.id,g.id.equals(category));
        ArrayList<App> visible=new ArrayList<>();for(App app:apps.values())if(category.isEmpty()||category.equals(app.category))visible.add(app);
        int available=getResources().getDisplayMetrics().widthPixels-dp(90);int density=prefs.getInt("app_density",0);int columns=density>=1&&density<=4?density+3:Math.max(4,Math.min(9,available/dp(130)));columns=Math.min(columns,Math.max(3,available/dp(112)));
        LinearLayout gridRow=null;ArrayList<View> nodes=null;
        for(int i=0;i<visible.size();i++){
            if(i%columns==0){gridRow=new LinearLayout(host);gridRow.setClipChildren(false);gridRow.setClipToPadding(false);body.addView(gridRow,new LayoutParams(-1,-2));nodes=new ArrayList<>();rows.add(nodes);}
            View v=circle(visible.get(i),"app:");LayoutParams size=new LayoutParams(available/columns,-2);size.bottomMargin=dp(16);gridRow.addView(v,size);nodes.add(v);
        }
        if(visible.isEmpty())empty("Choose apps for this category",()->actions.choose(category.isEmpty()?"apps":category));
    }
    private void filter(LinearLayout line,ArrayList<View> row,String title,String id,boolean selected){
        TextView chip=label(title,13,TEXT,selected);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(20),dp(11),dp(20),dp(11));focusable(chip);String key="category:"+id;focusViews.put(key,chip);
        chip.setBackground(shape(selected?0x80596381:0x40303950,24,0));
        chip.setOnFocusChangeListener((v,focus)->{chip.setBackground(shape(focus?0xffe5e8f6:selected?0x80596381:0x40303950,24,0));chip.setTextColor(focus?0xff172137:TEXT);if(focus){focusedKey=key;actions.selected(null);}});
        chip.setOnClickListener(v->{category=id;render(false);View next=focusViews.get(key);if(next!=null)next.requestFocusFromTouch();});LayoutParams size=new LayoutParams(-2,dp(42));size.rightMargin=dp(10);line.addView(chip,size);row.add(chip);
    }
    private void empty(String title,Runnable action){TextView v=label(title,16,TEXT,true);v.setPadding(dp(24),dp(20),dp(24),dp(20));focusable(v);v.setBackground(shape(0x70464b65,18,0));v.setOnFocusChangeListener((w,f)->v.setBackground(shape(f?0xb05a6685:0x70464b65,18,f?TEXT:0)));v.setOnClickListener(w->action.run());body.addView(v,new LayoutParams(-1,-2));ArrayList<View> row=new ArrayList<>();row.add(v);rows.add(row);}
    private void addCircle(LinearLayout line,ArrayList<View> row,App app,String prefix){View v=circle(app,prefix);LayoutParams size=new LayoutParams(dp(125),-2);size.rightMargin=dp(16);line.addView(v,size);row.add(v);}
    private View circle(App app,String prefix){
        LinearLayout tile=new LinearLayout(host);tile.setOrientation(VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(6),dp(5),dp(5));
        int[] sizes={70,86,98};int size=sizes[Math.max(0,Math.min(2,prefs.getInt("icon_size",1)))];
        FrameLayout disc=new FrameLayout(host);int fill=HomeTransparency.boxes(prefs)?HomeTransparency.fill(prefs,0xff353d58,true):0x28333c57;disc.setBackground(shape(fill,100,0));disc.setClipToOutline(true);
        ImageView icon=new ImageView(host);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);icon.setImageDrawable(copy(app.icon));int pad=app.customArtwork?dp(10):0;icon.setPadding(pad,pad,pad,pad);disc.addView(icon,new FrameLayout.LayoutParams(-1,-1));tile.addView(disc,new LayoutParams(dp(size),dp(size)));
        if(prefs.getBoolean("show_app_names",true)){TextView name=label(app.name,12,TEXT,false);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setMinLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(0,dp(10),0,0);tile.addView(name,new LayoutParams(-1,-2));}
        bindApp(tile,app,prefix+app.id,focused->{disc.setBackground(shape(fill,100,focused?TEXT:0));StudioStyle.focusMotion(disc,focused,1.09f,0);});return tile;
    }
    private Drawable copy(Drawable drawable){if(drawable==null)return null;Drawable.ConstantState state=drawable.getConstantState();return state==null?drawable:state.newDrawable(getResources()).mutate();}
    private FrameLayout card(){FrameLayout card=new FrameLayout(host);card.setBackground(shape(0xff273047,16,0));card.setClipToOutline(true);return card;}
    private int cardWidth(){float width=getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density;return Math.round(Math.max(188,Math.min(266,(width-100)/4.1f)));}
    private void addWideApp(LinearLayout line,ArrayList<View> row,App app,String prefix){
        FrameLayout card=card();int hash=app.id.hashCode();int[] palette={0xff273e5c,0xff3a304e,0xff234343,0xff433545,0xff283653};int colour=palette[Math.floorMod(hash,palette.length)];card.setBackground(shape(colour,16,0));
        ImageView art=new ImageView(host);art.setScaleType(app.banner==null?ImageView.ScaleType.FIT_CENTER:ImageView.ScaleType.CENTER_CROP);art.setImageDrawable(copy(app.banner==null?app.icon:app.banner));if(app.banner==null)art.setPadding(dp(40),dp(16),dp(40),dp(36));card.addView(art,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(host);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x0009101d,0x0009101d,0xe809101d}));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView title=label(app.name,14,TEXT,true);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setPadding(dp(15),dp(10),dp(15),dp(11));card.addView(title,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        bindApp(card,app,prefix+app.id,focused->{card.setForeground(shape(0x00000000,16,focused?TEXT:0));StudioStyle.focusMotion(card,focused,1.035f,0);});addCard(line,row,card);
    }
    private void addCard(LinearLayout line,ArrayList<View> row,View card){LayoutParams size=new LayoutParams(dp(cardWidth()),dp(Math.round(cardWidth()*9f/16)));size.rightMargin=dp(20);line.addView(card,size);row.add(card);}
    private void bindApp(View v,App app,String key,Consumer<Boolean> paint){
        focusable(v);v.setContentDescription(app.name);focusViews.put(key,v);v.setOnClickListener(w->actions.launch(app.id));v.setOnLongClickListener(w->{actions.menu(app.id);return true;});
        v.setOnFocusChangeListener((w,focused)->{paint.accept(focused);if(focused){focusedKey=key;actions.selected(app.id);}});
    }
    private void programRow(String title,List<TvHomeFeed.Program> programs){
        if(programs.isEmpty())return;heading(title==null||title.isEmpty()?"From your apps":title,null);ArrayList<View> row=new ArrayList<>();LinearLayout line=rail(row);
        for(TvHomeFeed.Program program:programs){
            App app=apps.get(program.owner);if(app==null)continue;FrameLayout card=card();ImageView image=new ImageView(host);image.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(image,new FrameLayout.LayoutParams(-1,-1));
            ImageView fallback=new ImageView(host);fallback.setImageDrawable(copy(app.icon));fallback.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams badge=new FrameLayout.LayoutParams(dp(32),dp(32),Gravity.TOP|Gravity.RIGHT);badge.setMargins(0,dp(10),dp(10),0);card.addView(fallback,badge);
            loadPoster(program.poster,image);
            View shade=new View(host);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0x00000000,0xec070c17}));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));
            TextView name=label(program.title,13,TEXT,true);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(dp(12),dp(5),dp(12),dp(12));card.addView(name,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
            if(program.duration>0&&program.position>0){ProgressBar progress=new ProgressBar(host,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgress((int)Math.min(1000,program.position*1000d/program.duration));progress.setProgressTintList(android.content.res.ColorStateList.valueOf(StudioStyle.BLUE));FrameLayout.LayoutParams size=new FrameLayout.LayoutParams(-1,dp(3),Gravity.BOTTOM);card.addView(progress,size);}
            focusable(card);card.setContentDescription(program.title+" · "+app.name);focusViews.put(program.key,card);card.setOnClickListener(v->actions.program(program));card.setOnLongClickListener(v->{actions.menu(app.id);return true;});card.setOnFocusChangeListener((v,focus)->{card.setForeground(shape(0,16,focus?TEXT:0));StudioStyle.focusMotion(card,focus,1.035f,0);if(focus){focusedKey=program.key;actions.selected(app.id);}});addCard(line,row,card);
        }
    }
    private void linkRows(){
        rows.removeIf(row->row.isEmpty());
        for(int r=0;r<rows.size();r++){ArrayList<View> row=rows.get(r);for(int c=0;c<row.size();c++){
            View v=row.get(c);v.setNextFocusLeftId(row.get(Math.max(0,c-1)).getId());v.setNextFocusRightId(row.get(Math.min(row.size()-1,c+1)).getId());
            v.setNextFocusUpId(r==0?(library?appsTab:homeTab).getId():rows.get(r-1).get(Math.min(c,rows.get(r-1).size()-1)).getId());
            v.setNextFocusDownId(r+1<rows.size()?rows.get(r+1).get(Math.min(c,rows.get(r+1).size()-1)).getId():v.getId());
        }}
        // Category chips are filters, rather than columns aligned with the grid.
        if(library&&rows.size()>1){
            View selected=focusViews.get("category:"+category);
            for(View filter:rows.get(0))filter.setNextFocusDownId(rows.get(1).get(0).getId());
            if(selected!=null)for(View app:rows.get(1))app.setNextFocusUpId(selected.getId());
        }
        for(View v:nav)v.setNextFocusDownId(rows.isEmpty()?v.getId():rows.get(0).get(0).getId());
    }
    private void loadPoster(String uri,ImageView target){
        if(uri==null||uri.isEmpty()||closed)return;Bitmap cached=posterCache.get(uri);if(cached!=null){target.setImageBitmap(cached);return;}
        posterViews.computeIfAbsent(uri,k->new ArrayList<>()).add(target);if(!queuedPosters.add(uri))return;
        posters.execute(()->{Bitmap bitmap=null;try{byte[] bytes=posterBytes(uri);if(bytes!=null){BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);if(options.outWidth>0&&options.outHeight>0){options.inSampleSize=1;while(options.outWidth/options.inSampleSize>640||options.outHeight/options.inSampleSize>400)options.inSampleSize*=2;options.inJustDecodeBounds=false;bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);}}}catch(Exception|OutOfMemoryError ignored){}
            final Bitmap decoded=bitmap;handler.post(()->{queuedPosters.remove(uri);if(closed)return;if(decoded!=null){posterCache.put(uri,decoded);ArrayList<ImageView> targets=posterViews.remove(uri);if(targets!=null)for(ImageView v:targets)v.setImageBitmap(decoded);}});
        });
    }
    private byte[] posterBytes(String value)throws IOException{
        Uri uri=Uri.parse(value);String scheme=uri.getScheme();InputStream input;HttpURLConnection connection=null;
        if("https".equalsIgnoreCase(scheme)){
            URL url=new URL(value);connection=(HttpURLConnection)url.openConnection();connection.setConnectTimeout(4500);connection.setReadTimeout(4500);connection.setInstanceFollowRedirects(false);int status=connection.getResponseCode();if(status!=200){connection.disconnect();return null;}input=connection.getInputStream();
        }else if("content".equalsIgnoreCase(scheme)||"android.resource".equalsIgnoreCase(scheme))input=host.getContentResolver().openInputStream(uri);else return null;
        try(InputStream stream=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(stream==null)return null;byte[] buffer=new byte[8192];int n;while((n=stream.read(buffer))!=-1){if(Thread.currentThread().isInterrupted()||out.size()+n>3*1024*1024)return null;out.write(buffer,0,n);}return out.toByteArray();
        }finally{if(connection!=null)connection.disconnect();}
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();try{host.getContentResolver().registerContentObserver(Uri.parse("content://android.media.tv"),true,observer);observing=true;}catch(RuntimeException ignored){}}
    void close(){if(closed)return;closed=true;request++;if(query!=null)query.cancel();handler.removeCallbacksAndMessages(null);if(observing){host.getContentResolver().unregisterContentObserver(observer);observing=false;}feedWorker.shutdownNow();posters.shutdownNow();posterCache.evictAll();posterViews.clear();}
    @Override protected void onDetachedFromWindow(){close();super.onDetachedFromWindow();}
}
