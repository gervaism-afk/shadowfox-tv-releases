package com.shadowfox.tvlauncher;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.media.tv.TvContract;
import java.util.*;

/** Reads the system TV provider. Never publishes programs or reads preview videos. */
final class TvHomeFeed {
    static final class Program {
        final String key,owner,title,poster,intent;
        final long position,duration;
        Program(String key,String owner,String title,String poster,String intent,long position,long duration){
            this.key=key;this.owner=owner;this.title=title;this.poster=poster;this.intent=intent;this.position=position;this.duration=duration;
        }
    }
    static final class Channel {
        final String title;final List<Program> programs;
        Channel(String title,List<Program> programs){this.title=title;this.programs=programs;}
    }
    static final class Snapshot {
        final List<Channel> channels=new ArrayList<>();
        final List<Program> continuing=new ArrayList<>();
        String signature(){StringBuilder s=new StringBuilder();for(Channel c:channels){s.append(c.title);for(Program p:c.programs)append(s,p);}for(Program p:continuing)append(s,p);return s.toString();}
        private void append(StringBuilder s,Program p){s.append('|').append(p.key).append('|').append(p.title).append('|').append(p.poster).append('|').append(p.intent).append('|').append(p.position).append('|').append(p.duration);}
    }
    static Snapshot read(Context host,Set<String> visible,CancellationSignal signal){
        Snapshot result=new Snapshot();if(Build.VERSION.SDK_INT<26)return result;
        // Other launchers/devices may restrict cross-app rows. Empty and denied providers
        // both leave the real installed-app shortcuts usable, including when offline.
        try(Cursor channels=host.getContentResolver().query(TvContract.Channels.CONTENT_URI,
                new String[]{"_id","package_name","display_name","browsable","type"},null,null,null,signal)){
            while(channels!=null&&channels.moveToNext()&&result.channels.size()<8){
                String owner=channels.getString(1);
                if(!visible.contains(owner)||channels.getInt(3)!=1||!"TYPE_PREVIEW".equals(channels.getString(4)))continue;
                Uri uri=TvContract.buildPreviewProgramsUriForChannel(channels.getLong(0));
                List<Program> programs=programs(host,uri,owner,visible,signal,false);
                if(!programs.isEmpty())result.channels.add(new Channel(channels.getString(2),programs));
            }
        }catch(RuntimeException ignored){/* Provider missing, restricted or cancelled. */}
        try{result.continuing.addAll(programs(host,TvContract.WatchNextPrograms.CONTENT_URI,null,visible,signal,true));}
        catch(RuntimeException ignored){/* Watch Next is optional. */}
        return result;
    }
    private static List<Program> programs(Context host,Uri uri,String channelOwner,Set<String> visible,CancellationSignal signal,boolean watch){
        ArrayList<Program> out=new ArrayList<>();
        String[] columns=watch?new String[]{"_id","package_name","title","poster_art_uri","intent_uri","browsable","last_playback_position_millis","duration_millis","watch_next_type"}
                :new String[]{"_id","package_name","title","poster_art_uri","intent_uri","browsable"};
        try(Cursor rows=host.getContentResolver().query(uri,columns,null,null,watch?"last_engagement_time_utc_millis DESC":null,signal)){
            while(rows!=null&&rows.moveToNext()&&out.size()<12){
                String owner=rows.getString(1),title=rows.getString(2),intent=rows.getString(4);
                if(!visible.contains(owner)||(channelOwner!=null&&!channelOwner.equals(owner))||rows.getInt(5)!=1||title==null||title.trim().isEmpty()||intent==null||intent.isEmpty())continue;
                // Only the CONTINUE type represents unfinished viewing, rather than a watchlist.
                if(watch&&rows.getInt(8)!=TvContract.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)continue;
                out.add(new Program((watch?"watch:":"program:")+rows.getLong(0),owner,title,rows.getString(3),intent,watch?rows.getLong(6):0,watch?rows.getLong(7):0));
            }
        }return out;
    }
    static Intent launchIntent(Context host,Program program){
        try{
            Intent source=Intent.parseUri(program.intent,Intent.URI_INTENT_SCHEME);
            Uri data=source.getData();String scheme=data==null?null:data.getScheme();
            if(scheme!=null&&(scheme.equalsIgnoreCase("file")||scheme.equalsIgnoreCase("javascript")||scheme.equalsIgnoreCase("data")))return null;
            // Keep provider deep-link extras, but force the program owner's installed app.
            source.setSelector(null);source.setClipData(null);source.setPackage(program.owner);
            if(source.getComponent()!=null&&!program.owner.equals(source.getComponent().getPackageName()))return null;
            source.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            android.content.pm.ResolveInfo resolved=host.getPackageManager().resolveActivity(source,0);
            if(resolved==null||!program.owner.equals(resolved.activityInfo.packageName)||!resolved.activityInfo.exported)return null;
            return source;
        }catch(Exception ignored){return null;}
    }
}
